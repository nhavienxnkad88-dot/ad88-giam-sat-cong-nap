// AD88 Giám Sát Cổng Nạp — bảng điều khiển (dữ liệu thật từ BO)
(function () {
"use strict";
const $ = (id) => document.getElementById(id);
const nk = (s) => String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[đĐ]/g, "d").toLowerCase().replace(/[^a-z0-9]/g, "");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const pad = (n) => String(n).padStart(2, "0");
const dayKey = (d) => d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
const dayStartOf = (key) => { const [y, m, d] = key.split("-").map(Number); return Math.floor(new Date(y, m - 1, d).getTime() / 1000); };
const nowU = () => Math.floor(Date.now() / 1000);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

// ===== Cài đặt =====
const SET = { usdt: true, rRed: 20, rWarn: 50, rOk: 80, minN: 5, stale: CFG.STALE / 60, sound: true };
async function loadSettings() {
  const s = await chrome.storage.local.get(["settings", "boDomain"]);
  Object.assign(SET, s.settings || {});
  SET.domain = s.boDomain || CFG.BO_DOMAIN;
}
const STALE = () => SET.stale * 60, ABANDON = CFG.ABANDON;

// ===== Dữ liệu =====
let DAY = dayKey(new Date()), DAY0 = dayStartOf(DAY);
const ORD = new Map();          // đơn hôm nay
let orders = [];                // đơn dùng để thống kê cổng (đã bỏ lệnh ảo)
let ALL = [];                   // tất cả đơn (kể cả lệnh ảo)
let FAKESET = new Set();        // tài khoản lệnh ảo (đã đánh dấu + rất nghi ngờ)
let HOUSES = [], HIDX = {};     // nhà thứ 3
let GATES = [], GIDX = {};      // cổng nạp
let COMBO = {};                 // "h_g" -> {fee, chs:Set}
let BAL = {};                   // nk(merchName) -> bản ghi listV2
let balAt = 0;
const GATE_SHORT = { "quetmanganhang": "QR ngân hàng", "napnhanh": "Chuyển khoản", "momopay": "Momo", "zalopay": "Zalo Pay", "thecao": "Thẻ cào" };
const GATE_ORDER = ["quetmanganhang", "napnhanh", "momopay", "zalopay", "thecao"];
// Xem ngày cũ: VIEW = "YYYY-MM-DD" (null = hôm nay, trực tiếp)
let VIEW = null, VIEW0 = 0; const VORD = new Map();
const V0 = () => (VIEW ? VIEW0 : DAY0);
const NOWS = () => (VIEW ? 86399 : nowU() - DAY0);
// "U2Pay2 - USDT", "RCPay(USDT)" ghép chung với "U2Pay2", "RCPay" trong danh sách số dư
const hkey = (name) => { const k = nk(name); const b = k.replace(/usdt$/, ""); return b || k || "khac"; };

const SRC = () => (VIEW ? VORD : ORD);
function rebuild() {
  const hs = {}, gs = {};
  for (const o of SRC().values()) {
    const hk = hkey(o.merch), gk = nk(o.gate) || "khac";
    (hs[hk] ??= { k: hk, n: o.merch, cnt: 0, cur: o.cur }).cnt++;
    (gs[gk] ??= { k: gk, raw: o.gate, n: GATE_SHORT[gk] || o.gate, cnt: 0 }).cnt++;
  }
  // nhà có trong listV2 nhưng hôm nay chưa có đơn vẫn hiện số dư
  for (const k in BAL) if (!hs[k]) { const r = BAL[k]; hs[k] = { k, n: r.merchName, cnt: 0, cur: r.payCurrency || "VND" }; }
  HOUSES = Object.values(hs).sort((a, b) => b.cnt - a.cnt).map((h) => {
    const r = BAL[h.k];
    return { k: h.k, n: h.n, mid: r ? r.id : null, berr: r ? BALERR[r.id] : null, cnt: h.cnt, cur: r ? r.payCurrency || "VND" : h.cur, bal: r && r.balance != null ? Number(r.balance) : null, balAt: r ? r.balAt : 0, on: r ? r.status === 1 : null, mid: r ? r.id : null };
  });
  HIDX = {}; HOUSES.forEach((h, i) => (HIDX[h.k] = i));
  GATES = Object.values(gs).sort((a, b) => {
    const ia = GATE_ORDER.indexOf(a.k), ib = GATE_ORDER.indexOf(b.k);
    return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib) || b.cnt - a.cnt;
  });
  GIDX = {}; GATES.forEach((g, i) => (GIDX[g.k] = i));
  COMBO = {};
  orders = [];
  const sorted = [...SRC().values()].sort((a, b) => a.ts - b.ts);
  for (const o of sorted) {
    o.h = HIDX[hkey(o.merch)]; o.g = GIDX[nk(o.gate) || "khac"]; o.t = o.ts - V0();
    const c = (COMBO[o.h + "_" + o.g] ??= { fee: o.fee, chs: new Set() });
    c.fee = o.fee; if (o.ch) c.chs.add(o.ch);
    orders.push(o);
  }
  ALL = orders;
  try { FAKESET = new Set(fakeRows(ALL).filter((r) => r.lv === "mark" || r.lv === "high").map((r) => r.acc)); } catch (e) { FAKESET = new Set(); }
  orders = SET.exFake !== false ? ALL.filter((o) => !FAKESET.has(o.acc)) : ALL;
}
const combo = (hi, gi) => COMBO[hi + "_" + gi] || null;
const chText = (c) => (c ? [...c.chs].slice(0, 3).join(", ") + (c.chs.size > 3 ? "…" : "") : "");

// ===== Tính toán =====
function agg(list) {
  const N = NOWS(), S = STALE();
  const a = { n: 0, ok: 0, pend: 0, stale: 0, aband: 0, err: 0, amt: 0, okAmt: 0, fee: 0, spSum: 0, s3: 0, s10: 0, sOver: 0, sps: [] };
  for (const o of list) {
    a.n++; a.amt += o.amt;
    if (o.st === 2) { a.ok++; a.okAmt += o.amt; a.fee += o.amt * o.fee / 100; a.spSum += o.sp; a.sps.push(o.sp); if (o.sp <= 180) a.s3++; else if (o.sp <= 600) a.s10++; else a.sOver++; }
    else if (o.st === 3) a.err++;
    else if (o.st === 4 || o.st === 5) a.aband++;
    else { const age = N - o.t; if (age > ABANDON) a.aband++; else { a.pend++; if (age > S) a.stale++; } }
  }
  a.rate = a.n ? a.ok / a.n * 100 : null;   // tỷ lệ = đơn thành công / tổng đơn nạp
  a.sp = a.ok ? a.spSum / a.ok : 0;
  a.sps.sort((x, y) => x - y); a.p90 = a.sps.length ? a.sps[Math.floor(a.sps.length * 0.9)] : 0; a.med = a.sps.length ? a.sps[Math.floor(a.sps.length / 2)] : 0;
  a.waiting = a.pend + a.aband; return a;
}
const fmt = (n) => Math.round(n).toLocaleString("vi-VN");
const vnd = (k) => fmt(k * 1000);
const pct = (r) => (r == null ? "—" : r.toFixed(1) + "%");
const mmss = (s) => { s = Math.round(s); return Math.floor(s / 60) + "'" + pad(s % 60) + '"'; };
const clock = (t) => [Math.floor(t / 3600), Math.floor(t % 3600 / 60), t % 60].map((v) => pad(Math.floor(v))).join(":");
const rc = (r) => (r == null ? "mut" : r >= SET.rOk ? "ok" : r > SET.rWarn ? "mid" : r >= SET.rRed ? "warn" : "bad");
let day, BASE, byCell, LV, win30;
function derive() {
  day = agg(orders);
  byCell = {}; for (const o of orders) (byCell[o.h + "_" + o.g] ??= []).push(o);
  BASE = {}; for (const k in byCell) BASE[k] = agg(byCell[k]).rate;
  const N = NOWS();
  win30 = {}; for (const o of orders) if (o.t >= N - 1800) (win30[o.h + "_" + o.g] ??= []).push(o);
  LV = {}; for (const k in win30) LV[k] = level(agg(win30[k]), k);
}
// Trạng thái theo tỷ lệ thành công (thành công / tổng đơn):
//  dưới 20% = Cảnh báo (đỏ) · 20%–50% = Theo dõi (vàng) · trên 50% đến dưới 80% = Tạm ổn định · từ 80% = Ổn định
function level(a, key) {
  if (!a || !a.n) return "na";
  const r = a.rate;
  return r < SET.rRed ? "bad" : r <= SET.rWarn ? "warn" : r < SET.rOk ? "mid" : "ok";
}
const PILL = { bad: '<span class="pill badp">Cảnh báo</span>', warn: '<span class="pill warnp">Theo dõi</span>', mid: '<span class="pill midp">Tạm ổn định</span>', ok: '<span class="pill on">Ổn định</span>', na: '<span class="pill" style="background:var(--panel2);color:var(--muted)">Chưa có đơn</span>' };
const RANK = { na: 0, ok: 0, mid: 1, slow: 1, warn: 2, bad: 3 };
// trạng thái hiển thị: lấy mức xấu hơn giữa 30 phút gần nhất và khung thời gian đang xem
const lvBoth = (k, a) => { const x = LV[k] || "ok", y = level(a, k); return RANK[y] > RANK[x] ? y : x; };
const houseLv = (hi) => { let l = "ok"; for (const k in LV) if (k.startsWith(hi + "_")) { if (LV[k] === "bad") return "bad"; if (LV[k] === "warn") l = "warn"; } return l; };
const TF = () => [["1h", "1 giờ", 3600], ["3h", "3 giờ", 10800], ["6h", "6 giờ", 21600], ["day", "00:00 → nay", NOWS()]];
const st = { tab: "home", house: -1, gate: -1, speedH: -1, pendH: -1, pendG: -1, pendMin: 0, ostat: "pend", page: 0, q: "", feeH: -1, feeMon: null, tf: { house: "day", gate: "day", speed: "3h", list: "day", fake: "day", maint: "day" }, maintH: -1 };
// khung giờ tự chọn: st.cust[key] = {a, b} tính bằng giây từ 00:00
st.cust = {};
const hms = (s) => clock(Math.max(0, Math.min(86399, s)));
const parseHms = (v) => { const p = String(v || "").split(":").map(Number); return (p[0] || 0) * 3600 + (p[1] || 0) * 60 + (p[2] || 0); };
const tfRange = (key) => {
  const N = NOWS();
  if (st.tf[key] === "custom") { const c = st.cust[key] || { a: 0, b: N }; return [Math.min(c.a, c.b), Math.max(c.a, c.b)]; }
  const f = TF().find((x) => x[0] === st.tf[key]) || TF()[3]; return [N - f[2], N];
};
const tfSec = (key) => { const [x, y] = tfRange(key); return y - x; };
const inTf = (key) => { const [from, to] = tfRange(key); return (key === "list" || key === "fake" ? ALL : orders).filter((o) => o.t >= from && o.t <= to); };
const tfLabel = (key) => { if (st.tf[key] === "custom") { const [x, y] = tfRange(key); return "Từ " + hms(x) + " đến " + hms(y); } const f = TF().find((x) => x[0] === st.tf[key]); const N = NOWS(); return f[0] === "day" ? "Từ 00:00 đến " + clock(N).slice(0, 5) : f[1] + " gần nhất (" + clock(Math.max(0, N - f[2])).slice(0, 5) + " → " + clock(N).slice(0, 5) + ")"; };
const rateBar = (a) => { const t = Math.max(1, a.n); return `<span class="rate"><span class="${rc(a.rate)}">${pct(a.rate)}</span><span class="track"><span style="width:${a.ok / t * 100}%;background:var(--b1)"></span><span style="width:${a.waiting / t * 100}%;background:var(--b3)"></span><span style="width:${a.err / t * 100}%;background:var(--b5)"></span></span></span>`; };
const balTxt = (h) => (h.bal == null ? (h.on == null ? "—" : h.berr ? "lỗi: " + h.berr.slice(0, 40) : "đang lấy…") : fmt(h.bal) + (h.cur && h.cur !== "VND" ? " " + h.cur : " ₫"));
const statusPill = (h) => (h.on == null ? '<span class="pill" style="background:var(--panel2);color:var(--muted)">Chưa ghép số dư</span>' : h.on ? '<span class="pill on">Bật</span>' : '<span class="pill off">Rút tắt</span>') + (h.bal != null && h.cur === "VND" && h.bal < 20e6 ? ' <span class="pill low">Số dư thấp</span>' : "");
const empty = (t) => `<div class="empty">${t}</div>`;

// ===== TỔNG QUAN =====
function renderHome() {
  const HN = Math.floor(NOWS() / 3600) + 1;
  const vndH = HOUSES.filter((h) => h.cur === "VND" && h.bal != null);
  const kp = [[VIEW ? "Tổng đơn ngày " + VIEW.slice(8) + "/" + VIEW.slice(5, 7) : "Tổng đơn hôm nay", fmt(day.n), "Tổng tiền " + vnd(day.amt) + " ₫", ""],
    ["Thành công", fmt(day.ok), pct(day.rate) + " tỷ lệ thành công", "ok"],
    ["Đang chờ", fmt(day.pend), "Tạo trong 30 phút gần nhất", "warn"],
    ["Chờ quá " + SET.stale + " phút", fmt(day.stale), "Tín hiệu cổng có vấn đề", "bad"],
    ["Thất bại", fmt(day.err), (day.n ? day.err / day.n * 100 : 0).toFixed(1) + "% tổng đơn", "bad"],
    ["Tiền đã lên điểm", (day.okAmt / 1e6).toLocaleString("vi-VN", { maximumFractionDigits: 2 }) + " tỷ", vnd(day.okAmt) + " ₫ · phí ~" + (day.fee / 1000).toLocaleString("vi-VN", { maximumFractionDigits: 1 }) + " tr", "ok"],
    ["Thời gian lên điểm", day.ok ? mmss(day.sp) : "—", "Trung bình · " + (day.ok ? (day.s3 / day.ok * 100).toFixed(0) : 0) + "% đơn dưới 3 phút", ""],
    ["Tổng số dư nhà thứ 3", (vndH.reduce((a, h) => a + h.bal, 0) / 1e6).toLocaleString("vi-VN", { maximumFractionDigits: 1 }) + " tr", vndH.length + " nhà VND · cập nhật " + (balAt ? new Date(balAt).toLocaleTimeString("vi-VN").slice(0, 5) : "—"), ""]];
  const KIC = ['<svg viewBox="0 0 24 24"><path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6"/></svg>', '<svg viewBox="0 0 24 24"><path d="M5 12l5 5 9-10"/></svg>', '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><path d="M12 8v4l3 2"/></svg>', '<svg viewBox="0 0 24 24"><path d="M12 7v6M12 17h.01"/></svg>', '<svg viewBox="0 0 24 24"><path d="M7 7l10 10M17 7L7 17"/></svg>', '<svg viewBox="0 0 24 24"><path d="M12 4v16M16 8c0-1.7-1.8-3-4-3s-4 1.3-4 3 1.8 2.6 4 3 4 1.3 4 3-1.8 3-4 3-4-1.3-4-3"/></svg>', '<svg viewBox="0 0 24 24"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l2 2M10 2h4"/></svg>', '<svg viewBox="0 0 24 24"><path d="M3 10l9-6 9 6M5 10v8M9 10v8M15 10v8M19 10v8M3 20h18"/></svg>'];
  const TINT = ["#2e8bff", "#22c97a", "#f2a516", "#ff3b4f", "#b45cff", "#19c7b0", "#3d8bff", "#6b5cff"];
  const N = NOWS(), S = STALE();
  const hr = (f) => { const b = new Array(Math.max(2, HN)).fill(0); for (const o of orders) if (f(o)) b[Math.min(b.length - 1, Math.floor(o.t / 3600))]++; return b; };
  const spH = () => { const s = new Array(Math.max(2, HN)).fill(0), c = new Array(Math.max(2, HN)).fill(0); for (const o of orders) if (o.st === 2) { const i = Math.min(s.length - 1, Math.floor(o.t / 3600)); s[i] += o.sp; c[i]++; } return s.map((v, i) => (c[i] ? v / c[i] : 0)); };
  const SER = [hr(() => 1), hr((o) => o.st === 2), hr((o) => o.st === 1 && N - o.t <= ABANDON), hr((o) => o.st === 1 && N - o.t > S && N - o.t <= ABANDON), hr((o) => o.st === 3), hr((o) => o.st === 2), spH(), hr(() => 1)];
  const wave = (arr, c) => {
    const W = 300, H = 38, mx = Math.max(...arr), mn = Math.min(...arr), r = mx - mn || 1;
    const pts = arr.map((v, i) => [i * W / (arr.length - 1), H - 6 - (v - mn) / r * (H - 14)]);
    let d = `M${pts[0][0]} ${pts[0][1]}`; for (let i = 1; i < pts.length; i++) { const [x0, y0] = pts[i - 1], [x1, y1] = pts[i], cx = (x0 + x1) / 2; d += ` C${cx} ${y0} ${cx} ${y1} ${x1} ${y1}`; }
    const id = "g" + Math.random().toString(36).slice(2, 7);
    return `<svg class="wave" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${c}" stop-opacity=".45"/><stop offset="1" stop-color="${c}" stop-opacity="0"/></linearGradient></defs><path d="${d} L${W} ${H} L0 ${H}Z" fill="url(#${id})"/><path d="${d}" fill="none" stroke="${c}" stroke-width="2" style="filter:drop-shadow(0 0 4px ${c})"/></svg>`;
  };
  const GOH = [{ s: "all" }, { s: "ok" }, { s: "pend" }, { s: "pend", m: 5 }, { s: "err" }, { s: "ok" }, { s: "ok" }, null];
  $("kpis").innerHTML = kp.map((k, i) => `<div class="kpi ${k[3]}${GOH[i] ? " go" : ""}" style="--t:${TINT[i]}"${GOH[i] ? ` data-go-list='${JSON.stringify({ ...GOH[i], tf: "day" })}' title="Bấm để xem danh sách đơn"` : ""}><span class="kic">${KIC[i]}</span><div class="lab">${k[0]}</div><div class="val">${k[1]}</div><div class="sub">${k[2]}</div>${wave(SER[i], TINT[i])}</div>`).join("");
  const al = alerts();
  $("cnt-alert").textContent = al.length;
  $("alerts").innerHTML = al.length ? al.map((x) => `<button class="alert ${x.lv === "fake" ? "slow" : x.lv}" ${x.tab ? `data-go-tab="${x.tab}"` : `data-go-house="${x.hi}"`}><span class="lvl">${x.lv === "bad" ? "ĐỎ" : x.lv === "warn" ? "VÀNG" : x.lv === "fake" ? "ẢO" : "CHẬM"}</span><span class="t">${esc(x.t)}</span><span class="act">${x.act}</span><span class="d">${esc(x.d)}</span></button>`).join("") : empty("Không có cổng nào bất thường trong 30 phút gần nhất.");
  const rows = HOUSES.map((h, hi) => ({ h, hi, a: agg(orders.filter((o) => o.h === hi)) })).sort((x, y) => y.a.n - x.a.n);
  $("hcards").innerHTML = rows.length ? rows.map(({ h, hi, a }) => {
    const lv = houseLv(hi);
    const gt = GATES.map((g, gi) => { if (!combo(hi, gi)) return ""; const c = agg(byCell[hi + "_" + gi] || []); const l = LV[hi + "_" + gi] || "ok"; return `<span class="gtag ${l === "bad" || l === "warn" ? l : ""}">${esc(g.n)} <b>${pct(c.rate)}</b></span>`; }).join("");
    return `<button class="hc ${lv === "ok" ? "" : lv}" data-go-house="${hi}">
      <div class="hc-top"><b>${esc(h.n)}</b>${statusPill(h)}<span class="bal">${balTxt(h)}</span></div>
      <div class="hc-stats"><div><small>Đơn</small><span>${fmt(a.n)}</span></div><div><small>Thành công</small><span class="ok">${fmt(a.ok)}</span></div><div><small>Chờ &gt;${SET.stale}'</small><span class="${a.stale ? "warn" : ""}">${fmt(a.stale)}</span></div><div><small>Thất bại</small><span class="${a.err ? "bad" : ""}">${fmt(a.err)}</span></div></div>
      <div style="display:flex;justify-content:space-between;align-items:center">${rateBar(a)}<span class="mut" style="font-size:11.5px">Lên điểm TB <b class="mono" style="color:var(--fg)">${a.ok ? mmss(a.sp) : "—"}</b></span></div>
      <div class="hc-gates">${gt}</div></button>`;
  }).join("") : empty("Chưa có đơn nào hôm nay.");
}
function alerts() {
  const al = [];
  for (const k in LV) {
    if (LV[k] !== "bad" && LV[k] !== "warn") continue;
    const [hi, gi] = k.split("_").map(Number); const a = agg(win30[k]);
    if (a.n < SET.minN) continue;
    al.push({ k, lv: LV[k], hi, t: `${HOUSES[hi].n} · ${GATES[gi].n}`, d: `30 phút gần nhất: thành công ${a.ok}/${a.n} đơn = ${pct(a.rate)} · đang chờ ${a.pend} (quá ${SET.stale}' : ${a.stale}) · hết hạn/huỷ ${a.aband} · kênh ${chText(combo(hi, gi))}`, act: LV[k] === "bad" ? "Cảnh báo" : "Theo dõi" });
  }
  // đơn "Đặt cọc không thành công" của khách thật trong 30 phút = lỗi cổng (sai cấu hình, bảo trì, đóng cổng)
  for (const k in win30) {
    const errs = win30[k].filter(isMaint); if (!errs.length) continue;
    const lastE = Math.max(...errs.map((o) => o.t));
    if (win30[k].some((o) => o.st === 2 && o.t > lastE)) continue; // đã có khách nạp thành công sau đó = hết bảo trì
    const [hi, gi] = k.split("_").map(Number), why = errs[errs.length - 1].why || "BO không ghi lý do";
    const ex = al.find((x) => x.k === k);
    const d = `${errs.length} đơn "Đặt cọc không thành công" trong 30 phút · lý do BO: ${why}`;
    if (ex) { ex.d = d + " · " + ex.d; ex.lv = "bad"; ex.act = "Lỗi cổng"; }
    else al.push({ k, lv: "bad", hi, t: `${HOUSES[hi].n} · ${GATES[gi].n}`, d, act: "Lỗi cổng" });
  }
  const N = NOWS(), w3 = {}; for (const o of orders) if (o.t >= N - 10800) (w3[o.h + "_" + o.g] ??= []).push(o);
  for (const k in w3) {
    const a = agg(w3[k]);
    if (a.ok >= 15 && a.med > 240 && (LV[k] || "ok") !== "bad" && LV[k] !== "warn") {
      const [hi, gi] = k.split("_").map(Number);
      al.push({ k, lv: "slow", hi, t: `${HOUSES[hi].n} · ${GATES[gi].n}`, d: `Lên điểm chậm 3 giờ gần nhất: trung vị ${mmss(a.med)} · ${a.sOver} đơn trên 10 phút · ${(a.s3 / a.ok * 100).toFixed(0)}% dưới 3 phút`, act: "Lên điểm chậm" });
    }
  }
  // lệnh ảo: báo riêng, không tính vào cổng
  const fr = fakeRows(ALL.filter((o) => o.t >= N - 1800)).filter((r) => r.lv !== "mark");
  if (fr.length) al.push({ k: "fake", lv: "fake", hi: -1, tab: "fake", t: `${fr.length} tài khoản nghi tạo lệnh ảo (30 phút)`, d: fr.slice(0, 6).map((r) => r.acc).join(", ") + (fr.length > 6 ? "…" : "") + " · đã bỏ khỏi thống kê cổng", act: "Chặn khách" });
  const ord = { bad: 0, warn: 1, slow: 2, fake: 3 }; al.sort((x, y) => ord[x.lv] - ord[y.lv]);
  return al;
}

// ===== bộ lọc dùng chung =====
function chips(el, list, cur, onPick, withLv) {
  $(el).innerHTML = `<button class="chip" aria-pressed="${cur === -1}" data-v="-1">Tất cả</button>` + list.map((x, i) => `<button class="chip" aria-pressed="${cur === i}" data-v="${i}">${withLv ? `<i class="${HOUSES[i].on === false ? "off" : houseLv(i)}"></i>` : ""}${esc(x.n)}</button>`).join("");
  $(el).onclick = (e) => { const b = e.target.closest(".chip"); if (b) onPick(+b.dataset.v); };
}
function segs() {
  document.querySelectorAll("[data-tf]").forEach((el) => {
    const key = el.dataset.tf;
    const c = st.cust[key] || { a: Math.max(0, NOWS() - 3600), b: NOWS() };
    el.innerHTML = TF().map((f) => `<button aria-pressed="${st.tf[key] === f[0]}" data-v="${f[0]}">${f[1]}</button>`).join("") +
      `<button aria-pressed="${st.tf[key] === "custom"}" data-v="custom" title="Tự chọn giờ:phút:giây">Tự chọn</button>` +
      "";
    el.onclick = (e) => { const b = e.target.closest("button"); if (!b) return;
      if (b.dataset.v === "custom") { const r = document.querySelector(`.qrow[data-k="${key}"]`); if (r) return qFind(r); }
      st.tf[key] = b.dataset.v; st.page = 0; segs(); render(); };
  });
  syncRows();
}
// hàng Ngày + từ giờ:phút:giây đến giờ:phút:giây + nút Tìm trong từng mục
function syncRows() {
  document.querySelectorAll(".qrow").forEach((r) => {
    const [a, b] = tfRange(r.dataset.k);
    r.querySelector(".qa").value = hms(a); r.querySelector(".qb").value = hms(b);
  });
}
async function qFind(r) {
  const k = r.dataset.k, d = r.querySelector(".dayPick").value || DAY;
  const a = parseHms(normHms(r.querySelector(".qa").value)), b = parseHms(normHms(r.querySelector(".qb").value));
  if (d !== (VIEW || DAY)) await setView(d);
  st.cust[k] = { a: Math.min(a, b), b: Math.max(a, b) }; st.tf[k] = "custom"; st.page = 0;
  segs(); render();
}
// ô giờ 24h (00:00:00 → 23:59:59): gõ số là tự thêm dấu ":"; mũi tên lên/xuống để tăng giảm
const fmtHmsIn = (v) => { const d = String(v).replace(/\D/g, "").slice(0, 6); return d.replace(/^(\d{2})(\d)/, "$1:$2").replace(/^(\d{2}:\d{2})(\d)/, "$1:$2"); };
const normHms = (v) => { const p = String(v || "").split(":").map((x) => parseInt(x, 10) || 0); return hms(Math.min(23, p[0] || 0) * 3600 + Math.min(59, p[1] || 0) * 60 + Math.min(59, p[2] || 0)); };
document.querySelectorAll(".qrow .qa, .qrow .qb").forEach((i) => {
  i.addEventListener("input", () => { const c = i.selectionStart === i.value.length; i.value = fmtHmsIn(i.value); if (c) i.selectionStart = i.selectionEnd = i.value.length; });
  i.addEventListener("blur", () => { i.value = normHms(i.value); });
  i.addEventListener("focus", () => i.select());
  i.addEventListener("keydown", (e) => {
    if (e.key !== "ArrowUp" && e.key !== "ArrowDown") return; e.preventDefault();
    const pos = i.selectionStart ?? 0, unit = pos <= 2 ? 3600 : pos <= 5 ? 60 : 1, t = parseHms(normHms(i.value)) + (e.key === "ArrowUp" ? unit : -unit);
    i.value = hms(Math.max(0, Math.min(86399, t))); i.setSelectionRange(pos <= 2 ? 0 : pos <= 5 ? 3 : 6, pos <= 2 ? 2 : pos <= 5 ? 5 : 8);
  });
});
document.querySelectorAll(".qrow").forEach((r) => {
  r.querySelector(".qgo").onclick = () => qFind(r);
  r.querySelectorAll("input").forEach((i) => i.addEventListener("keydown", (e) => { if (e.key === "Enter") qFind(r); }));
});

// ===== NHÀ THỨ 3 =====
function gateBlock(hi, gi, list) {
  const g = GATES[gi], c0 = combo(hi, gi), a = agg(list), l = lvBoth(hi + "_" + gi, a);
  return `<div class="gate ${l === "bad" || l === "warn" ? l : ""}"><div class="gate-h"><b>${esc(g.n)}</b>${boTag(hi, gi)}<small>${esc(chText(c0))}</small><span class="fee">phí ${c0 ? c0.fee : "—"}%</span></div>
   <div class="gate-g">${[["Đơn", "all", a.n, ""], ["Thành công", "ok", a.ok, "ok"], ["Chờ", "pend", a.waiting, a.stale ? "warn" : ""], ["Thất bại", "err", a.err, a.err ? "bad" : ""]].map(([l, s, v, cl]) => `<div class="gocell" data-go-list='${JSON.stringify({ s, h: hi, g: gi, tf: st.tf.house })}' title="Bấm để xem danh sách đơn"><small>${l}</small><span class="${cl}">${fmt(v)}</span></div>`).join("")}</div>
   <div style="display:flex;justify-content:space-between;align-items:center">${rateBar(a)}<span class="mut" style="font-size:11px">TB ${a.ok ? mmss(a.sp) : "—"}</span></div></div>`;
}
function renderHouse() {
  if (st.house >= HOUSES.length) st.house = -1;
  chips("hf", HOUSES, st.house, (v) => { st.house = v; render(); }, true);
  const list = inTf("house"); const by = {}; for (const o of list) (by[o.h + "_" + o.g] ??= []).push(o);
  if (!HOUSES.length) { $("house-body").innerHTML = empty("Chưa có dữ liệu."); return; }
  if (st.house === -1) {
    const order = HOUSES.map((h, hi) => ({ h, hi, n: list.filter((o) => o.h === hi).length })).sort((a, b) => b.n - a.n);
    $("house-body").innerHTML = `<div class="page-h"><h2>Tất cả nhà</h2><p>${tfLabel("house")} · mỗi cột là một nhà, cổng nạp xếp dọc. Kéo ngang để xem hết. Bấm tên nhà để mở chi tiết.</p></div>
    <div class="hcols">${order.map(({ h, hi }) => {
      const a = agg(list.filter((o) => o.h === hi));
      return `<div class="hcol"><button class="hcol-h" data-pick-house="${hi}"><span class="n"><b>${esc(h.n)}</b>${statusPill(h)}</span>
       <span class="s"><span>Số dư <b>${balTxt(h)}</b>${h.balAt ? ` <small class="mut">${new Date(h.balAt).toLocaleTimeString("vi-VN").slice(0, 5)}</small>` : ""}</span><span>Tỷ lệ <b class="${rc(a.rate)}">${pct(a.rate)}</b></span></span>
       <span class="s"><span>Đơn <b>${fmt(a.n)}</b></span><span>Thành công <b>${fmt(a.ok)}</b></span><span>Lỗi <b>${fmt(a.err)}</b></span></span></button>
       ${GATES.map((g, gi) => (combo(hi, gi) ? gateBlock(hi, gi, by[hi + "_" + gi] || []) : "")).join("")}</div>`;
    }).join("")}</div>`;
  } else {
    const hi = st.house, h = HOUSES[hi]; const a = agg(list.filter((o) => o.h === hi));
    const kp = [["Số dư", balTxt(h), h.on == null ? "Chưa ghép với listV2" : h.on ? "Rút đang bật" : "Rút đang tắt", ""], ["Tổng đơn", fmt(a.n), vnd(a.amt) + " ₫", ""], ["Thành công", fmt(a.ok), pct(a.rate), "ok"], ["Đang chờ / hết hạn", fmt(a.waiting), a.stale + " đơn chờ quá " + SET.stale + "'", "warn"], ["Thất bại", fmt(a.err), "", a.err ? "bad" : ""], ["Lên điểm TB", a.ok ? mmss(a.sp) : "—", (a.ok ? (a.s3 / a.ok * 100).toFixed(0) : 0) + "% dưới 3 phút", ""], ["Phí ước tính", vnd(a.fee), "₫ · TB " + (a.okAmt ? (a.fee / a.okAmt * 100).toFixed(2) : "0") + "%", ""]];
    let t = `<thead><tr><th class="l">Cổng nạp</th><th class="l">Kênh</th><th>Phí %</th><th>Đơn</th><th>Thành công</th><th>Đang chờ</th><th>Chờ &gt;${SET.stale}'</th><th>Hết hạn/huỷ</th><th>Thất bại</th><th>Tỷ lệ</th><th>Lên điểm TB</th><th>&lt; 3'</th><th>&gt; 10'</th><th>Tiền lên điểm (₫)</th><th>Phí ước tính (₫)</th><th class="l">Trạng thái</th></tr></thead><tbody>`;
    GATES.forEach((g, gi) => {
      const v = combo(hi, gi); if (!v) return; const c = agg(by[hi + "_" + gi] || []); const l = lvBoth(hi + "_" + gi, c);
      t += `<tr class="${l === "bad" ? "rbad" : l === "warn" ? "rwarn" : ""}"><td class="name">${esc(g.n)} ${boTag(hi, gi)}<small>${esc(g.raw)}</small></td><td class="l">${esc([...v.chs].join(", "))}</td><td>${v.fee}%</td>${[["all", c.n, ""], ["ok", c.ok, "ok"], ["pend", c.pend, ""], ["pend5", c.stale, c.stale ? "warn" : "mut"], ["aband", c.aband, "mut"], ["err", c.err, c.err ? "bad" : "mut"]].map(([s, v, cl]) => `<td class="${cl} gocell" data-go-list='${JSON.stringify({ s: s === "pend5" ? "pend" : s, m: s === "pend5" ? 5 : 0, h: hi, g: gi, tf: st.tf.house })}' title="Bấm để xem danh sách đơn">${fmt(v)}</td>`).join("")}<td>${rateBar(c)}</td><td>${c.ok ? mmss(c.sp) : "—"}</td><td>${c.ok ? (c.s3 / c.ok * 100).toFixed(0) + "%" : "—"}</td><td class="${c.sOver ? "bad" : "mut"}">${fmt(c.sOver)}</td><td>${vnd(c.okAmt)}</td><td>${vnd(c.fee)}</td><td class="l">${PILL[l]}</td></tr>`;
    });
    t += `</tbody><tfoot><tr><td class="l">Tổng ${esc(h.n)}</td><td></td><td>${a.okAmt ? (a.fee / a.okAmt * 100).toFixed(2) + "%" : "—"}</td><td>${fmt(a.n)}</td><td class="ok">${fmt(a.ok)}</td><td>${fmt(a.pend)}</td><td>${fmt(a.stale)}</td><td>${fmt(a.aband)}</td><td>${fmt(a.err)}</td><td>${rateBar(a)}</td><td>${a.ok ? mmss(a.sp) : "—"}</td><td>${a.ok ? (a.s3 / a.ok * 100).toFixed(0) + "%" : "—"}</td><td>${fmt(a.sOver)}</td><td>${vnd(a.okAmt)}</td><td>${vnd(a.fee)}</td><td></td></tr></tfoot>`;
    $("house-body").innerHTML = `<div class="page-h"><h2>${esc(h.n)}</h2><p>${tfLabel("house")} · từng cổng nạp của ${esc(h.n)}</p></div>
     <div class="kpis">${kp.map((k, i) => { const g = [null, "all", "ok", "pend", "err", "ok", "ok"][i]; return `<div class="kpi ${k[3]}${g ? " go" : ""}"${g ? ` data-go-list='${JSON.stringify({ s: g, h: hi, tf: st.tf.house })}' title="Bấm để xem danh sách đơn"` : ""}><div class="lab">${k[0]}</div><div class="val">${k[1]}</div><div class="sub">${k[2]}</div></div>`; }).join("")}</div>
     <div class="card"><div class="card-h"><h3>Cổng nạp của ${esc(h.n)}</h3><span class="hint">Kéo ngang nếu bảng dài</span></div><div class="scroll"><table class="tbl">${t}</table></div></div>
     <div class="card chart"><div class="card-h"><h3>Đơn theo giờ · ${esc(h.n)}</h3></div><div class="card-b">${hourChart(orders.filter((o) => o.h === hi))}</div></div>`;
  }
}

// ===== CỔNG NẠP =====
function hourChart(list) {
  const HN = Math.max(1, Math.floor(NOWS() / 3600) + 1);
  const b = Array.from({ length: HN }, () => ({ ok: 0, p: 0, e: 0 }));
  for (const o of list) { const i = Math.min(HN - 1, Math.floor(o.t / 3600)); if (o.st === 2) b[i].ok++; else if (o.st === 3) b[i].e++; else b[i].p++; }
  const mx = Math.max(1, ...b.map((x) => x.ok + x.p + x.e)); const step = [1, 2, 5, 10, 20, 50, 100, 200, 250, 500, 1000, 2000].find((s) => mx / s <= 5) || 5000; const top = Math.ceil(mx / step) * step;
  const W = 560, H = 210, L = 44, R = 8, T = 10, B = 24, cw = (W - L - R) / Math.max(HN, 8), y = (v) => T + (H - T - B) * (1 - v / top);
  let s = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Số đơn theo giờ">`;
  for (let v = 0; v <= top; v += step) s += `<line class="gl" x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}"/><text x="${L - 6}" y="${y(v) + 3}" text-anchor="end">${fmt(v)}</text>`;
  b.forEach((x, i) => {
    const bx = L + i * cw + cw * 0.18, bw = cw * 0.64; let base = 0;
    [["ok", "var(--b1)"], ["p", "var(--b3)"], ["e", "var(--b5)"]].forEach(([k, c]) => { const v = x[k]; if (!v) return; s += `<rect x="${bx.toFixed(1)}" y="${y(base + v).toFixed(1)}" width="${bw.toFixed(1)}" height="${(y(base) - y(base + v)).toFixed(1)}" fill="${c}" rx="1.5"><title>${pad(i)}h: ${v}</title></rect>`; base += v; });
    s += `<text x="${(L + i * cw + cw / 2).toFixed(1)}" y="${H - 7}" text-anchor="middle">${pad(i)}h</text>`;
  });
  return s + "</svg>";
}
function renderGate() {
  if (!$("gstat").open) try { renderGstat(); } catch (e) {}
  if (!$("ghouse").open) try { renderGhouse(); } catch (e) {}
  if (st.gate >= GATES.length) st.gate = -1;
  chips("gf", GATES, st.gate, (v) => { st.gate = v; render(); }, false);
  const list = inTf("gate"); $("gate-hint").textContent = tfLabel("gate");
  const gs = st.gate === -1 ? GATES.map((g, i) => i) : [st.gate];
  let t = `<thead><tr><th class="l">Cổng / nhà</th><th>Phí %</th><th>Đơn</th><th>Thành công</th><th>Chờ &gt;${SET.stale}'</th><th>Hết hạn/huỷ</th><th>Thất bại</th><th>Tỷ lệ</th><th>Lên điểm TB</th><th>Tiền lên điểm (₫)</th></tr></thead><tbody>`;
  for (const gi of gs) {
    const g = GATES[gi]; const gl = list.filter((o) => o.g === gi); const a = agg(gl);
    t += `<tr class="grp"><td class="l">${esc(g.n)} <span class="mut" style="font-weight:400;font-size:11px">${esc(g.raw)}</span></td><td></td><td>${fmt(a.n)}</td><td class="ok">${fmt(a.ok)}</td><td>${fmt(a.stale)}</td><td>${fmt(a.aband)}</td><td>${fmt(a.err)}</td><td>${rateBar(a)}</td><td>${a.ok ? mmss(a.sp) : "—"}</td><td>${vnd(a.okAmt)}</td></tr>`;
    HOUSES.map((h, hi) => ({ h, hi })).filter((x) => combo(x.hi, gi)).map((x) => ({ ...x, a: agg(gl.filter((o) => o.h === x.hi)) })).sort((p, q) => q.a.n - p.a.n).forEach(({ h, hi, a: c }) => {
      const l = lvBoth(hi + "_" + gi, c), v = combo(hi, gi);
      t += `<tr class="${l === "bad" ? "rbad" : l === "warn" ? "rwarn" : ""}"><td class="name" style="padding-left:24px">${esc(h.n)} ${boTag(hi, gi)}<small>${esc(chText(v))}</small></td><td>${v.fee}%</td><td>${fmt(c.n)}</td><td class="ok">${fmt(c.ok)}</td><td class="${c.stale ? "warn" : "mut"}">${fmt(c.stale)}</td><td class="mut">${fmt(c.aband)}</td><td class="${c.err ? "bad" : "mut"}">${fmt(c.err)}</td><td>${rateBar(c)}</td><td>${c.ok ? mmss(c.sp) : "—"}</td><td>${vnd(c.okAmt)}</td></tr>`;
    });
  }
  $("gate-tbl").innerHTML = t + "</tbody>";
  $("gate-chart-hint").textContent = st.gate === -1 ? "Tất cả cổng · hôm nay" : GATES[st.gate].n + " · hôm nay";
  $("gate-chart").innerHTML = hourChart(st.gate === -1 ? orders : orders.filter((o) => o.g === st.gate));
}

// ===== TỐC ĐỘ =====
function renderSpeed() {
  if (st.speedH >= HOUSES.length) st.speedH = -1;
  chips("sf", HOUSES, st.speedH, (v) => { st.speedH = v; render(); }, true);
  const list = inTf("speed").filter((o) => st.speedH === -1 || o.h === st.speedH); const a = agg(list);
  const kp = [["Tổng đơn", fmt(a.n), tfLabel("speed"), ""], ["Dưới 3 phút", fmt(a.s3), (a.ok ? (a.s3 / a.ok * 100).toFixed(1) : 0) + "% đơn thành công", "ok"], ["3–10 phút", fmt(a.s10), (a.ok ? (a.s10 / a.ok * 100).toFixed(1) : 0) + "%", "warn"], ["Trên 10 phút", fmt(a.sOver), (a.ok ? (a.sOver / a.ok * 100).toFixed(1) : 0) + "%", "bad"], ["Chưa lên điểm", fmt(a.waiting), "Đang chờ + bỏ dở", ""], ["Thất bại", fmt(a.err), "", "slow"], ["Trung vị / P90", a.ok ? mmss(a.med) : "—", "90% đơn lên trong " + (a.ok ? mmss(a.p90) : "—"), ""]];
  const GOS = [{ s: "all" }, { s: "ok" }, { s: "ok" }, { s: "ok" }, { s: "pend" }, { s: "err" }, { s: "ok" }];
  $("speed-kpis").innerHTML = kp.map((k, i) => `<div class="kpi ${k[3]} go" data-go-list='${JSON.stringify({ ...GOS[i], h: st.speedH, tf: st.tf.speed })}' title="Bấm để xem danh sách đơn"><div class="lab">${k[0]}</div><div class="val">${k[1]}</div><div class="sub">${k[2]}</div></div>`).join("");
  const rows = []; const by = {}; for (const o of list) (by[o.h + "_" + o.g] ??= []).push(o);
  for (const k in by) { const [hi, gi] = k.split("_").map(Number); rows.push({ hi, gi, a: agg(by[k]) }); }
  rows.sort((p, q) => (q.a.ok >= 5 ? q.a.med : 0) - (p.a.ok >= 5 ? p.a.med : 0));
  let t = `<thead><tr><th class="l">Nhà</th><th class="l">Cổng</th><th class="l">Kênh</th><th>Tổng đơn</th><th>&lt; 3 phút</th><th>3–10 phút</th><th>&gt; 10 phút</th><th>Chưa lên</th><th>Thất bại</th><th class="l">Phân bố</th><th>% dưới 3'</th><th>Trung vị</th><th>P90</th><th>Chậm nhất</th><th class="l">Đánh giá</th></tr></thead><tbody>`;
  for (const { hi, gi, a: c } of rows) {
    const T = Math.max(1, c.n); const r3 = c.ok ? c.s3 / c.ok * 100 : 0;
    const ev = c.ok < 5 ? '<span class="pill" style="background:var(--panel2);color:var(--muted)">Ít đơn</span>' : c.med > 300 || r3 < 50 ? '<span class="pill badp">Rất chậm</span>' : c.med > 150 || r3 < 75 ? '<span class="pill warnp">Chậm</span>' : '<span class="pill on">Nhanh</span>';
    t += `<tr><td class="name">${esc(HOUSES[hi].n)}</td><td class="l">${esc(GATES[gi].n)}</td><td class="l mut">${esc(chText(combo(hi, gi)))}</td><td>${fmt(c.n)}</td><td class="ok">${fmt(c.s3)}</td><td class="${c.s10 ? "warn" : "mut"}">${fmt(c.s10)}</td><td class="${c.sOver ? "bad" : "mut"}">${fmt(c.sOver)}</td><td class="mut">${fmt(c.waiting)}</td><td class="${c.err ? "slow" : "mut"}">${fmt(c.err)}</td>
    <td class="l"><span class="track wide"><span style="width:${c.s3 / T * 100}%;background:var(--b1)"></span><span style="width:${c.s10 / T * 100}%;background:var(--b3)"></span><span style="width:${c.sOver / T * 100}%;background:var(--b5)"></span><span style="width:${c.waiting / T * 100}%;background:var(--b6)"></span><span style="width:${c.err / T * 100}%;background:var(--slow)"></span></span></td>
    <td class="${rc(r3 >= 85 ? 80 : r3 >= 70 ? 60 : 40)}">${c.ok ? r3.toFixed(0) + "%" : "—"}</td><td>${c.ok ? mmss(c.med) : "—"}</td><td>${c.ok ? mmss(c.p90) : "—"}</td><td class="mut">${c.ok ? mmss(c.sps[c.sps.length - 1]) : "—"}</td><td class="l">${ev}</td></tr>`;
  }
  if (!rows.length) t += `<tr><td class="l mut" colspan="15">Chưa có đơn trong khung thời gian này</td></tr>`;
  $("speed-tbl").innerHTML = t + "</tbody>";
}

// ===== DANH SÁCH ĐƠN =====
const OST = [["pend", "Đang chờ thanh toán", "warn"], ["ok", "Thành công", "ok"], ["err", "Thất bại", "bad"], ["aband", "Hết hạn / huỷ / bỏ dở", ""], ["all", "Tất cả đơn", ""]];
const stOf = (o) => (o.st === 2 ? "ok" : o.st === 3 ? "err" : o.st >= 4 || NOWS() - o.t > ABANDON ? "aband" : "pend");
const PAGE = 50;
let LIST = [];
const NTAG = { first: "Lần đầu", second: "Lần 2" };
const nTxt = (o) => o.nAll == null ? '<span class="mut">—</span>' : `<span title="Thành công ${o.nOk} / tổng ${o.nAll} lần nạp">${fmt(o.nOk)}<span class="mut">/${fmt(o.nAll)}</span></span>${NTAG[o.ntag] ? ` <span class="pill ${o.ntag === "first" ? "on" : "low"}">${NTAG[o.ntag]}</span>` : ""}`;
function renderPend() {
  $("pxlsTxt").textContent = "Tải Excel · " + OST.find((x) => x[0] === st.ostat)[1];
  const N = NOWS();
  const base = inTf("list").filter((o) => (st.pendH === -1 || o.h === st.pendH) && (st.pendG === -1 || o.g === st.pendG));
  const cnt = { pend: 0, ok: 0, err: 0, aband: 0, all: base.length }, amt = { pend: 0, ok: 0, err: 0, aband: 0, all: 0 };
  for (const o of base) { const k = stOf(o); cnt[k]++; amt[k] += o.amt; amt.all += o.amt; }
  $("ost").innerHTML = OST.map(([k, n, c]) => `<button class="stab ${c}" aria-pressed="${st.ostat === k}" data-v="${k}"><small>${n}</small><b>${fmt(cnt[k])}</b><span>${vnd(amt[k])} ₫</span></button>`).join("");
  $("ost").onclick = (e) => { const b = e.target.closest(".stab"); if (b) { st.ostat = b.dataset.v; st.page = 0; if (st.ostat !== "pend") st.pendMin = 0; render(); } };
  chips("pf", HOUSES, st.pendH, (v) => { st.pendH = v; st.page = 0; render(); }, true);
  chips("pg", GATES, st.pendG, (v) => { st.pendG = v; st.page = 0; render(); }, false);
  $("pwait").hidden = st.ostat !== "pend";
  const opts = [[0, "Tất cả"], [5, "> 5 phút"], [10, "> 10 phút"], [15, "> 15 phút"]];
  $("pseg").innerHTML = opts.map((o) => `<button aria-pressed="${st.pendMin === o[0]}" data-v="${o[0]}">${o[1]}</button>`).join("");
  $("pseg").onclick = (e) => { const b = e.target.closest("button"); if (b) { st.pendMin = +b.dataset.v; st.page = 0; render(); } };
  const q = st.q.trim().toLowerCase();
  const list = LIST = base.filter((o) => (st.ostat === "all" || stOf(o) === st.ostat) && (st.ostat !== "pend" || N - o.t >= st.pendMin * 60) && (!q || o.no.includes(q) || o.acc.toLowerCase().includes(q)));
  list.sort(st.ostat === "pend" ? (a, b) => a.t - b.t : (a, b) => b.t - a.t);
  const sum = list.reduce((x, o) => x + o.amt, 0);
  $("pend-h").textContent = OST.find((x) => x[0] === st.ostat)[1];
  $("pend-hint").textContent = tfLabel("list") + (st.ostat === "pend" ? " · chờ lâu nhất trên cùng" : " · mới nhất trên cùng");
  $("pend-sum").textContent = fmt(list.length) + " đơn · " + vnd(sum) + " ₫";
  const pages = Math.max(1, Math.ceil(list.length / PAGE)); st.page = Math.min(st.page, pages - 1);
  const rows = list.slice(st.page * PAGE, st.page * PAGE + PAGE);
  const tagOf = (o) => { const k = stOf(o); return k === "ok" ? '<span class="tag ok">Thành công</span>' : k === "err" ? `<span class="tag bad">${esc(o.psl || "Thất bại")}</span>` : k === "aband" ? `<span class="tag mut">${esc(o.st >= 4 ? o.psl || "Hết hạn" : "Chờ quá 30 phút")}</span>` : '<span class="tag warn">Đang chờ</span>'; };
  let t = `<thead><tr><th class="l">Số lệnh</th><th class="l">Tài khoản</th><th title="Số lần nạp thành công / tổng số lần nạp của khách (theo BO)">Số lần nạp</th><th class="l">Nhà</th><th class="l">Cổng</th><th class="l">Kênh</th><th>Số tiền</th><th>Tạo lúc</th>`;
  if (st.ostat === "pend") t += `<th>Đã chờ</th>`;
  else if (st.ostat === "ok") t += `<th>Thành công lúc</th><th>Lên điểm sau</th><th>Phí %</th><th>Phí (₫)</th>`;
  else if (st.ostat === "all") t += `<th class="l">Tình trạng</th><th>Lên điểm sau</th><th class="l">Lý do (BO)</th>`;
  else t += `<th class="l">Tình trạng</th><th class="l">Lý do (BO)</th>`;
  t += `</tr></thead><tbody>`;
  for (const o of rows) {
    const age = N - o.t;
    t += `<tr><td class="l">${esc(o.no)}</td><td class="name" style="font-weight:500">${esc(o.acc)}${FAKESET.has(o.acc) ? ' <span class="pill badp">Lệnh ảo</span>' : ""}</td><td>${nTxt(o)}</td><td class="name">${esc(HOUSES[o.h].n)}</td><td class="l">${esc(GATES[o.g].n)}</td><td class="l mut">${esc(o.ch)}</td><td>${o.cur === "VND" ? vnd(o.amt) + " ₫" : fmt(o.raw) + " " + o.cur}</td><td>${clock(o.t)}</td>`;
    if (st.ostat === "pend") t += `<td class="${age > 600 ? "bad" : age > 300 ? "warn" : "mut"}">${mmss(age)}</td>`;
    else if (st.ostat === "ok") t += `<td>${clock(o.t + o.sp)}</td><td class="${o.sp > 600 ? "bad" : o.sp > 180 ? "warn" : "ok"}">${mmss(o.sp)}</td><td>${o.fee}%</td><td>${vnd(o.amt * o.fee / 100)}</td>`;
    else if (st.ostat === "all") t += `<td class="l">${tagOf(o)}</td><td class="${o.st === 2 ? (o.sp > 600 ? "bad" : o.sp > 180 ? "warn" : "ok") : "mut"}">${o.st === 2 ? mmss(o.sp) : "—"}</td><td class="l mut why">${esc(o.why || "")}</td>`;
    else t += `<td class="l">${tagOf(o)}</td><td class="l why">${esc(o.why || "")}</td>`;
    t += `</tr>`;
  }
  if (!rows.length) t += `<tr><td class="l mut" colspan="12">Không có đơn nào khớp bộ lọc</td></tr>`;
  $("pend-tbl").innerHTML = t + "</tbody>";
  let rs = "";
  if (st.ostat === "err" && list.length) {
    const m = {}; for (const o of list) { const k = (o.why || "Không ghi lý do").replace(/[\d.]+/g, (x) => x); (m[k] ??= { n: 0, hs: new Set() }).n++; m[k].hs.add(HOUSES[o.h].n + " · " + GATES[o.g].n); }
    rs = `<div class="reasons"><b>Lý do lỗi theo BO:</b>` + Object.entries(m).sort((x, y) => y[1].n - x[1].n).slice(0, 8).map(([k, v]) => `<div><span class="pill badp">${fmt(v.n)} đơn</span> <span class="why">${esc(k)}</span> <small class="mut">${esc([...v.hs].slice(0, 4).join(", "))}</small></div>`).join("") + `</div>`;
  }
  $("pend-reasons").innerHTML = rs; $("pend-reasons").hidden = !rs;
  $("pager").innerHTML = `<button id="pg-prev" ${st.page ? "" : "disabled"}>‹ Trước</button><span>Trang <b class="mono">${st.page + 1}</b> / ${pages} · ${PAGE} đơn mỗi trang</span><button id="pg-next" ${st.page < pages - 1 ? "" : "disabled"}>Sau ›</button>`;
  $("pg-prev").onclick = () => { st.page--; render(); }; $("pg-next").onclick = () => { st.page++; render(); };
}
function pendBadge() { const N = NOWS(), S = STALE(); $("cnt-pend").textContent = orders.filter((o) => o.st === 1 && N - o.t > S && N - o.t <= ABANDON).length; }

// ===== PHÍ TRONG THÁNG (bot tự ghi lịch sử channelRate) =====
let FEEH = {};   // "merch|gate|kênh" -> {ngày: {r, ts}} (phí của đơn mới nhất trong ngày)
let feeDirty = false;
function noteFee(o) {
  const k = o.merch + "|" + o.gate + "|" + (o.ch || "");
  const m = (FEEH[k] ??= {});
  const e = m[o.day];
  if (!e || o.ts >= e.ts) { if (!e || e.r !== o.fee || e.ts !== o.ts) { m[o.day] = { r: o.fee, ts: o.ts }; feeDirty = true; } }
}
// chuyển thành danh sách các lần phí khác ngày trước
function feeArr(k) {
  const m = FEEH[k] || {}; const out = [];
  for (const d of Object.keys(m).sort()) { const r = m[d].r; if (!out.length || out[out.length - 1].r !== r) out.push({ day: d, r }); }
  return out;
}
async function saveFee() { if (feeDirty) { feeDirty = false; await Store.kvSet("feeHist", FEEH); } }
function renderFee() {
  const FA = {}; for (const k in FEEH) FA[k] = feeArr(k);
  const months = new Set([DAY.slice(0, 7)]);
  for (const k in FA) for (const e of FA[k]) months.add(e.day.slice(0, 7));
  const ml = [...months].sort().reverse();
  if (!st.feeMon || !months.has(st.feeMon)) st.feeMon = ml[0];
  $("fmon").innerHTML = ml.map((m) => `<button aria-pressed="${m === st.feeMon}" data-v="${m}">${m.slice(5)}/${m.slice(0, 4)}</button>`).join("");
  $("fmon").onclick = (e) => { const b = e.target.closest("button"); if (b) { st.feeMon = b.dataset.v; render(); } };
  const merchs = [...new Set(Object.keys(FEEH).map((k) => k.split("|")[0]))];
  const FH = merchs.map((n) => ({ n }));
  if (st.feeH >= FH.length) st.feeH = -1;
  chips("ff", FH, st.feeH, (v) => { st.feeH = v; render(); }, false);
  const [y, m] = st.feeMon.split("-").map(Number);
  const lastDay = new Date(y, m, 0).getDate();
  const upto = st.feeMon === DAY.slice(0, 7) ? +DAY.slice(8) : lastDay;
  const days = Array.from({ length: upto }, (_, i) => `${st.feeMon}-${pad(i + 1)}`);
  $("fee-range").textContent = `01/${pad(m)} → ${pad(upto)}/${pad(m)} · ▲ tăng là bất lợi`;
  const series = (k) => { const arr = FA[k]; let v = null; return days.map((d) => { for (const e of arr) if (e.day <= d) v = e.r; return v; }); };
  const keys = Object.keys(FEEH).filter((k) => (st.feeH === -1 || k.split("|")[0] === merchs[st.feeH]) && series(k).some((v) => v != null));
  let up = 0, down = 0, nChg = 0;
  const rows = keys.map((k) => {
    const s = series(k).filter((v) => v != null); const first = s[0], cur = s[s.length - 1];
    const lg = FA[k].filter((e, i) => i > 0 && e.day.startsWith(st.feeMon));
    if (cur > first) up++; else if (cur < first) down++; nChg += lg.length;
    return { k, s: series(k), first, cur, min: Math.min(...s), max: Math.max(...s), lg };
  }).sort((a, b) => Math.abs(b.cur - b.first) - Math.abs(a.cur - a.first) || b.lg.length - a.lg.length);
  $("fee-kpis").innerHTML = [["Số kênh đang theo dõi", fmt(rows.length), "Ghi từ đơn trên BO", ""], ["Kênh tăng phí", up, "So với đầu tháng", up ? "bad" : ""], ["Kênh giảm phí", down, "So với đầu tháng", down ? "ok" : ""], ["Lần đổi phí", nChg, "Trong tháng", ""], ["Phí hôm nay (ước tính)", vnd(day.fee), "₫ · TB " + (day.okAmt ? (day.fee / day.okAmt * 100).toFixed(2) : 0) + "%", ""]]
    .map((k) => `<div class="kpi ${k[3]}"><div class="lab">${k[0]}</div><div class="val">${k[1]}</div><div class="sub">${k[2]}</div></div>`).join("");
  const stepSvg = (a) => { const v = a.filter((x) => x != null); if (!v.length) return ""; const W = 96, H = 22, mn = Math.min(...v), mx = Math.max(...v), r = mx - mn || 1; let d = "", started = false; a.forEach((x, i) => { if (x == null) return; const X = i * (W / Math.max(1, a.length - 1)), Y = H - 3 - (x - mn) / r * (H - 6); d += started ? `H${X.toFixed(1)}V${Y.toFixed(1)}` : `M${X.toFixed(1)} ${Y.toFixed(1)}`; started = true; }); return `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" aria-hidden="true"><path d="${d}" fill="none" stroke="var(--accent)" stroke-width="1.5"/></svg>`; };
  let t = `<thead><tr><th class="l">Nhà</th><th class="l">Cổng</th><th class="l">Kênh</th><th>Đầu tháng</th><th>Hiện tại</th><th>Thay đổi</th><th>Thấp nhất</th><th>Cao nhất</th><th>Số lần đổi</th><th>Đổi gần nhất</th><th class="l">Trong tháng</th></tr></thead><tbody>`;
  for (const r of rows) {
    const [mc, g, ch] = r.k.split("|"); const ch2 = +(r.cur - r.first).toFixed(3);
    t += `<tr><td class="name">${esc(mc)}</td><td class="l">${esc(GATE_SHORT[nk(g)] || g)}</td><td class="l mut">${esc(ch)}</td><td>${r.first}%</td><td><b>${r.cur}%</b></td><td class="${ch2 > 0 ? "up" : ch2 < 0 ? "down" : "mut"}">${ch2 > 0 ? "▲ +" + ch2 : ch2 < 0 ? "▼ " + ch2 : "—"}</td><td>${r.min}%</td><td>${r.max}%</td><td>${r.lg.length || "—"}</td><td class="mut">${r.lg.length ? r.lg[r.lg.length - 1].day.slice(8) + "/" + r.lg[r.lg.length - 1].day.slice(5, 7) : "—"}</td><td class="l">${stepSvg(r.s)}</td></tr>`;
  }
  if (!rows.length) t += `<tr><td class="l mut" colspan="11">Chưa có dữ liệu phí cho tháng này. Bot ghi phí từ ngày cài đặt.</td></tr>`;
  $("fee-tbl").innerHTML = t + "</tbody>";
  // biểu đồ theo nhà
  const pick = st.feeH === -1 ? (rows[0] ? rows[0].k.split("|")[0] : null) : merchs[st.feeH];
  const ks = rows.filter((r) => r.k.split("|")[0] === pick).slice(0, 6);
  $("fee-chart-h").textContent = "Diễn biến phí" + (pick ? " · " + pick : "");
  const cols = ["var(--accent)", "var(--ok)", "var(--warn)", "var(--slow)", "var(--bad)", "#2ec4d6"];
  if (!ks.length) { $("fee-chart").innerHTML = empty("Chưa có dữ liệu."); $("fee-legend").innerHTML = ""; }
  else {
    const all = ks.flatMap((r) => r.s.filter((v) => v != null)); let mn = Math.min(...all), mx = Math.max(...all); if (mx - mn < 0.2) { mn = Math.max(0, mn - 0.1); mx = mx + 0.1; }
    const D = days.length, W = 560, H = 210, L = 44, R = 12, T = 12, B = 24, x = (i) => L + i * (W - L - R) / Math.max(1, D - 1), yv = (v) => T + (H - T - B) * (1 - (v - mn) / (mx - mn));
    let s = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Diễn biến phí">`;
    for (let i = 0; i <= 4; i++) { const v = mn + (mx - mn) * i / 4; s += `<line class="gl" x1="${L}" x2="${W - R}" y1="${yv(v)}" y2="${yv(v)}"/><text x="${L - 6}" y="${yv(v) + 3}" text-anchor="end">${v.toFixed(2)}%</text>`; }
    for (let d = 0; d < D; d += D > 16 ? 2 : 1) s += `<text x="${x(d)}" y="${H - 7}" text-anchor="middle">${pad(d + 1)}</text>`;
    ks.forEach((r, j) => { let p = "", started = false; r.s.forEach((v, i) => { if (v == null) return; p += started ? `H${x(i).toFixed(1)}V${yv(v).toFixed(1)}` : `M${x(i).toFixed(1)} ${yv(v).toFixed(1)}`; started = true; }); const lv = r.s[r.s.length - 1]; s += `<path d="${p}" fill="none" stroke="${cols[j]}" stroke-width="2"/>${lv != null ? `<circle cx="${x(D - 1)}" cy="${yv(lv)}" r="3" fill="${cols[j]}"/>` : ""}`; });
    $("fee-chart").innerHTML = s + "</svg>";
    $("fee-legend").innerHTML = ks.map((r, j) => { const [, g, ch] = r.k.split("|"); return `<span><i style="background:${cols[j]}"></i>${esc(GATE_SHORT[nk(g)] || g)} ${esc(ch)} · ${r.cur}%</span>`; }).join("");
  }
  const lg = rows.flatMap((r) => r.lg.map((e) => { const arr = FA[r.k], i = arr.indexOf(e); return { k: r.k, day: e.day, from: arr[i - 1].r, to: e.r }; })).sort((a, b) => (a.day < b.day ? 1 : -1));
  $("fee-log").innerHTML = `<thead><tr><th class="l">Ngày</th><th class="l">Nhà</th><th class="l">Cổng</th><th class="l">Kênh</th><th>Phí cũ</th><th>Phí mới</th><th>Chênh lệch</th></tr></thead><tbody>` + (lg.length ? lg.map((l) => { const [mc, g, ch] = l.k.split("|"); const dd = +(l.to - l.from).toFixed(3); return `<tr><td class="l">${l.day.split("-").reverse().join("/")}</td><td class="name">${esc(mc)}</td><td class="l">${esc(GATE_SHORT[nk(g)] || g)}</td><td class="l mut">${esc(ch)}</td><td>${l.from}%</td><td><b>${l.to}%</b></td><td class="${dd > 0 ? "up" : "down"}">${dd > 0 ? "▲ +" + dd : "▼ " + dd}</td></tr>`; }).join("") : `<tr><td class="l mut" colspan="7">Chưa có lần đổi phí nào trong tháng</td></tr>`) + "</tbody>";
}


// ===== LỆNH ẢO =====
// Danh sách tài khoản quản lý đã xác nhận là lệnh ảo (thêm tay) và đã bỏ qua
const FAKE_SEED = ["hophat787sloni","trancong6480zi","lycong60neavtk","phamtien401uwk","hominh347gazcp","ngoanh327clewy","lybao211dvyrky","dohung14ctvchs","lehong534gyqek","huynhthao6477q","lythinh24ysimm","phamhai5743yvx","lyphat54nqqvps","hohuy332hxbojf","hoangthin84csv","vuhuu98bcwuepe"];
let FMARK = {}, FIGN = {};   // tài khoản -> thời điểm đánh dấu / bỏ qua
const HO = ["nguyen","tran","le","pham","hoang","huynh","phan","vu","vo","dang","bui","do","ho","ngo","duong","ly","dinh","mai","truong","cao","lam","luong","trinh","dao","doan","ha","kieu","ta","quach","to","thai","chau","la","tang","van","khuc","lu","mac","tieu","hua","giang","phung","tu","au","lai","nghiem","ong","son","tong","vuong","chu","luu","dam","diep","hong","nong","thach","than","trieu","ung","yen"];
const BIG = 50000;   // 50 triệu VND (số tiền trên BO tính theo nghìn)
// tên kiểu "họ + tên + số + chuỗi chữ lung tung": hophat787sloni, huynhthao6477q, dohung14ctvchs
function nameScore(acc) {
  const s = String(acc || "").toLowerCase();
  const m = /^([a-z]{3,14})(\d{1,4})([a-z]{1,8})$/.exec(s);
  if (!m) return 0;
  const head = m[1], tail = m[3];
  if (!HO.some((h) => head.startsWith(h) && head.length - h.length >= 2)) return 0;
  const vowels = (tail.match(/[aeiouy]/g) || []).length;
  return tail.length >= 3 && vowels / tail.length <= 0.5 ? 2 : 1;   // đuôi càng ít nguyên âm càng giống chữ ngẫu nhiên
}
function fakeRows(list) {
  const by = {};
  for (const o of list) { if (!o.acc) continue; (by[o.acc] ??= []).push(o); }
  const rows = [];
  for (const acc in by) {
    const os = by[acc].sort((x, y) => x.ts - y.ts);
    const ok = os.filter((o) => o.st === 2).length, n = os.length;
    const big = os.filter((o) => o.cur === "VND" && o.amt >= BIG).length;
    const maxAmt = Math.max(...os.map((o) => o.amt));
    const last = os[os.length - 1];
    const nm = nameScore(acc);
    const fails = n >= 3 && ok === 0;
    const neverOk = last.nOk === 0;
    const sig = [];
    if (nm) sig.push(["Tên lung tung", nm === 2 ? "bad" : "warn"]);
    if (big) sig.push([`${big} lệnh ≥ 50 triệu`, "bad"]);
    if (fails) sig.push([`${n} lệnh, 0 thành công`, "bad"]);
    if (neverOk && last.nAll >= 2) sig.push([`BO: chưa nạp thành công lần nào (${last.nAll} lần)`, "warn"]);
    let score = (nm ? 1 : 0) + (big ? 1 : 0) + (fails ? 1 : 0) + (neverOk && last.nAll >= 3 ? 0.5 : 0);
    const marked = !!FMARK[acc] || FAKE_SEED.includes(acc);
    if (FIGN[acc]) continue;
    let lv = marked ? "mark" : score >= 2.5 ? "high" : score >= 2 ? "mid" : null;
    if (!lv) continue;
    rows.push({ acc, lv, score, sig, n, ok, big, maxAmt, sum: os.reduce((s, o) => s + o.amt, 0), first: os[0].ts, lastTs: last.ts, nOk: last.nOk, nAll: last.nAll, hs: [...new Set(os.map((o) => HOUSES[o.h].n))], gs: [...new Set(os.map((o) => GATES[o.g].n))] });
  }
  const R = { mark: 0, high: 1, mid: 2 };
  return rows.sort((x, y) => R[x.lv] - R[y.lv] || y.score - x.score || y.lastTs - x.lastTs);
}
// tài khoản đã đánh dấu nhưng hôm nay chưa tạo lệnh vẫn nằm trong danh sách để sao chép
function markedNoOrder(seen) { return [...new Set([...FAKE_SEED, ...Object.keys(FMARK)])].filter((a) => !seen.has(a) && !FIGN[a]); }
const FLV = [["all", "Tất cả nghi ngờ", ""], ["high", "Rất nghi ngờ", "bad"], ["mid", "Nghi ngờ", "warn"], ["mark", "Đã đánh dấu", "ok"]];
let FLIST = [];
function renderFake() {
  const list = inTf("fake");
  let rows = fakeRows(list);
  const seen = new Set(rows.map((r) => r.acc));
  const cnt = { all: rows.length, high: 0, mid: 0, mark: 0 }; rows.forEach((r) => cnt[r.lv]++);
  const extra = markedNoOrder(new Set(list.map((o) => o.acc)));
  cnt.mark += extra.length; cnt.all += extra.length;
  st.fakeLv ??= "all";
  $("fst").innerHTML = FLV.map(([k, n, c]) => `<button class="stab ${c}" aria-pressed="${st.fakeLv === k}" data-v="${k}"><small>${n}</small><b>${fmt(cnt[k])}</b><span>${k === "mark" ? "đã xác nhận" : k === "all" ? "tài khoản" : "tài khoản trong khung giờ"}</span></button>`).join("");
  $("fst").onclick = (e) => { const b = e.target.closest(".stab"); if (b) { st.fakeLv = b.dataset.v; render(); } };
  const q = ($("fsearch").value || "").trim().toLowerCase();
  let show = rows.filter((r) => (st.fakeLv === "all" || r.lv === st.fakeLv) && (!q || r.acc.includes(q)));
  if (st.fakeLv === "all" || st.fakeLv === "mark") show = show.concat(extra.filter((a) => !q || a.includes(q)).map((acc) => ({ acc, lv: "mark", sig: [["Hôm nay chưa tạo lệnh", "mut"]], n: 0, ok: 0, sum: 0, maxAmt: 0, hs: [], gs: [], none: true })));
  FLIST = show;
  $("cnt-fake").textContent = rows.filter((r) => r.lv !== "mark").length;
  $("fake-hint").textContent = tfLabel("fake");
  $("fake-sum").textContent = fmt(show.length) + " tài khoản";
  const LVT = { mark: '<span class="pill badp">Đã đánh dấu</span>', high: '<span class="pill badp">Rất nghi ngờ</span>', mid: '<span class="pill warnp">Nghi ngờ</span>' };
  let t = `<thead><tr><th class="l">Tài khoản</th><th class="l">Mức</th><th class="l">Dấu hiệu</th><th>Lệnh</th><th>Thành công</th><th>Lệnh lớn nhất (₫)</th><th>Tổng tiền đặt (₫)</th><th title="Số lần nạp thành công / tổng theo BO">Số lần nạp (BO)</th><th class="l">Nhà · cổng</th><th>Lệnh đầu</th><th>Lệnh cuối</th><th class="l"></th></tr></thead><tbody>`;
  for (const r of show.slice(0, 500)) {
    t += `<tr class="${r.lv === "mark" || r.lv === "high" ? "rbad" : ""}"><td class="name">${esc(r.acc)}</td><td class="l">${LVT[r.lv]}</td><td class="l">${r.sig.map(([s, c]) => `<span class="tag ${c}">${esc(s)}</span>`).join(" ")}</td>
      <td>${r.none ? "—" : fmt(r.n)}</td><td class="${r.ok ? "ok" : "bad"}">${r.none ? "—" : fmt(r.ok)}</td><td>${r.none ? "—" : vnd(r.maxAmt)}</td><td>${r.none ? "—" : vnd(r.sum)}</td><td>${r.nAll == null ? "—" : fmt(r.nOk) + "/" + fmt(r.nAll)}</td>
      <td class="l mut">${esc(r.hs.join(", "))}${r.gs.length ? " · " + esc(r.gs.join(", ")) : ""}</td><td>${r.none ? "—" : clock(r.first - V0())}</td><td>${r.none ? "—" : clock(r.lastTs - V0())}</td>
      <td class="l" style="white-space:nowrap">${r.none ? "" : `<button class="btn" data-fview="${esc(r.acc)}">Xem lệnh</button> `}${r.lv === "mark" ? `<button class="btn" data-funmark="${esc(r.acc)}">Bỏ đánh dấu</button>` : `<button class="btn" data-fmark="${esc(r.acc)}">Đánh dấu</button> <button class="btn" data-fign="${esc(r.acc)}">Không phải</button>`}</td></tr>`;
  }
  if (!show.length) t += `<tr><td class="l mut" colspan="12">Không có tài khoản nghi ngờ trong khung thời gian này</td></tr>`;
  $("fake-tbl").innerHTML = t + "</tbody>";
}
async function saveFake() { await chrome.storage.local.set({ fakeMark: FMARK, fakeIgn: FIGN }); }
document.addEventListener("click", async (e) => {
  const b = e.target.closest("[data-fview],[data-fmark],[data-funmark],[data-fign]"); if (!b) return;
  if (b.dataset.fview) { st.ostat = "all"; st.pendH = -1; st.pendG = -1; st.pendMin = 0; st.tf.list = "day"; st.page = 0; st.q = b.dataset.fview; $("psearch").value = st.q; go("pend"); return; }
  if (b.dataset.fmark) { FMARK[b.dataset.fmark] = Date.now(); delete FIGN[b.dataset.fmark]; }
  if (b.dataset.funmark) { const a = b.dataset.funmark; delete FMARK[a]; if (FAKE_SEED.includes(a)) FIGN[a] = Date.now(); }
  if (b.dataset.fign) { FIGN[b.dataset.fign] = Date.now(); delete FMARK[b.dataset.fign]; }
  await saveFake(); rebuild(); render();
});
$("fsearch").addEventListener("input", () => render());
$("faddb").onclick = async () => { const xs = $("fadd").value.split(/[\s,;]+/).map((x) => x.trim()).filter(Boolean); xs.forEach((x) => { FMARK[x] = Date.now(); delete FIGN[x]; }); $("fadd").value = ""; await saveFake(); rebuild(); render(); };
$("fcopy").onclick = async () => {
  const txt = FLIST.map((r) => r.acc).join(",");
  try { await navigator.clipboard.writeText(txt); sysmsg(`Đã sao chép ${FLIST.length} tài khoản (cách nhau dấu phẩy). Dán vào ô "Tài khoản thành viên" trên BO, mỗi lần tối đa 200 tài khoản.`, "info"); }
  catch (e) { sysmsg("Không sao chép được: " + esc(e.message), "err"); }
  setTimeout(() => sysmsg(""), 6000);
};
$("fxls").onclick = async () => {
  const F = "Times New Roman", S = (o) => Object.assign({ border: true, font: { name: F, size: 10 }, align: { v: "center" } }, o || {});
  const wb = new XLSXW.Book(), ws = wb.sheet("Lệnh ảo");
  const H = ["Tài khoản", "Mức", "Dấu hiệu", "Số lệnh", "Thành công", "Lệnh lớn nhất (₫)", "Tổng tiền đặt (₫)", "Nạp thành công (BO)", "Tổng lần nạp (BO)", "Nhà thứ 3", "Cổng nạp"];
  const W = [20, 14, 50, 9, 10, 16, 18, 12, 12, 24, 24];
  H.forEach((h, i) => { ws.set(1, i + 1, h, S({ font: { name: F, size: 10, bold: true, color: "FFFFFF" }, fill: "0B2A55", align: { h: "center", v: "center", wrap: true } })); ws.width(i + 1, W[i]); });
  const L = { mark: "Đã đánh dấu", high: "Rất nghi ngờ", mid: "Nghi ngờ" };
  FLIST.forEach((r, i) => [r.acc, L[r.lv], r.sig.map((s) => s[0]).join("; "), r.n, r.ok, r.maxAmt * 1000, r.sum * 1000, r.nOk ?? null, r.nAll ?? null, r.hs.join(", "), r.gs.join(", ")]
    .forEach((v, j) => ws.set(i + 2, j + 1, v, S(j >= 3 && j <= 8 ? { fmt: "#,##0" } : {}))));
  ws.freeze(2, 2); ws.height(1, 30);
  const blob = await wb.blob(), now = new Date();
  const el = document.createElement("a"); el.href = URL.createObjectURL(blob); el.download = `Lenh_ao_${pad(now.getDate())}-${pad(now.getMonth() + 1)}_${pad(now.getHours())}h${pad(now.getMinutes())}.xlsx`; document.body.appendChild(el); el.click(); el.remove();
};


// ===== TRẠNG THÁI KÊNH TRÊN BO (Dừng/bật) =====
let PSET = null, PSAT = 0, PSERR = "", PSTATE = {}, PSW = [], PSWDAY = null, lastPS = 0;
const PS_MIN = 1; // đọc lại mỗi 1 phút
async function loadPaySet() {
  const d = await BO.paySettings();
  const now = nowU() - DAY0, list = [];
  for (const t of d) for (const c of t.channelList || []) {
    list.push({ key: (t.payTypeId || t.payTypeName) + "_" + c.id, type: t.payTypeName || c.paymentName || "", typeOn: t.switchStatus == null || Number(t.switchStatus) === 1,
      gk: nk(c.paymentName || t.payTypeName) || "khac", hk: hkey(c.merchName), merch: (c.merchName || "").trim(), desc: String(c.merchDesc || "").trim(),
      on: Number(c.status) === 1, min: Number(c.min) || 0, max: Number(c.max) || 0, rate: c.successRechargeRate, fee: c.channelRate, cur: c.payCurrency || "VND" });
  }
  if (PSWDAY !== DAY) { PSWDAY = DAY; PSW = (await Store.kvGet("psw:" + DAY).catch(() => null)) || []; }
  let changed = false;
  for (const c of list) {
    const p = PSTATE[c.key];
    if (!p) { PSTATE[c.key] = { on: c.on, since: null }; changed = true; continue; }
    if (p.on !== c.on) { PSW.push({ t: now, key: c.key, on: c.on, type: c.type, merch: c.merch, desc: c.desc, gk: c.gk, hk: c.hk }); PSTATE[c.key] = { on: c.on, since: DAY0 + now }; changed = true; }
  }
  PSET = list; PSAT = Date.now(); PSERR = "";
  if (changed) { Store.kvSet("pstate", PSTATE).catch(() => {}); Store.kvSet("psw:" + DAY, PSW).catch(() => {}); }
}
// trạng thái BO của 1 nhà × cổng: null = không có trong cài đặt, true = có kênh đang bật, false = tất cả đang dừng
function boState(hi, gi) {
  if (!PSET || VIEW || hi == null || gi == null || !HOUSES[hi] || !GATES[gi]) return null;
  const cs = PSET.filter((c) => c.hk === HOUSES[hi].k && c.gk === GATES[gi].k); if (!cs.length) return null;
  return cs.some((c) => c.on && c.typeOn);
}
const boTag = (hi, gi) => { const b = boState(hi, gi); return b == null ? "" : b ? '<span class="pill on" title="Trạng thái Dừng/bật trên BO">BO bật</span>' : '<span class="pill badp" title="Trạng thái Dừng/bật trên BO">BO tắt</span>'; };
const sinceTxt = (c) => { const p = PSTATE[c.key]; return p && p.since ? clock(p.since - DAY0 >= 0 ? p.since - DAY0 : 0) : ""; };
async function pswOf(dk) { if (!dk || dk === DAY) return PSW; return (await Store.kvGet("psw:" + dk).catch(() => null)) || []; }
let PSWV = [];

// ===== BẢO TRÌ CỔNG =====
// thời điểm đơn thành công đầu tiên của khách thật sau lúc t trên cùng nhà × cổng = cổng đã hoạt động lại
function okIndex() { const m = {}; for (const o of orders) if (o.st === 2) (m[o.h + "_" + o.g] ??= []).push(o.t); for (const k in m) m[k].sort((a, b) => a - b); return m; }
function okAfter(idx, k, t) { const a = idx[k]; if (!a) return null; let lo = 0, hi = a.length; while (lo < hi) { const md = (lo + hi) >> 1; if (a[md] > t) hi = md; else lo = md + 1; } return lo < a.length ? a[lo] : null; }
// Chỉ tính là bảo trì / lỗi cổng khi BO ghi lý do phía cổng (vd "Kênh này đang bảo trì").
// Không tính: BO không ghi lý do, hoặc lỗi do khách (số tiền dưới mức tối thiểu / vượt mức tối đa…)
const CUSTERR = /amount|less than|greater than|minimum|maximum|s[oố] ti[eề]n|t[oố]i thi[eể]u|t[oố]i [dđ]a|v[uượ][oợ]t|h[aạ]n m[uứ]c|limit/i;
const isMaint = (o) => o.st === 3 && !!(o.why && o.why.trim()) && !CUSTERR.test(o.why);
const MGAP = 900; // đơn lỗi cùng cổng cách nhau <= 15 phút = cùng 1 đợt
function maintEvents(errs) {
  const by = {}; for (const o of errs) (by[o.h + "_" + o.g] ??= []).push(o);
  const ev = [];
  for (const k in by) {
    const [hi, gi] = k.split("_").map(Number); let cur = null;
    for (const o of by[k].sort((a, b) => a.t - b.t)) {
      if (!cur || o.t - cur.b > MGAP) { cur = { k, hi, gi, a: o.t, b: o.t, list: [], why: {} }; ev.push(cur); }
      cur.b = o.t; cur.list.push(o); const w = o.why || "BO không ghi lý do"; cur.why[w] = (cur.why[w] || 0) + 1;
    }
  }
  return ev.sort((x, y) => y.b - x.b);
}
const whyTxt = (w) => Object.entries(w).sort((a, b) => b[1] - a[1]).map(([t, n]) => `${t}${n > 1 ? " (" + n + ")" : ""}`).join("; ");
let MEV = [], MROWS = [], MPSW = { dk: null, L: [] };
const gName = (gk, fb) => { const gi = GIDX[gk]; return gi != null ? GATES[gi].n : GATE_SHORT[gk] || fb || gk; };
const hName = (hk, fb) => { const hi = HIDX[hk]; return hi != null ? HOUSES[hi].n : fb || hk; };
// Các khoảng BO tắt (Dừng) của từng nhà × cổng trong ngày, dựng lại từ trạng thái hiện tại + lịch sử bật/tắt
function boOffSpans(L, today) {
  const keys = {};
  const add = (hk, gk, ck, desc, merch, type) => { const K = hk + "|" + gk; const r = (keys[K] ??= { hk, gk, merch, type, chs: {} }); return (r.chs[ck] ??= { desc, ev: [], cur: null }); };
  if (today && PSET) for (const c of PSET) add(c.hk, c.gk, c.key, c.desc, c.merch, c.type).cur = c.on && c.typeOn;
  for (const w of L) add(w.hk, w.gk, w.key, w.desc, w.merch, w.type).ev.push(w);
  const spans = [];
  for (const K in keys) {
    const r = keys[K], chs = Object.values(r.chs);
    for (const c of chs) { c.ev.sort((a, b) => a.t - b.t); c.init = c.ev.length ? !c.ev[0].on : c.cur == null ? true : c.cur; }
    const stAt = (c, t) => { let s = c.init; for (const e of c.ev) if (e.t <= t) s = e.on; return s; };
    const pts = [...new Set([0, ...chs.flatMap((c) => c.ev.map((e) => e.t))])].sort((a, b) => a - b);
    let cur = null;
    for (const t of pts) {
      const on = chs.some((c) => stAt(c, t));
      if (!on && !cur) { cur = { K, hk: r.hk, gk: r.gk, merch: r.merch, type: r.type, a: t, pre: t === 0, b: null, src: "bo", descs: chs.map((c) => c.desc) }; spans.push(cur); }
      else if (on && cur) { cur.b = t; cur = null; }
    }
  }
  return spans;
}
// Đợt bảo trì = BO tắt kênh, hoặc tool phát hiện đơn khách thật bị lỗi phía cổng.
// Hoàn tất khi BO bật lại (nếu đã tắt) VÀ có đơn thành công sau đó.
function buildIncidents(errs, L, today) {
  const OKI = okIndex();
  const inc = boOffSpans(L, today).map((s) => ({ ...s, list: [], why: {}, last: s.a }));
  for (const e of maintEvents(errs)) {
    const hk = HOUSES[e.hi].k, gk = GATES[e.gi].k, K = hk + "|" + gk;
    const m = inc.find((x) => x.K === K && x.src !== "err" && e.a <= (x.b == null ? 1e9 : x.b) && (e.b >= x.a - MGAP || (() => { const ok = okAfter(OKI, e.k, e.b); return ok == null || ok > x.a; })()));
    if (m) { m.src = "both"; if (!m.pre) m.a = Math.min(m.a, e.a); m.list.push(...e.list); for (const w in e.why) m.why[w] = (m.why[w] || 0) + e.why[w]; m.last = Math.max(m.last, e.b); }
    else inc.push({ K, hk, gk, merch: HOUSES[e.hi].n, type: GATES[e.gi].raw, a: e.a, b: null, pre: false, src: "err", list: [...e.list], why: { ...e.why }, last: e.b, descs: [...new Set(e.list.map((o) => o.ch).filter(Boolean))] });
  }
  for (const x of inc) {
    const hi = HIDX[x.hk], gi = GIDX[x.gk];
    x.hi = hi; x.gi = gi;
    x.resume = x.src === "err" ? x.last : x.b == null ? null : Math.max(x.b, x.last);
    x.ok = x.resume == null || hi == null || gi == null ? null : okAfter(OKI, hi + "_" + gi, x.resume);
    x.state = x.ok != null ? "done" : x.src !== "err" && x.b == null ? "off" : x.src !== "err" ? "wait" : "err";
  }
  return inc.sort((p, q) => (q.ok ?? q.b ?? 1e9) - (p.ok ?? p.b ?? 1e9) || q.a - p.a);
}
const MSRC = { bo: "BO tắt kênh", err: "Tool phát hiện lỗi", both: "Lỗi cổng + BO tắt" };
function mTag(x) {
  if (x.state === "done") return `<span class="pill on">Hoàn tất bảo trì ${clock(x.ok)}</span>`;
  if (x.state === "off") return `<span class="pill badp">Đang bảo trì · BO đang tắt</span>`;
  if (x.state === "wait") return `<span class="pill warnp">BO bật lại ${clock(x.b)} · chờ đơn thành công</span>`;
  return VIEW ? '<span class="pill warnp">Không thấy hoạt động lại</span>' : '<span class="pill badp">Đang bảo trì · tool phát hiện lỗi</span>';
}
const mStart = (x) => (x.pre ? (VIEW ? "Từ 00:00" : "Tắt từ trước") : clock(x.a));
const durTxt = (s) => (s >= 3600 ? Math.floor(s / 3600) + " giờ " + pad(Math.floor((s % 3600) / 60)) + " phút" : mmss(s));
const mDur = (x, N) => (x.pre ? "—" : x.state === "done" ? durTxt(x.ok - x.a) : VIEW ? "—" : durTxt(N - x.a) + "+");
function maintActive() { try { return buildIncidents(orders.filter(isMaint), PSW, true).filter((x) => x.state !== "done").length; } catch (e) { return 0; } }
function renderMaint() {
  if (st.maintH >= HOUSES.length) st.maintH = -1;
  chips("mf", HOUSES, st.maintH, (v) => { st.maintH = v; render(); }, true);
  const today = !VIEW;
  if (!today && MPSW.dk !== VIEW) { const dk = VIEW; pswOf(dk).then((L) => { MPSW = { dk, L }; if (st.tab === "maint") render(); }); }
  const L = today ? PSW : MPSW.dk === VIEW ? MPSW.L : [];
  const [from, to] = tfRange("maint"), N = NOWS();
  const allErr = orders.filter((o) => o.st === 3), errs = allErr.filter(isMaint);
  const skipped = allErr.filter((o) => o.t >= from && o.t <= to).length - errs.filter((o) => o.t >= from && o.t <= to).length;
  const hk0 = st.maintH >= 0 ? HOUSES[st.maintH].k : null;
  const inc = buildIncidents(errs, L, today).filter((x) => (!hk0 || x.hk === hk0) && x.a <= to && (x.ok ?? (x.state === "done" ? x.ok : N)) >= from);
  MEV = inc;
  const by = {};
  for (const x of inc) {
    const r = (by[x.K] ??= { K: x.K, hk: x.hk, gk: x.gk, hi: x.hi, gi: x.gi, merch: x.merch, type: x.type, n: 0, err: 0, acc: new Set(), amt: 0, a: x.a, pre: x.pre, why: {}, last: x, dur: 0, descs: new Set() });
    r.n++; r.err += x.list.length; x.list.forEach((o) => { r.acc.add(o.acc); r.amt += o.amt; }); x.descs.forEach((d) => r.descs.add(d));
    if (x.a < r.a) { r.a = x.a; r.pre = x.pre; }
    for (const w in x.why) r.why[w] = (r.why[w] || 0) + x.why[w];
    if ((x.ok ?? 1e9) >= (r.last.ok ?? 1e9) && x.a >= r.last.a) r.last = x;
    r.dur += x.pre ? 0 : x.state === "done" ? x.ok - x.a : today ? N - x.a : 0;
  }
  const rows = Object.values(by).sort((p, q) => (q.last.state !== "done") - (p.last.state !== "done") || q.n - p.n); MROWS = rows;
  const act = inc.filter((x) => x.state !== "done").length, done = inc.length - act;
  const errIn = inc.flatMap((x) => x.list), amt = errIn.reduce((s, o) => s + o.amt, 0);
  const kp = [["Số lần bảo trì", fmt(inc.length), tfLabel("maint"), ""], ["Đang bảo trì", fmt(act), act ? "cổng chưa hoạt động lại" : "không có cổng đang bảo trì", act ? "bad" : "ok"], ["Hoàn tất bảo trì", fmt(done), "BO bật lại + có đơn thành công", "ok"], ["Đơn khách thật bị lỗi", fmt(errIn.length), fmt(new Set(errIn.map((o) => o.acc)).size) + " khách", "slow"], ["Tiền khách nạp không vào", vnd(amt) + " ₫", "", "warn"]];
  $("maint-kpis").innerHTML = kp.map((k) => `<div class="kpi ${k[3]}"><div class="lab">${k[0]}</div><div class="val">${k[1]}</div><div class="sub">${k[2]}</div></div>`).join("");
  $("maint-hint").textContent = tfLabel("maint") + (skipped > 0 ? ` · không tính ${fmt(skipped)} đơn thất bại do khách hoặc BO không ghi lý do` : "");
  let t = `<thead><tr><th class="l">Nhà</th><th class="l">Cổng</th><th class="l">Kênh</th><th>Số lần bảo trì</th><th>Tổng thời gian</th><th>Đơn lỗi</th><th>Khách</th><th>Tiền (₫)</th><th>Bắt đầu lần đầu</th><th class="l">Lý do</th><th class="l">Hiện tại</th><th class="l"></th></tr></thead><tbody>`;
  for (const r of rows) t += `<tr class="${r.last.state === "done" ? "" : r.last.state === "wait" ? "rwarn" : "rbad"}"><td class="name">${esc(hName(r.hk, r.merch))}</td><td class="l">${esc(gName(r.gk, r.type))}</td><td class="l mut">${esc([...r.descs].join(", "))}</td><td class="bad" style="font-weight:700">${fmt(r.n)}</td><td>${r.dur ? durTxt(r.dur) : "—"}</td><td>${fmt(r.err)}</td><td>${fmt(r.acc.size)}</td><td>${vnd(r.amt)}</td><td class="mono">${r.pre ? (VIEW ? "00:00:00" : "Tắt từ trước") : clock(r.a)}</td><td class="l">${esc(whyTxt(r.why) || (r.last.src === "bo" ? "BO tắt kênh" : ""))}</td><td class="l">${mTag(r.last)}</td><td class="l">${r.hi != null && r.gi != null ? `<button class="btn gocell" data-go-list='${JSON.stringify({ s: r.err ? "err" : "all", h: r.hi, g: r.gi, tf: st.tf.maint })}'>Xem đơn</button>` : ""}</td></tr>`;
  if (!rows.length) t += `<tr><td class="l mut" colspan="12">Không có cổng nào bảo trì trong khung thời gian này</td></tr>`;
  $("maint-tbl").innerHTML = t + "</tbody>";
  let u = `<thead><tr><th class="l">Bắt đầu</th><th class="l">Nguồn</th><th class="l">Nhà</th><th class="l">Cổng</th><th class="l">Kênh</th><th>BO bật lại</th><th>Đơn thành công đầu tiên</th><th>Thời gian bảo trì</th><th class="l">Tình trạng</th><th>Đơn lỗi</th><th class="l">Lý do</th><th class="l">Tài khoản bị lỗi</th></tr></thead><tbody>`;
  for (const x of inc.slice(0, 500)) { const ac = [...new Set(x.list.map((o) => o.acc))]; u += `<tr class="${x.state === "done" ? "" : x.state === "wait" ? "rwarn" : "rbad"}"><td class="l mono">${mStart(x)}</td><td class="l">${MSRC[x.src]}</td><td class="name">${esc(hName(x.hk, x.merch))}</td><td class="l">${esc(gName(x.gk, x.type))}</td><td class="l mut">${esc(x.descs.join(", "))}</td><td class="mono">${x.b != null ? clock(x.b) : x.src === "err" ? "—" : "chưa"}</td><td class="mono">${x.ok != null ? clock(x.ok) : "chưa"}</td><td>${mDur(x, N)}</td><td class="l">${mTag(x)}</td><td class="${x.list.length ? "bad" : "mut"}">${fmt(x.list.length)}</td><td class="l">${esc(whyTxt(x.why) || (x.src === "bo" ? "BO tắt kênh" : ""))}</td><td class="l mut">${esc(ac.slice(0, 4).join(", "))}${ac.length > 4 ? "…" : ""}</td></tr>`; }
  if (!inc.length) u += `<tr><td class="l mut" colspan="12">Chưa có đợt nào</td></tr>`;
  $("maint-ev").innerHTML = u + "</tbody>";
  $("maint-sum").textContent = `${fmt(inc.length)} đợt · ${fmt(act)} đang bảo trì`;
  if (today) $("cnt-maint").textContent = act;
}
st.statDay = null; st.statF = "all";
function renderStat() {
  const dk = st.statDay || DAY, today = dk === DAY;
  $("statDay").max = DAY; $("statDay").value = dk;
  $("statF").innerHTML = [["all", "Tất cả"], ["off", "Đang tắt"], ["on", "Đang bật"]].map(([k, n]) => `<button aria-pressed="${st.statF === k}" data-v="${k}">${n}</button>`).join("");
  const off = PSET ? PSET.filter((c) => !c.on || !c.typeOn).length : 0;
  $("cnt-stat").textContent = off;
  const L = today ? PSW : PSWV;
  const kp = [["Tổng kênh nạp", PSET ? fmt(PSET.length) : "—", PSET ? "cập nhật " + new Date(PSAT).toLocaleTimeString("vi-VN", { hour12: false }) : "chưa đọc được", ""], ["Đang bật", PSET ? fmt(PSET.length - off) : "—", "khách nạp được", "ok"], ["Đang tắt (bảo trì)", PSET ? fmt(off) : "—", "Dừng trên BO", "bad"], ["Lần tắt " + (today ? "hôm nay" : dk.split("-").reverse().join("/")), fmt(L.filter((w) => !w.on).length), "ghi từ lúc tool chạy", "warn"], ["Lần bật lại", fmt(L.filter((w) => w.on).length), "", "ok"]];
  $("stat-kpis").innerHTML = kp.map((k) => `<div class="kpi ${k[3]}"><div class="lab">${k[0]}</div><div class="val">${k[1]}</div><div class="sub">${k[2]}</div></div>`).join("");
  renderBoSw(dk);
}
$("statF").addEventListener("click", (e) => { const b = e.target.closest("button"); if (b) { st.statF = b.dataset.v; render(); } });
$("statDay").addEventListener("change", async (e) => { const v = e.target.value; st.statDay = v && v < DAY ? v : null; PSWV = await pswOf(st.statDay || DAY); render(); });
$("statToday").onclick = () => { st.statDay = null; render(); };
async function statRefresh() {
  const b = $("statF5"); if (b.disabled) return; b.disabled = true; $("statF5t").textContent = "Đang đọc BO…";
  try { await loadPaySet(); lastPS = Date.now(); $("statF5t").textContent = "Đã cập nhật " + new Date().toLocaleTimeString("vi-VN", { hour12: false }); }
  catch (e) { PSERR = e.message; $("statF5t").textContent = "Lỗi: thử lại"; }
  finally { b.disabled = false; render(); setTimeout(() => ($("statF5t").textContent = "Làm mới (F5)"), 3000); }
}
$("statF5").onclick = statRefresh;
// F5 trong tab Trạng thái cổng = đọc lại BO ngay, không tải lại cả trang
document.addEventListener("keydown", (e) => { if (e.key === "F5" && st.tab === "stat" && !e.ctrlKey) { e.preventDefault(); statRefresh(); } });
function renderBoSw(dk) {
  const box = $("maint-bo"), past = dk !== DAY;
  if (past) box.innerHTML = `<div class="card-h"><h3>Trạng thái kênh trên BO</h3><span class="hint">Chỉ xem được trạng thái hiện tại khi xem hôm nay. Bên dưới là lịch sử bật/tắt đã ghi của ngày này.</span></div>`;
  else if (!PSET) box.innerHTML = `<div class="card-h"><h3>Trạng thái kênh trên BO</h3><span class="hint">${PSERR ? "Chưa đọc được: " + esc(PSERR) + ". " : "Đang đọc… "}Nếu lâu không hiện, mở trang <b>Cài đặt nạp tiền</b> (bật/dừng kênh) trên BO một lần để tool học cách đọc.</span></div>`;
  else {
    const types = []; for (const c of PSET) { let t = types.find((x) => x.n === c.type); if (!t) types.push((t = { n: c.type, typeOn: c.typeOn, cs: [] })); t.cs.push(c); }
    const off = PSET.filter((c) => !c.on || !c.typeOn).length;
    const F = (c) => st.statF === "all" || (st.statF === "off") === !(c.on && c.typeOn);
    box.innerHTML = `<div class="card-h"><h3>Trạng thái kênh trên BO</h3><span class="hint">Cập nhật ${new Date(PSAT).toLocaleTimeString("vi-VN", { hour12: false })}</span><span class="r mono"><span class="ok">${fmt(PSET.length - off)} bật</span> · <span class="bad">${fmt(off)} tắt</span></span></div>
      <div class="scroll"><table class="tbl sttbl"><thead><tr><th class="l">Hạng mục</th><th class="l">Nhà thứ 3</th><th class="l">Kênh</th><th class="l">Trạng thái</th><th title="Giờ tool thấy BO bật / tắt kênh này hôm nay">Đổi trạng thái lúc</th><th>% phí</th><th>Tối thiểu (₫)</th><th>Tối đa (₫)</th><th title="Cột Tỷ lệ nạp tiền thành công trên BO">Tỷ lệ thành công (BO)</th></tr></thead><tbody>${types.filter((t) => t.cs.some(F)).map((t) => { const n = t.cs.filter((c) => c.on && t.typeOn).length;
        return `<tr class="grp"><td class="l" colspan="9">${esc(t.n)} <span class="${n ? (n < t.cs.length ? "warn" : "ok") : "bad"}" style="margin-left:8px">${n}/${t.cs.length} bật</span>${t.typeOn ? "" : ' <span class="stp off">HẠNG MỤC TẮT</span>'}</td></tr>` +
          t.cs.filter(F).map((c) => { const on = c.on && t.typeOn, s0 = sinceTxt(c); return `<tr class="${on ? "" : "rbad"}"><td class="l mut">${esc(t.n)}</td><td class="name">${esc(c.merch)}</td><td class="l">${esc(c.desc)}</td><td class="l"><span class="stp ${on ? "on" : "off"}"><i></i>${on ? "ĐANG BẬT" : "ĐANG TẮT"}</span></td><td class="mono">${s0 || "—"}</td><td>${c.fee !== "" && c.fee != null ? esc(c.fee) + "%" : "—"}</td><td>${c.cur === "VND" ? fmt(c.min) : c.min}</td><td>${c.cur === "VND" ? fmt(c.max) : c.max}</td><td>${c.rate ? esc(c.rate) + "%" : "—"}</td></tr>`; }).join(""); }).join("")}</tbody></table></div>`;
  }
  $("stat-hint").textContent = past ? "Ngày " + dk.split("-").reverse().join("/") : "Hôm nay · ghi từ lúc tool chạy";
  pswOf(dk).then((L) => {
    PSWV = L; const rows = [...L].sort((a, b) => b.t - a.t);
    let t = `<thead><tr><th class="l">Giờ</th><th class="l">Hạng mục</th><th class="l">Nhà</th><th class="l">Kênh</th><th class="l">Thay đổi trên BO</th><th>Đã tắt trong</th></tr></thead><tbody>`;
    for (const w of rows) { const prev = w.on ? L.filter((x) => x.key === w.key && !x.on && x.t < w.t).map((x) => x.t).pop() : null; t += `<tr class="${w.on ? "" : "rbad"}"><td class="l mono">${clock(w.t)}</td><td class="l">${esc(w.type)}</td><td class="name">${esc(w.merch)}</td><td class="l">${esc(w.desc)}</td><td class="l">${w.on ? '<span class="pill on">Bật lại</span>' : '<span class="pill badp">Tắt (bảo trì)</span>'}</td><td>${prev != null ? mmss(w.t - prev) : "—"}</td></tr>`; }
    if (!rows.length) t += `<tr><td class="l mut" colspan="6">Chưa ghi nhận lần bật/tắt nào ${dk === DAY ? "từ lúc mở tool hôm nay" : "trong ngày này"}</td></tr>`;
    $("maint-sw").innerHTML = t + "</tbody>";
    const offN = {}; for (const w of L) if (!w.on) { const k = w.merch + " · " + w.type; offN[k] = (offN[k] || 0) + 1; }
    $("maint-sw-sum").textContent = `${fmt(L.filter((w) => !w.on).length)} lần tắt · ${fmt(L.filter((w) => w.on).length)} lần bật lại`;
  });
}
$("sxls").onclick = async () => {
  const F = "Times New Roman", S = (o) => Object.assign({ border: true, font: { name: F, size: 10 }, align: { v: "center", wrap: true } }, o || {});
  const HS = S({ font: { name: F, size: 10, bold: true, color: "FFFFFF" }, fill: "0B2A55", align: { h: "center", v: "center", wrap: true } });
  const dk = st.statDay || DAY, d = dk.split("-").reverse().join("/"), tv = (s) => Math.round(s) / 86400;
  const L = await pswOf(dk);
  const wb = new XLSXW.Book();
  const put = (ws, H, W, rows, fm) => { H.forEach((x, i) => { ws.set(1, i + 1, x, HS); ws.width(i + 1, W[i]); }); rows.forEach((r, i) => r.forEach((v, j) => ws.set(i + 2, j + 1, v, S(fm[j] ? { fmt: fm[j] } : {})))); ws.freeze(2, 1); ws.height(1, 30); };
  if (PSET && dk === DAY) put(wb.sheet("Trạng thái hiện tại"), ["Hạng mục", "Nhà thứ 3", "Kênh", "Trạng thái", "Đổi trạng thái lúc", "% phí", "Tối thiểu", "Tối đa", "Tỷ lệ thành công BO (%)"], [18, 16, 20, 10, 12, 8, 14, 16, 13],
    PSET.map((c) => [c.type, c.merch, c.desc, c.on && c.typeOn ? "Bật" : "Tắt", sinceTxt(c) || "", c.fee !== "" && c.fee != null ? Number(c.fee) : "", c.min, c.max, c.rate ? Number(c.rate) : ""]), [0, 0, 0, 0, 0, "0.00", "#,##0", "#,##0", "0.00"]);
  put(wb.sheet("Lịch sử bật tắt"), ["Ngày", "Giờ", "Hạng mục", "Nhà thứ 3", "Kênh", "Thay đổi"], [12, 10, 18, 16, 20, 12],
    [...L].sort((a, b) => b.t - a.t).map((w) => [d, tv(w.t), w.type, w.merch, w.desc, w.on ? "Bật lại" : "Tắt"]), [0, "hh:mm:ss"]);
  const blob = await wb.blob(), now = new Date();
  const el = document.createElement("a"); el.href = URL.createObjectURL(blob); el.download = `Trang_thai_cong_${dk.slice(8)}-${dk.slice(5, 7)}_${pad(now.getHours())}h${pad(now.getMinutes())}.xlsx`; document.body.appendChild(el); el.click(); el.remove();
};
$("mxls").onclick = async () => {
  if (!MEV.length) { sysmsg("Không có đợt bảo trì nào để tải.", "info"); setTimeout(() => sysmsg(""), 3000); return; }
  const F = "Times New Roman", S = (o) => Object.assign({ border: true, font: { name: F, size: 10 }, align: { v: "center", wrap: true } }, o || {});
  const HS = S({ font: { name: F, size: 10, bold: true, color: "FFFFFF" }, fill: "0B2A55", align: { h: "center", v: "center", wrap: true } });
  const tv = (s) => Math.round(s) / 86400, dk = VIEW || DAY, d = dk.split("-").reverse().join("/"), N = NOWS();
  const ST = { done: "Hoàn tất bảo trì", off: "Đang bảo trì (BO đang tắt)", wait: "BO đã bật lại, chờ đơn thành công", err: VIEW ? "Không thấy hoạt động lại" : "Đang bảo trì (tool phát hiện lỗi)" };
  const wb = new XLSXW.Book();
  const put = (ws, H, W, rows, fm) => { H.forEach((x, i) => { ws.set(1, i + 1, x, HS); ws.width(i + 1, W[i]); }); rows.forEach((r, i) => r.forEach((v, j) => ws.set(i + 2, j + 1, v, S(fm[j] ? { fmt: fm[j] } : {})))); ws.freeze(2, 3); ws.height(1, 30); };
  put(wb.sheet("Theo cổng"), ["Ngày", "Nhà thứ 3", "Cổng nạp", "Kênh", "Số lần bảo trì", "Tổng thời gian", "Đơn lỗi", "Khách", "Tiền (₫)", "Bắt đầu lần đầu", "Hiện tại", "Lý do"], [12, 16, 16, 18, 10, 11, 9, 9, 15, 12, 30, 50],
    MROWS.map((r) => [d, hName(r.hk, r.merch), gName(r.gk, r.type), [...r.descs].join(", "), r.n, r.dur ? tv(r.dur) : null, r.err, r.acc.size, r.amt * 1000, r.pre ? "Tắt từ trước" : tv(r.a), ST[r.last.state] + (r.last.ok != null ? " " + clock(r.last.ok) : ""), whyTxt(r.why)]), [0, 0, 0, 0, "#,##0", "[h]:mm:ss", "#,##0", "#,##0", "#,##0", "hh:mm:ss"]);
  put(wb.sheet("Từng đợt"), ["Ngày", "Nhà thứ 3", "Cổng nạp", "Kênh", "Nguồn", "Bắt đầu", "BO bật lại", "Đơn thành công đầu tiên", "Thời gian bảo trì", "Tình trạng", "Đơn lỗi", "Tiền (₫)", "Lý do", "Tài khoản"], [12, 16, 16, 18, 18, 12, 11, 13, 12, 30, 9, 15, 45, 50],
    MEV.map((x) => [d, hName(x.hk, x.merch), gName(x.gk, x.type), x.descs.join(", "), MSRC[x.src], x.pre ? "Tắt từ trước" : tv(x.a), x.b != null ? tv(x.b) : "", x.ok != null ? tv(x.ok) : "Chưa", x.pre ? null : x.state === "done" ? tv(x.ok - x.a) : VIEW ? null : tv(N - x.a), ST[x.state], x.list.length, x.list.reduce((s, o) => s + o.amt, 0) * 1000, whyTxt(x.why), [...new Set(x.list.map((o) => o.acc))].join(", ")]),
    [0, 0, 0, 0, 0, "hh:mm:ss", "hh:mm:ss", "hh:mm:ss", "[h]:mm:ss", 0, "#,##0", "#,##0"]);
  put(wb.sheet("Đơn lỗi"), ["Ngày", "Nhà thứ 3", "Cổng nạp", "Số lệnh", "Tài khoản", "Kênh", "Số tiền (₫)", "Tạo lúc", "Lý do BO"], [12, 16, 18, 24, 18, 14, 15, 10, 50],
    MEV.flatMap((x) => x.list).sort((a, b) => b.t - a.t).map((o) => [d, HOUSES[o.h].n, GATES[o.g].n, o.no, o.acc, o.ch, o.cur === "VND" ? o.amt * 1000 : o.raw, tv(o.t), o.why || ""]), [0, 0, 0, 0, 0, 0, "#,##0", "hh:mm:ss"]);
  const blob = await wb.blob(), now = new Date();
  const el = document.createElement("a"); el.href = URL.createObjectURL(blob); el.download = `Bao_tri_cong_${dk.slice(8)}-${dk.slice(5, 7)}_${pad(now.getHours())}h${pad(now.getMinutes())}.xlsx`; document.body.appendChild(el); el.click(); el.remove();
};

// Mốc thời gian khi tải dữ liệu cổng nạp: Tạo thời gian (dữ liệu tool đã đọc) / Thời gian thành công / Cập nhật thời gian (đọc lại từ BO)
const BASIS = { create: ["Tạo thời gian", null], ok: ["Thời gian thành công", "nt"], upd: ["Cập nhật thời gian", "ut"] };
try { const v = localStorage.getItem("gbasis"); if (v && BASIS[v]) $("gbasis").value = v; } catch (e) {}
$("gbasis").addEventListener("change", () => { try { localStorage.setItem("gbasis", $("gbasis").value); } catch (e) {} });
// Dò mã timeType của BO cho từng mốc.
//  - Thời gian thành công: mã mà các đơn trả về đều có giờ thành công nằm trong khoảng đã chọn
//  - Cập nhật thời gian: mã còn lại mà trang BO đã gửi khi bạn chọn "Cập nhật thời gian" (tool tự ghi nhớ), hoặc mã khác 0 / khác mã thành công
async function findTimeType(kind, from, to) {
  const s = await chrome.storage.local.get(["timeType_ok", "timeType_upd", "orderTT"]);
  const seen = Object.keys(s.orderTT || {}).map(Number).filter((x) => x !== 0 && !isNaN(x));
  const probe = async (tt) => { const d = await BO.listOrders("VND", from, to, 1, 50, tt).catch(() => null); return (d && d.list) || null; };
  const okTest = (L) => { const w = L.filter((r) => Number(r.notifyTime) > 0); return w.length > 0 && w.length >= L.length * 0.9 && w.every((r) => r.notifyTime >= from && r.notifyTime <= to); };
  let okTT = s.timeType_ok;
  if (okTT == null || kind === "ok") {
    for (const tt of [...new Set([okTT, ...seen, 1, 2, 3, 4].filter((x) => x != null && x !== 0))]) {
      const L = await probe(tt); if (L && okTest(L)) { okTT = tt; await chrome.storage.local.set({ timeType_ok: tt }); break; }
    }
  }
  if (kind === "ok") { if (okTT != null) return okTT; throw new Error('Chưa dò được mã "Thời gian thành công" của BO. Mở trang Tổng nạp tiền trên BO, chọn "Thời gian thành công" rồi bấm Tìm kiếm một lần, sau đó thử lại.'); }
  if (s.timeType_upd != null) return s.timeType_upd;
  // BO xếp ô chọn theo thứ tự Tạo → Thành công → Cập nhật → Hết giờ, nên mã Cập nhật thường liền sau mã Thành công
  const cand = [...seen.filter((x) => x !== okTT), ...(okTT != null ? [okTT + 1] : []), ...[2, 1, 3].filter((x) => x !== okTT)];
  for (const tt of [...new Set(cand)]) {
    const L = await probe(tt);
    if (L && L.length) { if (seen.includes(tt)) await chrome.storage.local.set({ timeType_upd: tt }); return tt; }
  }
  throw new Error('Chưa dò được mã "Cập nhật thời gian" của BO. Mở trang Tổng nạp tiền trên BO, chọn "Cập nhật thời gian" rồi bấm Tìm kiếm một lần, sau đó thử lại.');
}
async function fetchByBasis(kind, dk, a, b) {
  const D0 = dayStartOf(dk), from = D0 + a, to = D0 + b, f = BASIS[kind][1];
  sysmsg(`Đang dò mốc <b>${BASIS[kind][0]}</b> trên BO…`, "info");
  const tt = await findTimeType(kind, from, to), out = [];
  for (const cur of curs()) {
    let page = 1, pages = 1;
    while (page <= pages) {
      let d;
      try { d = await BO.listOrders(cur, from, to, page, 500, tt); } catch (e) { if (cur === "USDT" && e.kind === "api") break; throw e; }
      const L = (d && d.list) || [], total = Number(d && d.total) || 0;
      if (page === 1) pages = Math.max(1, Math.ceil(total / Math.max(1, L.length || 500)));
      for (const r of L) {
        const o = BO.norm(r, dk, D0, cur), v = o[f];
        if (kind === "ok" && o.st === 2 && v && (v < from || v > to)) continue;   // chắc chắn đúng mốc thành công
        const bt = v && v >= from && v <= to ? v : o.ts;
        o.t = Math.max(0, Math.min(86399, bt - D0)); out.push(o);
      }
      sysmsg(`Đang tải đơn theo <b>${BASIS[kind][0]}</b> từ BO (${cur}): trang ${page}/${pages} · ${fmt(out.length)} đơn <span class="prog"><span style="width:${(page / pages * 100).toFixed(0)}%"></span></span>`, "info");
      if (!L.length) break; page++;
    }
  }
  return out;
}
// Ô chọn Tình trạng đơn hàng khi tải (giống ô "Tình trạng đơn hàng" trên BO)
const nTxt0 = (t) => String(t || "").normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/gi, "d").toLowerCase();
const OSTS = [
  ["pend", "Thanh toán đang chờ", (o, t) => t.includes("dang cho") || (!t && o.st === 1)],
  ["exp", "Hết thời gian nạp tiền", (o, t) => t.includes("het thoi gian") || (!t && o.st === 4)],
  ["fail", "Đặt cọc không thành công", (o, t) => t.includes("khong thanh cong") || (!t && o.st === 3)],
  ["ok", "Đặt cọc thành công", (o) => o.st === 2],
  ["mcancel", "Thành viên bị hủy", (o, t) => t.includes("thanh vien") && t.includes("huy")],
  ["bcancel", "Hủy trong nền", (o, t) => t.includes("huy trong nen") || (!t && o.st === 5)],
  ["review", "Bổ sung đang được xem xét", (o, t) => t.includes("xem xet")]
];
let GSTAT = new Set(["ok"]);
try { const v = JSON.parse(localStorage.getItem("gstat") || "null"); if (Array.isArray(v) && v.length) GSTAT = new Set(v); } catch (e) {}
const ostKey = (o) => { const t = nTxt0(o.psl); const m = OSTS.find(([, , f]) => f(o, t)); return m ? m[0] : ({ 1: "pend", 2: "ok", 3: "fail", 4: "exp", 5: "bcancel" })[o.st] || "pend"; };
function renderGstat() {
  const cnt = {}; for (const o of inTf("gate")) { if (st.gate !== -1 && o.g !== st.gate) continue; const k = ostKey(o); cnt[k] = (cnt[k] || 0) + 1; }
  const all = GSTAT.size === OSTS.length;
  $("gstatList").innerHTML = `<label class="all"><input type="checkbox" data-all ${all ? "checked" : ""}> Chọn tất cả</label>` + OSTS.map(([k, n]) => `<label><input type="checkbox" data-k="${k}" ${GSTAT.has(k) ? "checked" : ""}> ${n}<small>${cnt[k] ? fmt(cnt[k]) : ""}</small></label>`).join("");
  $("gstatTxt").textContent = all ? "Tất cả tình trạng" : GSTAT.size ? OSTS.filter(([k]) => GSTAT.has(k)).map((x) => x[1]).join(", ") : "Chưa chọn";
}
$("gstatList").addEventListener("change", (e) => {
  const i = e.target; if (i.dataset.all != null) GSTAT = new Set(i.checked ? OSTS.map((x) => x[0]) : []); else if (i.checked) GSTAT.add(i.dataset.k); else GSTAT.delete(i.dataset.k);
  try { localStorage.setItem("gstat", JSON.stringify([...GSTAT])); } catch (_) {}
  renderGstat();
});
$("gstat").addEventListener("toggle", () => { if ($("gstat").open) renderGstat(); });
document.addEventListener("click", (e) => { if ($("gstat").open && !e.target.closest("#gstat")) $("gstat").open = false; });
renderGstat();
// Ô chọn Nhà bên thứ 3 khi tải (giống ô "Nền tảng thanh toán của bên thứ 3" trên BO). Rỗng = tất cả nhà
let GHOUSE = new Set();
try { const v = JSON.parse(localStorage.getItem("ghouse") || "null"); if (Array.isArray(v)) GHOUSE = new Set(v); } catch (e) {}
function houseOpts() {
  const m = new Map(); HOUSES.forEach((h) => m.set(h.k, h.n));
  if (PSET) PSET.forEach((c) => { if (!m.has(c.hk)) m.set(c.hk, c.merch); });
  return [...m.entries()];
}
function renderGhouse() {
  const cnt = {}; for (const o of inTf("gate")) { if (st.gate !== -1 && o.g !== st.gate) continue; const k = HOUSES[o.h] ? HOUSES[o.h].k : ""; cnt[k] = (cnt[k] || 0) + 1; }
  const opts = houseOpts(), all = !GHOUSE.size || opts.every(([k]) => GHOUSE.has(k));
  $("ghouseList").innerHTML = `<label class="all"><input type="checkbox" data-all ${all ? "checked" : ""}> Chọn tất cả</label>` + opts.map(([k, n]) => `<label><input type="checkbox" data-k="${esc(k)}" ${all || GHOUSE.has(k) ? "checked" : ""}> ${esc(n)}<small>${cnt[k] ? fmt(cnt[k]) : ""}</small></label>`).join("");
  $("ghouseTxt").textContent = all ? "Tất cả nhà" : opts.filter(([k]) => GHOUSE.has(k)).map((x) => x[1]).join(", ") || "Chưa chọn";
}
$("ghouseList").addEventListener("change", (e) => {
  const i = e.target, opts = houseOpts().map((x) => x[0]);
  if (i.dataset.all != null) GHOUSE = new Set(i.checked ? [] : ["__none__"]);
  else { if (!GHOUSE.size) GHOUSE = new Set(opts); GHOUSE.delete("__none__"); if (i.checked) GHOUSE.add(i.dataset.k); else GHOUSE.delete(i.dataset.k); if (opts.every((k) => GHOUSE.has(k))) GHOUSE = new Set(); else if (!GHOUSE.size) GHOUSE = new Set(["__none__"]); }
  try { localStorage.setItem("ghouse", JSON.stringify([...GHOUSE])); } catch (_) {}
  renderGhouse();
});
$("ghouse").addEventListener("toggle", () => { if ($("ghouse").open) renderGhouse(); });
document.addEventListener("click", (e) => { if ($("ghouse").open && !e.target.closest("#ghouse")) $("ghouse").open = false; });
const houseOk = (o) => !GHOUSE.size || GHOUSE.has(hkey(o.merch));
renderGhouse();
// Tính theo Thời gian thành công / Cập nhật thời gian ngay từ dữ liệu đã lưu trong máy (không đọc lại BO):
// lấy đơn của ngày đang chọn + ngày hôm trước (đơn tạo tối hôm trước nhưng thành công sau 00:00)
async function localByBasis(kind, dk, a, b) {
  const D0 = dayStartOf(dk), from = D0 + a, to = D0 + b;
  const prev = dayKey(new Date((D0 - 43200) * 1000));
  const cur = dk === DAY ? [...ORD.values()] : dk === VIEW ? [...VORD.values()] : await Store.dayOrders(dk).catch(() => []);
  const old = await Store.dayOrders(prev).catch(() => []);
  const seen = new Set(), out = [];
  for (const o0 of [...cur, ...old]) {
    if (seen.has(o0.no)) continue; seen.add(o0.no);
    const o = { ...o0 }; if (o.st == null || o.ps != null) o.st = BO.stCode(Number(o.ps), o.psl);
    const okT = o.st === 2 ? o.ts + (o.sp || 0) : 0;
    const ut = o.ut > 1e11 ? Math.floor(o.ut / 1000) : o.ut;
    const bt = kind === "ok" ? okT : (ut >= D0 - 86400 && ut <= D0 + 2 * 86400 ? ut : 0) || okT || o.ts;
    if (!bt || bt < from || bt > to) continue;
    o.t = bt - D0; out.push(o);
  }
  GXNOTE = old.length ? "" : `Lưu ý: máy chưa lưu dữ liệu ngày ${prev.split("-").reverse().join("/")}, nên các đơn tạo tối hôm trước nhưng thành công sau 00:00 chưa được tính.`;
  return out;
}
let gxBusy = false, GXNOTE = "";
$("gxls").onclick = async () => {
  if (gxBusy) return; gxBusy = true;
  const btn = $("gxls"); btn.disabled = true;
  try {
    const kind = $("gbasis").value, dk = VIEW || DAY, [a, b] = tfRange("gate"), gn = st.gate >= 0 ? GATES[st.gate].n : "", gk = st.gate >= 0 ? GATES[st.gate].k : null;
    let list;
    if (kind === "create") list = inTf("gate").filter((o) => st.gate === -1 || o.g === st.gate);
    else list = (await localByBasis(kind, dk, a, b)).filter((o) => !gk || (nk(o.gate) || "khac") === gk).filter((o) => SET.exFake === false || !FAKESET.has(o.acc));
    sysmsg("");
    if (!GSTAT.size) { sysmsg("Chọn ít nhất 1 tình trạng đơn hàng.", "info"); setTimeout(() => sysmsg(""), 3000); return; }
    if (GHOUSE.has("__none__")) { sysmsg("Chọn ít nhất 1 nhà bên thứ 3.", "info"); setTimeout(() => sysmsg(""), 3000); return; }
    list = list.filter((o) => GSTAT.has(ostKey(o)) && houseOk(o));
    if (!list.length) { sysmsg("Không có đơn nào khớp tình trạng đã chọn trong khung thời gian này.", "info"); setTimeout(() => sysmsg(""), 3000); return; }
    const stTxt = GSTAT.size === OSTS.length ? "tất cả tình trạng" : OSTS.filter(([k]) => GSTAT.has(k)).map((x) => x[1]).join(", ");
    const hsTxt = GHOUSE.size ? houseOpts().filter(([k]) => GHOUSE.has(k)).map((x) => x[1]).join(", ") : "tất cả nhà";
    const title = `${BASIS[kind][0]} ${dk.split("-").reverse().join("/")} · ${clock(a)} → ${clock(b)}${gn ? " · cổng " + gn : " · tất cả cổng"} · ${hsTxt} · ${stTxt} · ${fmt(list.length)} đơn`;
    const blob = await Report.gateData(list, dk, { title, gate: gn, basis: BASIS[kind][0], status: stTxt });
    const el = document.createElement("a"); el.href = URL.createObjectURL(blob);
    el.download = `Du_lieu_cong_nap_${{ create: "tao", ok: "thanhcong", upd: "capnhat" }[kind]}_${dk.slice(8)}-${dk.slice(5, 7)}_${clock(a).slice(0, 5).replace(":", "h")}-${clock(b).slice(0, 5).replace(":", "h")}${gn ? "_" + nk(gn) : ""}.xlsx`;
    document.body.appendChild(el); el.click(); el.remove(); setTimeout(() => URL.revokeObjectURL(el.href), 4000);
    if (kind !== "create" && GXNOTE) { sysmsg(GXNOTE, "info"); setTimeout(() => sysmsg(""), 8000); }
  } catch (e) { sysmsg("Không tải được: " + esc(e.message), "err"); }
  finally { gxBusy = false; btn.disabled = false; }
};

// ===== XEM NGÀY CŨ =====
function viewBanner(extra) {
  sysmsg(`Đang xem dữ liệu <b>ngày ${VIEW.split("-").reverse().join("/")}</b> (${fmt(VORD.size)} đơn, đã lưu trong máy). Số dư và cảnh báo trực tiếp vẫn chạy nền cho hôm nay.${extra || ""}`, "info", ` <button class="btn" id="backToday">Về hôm nay</button>`);
  const b = document.getElementById("backToday"); if (b) b.onclick = () => setView(null);
}
let viewLoading = false;
async function setView(dk) {
  if (!dk || dk >= DAY) { VIEW = null; VORD.clear(); syncPicks(); $("dayLbl").textContent = "Hôm nay"; sysmsg(""); rebuild(); render(); $("readCount").textContent = fmt(ORD.size); return; }
  if (viewLoading) return;
  viewLoading = true;
  try {
    const d0 = dayStartOf(dk);
    const info = await Store.getDay(dk);
    let list = await Store.dayOrders(dk);
    if (!info || !info.complete || !list.length) {
      // chưa có đủ trong máy -> tải 1 lần từ BO rồi lưu lại, lần sau mở ngay
      for (const cur of curs()) {
        try { await fetchRange(cur, dk, d0, d0 + 86399, 0, (p, ps, got, total) => sysmsg(`Đang tải dữ liệu ngày ${dk.split("-").reverse().join("/")} từ BO (${cur}): trang ${p}/${ps} · ${fmt(got)}/${fmt(total)} đơn <span class="prog"><span style="width:${(p / ps * 100).toFixed(0)}%"></span></span>`, "info")); }
        catch (e) { if (!(cur === "USDT" && e.kind === "api")) throw e; }
      }
      await Store.setDay(dk, { day: dk, complete: true, at: Date.now() });
      list = await Store.dayOrders(dk);
    }
    VIEW = dk; VIEW0 = d0; VORD.clear();
    for (const o of list) { o.st = BO.stCode(Number(o.ps), o.psl); VORD.set(o.no, o); }
    for (const k in st.tf) st.tf[k] = "day";
    $("dayLbl").textContent = "Ngày"; $("dayRange").textContent = dk.slice(8) + "/" + dk.slice(5, 7) + " 00:00 → 23:59"; $("readCount").textContent = fmt(VORD.size);
    syncPicks(); rebuild(); segs(); render(); viewBanner();
  } catch (e) { sysmsg("Không tải được dữ liệu ngày này: " + esc(e.message), "err"); }
  finally { viewLoading = false; }
}
// ô chọn ngày ở thanh trên và trong từng mục đều đồng bộ với nhau
const PICKS = () => [$("viewDay"), ...document.querySelectorAll(".dayPick")];
function syncPicks() { PICKS().forEach((p) => { p.max = DAY; p.value = VIEW || DAY; }); }
$("viewDay").addEventListener("change", (e) => setView(e.target.value)); // ô ngày trong từng mục chỉ áp dụng khi bấm Tìm
$("viewToday").onclick = () => setView(null);
document.querySelectorAll(".dayNow").forEach((b) => (b.onclick = async () => { const k = b.closest(".qrow").dataset.k; await setView(null); st.tf[k] = TF()[3][0]; segs(); render(); }));
syncPicks();

// ===== điều hướng =====
function render() {
  derive(); pendBadge();
  ({ home: renderHome, house: renderHouse, gate: renderGate, speed: renderSpeed, pend: renderPend, fee: renderFee, fake: renderFake, maint: renderMaint, stat: renderStat })[st.tab]();
  if (st.tab !== "stat") $("cnt-stat").textContent = PSET ? PSET.filter((c) => !c.on || !c.typeOn).length : 0;
  if (st.tab !== "maint") $("cnt-maint").textContent = maintActive();
  if (st.tab !== "fake") $("cnt-fake").textContent = fakeRows(ALL).filter((r) => r.lv !== "mark").length;
  if (st.tab !== "home") $("cnt-alert").textContent = alerts().length;
}
function go(tab) {
  st.tab = tab; document.querySelectorAll(".nav button").forEach((b) => b.setAttribute("aria-selected", b.dataset.tab === tab));
  document.querySelectorAll(".page").forEach((p) => (p.hidden = p.id !== "p-" + tab)); segs(); render();
  try { localStorage.setItem("tab", tab); } catch (e) {}
}
document.querySelector(".nav").addEventListener("click", (e) => { const b = e.target.closest("button"); if (b) go(b.dataset.tab); });
document.addEventListener("click", (e) => {
  const L = e.target.closest("[data-go-list]");
  if (L) {
    e.stopPropagation(); e.preventDefault();
    const o = JSON.parse(L.dataset.goList);
    st.ostat = o.s; st.pendMin = o.m || 0; st.pendH = o.h ?? -1; st.pendG = o.g ?? -1; st.tf.list = o.tf || "day"; if (o.tf === "custom") st.cust.list = o.cu || st.cust[st.tab] || st.cust.list; st.page = 0; st.q = ""; $("psearch").value = "";
    go("pend"); window.scrollTo({ top: document.querySelector(".nav").offsetTop - 8, behavior: "smooth" }); return;
  }
  const gt = e.target.closest("[data-go-tab]"); if (gt) { go(gt.dataset.goTab); window.scrollTo({ top: 0 }); return; }
  const g = e.target.closest("[data-go-house]"); if (g) { st.house = +g.dataset.goHouse; go("house"); window.scrollTo({ top: 0 }); return; }
  const p = e.target.closest("[data-pick-house]"); if (p) { st.house = +p.dataset.pickHouse; render(); }
});
$("psearch").addEventListener("input", (e) => { st.q = e.target.value; st.page = 0; render(); });

// ===== giao diện: phông, cỡ chữ, sáng/tối, ảnh nền =====
$("fontSel").addEventListener("change", (e) => { document.body.dataset.font = e.target.value; try { localStorage.setItem("font", e.target.value); } catch (_) {} });
document.querySelector('[aria-label="Cỡ chữ"]').addEventListener("click", (e) => { const b = e.target.closest("button"); if (!b) return; document.body.dataset.size = b.dataset.size; b.parentNode.querySelectorAll("button").forEach((x) => x.setAttribute("aria-pressed", x === b)); try { localStorage.setItem("size", b.dataset.size); } catch (_) {} });
try { const f = localStorage.getItem("font"); if (f) { $("fontSel").value = f; document.body.dataset.font = f; } const z = localStorage.getItem("size"); if (z) document.querySelector(`[data-size="${z}"]`)?.click(); } catch (_) {}
// Ảnh nền: giao diện Tối dùng ảnh đêm, giao diện Sáng dùng ảnh ban ngày; tự đổi mỗi 8 giây
const BG = (() => {
  let k = 0;
  const list = () => [...document.querySelectorAll(".bn-bg")].filter((e) => e.dataset.mode === (document.body.dataset.skin === "b" ? "light" : "dark"));
  function show(i) { const l = list(); k = ((i % l.length) + l.length) % l.length; document.querySelectorAll(".bn-bg").forEach((e) => e.classList.toggle("on", e === l[k])); }
  if (!matchMedia("(prefers-reduced-motion: reduce)").matches) setInterval(() => show(k + 1), 8000);
  return { reset: () => show(0) };
})();
// Tự động: 06:00–17:59 giao diện Sáng (ảnh ban ngày), còn lại giao diện Tối (ảnh đêm)
let SKIN = "auto";
const autoSkin = () => { const h = new Date().getHours(); return h >= 6 && h < 18 ? "b" : "a"; };
function applySkin() { const want = SKIN === "auto" ? autoSkin() : SKIN; if (document.body.dataset.skin !== want) { document.body.dataset.skin = want; BG.reset(); } }
document.querySelector('[aria-label="Giao diện"]').addEventListener("click", (e) => { const b = e.target.closest("button"); if (!b) return; SKIN = b.dataset.skin; b.parentNode.querySelectorAll("button").forEach((x) => x.setAttribute("aria-pressed", x === b)); applySkin(); BG.reset(); try { localStorage.setItem("skin", SKIN); } catch (_) {} });
try { const s = localStorage.getItem("skin"); document.querySelector(`[data-skin="${s || "auto"}"]`)?.click(); } catch (_) { $("sk-auto").click(); }
setInterval(applySkin, 60000);
const THU = ["Chủ nhật", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"];
function tickClock() { const d = new Date(); $("bnClock").textContent = d.toLocaleTimeString("vi-VN", { hour12: false }); $("bnDate").textContent = THU[d.getDay()] + ", " + pad(d.getDate()) + "/" + pad(d.getMonth() + 1) + "/" + d.getFullYear(); }
setInterval(tickClock, 1000); tickClock();
$("verTxt").textContent = "v" + chrome.runtime.getManifest().version;
$("scanEvery").textContent = CFG.SCAN_SEC;

// ===== thông báo hệ thống =====
function sysmsg(text, kind, actions) {
  const el = $("sysmsg");
  if (!text) { el.hidden = true; return; }
  el.hidden = false; el.className = "sysmsg " + (kind || "info");
  el.innerHTML = `<span>${text}</span>` + (actions || "");
}
function runState(kind, txt) { const r = $("bnRun"); r.className = "bn-run" + (kind === "ok" ? "" : kind === "err" ? " err" : " idle"); $("bnRunTxt").textContent = txt; }

// ===== quét đơn =====
let scanning = false, lastFull = 0, lastBal = 0, lastOk = 0, timer = null, alerted = new Set();
async function ingest(list, cur, dayK, d0) {
  const changed = [];
  for (const rec of list) {
    const o = BO.norm(rec, dayK, d0, cur);
    noteFee(o);
    if (dayK !== DAY) { changed.push(o); continue; }
    const prev = ORD.get(o.no);
    if (!prev || prev.st !== o.st || prev.sp !== o.sp || prev.fee !== o.fee || prev.nOk !== o.nOk || prev.nAll !== o.nAll) { ORD.set(o.no, o); changed.push(o); }
  }
  if (changed.length) await Store.putOrders(changed.map(({ h, g, t, ...x }) => x));
  return changed.length;
}
// Đọc 1 trang đơn; tự nhận biết BO cho tối đa bao nhiêu đơn/trang
let pageSize = CFG.PAGE_SIZE;
async function getPage(cur, from, to, page) {
  let d;
  try { d = await BO.listOrders(cur, from, to, page, pageSize); }
  catch (e) { if (e.kind === "api" && pageSize > CFG.PAGE_SIZE_MIN && page === 1) { pageSize = CFG.PAGE_SIZE_MIN; d = await BO.listOrders(cur, from, to, page, pageSize); } else throw e; }
  const list = (d && d.list) || [], total = Number(d && d.total) || 0;
  if (page === 1 && list.length && list.length < pageSize && total > list.length) pageSize = list.length; // BO giới hạn số đơn/trang
  return { list, total, pages: Math.max(1, Math.ceil(total / pageSize)) };
}
async function fetchRange(cur, dayK, from, to, stopBefore, onProg) {
  const d0 = dayStartOf(dayK);
  let page = 1, pages = 1, got = 0;
  while (page <= pages) {
    const r = await getPage(cur, from, to, page); pages = r.pages;
    await ingest(r.list, cur, dayK, d0); got += r.list.length;
    if (onProg) onProg(page, pages, got, r.total);
    if (!r.list.length) break;
    if (stopBefore && Math.min(...r.list.map((x) => Number(x.createTime) || 0)) < stopBefore) break;
    page++;
  }
  return got;
}
function curs() { return SET.usdt ? ["VND", "USDT"] : ["VND"]; }
let usdtOk = true;
// Tải toàn bộ đơn trong ngày theo từng lượt, lỗi giữa chừng thì lượt sau đọc tiếp từ trang đang dở
let job = null;
async function runJob(deadline) {
  while (job && Date.now() < deadline) {
    const cur = curs()[job.ci];
    if (!cur) {
      lastFull = Date.now(); job = null; Store.kvSet("job", null).catch(() => {});
      await Store.setDay(DAY, { day: DAY, complete: false, at: Date.now() });
      return true;
    }
    if (cur === "USDT" && !usdtOk) { job.ci++; job.page = 1; continue; }
    let r;
    try { r = await getPage(cur, DAY0, DAY0 + 86399, job.page); }
    catch (e) { if (cur === "USDT" && e.kind === "api") { usdtOk = false; job.ci++; job.page = 1; continue; } throw e; }
    await ingest(r.list, cur, DAY, DAY0);
    job.pages = r.pages; job.total = r.total; job.got += r.list.length;
    if (job.kind === "full") Store.kvSet("job", { day: DAY, ci: job.ci, page: job.page, pages: r.pages, at: Date.now() }).catch(() => {});
    if (job.kind === "full") {
      $("readCount").textContent = fmt(ORD.size);
      sysmsg(`${job.resumed ? "Đang tải tiếp" : "Đang tải"} đơn hôm nay (${cur}): trang ${job.page}/${r.pages} · ${fmt(ORD.size)}/${fmt(r.total)} đơn <span class="prog"><span style="width:${(job.page / r.pages * 100).toFixed(0)}%"></span></span>`, "info");
      if (job.page % 4 === 0) { rebuild(); render(); }
    }
    if (!r.list.length || job.page >= r.pages) { job.ci++; job.page = 1; } else job.page++;
  }
  return !job;
}
let catchUpFrom = 0, lastWide = Date.now();   // mở lại tool: đọc bù từ lần quét cuối, không tải lại cả ngày
let incPage = 0;   // trang đang đọc bù dở (giữ qua các lượt quét)
async function incremental(deadline) {
  const stop = Math.min(nowU() - CFG.INC_WINDOW_MIN * 60, catchUpFrom || Infinity);
  for (const cur of curs()) {
    if (cur === "USDT" && !usdtOk) continue;
    const resume = cur === "VND" && catchUpFrom && incPage > 1;
    for (let page = 1; Date.now() < deadline; page++) {
      if (resume && page === 2) page = Math.max(2, incPage);   // đọc trang mới nhất trước, rồi đọc tiếp chỗ dở
      let r;
      try { r = await getPage(cur, DAY0, DAY0 + 86399, page); }
      catch (e) { if (cur === "USDT" && e.kind === "api") { usdtOk = false; break; } throw e; }
      await ingest(r.list, cur, DAY, DAY0);
      if (cur === "VND" && catchUpFrom) incPage = page + 1;
      if (!r.list.length || page >= r.pages || Math.min(...r.list.map((x) => Number(x.createTime) || 0)) < stop) {
        if (cur === "VND") { catchUpFrom = 0; incPage = 0; }
        break;
      }
    }
    if (Date.now() >= deadline) break;
  }
}
// Số dư: listV2 có lúc trả thiếu số dư (trống) cho một số nhà -> tool tự gọi "làm mới số dư" cho từng nhà
const BALT = {};   // id -> {bal, at} số dư đọc được gần nhất của từng nhà
let balQ = [];     // hàng đợi nhà cần làm mới số dư
async function loadBalances(refresh) {
  const recs = await BO.listBalances();
  for (const r of recs) {
    const v = r.balance;
    if (v != null && v !== "" && !refresh) { if (!BALT[r.id] || BALT[r.id].src !== "refresh" || Date.now() - BALT[r.id].at > 10 * 60e3) BALT[r.id] = { bal: Number(v), at: Date.now(), src: "list" }; }
    else if (!balQ.includes(r.id)) balQ.push(r.id);
  }
  if (refresh) {
    let i = 0;
    for (const r of recs) {
      sysmsg(`Đang làm mới số dư ${++i}/${recs.length}: ${esc(r.merchName)}…`, "info");
      await refreshOne(r.id);
    }
    balQ = [];
  }
  // Mỗi nhà có thể có nhiều bản ghi (kênh nạp, kênh rút). Số dư nằm ở bản ghi kênh RÚT (có balanceUrl / merchType 2).
  const score = (r) => (r.balanceUrl ? 8 : 0) + (r.merchType === 2 ? 4 : 0) + (r.withdrawUrl ? 2 : 0) + (r.status === 1 ? 1 : 0) + (BALT[r.id] ? 1 : 0);
  BAL = {}; for (const r of recs) { const k = hkey(r.merchName); if (!BAL[k] || score(r) > score(BAL[k])) BAL[k] = r; }
  applyBal(); balAt = Date.now(); lastBal = Date.now();
}
const BALERR = {};
async function refreshOne(id) {
  try {
    const v = await BO.refreshBalance(id);
    if (v != null && v !== "" && !isNaN(Number(v))) { BALT[id] = { bal: Number(v), at: Date.now(), src: "refresh" }; delete BALERR[id]; }
    else BALERR[id] = "BO không trả số dư";
  } catch (e) { if (e.kind === "login") throw e; BALERR[id] = e.message.replace(/^BO báo lỗi: /, ""); }
}
function applyBal() { for (const k in BAL) { const r = BAL[k], t = BALT[r.id]; r.balance = t ? t.bal : null; r.balAt = t ? t.at : 0; } Store.kvSet("balt", BALT).catch(() => {}); }
// mỗi lượt quét làm mới thêm vài nhà (ưu tiên nhà đang trống số dư), để mọi nhà đều có số dư mới
async function balanceStep(n) {
  const ids = Object.values(BAL).map((r) => r.id);
  balQ = balQ.filter((id) => ids.includes(id));
  for (const id of ids) if (!BALT[id] && !balQ.includes(id)) balQ.push(id);
  const order = [...balQ, ...ids.filter((id) => !balQ.includes(id)).sort((x, y) => (BALT[x]?.at || 0) - (BALT[y]?.at || 0))];
  for (const id of order.slice(0, n)) { await refreshOne(id); balQ = balQ.filter((x) => x !== id); }
  applyBal();
}
async function rollDay() {
  const today = dayKey(new Date());
  if (today === DAY) return false;
  // chốt ngày cũ: đối soát lại lần cuối
  try { const old = DAY, o0 = DAY0; for (const cur of curs()) await fetchRange(cur, old, o0, o0 + 86399, o0 + 86400 - 3600); await Store.setDay(old, { day: old, complete: true, at: Date.now() }); } catch (e) { /* bỏ qua */ }
  DAY = today; DAY0 = dayStartOf(DAY); ORD.clear(); lastFull = 0; job = null; alerted.clear();
  Store.prune(CFG.KEEP_DAYS).catch(() => {});
  return true;
}
function notifyNew() {
  const al = alerts().filter((a) => a.lv === "bad");
  const fresh = al.filter((a) => !alerted.has(a.k));
  al.forEach((a) => alerted.add(a.k));
  for (const k of [...alerted]) if (!al.find((a) => a.k === k)) alerted.delete(k);
  if (fresh.length && SET.sound) {
    try { const c = new AudioContext(); [0, 0.25, 0.5].forEach((t) => { const o = c.createOscillator(), g = c.createGain(); o.frequency.value = 880; o.connect(g); g.connect(c.destination); g.gain.setValueAtTime(0.15, c.currentTime + t); g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + t + 0.2); o.start(c.currentTime + t); o.stop(c.currentTime + t + 0.22); }); } catch (e) {}
    chrome.runtime.sendMessage({ type: "notify", title: "Cổng nạp cần tắt", text: fresh.map((a) => a.t).join(", ") });
  }
}
async function tick() {
  if (scanning || !licensed) return;
  scanning = true;
  const deadline = Date.now() + CFG.TICK_BUDGET_SEC * 1000;
  try {
    if (await rollDay()) { rebuild(); render(); }
    if (!lastBal || Date.now() - lastBal > CFG.BAL_MIN * 60e3) { try { await loadBalances(false); } catch (e) { if (e.kind === "login" || e.kind === "net") throw e; } }
    if (!lastPS || Date.now() - lastPS > PS_MIN * 60e3) { lastPS = Date.now(); try { await loadPaySet(); } catch (e) { if (e.kind === "login" || e.kind === "net") throw e; PSERR = e.message; } }
    if (!lastFull) {
      if (!job || job.kind !== "full") job = { kind: "full", ci: 0, page: 1, pages: 1, total: 0, got: 0 };
      runState("idle", "ĐANG TẢI");
      if (catchUpFrom) await incremental(Math.min(deadline, Date.now() + 12000));   // đọc bù đơn mới vào trong lúc tool tắt
      if (job.page > 2) { try { await ingest((await getPage("VND", DAY0, DAY0 + 86399, 1)).list, "VND", DAY, DAY0); } catch (e) { if (e.kind !== "api") throw e; } }  // cập nhật đơn mới nhất trong lúc tải cả ngày
      if (balQ.length) { try { await balanceStep(4); } catch (e) { if (e.kind === "login") throw e; } }
      const done = await runJob(deadline);
      rebuild(); render(); await saveFee();
      $("readCount").textContent = fmt(ORD.size);
      if (!done) { scanning = false; setTimeout(tick, 300); return; }   // tải tiếp ngay, không chờ 30 giây
    } else {
      if (!catchUpFrom && Date.now() - lastWide > CFG.RESYNC_MIN * 60e3) { catchUpFrom = nowU() - 3 * 3600; lastWide = Date.now(); }  // định kỳ đọc lại 3 giờ gần nhất
      await incremental(deadline);
      if (job) await runJob(deadline);
    }
    try { await balanceStep(balQ.length ? 4 : 2); } catch (e) { if (e.kind === "login") throw e; }
    rebuild(); render(); await saveFee();
    lastOk = Date.now();
    if (lastFull) Store.setDay(DAY, { day: DAY, complete: false, at: Date.now(), full: lastFull }).catch(() => {});
    $("lastScan").textContent = new Date().toLocaleTimeString("vi-VN", { hour12: false });
    if (!VIEW) { $("readCount").textContent = fmt(ORD.size); $("dayRange").textContent = DAY.slice(8) + "/" + DAY.slice(5, 7) + " 00:00 → " + new Date().toLocaleTimeString("vi-VN", { hour12: false }).slice(0, 5); }
    runState("ok", "ĐANG QUÉT"); if (VIEW) viewBanner(); else sysmsg(job && job.kind === "resync" ? `Đang đối soát lại đơn trong ngày: trang ${job.page}/${job.pages}` : "", "info");
    if (!VIEW) notifyNew();
  } catch (e) {
    console.warn(e);
    const a = await BO.auth();
    const openBtn = ` <button class="btn" id="openBo">Mở BO</button>`;
    if (e.kind === "login") {
      runState("err", "MẤT ĐĂNG NHẬP");
      sysmsg("Mất đăng nhập BO. Mở BO trên Chrome này, đăng nhập rồi vào trang <b>Tổng nạp nhanh</b> một lần — tool sẽ tự quét lại." + (a ? "" : " (Tool chưa lấy được phiên đăng nhập.)"), "err", openBtn);
    } else {
      runState("err", "LỖI KẾT NỐI");
      sysmsg(esc(e.message) + " · Tool tự thử lại sau " + CFG.SCAN_SEC + " giây, dữ liệu đã đọc vẫn giữ nguyên" + (a ? "" : " · Nếu vừa cài tool: mở BO và vào trang Tổng nạp nhanh một lần để tool lấy phiên đăng nhập."), "err", openBtn);
    }
    const b = document.getElementById("openBo"); if (b) b.onclick = async () => chrome.tabs.create({ url: "https://" + (await BO.domain()) + "/" });
  } finally { scanning = false; }
}

// ===== Xuất Excel =====
(function () {
  let mode = "upto";
  $("xh1").innerHTML = Array.from({ length: 24 }, (_, h) => `<option value="${h}">${pad(h)}:00 – ${h < 23 ? pad(h + 1) + ":00" : "23:59"}</option>`).join("");
  const nm = () => {
    const d1 = $("xd1").value, d2 = $("xd2").value; if (!d1 || !d2) return;
    const f = (d) => d.slice(8) + "-" + d.slice(5, 7);
    const k = mode === "day" ? "ca-ngay" : mode === "upto" ? "00h-" + $("xt").value.replace(":", "h") : pad($("xh1").value) + "h-" + pad(+$("xh1").value + 1) + "h";
    $("xname").textContent = `Toc_do_len_diem_${d1 === d2 ? f(d1) + "-" + d1.slice(0, 4) : f(d1) + "_" + f(d2) + "-" + d2.slice(0, 4)}_${k}.xlsx`;
  };
  $("xmode").onclick = (e) => { const b = e.target.closest("button"); if (!b) return; mode = b.dataset.v; $("xmode").querySelectorAll("button").forEach((x) => x.setAttribute("aria-pressed", x === b)); $("xupto").hidden = mode !== "upto"; $("xhour").hidden = mode !== "hour"; nm(); };
  $("xt").addEventListener("input", () => { const d = $("xt").value.replace(/\D/g, "").slice(0, 4); $("xt").value = d.replace(/^(\d{2})(\d)/, "$1:$2"); });
  $("xt").addEventListener("blur", () => { const p = $("xt").value.split(":").map((x) => parseInt(x, 10) || 0); $("xt").value = pad(Math.min(23, p[0] || 0)) + ":" + pad(Math.min(59, p[1] || 0)); nm(); });
  ["xd1", "xd2", "xt", "xh1"].forEach((i) => $(i).addEventListener("input", nm));
  $("btn-xls").onclick = () => {
    const now = new Date();
    $("xd1").value = $("xd1").value || DAY; $("xd2").value = $("xd2").value || DAY;
    $("xt").value = pad(now.getHours()) + ":" + pad(now.getMinutes()); $("xh1").value = String(Math.max(0, now.getHours() - 1));
    $("xback").hidden = false; $("xmsg").hidden = true; nm();
  };
  $("xclose").onclick = () => ($("xback").hidden = true);
  $("xback").onclick = (e) => { if (e.target.id === "xback") $("xback").hidden = true; };
  const msg = (t) => { $("xmsg").hidden = false; $("xmsg").innerHTML = t; };
  $("xgo").onclick = async () => {
    const d1 = $("xd1").value, d2 = $("xd2").value;
    if (!d1 || !d2 || d1 > d2) return msg("Chọn ngày bắt đầu và kết thúc hợp lệ.");
    const days = []; for (let d = new Date(d1); dayKey(d) <= d2; d.setDate(d.getDate() + 1)) days.push(dayKey(d));
    if (days.length > 31) return msg("Mỗi lần xuất tối đa 31 ngày.");
    $("xgo").disabled = true;
    try {
      let all = [];
      for (const dk of days) {
        let list;
        if (dk === DAY) list = [...ORD.values()];
        else {
          const info = await Store.getDay(dk);
          list = await Store.dayOrders(dk);
          if (!info || !info.complete) {
            msg(`Ngày ${dk.split("-").reverse().join("/")} chưa có đủ trong máy, đang tải từ BO…`);
            const d0 = dayStartOf(dk);
            for (const cur of curs()) {
              try { await fetchRange(cur, dk, d0, d0 + 86399, 0, (p, ps) => msg(`Đang tải ngày ${dk.split("-").reverse().join("/")} (${cur}): trang ${p}/${ps}…`)); }
              catch (e) { if (!(cur === "USDT" && e.kind === "api")) throw e; }
            }
            if (dk < DAY) await Store.setDay(dk, { day: dk, complete: true, at: Date.now() });
            list = await Store.dayOrders(dk);
          }
        }
        const d0 = dayStartOf(dk);
        all = all.concat(list.map((o) => ({ ...o, t: o.ts - d0 })));
      }
      let from = 0, to = 86400, suffix = "", title = "";
      if (mode === "upto") { const [h, m] = $("xt").value.split(":").map(Number); to = h * 3600 + m * 60 + 59; suffix = "00:00 - " + $("xt").value; }
      if (mode === "hour") { const h = +$("xh1").value; from = h * 3600; to = from + 3599; suffix = pad(h) + ":00 - " + (h < 23 ? pad(h + 1) + ":00" : "23:59"); }
      all = all.filter((o) => o.t >= from && o.t <= to);
      title = days[0].split("-").reverse().join("/") + (days.length > 1 ? " → " + days[days.length - 1].split("-").reverse().join("/") : "") + (suffix ? " · " + suffix : " · cả ngày");
      msg("Đang tạo file Excel…");
      const blob = await Report.build(all, days, { suffix, title });
      const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = $("xname").textContent; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 4000);
      msg("Đã tải file <b>" + esc($("xname").textContent) + "</b> (" + fmt(all.filter((o) => o.st === 2).length) + " đơn thành công).");
    } catch (e) { msg("Không xuất được: " + esc(e.message)); }
    finally { $("xgo").disabled = false; }
  };
})();

// ===== Tải Excel danh sách đơn đang xem =====
$("pxls").onclick = async () => {
  const list = LIST.slice(), kind = st.ostat, N = NOWS();
  if (!list.length) { sysmsg("Danh sách đang trống, không có gì để tải.", "info"); setTimeout(() => sysmsg(""), 3000); return; }
  const F = "Times New Roman", B = { border: true, align: { v: "center" } };
  const S = (o) => Object.assign({}, B, { font: { name: F, size: 10 } }, o || {});
  const H = S({ font: { name: F, size: 10, bold: true, color: "FFFFFF" }, fill: "0B2A55", align: { h: "center", v: "center", wrap: true } });
  const tz = new Date().getTimezoneOffset() * 60;
  const xdt = (ts) => (ts - tz) / 86400 + 25569;          // giờ Việt Nam -> số ngày Excel
  const dur = (s) => Math.round(s) / 86400;
  const stTxt = (o) => { const k = stOf(o); return k === "ok" ? "Thành công" : k === "err" ? o.psl || "Thất bại" : k === "aband" ? (o.st >= 4 ? o.psl || "Hết hạn" : "Chờ quá 30 phút") : "Đang chờ"; };
  const cols = [["Số lệnh", 24, (o) => o.no, S()], ["Tài khoản", 18, (o) => o.acc, S()], ["Số lần nạp thành công", 11, (o) => o.nOk, S({ fmt: "#,##0", align: { h: "center", v: "center" } })], ["Tổng số lần nạp", 10, (o) => o.nAll, S({ fmt: "#,##0", align: { h: "center", v: "center" } })], ["Nhãn", 9, (o) => NTAG[o.ntag] || "", S()], ["Nhà thứ 3", 14, (o) => HOUSES[o.h].n, S()], ["Cổng nạp", 16, (o) => GATES[o.g].n, S()], ["Kênh", 13, (o) => o.ch, S()],
    ["Tỷ lệ phí", 9, (o) => o.fee / 100, S({ fmt: "0.00%" })], ["Số tiền (₫)", 15, (o) => (o.cur === "VND" ? o.amt * 1000 : o.raw), S({ fmt: "#,##0" })], ["Tạo lúc", 19, (o) => xdt(o.ts), S({ fmt: "dd/mm/yyyy hh:mm:ss" })]];
  if (kind === "pend") cols.push(["Đã chờ", 11, (o) => dur(N - o.t), S({ fmt: "[h]:mm:ss" })]);
  else if (kind === "ok") cols.push(["Thành công lúc", 19, (o) => xdt(o.ts + o.sp), S({ fmt: "dd/mm/yyyy hh:mm:ss" })], ["Lên điểm sau", 11, (o) => dur(o.sp), S({ fmt: "[h]:mm:ss" })], ["Phí (₫)", 12, (o) => (o.cur === "VND" ? o.amt * 1000 * o.fee / 100 : null), S({ fmt: "#,##0" })]);
  else if (kind === "err") cols.push(["Tình trạng", 22, stTxt, S()], ["Lý do (BO)", 50, (o) => o.why || "", S({ align: { v: "center", wrap: true } })]);
  else if (kind === "aband") cols.push(["Tình trạng", 22, stTxt, S()], ["Thời gian từ lúc tạo", 13, (o) => dur(N - o.t), S({ fmt: "[h]:mm:ss" })]);
  else cols.push(["Tình trạng", 22, stTxt, S()], ["Thành công lúc", 19, (o) => (o.st === 2 ? xdt(o.ts + o.sp) : null), S({ fmt: "dd/mm/yyyy hh:mm:ss" })], ["Lên điểm sau", 11, (o) => (o.st === 2 ? dur(o.sp) : null), S({ fmt: "[h]:mm:ss" })], ["Đã chờ", 11, (o) => (stOf(o) === "pend" ? dur(N - o.t) : null), S({ fmt: "[h]:mm:ss" })], ["Lý do (BO)", 40, (o) => o.why || "", S()]);
  const wb = new XLSXW.Book(); const ws = wb.sheet(OST.find((x) => x[0] === kind)[1].replace(/[\\/?*\[\]:]/g, "-"));
  cols.forEach((c, i) => { ws.set(1, i + 1, c[0], H); ws.width(i + 1, c[1]); });
  list.forEach((o, r) => cols.forEach((c, i) => ws.set(r + 2, i + 1, c[2](o), c[3])));
  const last = list.length + 2, sc = cols.findIndex((c) => c[0] === "Số tiền (₫)") + 1;
  ws.set(last, 1, "Tổng " + fmt(list.length) + " đơn", S({ font: { name: F, size: 10, bold: true }, fill: "93C47D" }));
  ws.set(last, sc, { f: `SUM(${XLSXW.col(sc)}2:${XLSXW.col(sc)}${last - 1})` }, S({ font: { name: F, size: 10, bold: true }, fill: "93C47D", fmt: "#,##0" }));
  ws.freeze(2, 2); ws.height(1, 30);
  const blob = await wb.blob();
  const now = new Date(), name = `Don_${{ pend: "dang-cho", ok: "thanh-cong", err: "that-bai", aband: "het-han-huy", all: "tat-ca" }[kind]}${st.pendH >= 0 ? "_" + nk(HOUSES[st.pendH].n) : ""}${st.pendG >= 0 ? "_" + nk(GATES[st.pendG].n) : ""}_${pad(now.getDate())}-${pad(now.getMonth() + 1)}_${pad(now.getHours())}h${pad(now.getMinutes())}.xlsx`;
  const el = document.createElement("a"); el.href = URL.createObjectURL(blob); el.download = name; document.body.appendChild(el); el.click(); el.remove();
  setTimeout(() => URL.revokeObjectURL(el.href), 4000);
};

// ===== Số dư =====
$("btn-bal").onclick = async () => {
  if (!licensed) return;
  while (scanning) await sleep(300);
  scanning = true;
  try { await loadBalances(true); rebuild(); render(); sysmsg("Đã làm mới số dư lúc " + new Date().toLocaleTimeString("vi-VN"), "info"); setTimeout(() => sysmsg(""), 4000); }
  catch (e) { sysmsg("Không làm mới được số dư: " + esc(e.message), "err"); }
  finally { scanning = false; }
};

// ===== Nâng cấp =====
let updInfo = null;
async function checkUpdate(show) {
  try {
    updInfo = await Updater.check();
    const b = $("btn-upd"); b.hidden = false;
    if (updInfo.hasNew) { b.classList.add("pulse"); $("updTxt").textContent = "Nâng cấp " + updInfo.latest; }
    else { b.classList.remove("pulse"); $("updTxt").textContent = "v" + updInfo.current + " ✓"; }
    if (show) return updInfo;
  } catch (e) { if (show) throw e; }
}
$("btn-upd").onclick = () => {
  $("updback").hidden = false; $("updmsg").hidden = true;
  const i = updInfo;
  if (!i) { $("updinfo").innerHTML = "Chưa kiểm tra được bản mới."; $("updgo").hidden = true; return; }
  $("updgo").hidden = !i.hasNew;
  $("updinfo").innerHTML = i.hasNew
    ? `<p>Có bản mới <b>${esc(i.latest)}</b> (đang dùng ${esc(i.current)}).</p>${i.notes ? `<p class="mut">${esc(i.notes)}</p>` : ""}<p class="mut">Lần đầu bấm, Chrome sẽ hỏi thư mục: chọn đúng thư mục đang cài tool (thư mục có file <b>manifest.json</b>) và bấm <b>Cho phép sửa</b>. Những lần sau chỉ cần bấm Nâng cấp.</p>`
    : `<p>Bạn đang dùng bản mới nhất <b>${esc(i.current)}</b>.</p>`;
};
$("updclose").onclick = () => ($("updback").hidden = true);
$("updgo").onclick = async () => {
  $("updgo").disabled = true;
  const m = (t) => { $("updmsg").hidden = false; $("updmsg").textContent = t; };
  try { await Updater.run(updInfo, m); }
  catch (e) { m(e.name === "AbortError" ? "Đã huỷ chọn thư mục." : "Nâng cấp lỗi: " + e.message); $("updgo").disabled = false; }
};

// ===== Cài đặt =====
$("btn-set").onclick = async () => {
  $("sDomain").value = SET.domain; $("sUsdt").checked = SET.usdt; $("sRed").value = SET.rRed; $("sAmber").value = SET.rWarn; $("sOkR").value = SET.rOk; $("sMinN").value = SET.minN; $("sStale").value = SET.stale; $("sSound").checked = SET.sound; $("sExFake").checked = SET.exFake !== false;
  $("sDev").textContent = await License.deviceId();
  const r = await License.check(await License.saved());
  $("sKeyInfo").textContent = r.ok ? keyText(r) : r.reason;
  $("sVer").textContent = "v" + chrome.runtime.getManifest().version;
  $("setmsg").hidden = true; $("setback").hidden = false;
};
$("setclose").onclick = () => ($("setback").hidden = true);
$("sCopyDev").onclick = () => navigator.clipboard.writeText($("sDev").textContent).catch(() => {});
$("sChangeKey").onclick = () => { $("setback").hidden = true; showLock("Nhập key mới."); };
$("sPickDir").onclick = async () => { try { await Updater.pickFolder(); $("setmsg").hidden = false; $("setmsg").textContent = "Đã lưu thư mục cài tool."; } catch (e) { $("setmsg").hidden = false; $("setmsg").textContent = e.name === "AbortError" ? "Đã huỷ." : e.message; } };
$("sCheckUpd").onclick = async () => { $("setmsg").hidden = false; $("setmsg").textContent = "Đang kiểm tra…"; try { const i = await checkUpdate(true); $("setmsg").textContent = i.hasNew ? "Có bản mới " + i.latest + ". Bấm nút Nâng cấp ở thanh trên." : "Đang là bản mới nhất."; } catch (e) { $("setmsg").textContent = e.message; } };
$("setsave").onclick = async () => {
  const dom = $("sDomain").value.trim().replace(/^https?:\/\//, "").replace(/\/.*$/, "");
  if (dom && dom !== SET.domain) {
    if (!/\.cg\.ink$/.test(dom)) {
      const ok = await chrome.permissions.request({ origins: ["https://" + dom + "/*"] }).catch(() => false);
      if (!ok) { $("setmsg").hidden = false; $("setmsg").textContent = "Cần cho phép tool truy cập tên miền mới."; return; }
    }
    await chrome.storage.local.set({ boDomain: dom }); SET.domain = dom;
    await chrome.runtime.sendMessage({ type: "applyRules" });
    ORD.clear(); lastFull = 0; lastBal = 0;
  }
  SET.usdt = $("sUsdt").checked; usdtOk = true;
  SET.rRed = Math.max(0, +$("sRed").value || 20); SET.rWarn = Math.max(SET.rRed, +$("sAmber").value || 50); SET.rOk = Math.max(SET.rWarn, +$("sOkR").value || 80); SET.minN = Math.max(1, +$("sMinN").value || 5); SET.stale = Math.max(1, +$("sStale").value || 5); SET.sound = $("sSound").checked; SET.exFake = $("sExFake").checked;
  await chrome.storage.local.set({ settings: { usdt: SET.usdt, rRed: SET.rRed, rWarn: SET.rWarn, rOk: SET.rOk, minN: SET.minN, stale: SET.stale, sound: SET.sound, exFake: SET.exFake } });
  $("setback").hidden = true; render(); tick();
};

// ===== Key bản quyền =====
let licensed = false;
function keyText(r) {
  const p = r.info; const who = p.n ? p.n + " · " : "";
  if (!p.e) return who + "vĩnh viễn";
  const d = Math.floor(r.left / 86400), h = Math.floor((r.left % 86400) / 3600);
  return who + "còn " + (d ? d + " ngày" : h + " giờ") + " (hết " + new Date(p.e * 1000).toLocaleDateString("vi-VN") + ")";
}
async function showLock(msg) {
  licensed = false;
  $("lock").hidden = false; $("lockMsg").className = "lock-msg"; $("lockMsg").textContent = msg || "Nhập key để sử dụng tool.";
  $("lockDev").textContent = await License.deviceId();
  runState("idle", "CHƯA CÓ KEY");
}
$("lockCopy").onclick = () => navigator.clipboard.writeText($("lockDev").textContent).catch(() => {});
$("lockGo").onclick = async () => {
  const k = $("lockKey").value;
  const r = await License.check(k);
  if (!r.ok) { $("lockMsg").className = "lock-msg"; $("lockMsg").textContent = r.reason; return; }
  await License.save(k);
  $("lockMsg").className = "lock-msg ok"; $("lockMsg").textContent = "Kích hoạt thành công: " + keyText(r);
  setTimeout(() => { $("lock").hidden = true; licensed = true; showKey(r); start(); }, 700);
};
function showKey(r) {
  const c = $("keyChip"); c.textContent = "Key: " + keyText(r);
  c.className = "bn-key" + (r.info.e && r.left < 3 * 86400 ? " warn" : "");
}
async function verifyLoop() {
  const r = await License.check(await License.saved());
  if (!r.ok) { if (licensed || $("lock").hidden) showLock(r.reason); return false; }
  showKey(r); return true;
}

// ===== Khởi động =====
let started = false;
async function start() {
  if (started) { tick(); return; }
  started = true;
  runState("idle", "ĐANG TẢI");
  const cached = await Store.dayOrders(DAY).catch(() => []);
  for (const o of cached) { o.st = BO.stCode(Number(o.ps), o.psl); ORD.set(o.no, o); }
  const info = await Store.getDay(DAY).catch(() => null);
  const sj = await Store.kvGet("job").catch(() => null);
  const needNo = cached.length && cached.some((o) => o.nAll === undefined);   // đơn cũ chưa có số lần nạp -> đọc lại dần cả ngày
  if (!(info && info.full) && sj && sj.day === DAY && cached.length) {
    // tool khởi động lại giữa lúc đang tải cả ngày (vd vừa nâng cấp): tải tiếp từ trang đang dở
    job = { kind: "full", ci: sj.ci, page: Math.max(1, sj.page), pages: sj.pages, total: 0, got: 0, resumed: true };
    if (Date.now() - sj.at > 120e3) catchUpFrom = Math.floor(sj.at / 1000) - 600;
    sysmsg(`Đang tải tiếp đơn hôm nay từ trang ${job.page}/${sj.pages} (đã có ${fmt(cached.length)} đơn trong máy)…`, "info");
  }
  if (info && info.full && cached.length && needNo) job = { kind: "resync", ci: 0, page: 1, pages: 1, total: 0, got: 0 };
  if (info && info.full && cached.length) {
    lastFull = info.full;
    if (Date.now() - info.at < 60 * 60e3) catchUpFrom = Math.floor(info.at / 1000) - 1800;   // tắt dưới 1 giờ: đọc bù
    else catchUpFrom = Math.floor(info.at / 1000) - 1800;                                     // tắt lâu: đọc bù dần từ lần quét cuối
  }
  rebuild(); segs();
  $("dayRange").textContent = DAY.slice(8) + "/" + DAY.slice(5, 7) + " 00:00 → " + new Date().toLocaleTimeString("vi-VN", { hour12: false }).slice(0, 5);
  let s0 = "home"; try { s0 = localStorage.getItem("tab") || "home"; } catch (e) {}
  go(s0);
  $("readCount").textContent = fmt(ORD.size);
  tick();
  timer = setInterval(tick, CFG.SCAN_SEC * 1000);
  setInterval(() => { if (licensed && !scanning) render(); }, 60e3);
}
BO.onWait = (sec) => { if (!lastFull) runState("idle", "BO BẮT CHỜ " + sec + "S"); };
(async function boot() {
  await loadSettings();
  FEEH = (await Store.kvGet("feeHist").catch(() => null)) || {};
  PSTATE = (await Store.kvGet("pstate").catch(() => null)) || {};
  Object.assign(BALT, (await Store.kvGet("balt").catch(() => null)) || {});
  { const s = await chrome.storage.local.get(["fakeMark", "fakeIgn"]); FMARK = s.fakeMark || {}; FIGN = s.fakeIgn || {}; }
  rebuild(); segs(); go("home");
  checkUpdate(); setInterval(checkUpdate, 30 * 60e3);
  if (await verifyLoop()) { licensed = true; start(); } else { await showLock((await License.check(await License.saved())).reason); }
  setInterval(async () => { if (licensed) { const ok = await verifyLoop(); if (!ok) licensed = false; } }, 60e3);
})();
})();
