// Lưu đơn trong máy (IndexedDB) để mở lại nhanh và xuất Excel nhiều ngày
function makeStore(dbName) {
  let dbp = null;
  function db() {
    if (!dbp) dbp = new Promise((res, rej) => {
      const r = indexedDB.open(dbName, 2);
      r.onupgradeneeded = (ev) => {
        const d = r.result;
        if (ev.oldVersion < 1) {
          const o = d.createObjectStore("orders", { keyPath: "no" });
          o.createIndex("day", "day");
          d.createObjectStore("days", { keyPath: "day" });
          d.createObjectStore("kv");
        }
        // bản 2: chỉ mục theo tài khoản để tra cứu khách nhanh (Chrome tự dựng chỉ mục cho đơn đã lưu)
        const o = r.transaction.objectStore("orders");
        if (!o.indexNames.contains("acc")) o.createIndex("acc", "acc");
      };
      r.onsuccess = () => { const d = r.result; d.onversionchange = () => { d.close(); dbp = null; }; res(d); };
      r.onerror = () => rej(r.error);
    });
    return dbp;
  }
  const tx = async (stores, mode, fn) => {
    const d = await db();
    return new Promise((res, rej) => {
      const t = d.transaction(stores, mode);
      let out;
      Promise.resolve(fn(t)).then((v) => (out = v));
      t.oncomplete = () => res(out);
      t.onerror = () => rej(t.error);
      t.onabort = () => rej(t.error);
    });
  };
  const req = (r) => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });

  async function putOrders(list) {
    if (!list.length) return;
    await tx(["orders"], "readwrite", (t) => { const s = t.objectStore("orders"); for (const o of list) s.put(o); });
  }
  async function delOrders(nos) {
    if (!nos.length) return;
    await tx(["orders"], "readwrite", (t) => { const s = t.objectStore("orders"); for (const n of nos) s.delete(n); });
  }
  async function dayOrders(day) {
    return tx(["orders"], "readonly", (t) => req(t.objectStore("orders").index("day").getAll(day)));
  }
  async function setDay(day, info) { await tx(["days"], "readwrite", (t) => t.objectStore("days").put({ day, ...info })); }
  async function accOrders(acc) { return tx(["orders"], "readonly", (t) => req(t.objectStore("orders").index("acc").getAll(acc))); }
  async function getOrder(no) { return tx(["orders"], "readonly", (t) => req(t.objectStore("orders").get(no))); }
  async function getDay(day) { return tx(["days"], "readonly", (t) => req(t.objectStore("days").get(day))); }
  async function kvGet(k) { return tx(["kv"], "readonly", (t) => req(t.objectStore("kv").get(k))); }
  async function kvSet(k, v) { await tx(["kv"], "readwrite", (t) => t.objectStore("kv").put(v, k)); }
  async function prune(keepDays) {
    const lim = new Date(Date.now() - keepDays * 86400e3);
    const cut = lim.getFullYear() + "-" + String(lim.getMonth() + 1).padStart(2, "0") + "-" + String(lim.getDate()).padStart(2, "0");
    await tx(["orders", "days"], "readwrite", (t) => {
      const ix = t.objectStore("orders").index("day");
      ix.openCursor(IDBKeyRange.upperBound(cut, true)).onsuccess = (e) => { const c = e.target.result; if (c) { c.delete(); c.continue(); } };
      t.objectStore("days").openCursor(IDBKeyRange.upperBound(cut, true)).onsuccess = (e) => { const c = e.target.result; if (c) { c.delete(); c.continue(); } };
    });
  }
  return { putOrders, delOrders, dayOrders, setDay, getDay, kvGet, kvSet, prune, accOrders, getOrder };
}
const Store = makeStore("ad88gs");          // đơn nạp
const StoreX = makeStore("ad88gs-xuat");    // đơn xuất (rút tiền)
