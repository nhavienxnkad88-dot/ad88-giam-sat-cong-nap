// ===== CẤU HÌNH AD88 GIÁM SÁT CỔNG NẠP =====
// Sửa ở đây nếu đổi tên miền BO hoặc kho GitHub chứa bản nâng cấp.
const CFG = {
  PRODUCT: "gs",                       // mã sản phẩm trong key (không đổi)
  BO_DOMAIN: "8f75lftex8h.cg.ink",     // tên miền BO mặc định (đổi được trong Cài đặt)
  GH_OWNER: "nhavienxnkad88-dot",      // tài khoản GitHub
  GH_REPO: "ad88-giam-sat-cong-nap",   // kho riêng của tool Giám sát cổng nạp
  GH_BRANCH: "main",
  GH_DIR: "",                          // để trống = file nằm ngay ngoài cùng kho
  SCAN_SEC: 30,                         // chu kỳ quét đơn (giây)
  RESYNC_MIN: 60,                       // đối soát lại toàn bộ đơn trong ngày (phút)
  BAL_MIN: 2,                           // đọc lại số dư (phút)
  PAGE_SIZE: 500,                       // thử 500 đơn/trang, BO giới hạn thì tự về 200
  PAGE_SIZE_MIN: 200,
  INC_WINDOW_MIN: 45,                   // mỗi lượt quét đọc lại đơn trong 45 phút gần nhất
  TICK_BUDGET_SEC: 25,                  // thời gian tối đa cho 1 lượt quét
  REQ_GAP_MS: 1200,                     // khoảng cách tối thiểu giữa 2 lần gọi BO (tự giãn ra khi BO bắt chờ)
  KEEP_DAYS: 45,                        // số ngày giữ đơn trong máy để xuất Excel
  STALE: 300, ABANDON: 1800, RED: 15, AMBER: 8,
  PUBLIC_KEY: {"kty": "EC", "crv": "P-256", "x": "MrJDaVuXtlZsbK8Qc2FlOsDXA0B1qn_cxbvVtz2Z4N8", "y": "6k3eYvmR3be_X3vyqM4IRbKm8dNotO6Xp2PA5S39Ux4"}
};
CFG.UPDATE_BASE = `https://raw.githubusercontent.com/${CFG.GH_OWNER}/${CFG.GH_REPO}/${CFG.GH_BRANCH}/` + (CFG.GH_DIR ? CFG.GH_DIR + "/" : "");
if (typeof self !== "undefined") self.CFG = CFG;
