// Tạo file Excel tốc độ lên điểm theo mẫu của AD88
const Report = (() => {
  // Thứ tự nhà giữ cố định như bảng đang dùng; nhà mới thêm vào cuối
  const FIXED = ["GO-PAY", "VIPPAY", "FastPay", "BB168Pay", "OKPAY", "888PAY", "V6PAY", "A8PAY", "PPPAY", "VN196PAY", "U2Pay2", "RCPay(USDT)", "33PAY", "PaYoPay", "JYPay"];
  const nk = (s) => String(s).normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[đĐ]/g, "d").toLowerCase().replace(/[^a-z0-9]/g, "");
  const BUCKETS = [["10.000 – 999.999", 0, 1e6], ["1.000.000 – 9.999.999", 1e6, 1e7], ["10.000.000 – 19.999.999", 1e7, 2e7],
    ["20.000.000 – 49.999.999", 2e7, 5e7], ["50.000.000 – 99.999.999", 5e7, 1e8], ["≥ 100.000.000", 1e8, 1e15]];
  const F = "Times New Roman";
  const B = { border: true, align: { h: "center", v: "center", wrap: true } };
  const S = (o) => Object.assign({}, B, o);
  const tv = (s) => (s == null ? null : Math.round(s) / 86400);

  function houseOrder(names) {
    const out = [], seen = new Set();
    for (const f of FIXED) {
      const m = names.find((n) => !seen.has(n) && (nk(n) === nk(f) || nk(f).startsWith(nk(n)) && nk(n).length >= 4));
      out.push(m || f); if (m) seen.add(m);
    }
    names.filter((n) => !seen.has(n)).forEach((n) => out.push(n));
    return out;
  }
  function stats(lst) {
    const s = { n: lst.length, b30: 0, b1: 0, b3: 0, b15: 0, avg: null, amt: [], hr: [] };
    let sum = 0;
    for (const o of lst) { sum += o.sp; if (o.sp > 900) s.b15++; else if (o.sp > 180) s.b3++; else if (o.sp > 60) s.b1++; else if (o.sp > 30) s.b30++; }
    if (lst.length) s.avg = sum / lst.length;
    for (const [, lo, hi] of BUCKETS) { const b = lst.filter((o) => o.vnd >= lo && o.vnd < hi); s.amt.push([b.length, b.length ? b.reduce((a, o) => a + o.sp, 0) / b.length : null]); }
    for (let h = 0; h < 24; h++) { const b = lst.filter((o) => Math.floor(o.t / 3600) === h); s.hr.push(b.length ? b.reduce((a, o) => a + o.sp, 0) / b.length : null); }
    return s;
  }
  const dmy = (day) => { const [y, m, d] = day.split("-"); return d + "/" + m + "/" + y; };
  const toDate = (day) => { const [y, m, d] = day.split("-").map(Number); return new Date(y, m - 1, d); };

  function dataSheet(wb, name, groups, withGate) {
    const ws = wb.sheet(name), off = withGate ? 1 : 0;
    const hdr = ["Ngày", "通道"].concat(withGate ? ["Cổng nạp"] : [], ["Tổng đơn\n总订单", ">30s", "", ">1 Phút", "", ">3 Phút", "", ">15 Phút", "", "Tốc độ trung bình"]);
    BUCKETS.forEach((b) => hdr.push(b[0], "Thời gian xử lý"));
    for (let h = 0; h < 24; h++) hdr.push(h < 23 ? `${String(h).padStart(2, "0")}:00 - ${String(h + 1).padStart(2, "0")}:00` : "23:00 - 23:59");
    const hs = S({ font: { name: F, size: 10, bold: true, color: "FFFFFF" }, fill: "0B2A55" });
    hdr.forEach((v, i) => ws.set(1, i + 1, v, hs));
    [4, 6, 8, 10].forEach((c) => ws.merge(1, c + off, 1, c + off + 1));
    let r = 2;
    for (const [day, h, g, s, tot] of groups) {
      const font = { name: F, size: 10, bold: !!tot }, fill = tot ? "93C47D" : undefined;
      const st = (fmt) => S({ font, fill, fmt });
      ws.set(r, 1, toDate(day), st("dd/mm/yyyy")); ws.set(r, 2, h, st());
      if (withGate) ws.set(r, 3, g, st());
      const c = 3 + off, nc = XLSXW.col(c);
      ws.set(r, c, s.n, st("#,##0"));
      ["b30", "b1", "b3", "b15"].forEach((k, j) => {
        const cc = c + 1 + 2 * j, L = XLSXW.col(cc);
        ws.set(r, cc, s[k], st("#,##0"));
        ws.set(r, cc + 1, { f: `IF(OR(${nc}${r}=0,${L}${r}=0),"",${L}${r}/${nc}${r})` }, st("0.00%"));
      });
      ws.set(r, c + 9, tv(s.avg), st("hh:mm:ss"));
      let cc = c + 10;
      for (const [cnt, av] of s.amt) { ws.set(r, cc, cnt, st("#,##0")); ws.set(r, cc + 1, tv(av), st("hh:mm:ss")); cc += 2; }
      for (const av of s.hr) { ws.set(r, cc, tv(av), st("hh:mm:ss")); cc++; }
      r++;
    }
    ws.freeze(2, 3 + off);
    ws.width(1, 12); ws.width(2, 14); if (withGate) ws.width(3, 16);
    for (let i = 3 + off; i <= hdr.length; i++) ws.width(i, 11.5);
    ws.height(1, 34);
  }

  // orders: đơn thành công đã lọc theo khung giờ; days: danh sách ngày; label: mô tả khung
  function build(orders, days, opt) {
    const wb = new XLSXW.Book();
    const ok = orders.filter((o) => o.st === 2).map((o) => ({ ...o, vnd: o.cur === "VND" ? o.raw * 1000 : 0 }));
    const merchs = houseOrder([...new Set(ok.map((o) => o.merch))].sort((a, b) => ok.filter((o) => o.merch === b).length - ok.filter((o) => o.merch === a).length));
    const label = (day) => dmy(day) + (opt.suffix ? "  (" + opt.suffix + ")" : "");

    // Tổng quan
    const ws = wb.sheet("Tổng quan");
    ws.merge(1, 1, 2, 1); ws.set(1, 1, null, S({ fill: "B4A7D6" })); ws.set(2, 1, null, S({ fill: "B4A7D6" }));
    const names = ["Tổng"].concat(merchs);
    names.forEach((nm, i) => ws.set(3 + i, 1, nm, S({ font: { name: F, size: 12, bold: true }, fill: "8DB3B5" })));
    const sub = ["Tổng đơn\n总订单", ">30s", "Tỷ lệ", ">1 Phút", "Tỷ lệ", ">3 Phút", "Tỷ lệ", ">15 Phút", "Tỷ lệ"];
    const red = S({ font: { name: F, size: 10, bold: true, color: "FF0000" }, fmt: "0.00%" });
    let col = 2;
    for (const day of days) {
      const dl = ok.filter((o) => o.day === day);
      ws.merge(1, col, 1, col + 8);
      ws.set(1, col, label(day), S({ font: { name: F, size: 13, bold: true }, fill: "EAD1DC" }));
      for (let j = 1; j <= 8; j++) ws.set(1, col + j, null, S({ fill: "EAD1DC" }));
      sub.forEach((v, j) => ws.set(2, col + j, v, S({ font: { name: F, size: 12, bold: true, color: v === "Tỷ lệ" ? "FF0000" : "000000" }, fill: "CFE2F3" })));
      names.forEach((nm, i) => {
        const s = stats(nm === "Tổng" ? dl : dl.filter((o) => o.merch === nm)), r = 3 + i;
        const f = S({ font: { name: F, size: 10, bold: nm === "Tổng" }, fmt: "#,##0" });
        ws.set(r, col, s.n, f);
        ["b30", "b1", "b3", "b15"].forEach((k, j) => {
          const cc = col + 1 + 2 * j, L = XLSXW.col(cc), T = XLSXW.col(col);
          ws.set(r, cc, s[k], f);
          ws.set(r, cc + 1, { f: `IF(OR(${T}${r}=0,${L}${r}=0),"",${L}${r}/${T}${r})` }, red);
        });
      });
      col += 9;
    }
    ws.width(1, 16); for (let i = 2; i < col; i++) ws.width(i, 10.5);
    ws.height(2, 36); ws.freeze(3, 2);

    // Dữ liệu nhà
    const g1 = [];
    for (const day of days) {
      const dl = ok.filter((o) => o.day === day);
      g1.push([day, "Tổng", "", stats(dl), true]);
      for (const m of merchs) g1.push([day, m, "", stats(dl.filter((o) => o.merch === m)), false]);
    }
    dataSheet(wb, "Dữ liệu nhà", g1, false);

    // Dữ liệu cổng nạp
    const g2 = [];
    for (const day of days) {
      const dl = ok.filter((o) => o.day === day);
      g2.push([day, "Tổng", "Tất cả", stats(dl), true]);
      for (const m of merchs) {
        const gates = [...new Set(ok.filter((o) => o.merch === m).map((o) => o.gate))];
        for (const g of gates) g2.push([day, m, g, stats(dl.filter((o) => o.merch === m && o.gate === g)), false]);
      }
    }
    dataSheet(wb, "Dữ liệu cổng nạp", g2, true);

    const wn = wb.sheet("Ghi chú");
    [
      "Tốc độ lên điểm · " + opt.title,
      "Xuất từ AD88 Giám Sát Cổng Nạp lúc " + new Date().toLocaleString("vi-VN") + ".",
      "Tổng đơn = số đơn nạp THÀNH CÔNG trong khung thời gian (đơn đang chờ / thất bại chưa có thời gian lên điểm nên không tính).",
      "Thời gian lên điểm = Thời gian thành công − Thời gian tạo đơn.",
      ">30s = 30 giây – 1 phút · >1 Phút = 1 – 3 phút · >3 Phút = 3 – 15 phút · >15 Phút = trên 15 phút (các nhóm không chồng nhau).",
      "Tỷ lệ = số đơn trong nhóm ÷ Tổng đơn (công thức trong ô).",
      "Thời gian xử lý theo khung tiền / theo giờ = thời gian lên điểm trung bình của các đơn trong khung đó; ô trống = không có đơn.",
      "Khung tiền tính theo VND; đơn USDT không xếp vào khung tiền."
    ].forEach((t, i) => wn.set(i + 1, 1, t, { font: { name: F, size: 11, bold: i === 0 } }));
    wn.width(1, 120);
    return wb.blob();
  }
  return { build };
})();
