// Gọi API của BO bằng phiên đăng nhập sẵn có trên Chrome
const BO = (() => {
  let last = 0, chain = Promise.resolve();
  const gap = {};   // khoảng chờ riêng cho từng API, tự giãn khi BO bắt chờ
  const floor = {}; // khoảng chờ tối thiểu đã học được của từng API (không gọi nhanh hơn mức BO cho phép)
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // Tên miền BO: ưu tiên đúng tên miền BO mà Chrome này vừa đăng nhập (máy nhân viên có thể vào BO bằng tên miền khác)
  async function domain() {
    const s = await chrome.storage.local.get(["boDomain", "boAuth"]);
    const a = s.boAuth;
    if (a && a.domain && /\.cg\.ink$/i.test(a.domain) && Date.now() - (a.at || 0) < 12 * 3600e3) return a.domain;
    return (s.boDomain || CFG.BO_DOMAIN).trim();
  }
  async function auth() {
    const s = await chrome.storage.local.get("boAuth");
    return s.boAuth || null;
  }

  const PAGES = [["payOrderOnline", "Tổng nạp nhanh"], ["payOrderAll", "Tổng nạp tiền"], ["merchAgentSetting", "Thanh toán bên thứ ba (số dư nhà)"], ["refreshBalance", "Làm mới số dư nhà"], ["paySettingOnline", "Cấu hình kênh nạp"], ["paySetOnlineStop", "Kênh bị vô hiệu hóa"], ["withdrawAll", "Lệnh rút tiền"], ["withdrawRisk", "Đánh giá kiểm soát rủi ro"], ["withdrawCheck", "Thanh toán tài chính"], ["withdrawNoAudit", "Rút tiền không cần xem xét"], ["tidata", "Xuất tải xuống"]];
  const PAGE_NAME = (p) => { const m = PAGES.find(([k]) => p.includes(k)); return m ? `trang "${m[1]}" (${p})` : p; };
  class BoError extends Error { constructor(msg, kind) { super(msg); this.kind = kind; } }

  async function raw(path, { method = "GET", body, query } = {}) {
    const d = await domain();
    const a = await auth();
    const headers = { "Content-Type": "application/json;charset=UTF-8", Accept: "application/json, text/plain, */*" };
    if (a && a.headers) Object.assign(headers, a.headers);
    let url = "https://" + d + path;
    if (query) url += (url.includes("?") ? "&" : "?") + new URLSearchParams(query).toString();
    let r;
    try {
      r = await fetch(url, { method, headers, body: body ? JSON.stringify(body) : undefined, credentials: "include", cache: "no-store" });
    } catch (e) {
      throw new BoError("Không kết nối được BO (" + d + "). Kiểm tra mạng hoặc tên miền.", "net");
    }
    if (r.status === 401) throw new BoError(`BO (${d}) từ chối phiên đăng nhập (HTTP 401)`, "login");
    if (r.status === 403) { const e = new BoError(`Tài khoản BO không có quyền: ${PAGE_NAME(path)} (HTTP 403)`, "perm"); e.path = path; throw e; }
    if (r.status === 429) { const e = new BoError("BO giới hạn tốc độ, tạm chờ.", "rate"); e.wait = 5; throw e; }
    if (!r.ok) throw new BoError("BO trả lỗi HTTP " + r.status + " ở " + path, "http");
    let j;
    try { j = await r.json(); } catch (e) { throw new BoError("BO trả dữ liệu không phải JSON ở " + path + " (có thể đã đổi giao diện hoặc chưa đăng nhập).", "format"); }
    if (j && j.timestamp) License.noteServerTime(j.timestamp);
    if (j && (j.code === 0 || j.success === true)) return j.data;
    const msg = (j && (j.msg || j.message)) || "lỗi không rõ";
    const w = /(?:đợi|doi|wait)\D{0,6}(\d+)/i.exec(msg);
    if (w || /thử lại|try again|频繁|too many|稍后/i.test(msg)) { const e = new BoError("BO bắt chờ: " + msg, "rate"); e.wait = w ? Number(w[1]) : 4; throw e; }
    // tài khoản BO không có quyền xem trang này (không phải mất đăng nhập) → báo riêng, các phần khác vẫn chạy
    if (/quyền|permission|权限|no auth|not allowed|forbidden/i.test(msg)) { const e = new BoError(`Tài khoản BO không có quyền: ${PAGE_NAME(path)} — BO báo: ${msg}`, "perm"); e.path = path; throw e; }
    if (/login|token|đăng nhập|登录|unauthor/i.test(msg) || [401, 403, 10001, 10002].includes(j && j.code)) throw new BoError(`BO (${d}) báo: ${msg}`, "login");
    throw new BoError("BO báo lỗi: " + msg + " (" + path + ")", "api");
  }

  // Xếp hàng để không gọi BO quá dày; BO bắt chờ thì chờ đúng số giây rồi gọi lại
  function call(path, opt) {
    const run = async () => {
      for (let attempt = 0; ; attempt++) {
        const g = gap[path] || CFG.REQ_GAP_MS;
        const wait = Math.max(0, last + g - Date.now());
        if (wait) await sleep(wait);
        last = Date.now();
        try {
          const d = await raw(path, opt);
          if (gap[path]) gap[path] = Math.max(floor[path] || CFG.REQ_GAP_MS, Math.round(gap[path] * 0.98));
          return d;
        } catch (e) {
          if (e.kind !== "rate" || attempt >= 6) throw e;
          const ms = ((e.wait || 4) + 0.6) * 1000;
          floor[path] = Math.min(8000, (e.wait || 4) * 1000 + 250);
          gap[path] = Math.min(8000, Math.max(gap[path] || CFG.REQ_GAP_MS, floor[path]));
          if (api.onWait) api.onWait(e.wait || 4);
          await sleep(ms); last = Date.now();
        }
      }
    };
    const p = chain.then(run, run);
    chain = p.catch(() => {});
    return p;
  }

  // timeType: 0 = Tạo thời gian (mặc định); các mốc khác (Thời gian thành công, Cập nhật thời gian) tool tự dò
  function listOrders(cur, start, end, page, size, timeType) {
    return call("/api/finance/payOrderOnline/list", {
      method: "POST",
      body: { memberCurrency: cur, timeType: timeType || 0, current: page, size, startCreateTimeStr: start, endCreateTimeStr: end, isRefresh: false }
    });
  }

  let balMode = null; // "post" | "get"
  // Danh sách nhà thứ 3 (listV2) — đọc hết các trang
  async function listBalances() {
    const path = "/api/go-gateway-internal/admin/finance/merchAgentSetting/listV2";
    const tries = balMode === "get" ? ["get", "post"] : ["post", "get"];
    let err;
    for (const m of tries) {
      try {
        const all = [];
        for (let page = 1; page <= 10; page++) {
          const q = { current: page, size: 100 };
          const d = m === "post" ? await call(path, { method: "POST", body: q }) : await call(path, { method: "GET", query: q });
          if (!d || !Array.isArray(d.records)) throw new BoError("listV2 không có records", "format");
          all.push(...d.records);
          if (all.length >= (Number(d.total) || 0) || !d.records.length) break;
        }
        balMode = m; return all;
      } catch (e) { err = e; if (e.kind === "login" || e.kind === "net") throw e; }
    }
    throw err || new Error("Không đọc được danh sách số dư.");
  }
  function refreshBalance(merchId) {
    // BO gọi bằng POST (đã xác nhận từ trang BO): .../refreshBalance?merchId=<id kênh rút>
    return call("/api/finance/thirdWithdraw/refreshBalance", { method: "POST", query: { merchId } });
  }

  // Cài đặt kênh nạp (trang "Cài đặt nạp tiền"): mỗi hạng mục có channelList, status 1 = bật, 0 = dừng (Hủy kích hoạt)
  // Trang Cài đặt nạp tiền trên BO có 2 nguồn:
  //  - tab Cấu hình chính:      /paySettingOnline/getPaySettingList  (kênh đang bật)
  //  - tab Kênh bị vô hiệu hóa: /paySetOnlineStop/getPaySettingList  {selectValue:1,current,size} (kênh đang tắt)
  // Tool đọc cả 2 rồi gộp theo từng kênh
  async function paySettings() {
    const s = await chrome.storage.local.get(["paySetBody", "paySetStopBody"]);
    const parse = (raw, def) => { try { return raw ? JSON.parse(raw) || def : def; } catch (e) { return def; } };
    const srcs = [
      ["/api/finance/paySettingOnline/getPaySettingList", parse(s.paySetBody, {}), false],
      ["/api/finance/paySetOnlineStop/getPaySettingList", parse(s.paySetStopBody, { selectValue: 1, current: 1, size: 100 }), true]
    ];
    const types = new Map(); let ok = 0, err = null;
    for (const [path, body0, paged] of srcs) {
      for (let page = 1; page <= 5; page++) {
        const body = paged ? { ...body0, current: page, size: body0.size || 100 } : body0;
        let arr;
        try {
          const d = await call(path, { method: "POST", body });
          arr = Array.isArray(d) ? d : d && Array.isArray(d.records) ? d.records : null;
        } catch (e) { if (e.kind === "login" || e.kind === "net") throw e; err = e; break; }
        if (!arr) break;
        ok++; let n = 0;
        for (const t of arr) {
          const k = t.payTypeId || t.payTypeName;
          const T = types.get(k) || { ...t, channelList: [], _ch: new Map() };
          if (types.has(k) && t.switchStatus != null) T.switchStatus = t.switchStatus;
          for (const c of t.channelList || []) { n++; T._ch.set(c.id, c); }
          types.set(k, T);
        }
        if (!paged || n < (body.size || 100)) break;
      }
    }
    if (!ok) throw err || new BoError("getPaySettingList không có danh sách kênh", "format");
    return [...types.values()].map((T) => { T.channelList = [...T._ch.values()].sort((a, b) => (b.weight || 0) - (a.weight || 0)); delete T._ch; return T; });
  }

  // Tình trạng đơn trên BO (đọc theo chữ BO ghi, mã số chỉ dùng dự phòng):
  //  Thanh toán đang chờ / Bổ sung đang được xem xét -> 1 đang chờ
  //  Đặt cọc thành công -> 2 · Đặt cọc không thành công -> 3 lỗi thật
  //  Hết thời gian nạp tiền -> 4 hết hạn (khách bỏ dở) · Hủy trong nền -> 5 bị huỷ
  function stCode(ps, txt) {
    const t = String(txt || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/đ/gi, "d").toLowerCase();
    if (t) {
      if (t.includes("khong thanh cong") || t.includes("that bai")) return 3;
      if (t.includes("thanh cong")) return 2;
      if (t.includes("het thoi gian") || t.includes("het han") || t.includes("qua han")) return 4;
      if (t.includes("huy")) return 5;
      if (t.includes("dang cho") || t.includes("xem xet")) return 1;
    }
    // mã BO: 1 chờ · 6 bổ sung đang xem xét · 2 thành công · 3/4 hết thời gian · 10 không thành công · 5 huỷ trong nền
    return { 1: 1, 6: 1, 2: 2, 10: 3, 3: 4, 4: 4, 5: 5 }[ps] || 4;
  }
  const secs = (v) => { const n = Number(v) || 0; return n > 1e11 ? Math.floor(n / 1000) : n; };   // BO có lúc trả mili-giây
  // Chuẩn hóa 1 đơn từ BO
  function norm(rec, day, dayStart, cur) {
    const ps = Number(rec.payStatus);
    const st = stCode(ps, rec.payStatusStr);
    const ct = Number(rec.createTime) || 0;
    const done = Number(rec.notifyTime) || Number(rec.updateTime) || 0;
    const amt = Number(rec.amount) || 0;
    return {
      no: String(rec.orderNo), day, cur,
      acc: rec.account || rec.username || "",
      merch: (rec.merchName || "Không rõ").trim(),
      mc: rec.merchChannelName || "",
      gate: (rec.paymentName || "Không rõ").trim(),
      ch: rec.channelName || "",
      st, ps, psl: rec.payStatusStr || "", why: String(rec.backRemark || rec.remark || (rec.remarkDto && rec.remarkDto.backRemark) || "").slice(0, 160),
      ts: ct, t: ct - dayStart,
      sp: st === 2 && done >= ct ? done - ct : 0,
      amt: cur === "VND" ? amt : 0, raw: amt,
      fee: Number(rec.channelRate) || 0,
      // số lần nạp của khách theo BO: thành công / tổng số lần tạo đơn, và nhãn lần đầu/lần hai
      nOk: rec.rechargeSuccessCount != null ? Number(rec.rechargeSuccessCount) : null,
      nAll: rec.rechargeTotalCount != null ? Number(rec.rechargeTotalCount) : null,
      ntag: rec.orderCountTag || "",
      tag: String(rec.userTag || "").replace(/[（(][^)）]*[)）]/g, "").trim(),
      nt: secs(rec.notifyTime), ut: secs(rec.updateTime), xr: Number(rec.cryptoRate) || 0, cfr: rec.feeRate != null && rec.feeRate !== "" ? Number(rec.feeRate) : null,
      lvl: rec.vipLevelName || "", mk: Number(rec.mark) || 0, cbx: Number(rec.callbackExceptionType) || 0, why2: String(rec.backRemark || rec.remark || "").slice(0, 160), op: rec.optor || rec.createUser || "", orig: Number(rec.callbackAmount) > 0 ? Number(rec.callbackAmount) : amt 
    };
  }

  // ===== XUẤT KHOẢN =====
  const WD_TYPES = "15,6,10,11,12,24,25,71,72,73,318,381,428,430,432,461,493,494,495,499,502,503,392,398,400,366,434,377,396,435,26,51,67,127,175,365,368,427,437,506,114,115,402,34,150,394,33,436";
  const WD_STATUS = "1,101,102,3,5,9,7,2,4,8";
  // Lệnh rút tiền (trang Lệnh rút tiền). timeType 0 = Thời gian yêu cầu. queryType 5 = kiểu BO dùng khi Xuất báo cáo (có cột FK)
  function withdrawList(start, end, page, size, queryType, timeType, status) {
    return call("/api/finance/withdrawAll/index", { method: "POST", body: { create_start_time: start, create_end_time: end, current: page, size, isRefresh: false, lockBySelf: false, memberCurrency: "VND", queryType: queryType || 3, status: status || WD_STATUS, timeType: timeType || 0, withdrawAccountTypes: WD_TYPES } });
  }
  // Xuất báo cáo lệnh rút (file có cột FK) — BO tạo file trong mục Xuất tải xuống
  async function withdrawExport(start, end) {
    const f = await call("/api/finance/withdrawAll/exportTxt", { method: "GET" });
    const exportField = (Array.isArray(f) ? f : []).map((x) => ({ entityAttrName: x.field, filedChineseName: x.text }));
    return call("/api/finance/withdrawAll/exportExcelOffline", { method: "POST", body: { create_start_time: start, create_end_time: end, current: 1, size: 200, isRefresh: true, lockBySelf: false, memberCurrency: "VND", queryType: 5, status: WD_STATUS, timeType: 0, withdrawAccountTypes: WD_TYPES, exportField } });
  }
  // Lịch sử đẩy nhà thứ 3 của 1 lệnh rút (mỗi lần đẩy có mã 01, 02, 03… + số lệnh)
  const reviewOrders = (orderNo) => call("/api/finance/withdrawAll/reviewOrderList", { method: "GET", query: { current: 1, size: 20, orderNo } });
  // Mục Xuất tải xuống
  async function exportPage() {
    const s = await chrome.storage.local.get("dlPageBody");
    let body = { current: 1, size: 20 }; try { if (s.dlPageBody) body = { ...JSON.parse(s.dlPageBody), current: 1 }; } catch (e) {}
    return call("/api/tidata/download/excel/page", { method: "POST", body });
  }
  const exportUrls = (id) => call("/api/tidata/download/excel/viewUrls", { method: "POST", body: { id } });
  const exportPwd = (id) => call("/api/tidata/download/excel/viewpd", { method: "POST", body: { id } });
  // Rút tiền mà không cần xem xét (không qua FK, system tự đẩy sang nhà thứ 3)
  function withdrawNoAudit(start, end, page, size) {
    return call("/api/finance/withdrawNoAudit/index", { method: "POST", body: { create_start_time: start, create_end_time: end, current: page, size, isRefresh: false, lockBySelf: false, memberCurrency: "VND", queryType: 3, timeType: 0 } });
  }
  // Thanh toán tài chính: hàng chờ XNK chuyển tiền (đơn FK đã duyệt, chưa đẩy sang nhà)
  async function withdrawCheck(page, size) {
    const s = await chrome.storage.local.get("wdCheckBody");
    let body = { current: page || 1, size: size || 200, isRefresh: false, lockBySelf: false, memberCurrency: "VND", queryType: 3, timeType: 0, withdrawAccountTypes: WD_TYPES };
    try { if (s.wdCheckBody) body = { ...JSON.parse(s.wdCheckBody), current: page || 1, size: size || 200 }; } catch (e) {}
    return call("/api/finance/withdrawCheck/index", { method: "POST", body });
  }
  // Đánh giá kiểm soát rủi ro: đơn đang chờ FK (201 chưa khóa, 202 đã khóa)
  function withdrawRisk(page, size) {
    return call("/api/finance/withdrawRisk/index/masked", { method: "POST", body: { current: page || 1, size: size || 100, isRefresh: false, lockBySelf: false, memberCurrency: "VND", queryType: 3, status: "201,202", timeType: 0, withdrawAccountTypes: WD_TYPES } });
  }
  // Nhà thứ 3 bên rút (merchType 2): có sẵn số dư + bật/tắt
  async function withdrawMerchs() {
    const all = [];
    for (let page = 1; page <= 5; page++) {
      const d = await call("/api/go-gateway-internal/admin/finance/merchAgentSetting/listV2", { method: "POST", body: { current: page, size: 100, merchType: 2 } });
      const r = (d && d.records) || []; all.push(...r);
      if (all.length >= (Number(d && d.total) || 0) || !r.length) break;
    }
    return all;
  }

  const api = { reviewOrders, withdrawCheck, exportPage, exportUrls, exportPwd, withdrawList, withdrawExport, withdrawNoAudit, withdrawRisk, withdrawMerchs, stCode, call, listOrders, listBalances, refreshBalance, paySettings, norm, domain, auth, BoError, onWait: null };
  return api;
})();
