// Hiệu ứng nền động ở hai bên / sau nội dung. Chọn trong Cài đặt, tự đổi màu theo giao diện Sáng/Tối.
// Không dùng eval (hợp CSP của extension MV3).
const BgFx = (() => {
  let host = null, cv = null, ctx = null, raf = 0, cur = "off", mo = null;
  const isLight = () => document.body.dataset.skin === "b";
  const gut = () => Math.max(0, (innerWidth - 1500) / 2);
  const sidePos = () => { const g = gut(); if (g < 40) return Math.random() * innerWidth; return Math.random() < 0.5 ? Math.random() * g : innerWidth - Math.random() * g; };
  // bảng màu theo nền
  function pal() {
    return isLight()
      ? { bub1: "rgba(46,120,230,.30)", bub2: "rgba(46,120,230,.14)", bubln: "rgba(46,120,230,.40)", spark: "#1f6bd6", glow: "rgba(46,120,230,.55)", met: "#2e6bff", metp: "#1466e0", auro: .32, fly: "#e8a400", flyg: "rgba(230,150,0,.6)", petal: "#2e6bff", wave: "rgba(46,120,230,.18)", net: "46,120,230" }
      : { bub1: "rgba(255,255,255,.5)", bub2: "rgba(90,160,255,.25)", bubln: "rgba(150,200,255,.35)", spark: "#bcd4ff", glow: "rgba(120,170,255,.8)", met: "#bcd4ff", metp: "#dfeaff", auro: .5, fly: "#ffe9a6", flyg: "rgba(255,220,130,.9)", petal: "#8fb6ff", wave: "rgba(60,130,240,.25)", net: "150,190,255" };
  }
  function ensure() {
    if (host) return;
    host = document.createElement("div"); host.id = "bgfx"; host.setAttribute("aria-hidden", "true");
    cv = document.createElement("canvas"); cv.id = "bgfx-cv"; host.appendChild(cv);
    document.body.insertBefore(host, document.body.firstChild);
    ctx = cv.getContext("2d");
    addEventListener("resize", () => { if (cur !== "off") render(cur); });
    document.addEventListener("visibilitychange", () => { if (document.hidden) stopCanvas(); else if (cur === "network" || cur === "firework") render(cur); });
  }
  function stopCanvas() { cancelAnimationFrame(raf); raf = 0; if (ctx) ctx.clearRect(0, 0, cv.width, cv.height); }
  function sizeCanvas() { const r = Math.min(devicePixelRatio || 1, 2); cv.width = innerWidth * r; cv.height = innerHeight * r; ctx.setTransform(r, 0, 0, r, 0, 0); }
  function clear() { stopCanvas(); [...host.querySelectorAll(".bgfx-el")].forEach((e) => e.remove()); document.body.classList.remove("bgfx-border"); }
  const add = (cls, css) => { const d = document.createElement("div"); d.className = "bgfx-el " + cls; d.style.cssText = css; host.appendChild(d); return d; };

  function network() {
    sizeCanvas(); const g = gut() || innerWidth, N = Math.min(70, Math.round((g * 2) / 24));
    const mk = (a, b) => ({ x: a + Math.random() * (b - a), y: Math.random() * innerHeight, vx: (Math.random() - .5) * .3, vy: (Math.random() - .5) * .3 });
    const L = [], R = []; for (let i = 0; i < N; i++) { L.push(mk(0, g)); R.push(mk(innerWidth - g, innerWidth)); }
    const col = pal().net;
    (function step() { ctx.clearRect(0, 0, innerWidth, innerHeight);
      for (const arr of [L, R]) { for (const p of arr) { p.x += p.vx; p.y += p.vy; if (p.y < 0 || p.y > innerHeight) p.vy *= -1; }
        for (let i = 0; i < arr.length; i++) for (let j = i + 1; j < arr.length; j++) { const a = arr[i], b = arr[j], d = Math.hypot(a.x - b.x, a.y - b.y); if (d < 120) { ctx.strokeStyle = "rgba(" + col + "," + (1 - d / 120) * .5 + ")"; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); } }
        ctx.fillStyle = "rgba(" + col + ",.9)"; for (const p of arr) { ctx.beginPath(); ctx.arc(p.x, p.y, 1.8, 0, 7); ctx.fill(); } }
      raf = requestAnimationFrame(step); })();
  }
  function firework() {
    sizeCanvas(); let parts = [], t = 0;
    const burst = () => { const g = gut() || innerWidth, m = Math.max(g, 120); const x = Math.random() < .5 ? Math.random() * m : innerWidth - Math.random() * m, y = innerHeight * (.2 + Math.random() * .5), hue = Math.random() * 360;
      for (let i = 0; i < 55; i++) { const a = Math.random() * 7, sp = 1 + Math.random() * 4; parts.push({ x, y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 1, hue }); } };
    (function step() { ctx.clearRect(0, 0, innerWidth, innerHeight); if (t++ % 60 === 0) burst();
      parts = parts.filter((p) => p.life > 0); for (const p of parts) { p.x += p.vx; p.y += p.vy; p.vy += .03; p.vx *= .99; p.life -= .012; ctx.fillStyle = "hsla(" + p.hue + ",90%,65%," + p.life + ")"; ctx.beginPath(); ctx.arc(p.x, p.y, 2, 0, 7); ctx.fill(); }
      raf = requestAnimationFrame(step); })();
  }
  function render(name) {
    ensure(); clear(); cur = name; const c = pal();
    if (name === "bubble") for (let i = 0; i < 24; i++) { const s = 10 + Math.random() * 32; add("bgfx-bubble", `width:${s}px;height:${s}px;left:${sidePos()}px;--dx:${Math.random() * 60 - 30}px;--c1:${c.bub1};--c2:${c.bub2};--cl:${c.bubln};animation-duration:${8 + Math.random() * 10}s;animation-delay:${-Math.random() * 12}s`); }
    else if (name === "spark") for (let i = 0; i < 56; i++) add("bgfx-spark", `left:${sidePos()}px;--c:${c.spark};--g:${c.glow};transform:scale(${.6 + Math.random() * 1.5});animation-duration:${6 + Math.random() * 8}s;animation-delay:${-Math.random() * 10}s`);
    else if (name === "border") document.body.classList.add("bgfx-border");
    else if (name === "aurora") [["#2e6bff", "8%", "12%"], ["#8b5cf6", "86%", "18%"], ["#0ea5a3", "12%", "78%"], ["#e24d7a", "88%", "80%"]].forEach(([col, l, t]) => { const s = 260 + Math.random() * 150; add("bgfx-blob", `width:${s}px;height:${s}px;left:${l};top:${t};background:${col};opacity:${c.auro};--mx:${Math.random() * 120 - 60}px;--my:${Math.random() * 120 - 60}px;animation-duration:${14 + Math.random() * 10}s`); });
    else if (name === "meteor") for (let i = 0; i < 9; i++) add("bgfx-meteor", `left:${sidePos()}px;top:${Math.random() * 40}%;--c:${c.met};--p:${c.metp};--g:${c.glow};animation-duration:${3 + Math.random() * 4}s;animation-delay:${-Math.random() * 6}s`);
    else if (name === "firefly") for (let i = 0; i < 30; i++) add("bgfx-fly", `left:${sidePos()}px;top:${Math.random() * 100}%;--c:${c.fly};--g:${c.flyg};--mx:${Math.random() * 120 - 60}px;--my:${Math.random() * 120 - 60}px;--d:${8 + Math.random() * 10}s;--b:${1.6 + Math.random() * 2.5}s`);
    else if (name === "petal") for (let i = 0; i < 28; i++) { const s = 6 + Math.random() * 10; add("bgfx-petal", `width:${s}px;height:${s}px;left:${sidePos()}px;--dx:${Math.random() * 80 - 40}px;background:${c.petal};animation-duration:${7 + Math.random() * 7}s;animation-delay:${-Math.random() * 10}s`); }
    else if (name === "wave") { const d = "M0,60 C150,110 350,10 600,60 C850,110 1050,10 1200,60 L1200,160 L0,160 Z"; const w = document.createElement("div"); w.className = "bgfx-el bgfx-waves"; w.innerHTML = `<svg viewBox="0 0 1200 160" preserveAspectRatio="none"><defs><path id="bgwv" d="${d}"/></defs><g class="w1"><use href="#bgwv" fill="${c.wave}" x="0"/><use href="#bgwv" fill="${c.wave}" x="1200"/></g><g class="w2" opacity=".6"><use href="#bgwv" fill="${c.wave}" x="0" y="18"/><use href="#bgwv" fill="${c.wave}" x="1200" y="18"/></g></svg>`; host.appendChild(w); }
    else if (name === "network") network();
    else if (name === "firework") firework();
  }
  function set(name) { try { localStorage.setItem("bgfx", name); } catch (e) {} render(name || "off"); }
  function theme() { if (cur && cur !== "off") render(cur); }
  function boot() { let v = "off"; try { v = localStorage.getItem("bgfx") || "off"; } catch (e) {} render(v); }
  return { set, theme, boot, render };
})();
