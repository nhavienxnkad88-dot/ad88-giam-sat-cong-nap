// Bộ ghi file Excel (.xlsx) gọn nhẹ, có định dạng — dùng JSZip
const XLSXW = (() => {
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "");
  const col = (n) => { let s = ""; while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); } return s; };
  const ref = (r, c) => col(c) + r;

  class Book {
    constructor() { this.sheets = []; this.styles = [{}]; this.styleKey = { "{}": 0 }; }
    sheet(name) { const s = new Sheet(this, name); this.sheets.push(s); return s; }
    sid(st) {
      if (!st) return 0;
      const k = JSON.stringify(st);
      if (this.styleKey[k] == null) { this.styleKey[k] = this.styles.length; this.styles.push(st); }
      return this.styleKey[k];
    }
    stylesXml() {
      const fonts = ['<font><sz val="10"/><name val="Times New Roman"/></font>'], fk = { def: 0 };
      const fills = ['<fill><patternFill patternType="none"/></fill>', '<fill><patternFill patternType="gray125"/></fill>'], flk = {};
      const borders = ['<border><left/><right/><top/><bottom/><diagonal/></border>',
        '<border><left style="thin"><color rgb="FFBFBFBF"/></left><right style="thin"><color rgb="FFBFBFBF"/></right><top style="thin"><color rgb="FFBFBFBF"/></top><bottom style="thin"><color rgb="FFBFBFBF"/></bottom><diagonal/></border>'];
      const numFmts = [], nk = {}; let nid = 164;
      const builtin = { "General": 0, "0": 1, "0.00": 2, "#,##0": 3, "0%": 9, "0.00%": 10 };
      const xfs = [];
      for (const st of this.styles) {
        let fontId = 0, fillId = 0, borderId = 0, numId = 0;
        if (st.font) {
          const f = st.font, k = JSON.stringify(f);
          if (fk[k] == null) { fk[k] = fonts.length; fonts.push(`<font>${f.bold ? "<b/>" : ""}${f.italic ? "<i/>" : ""}<sz val="${f.size || 10}"/>${f.color ? `<color rgb="FF${f.color}"/>` : ""}<name val="${esc(f.name || "Times New Roman")}"/></font>`); }
          fontId = fk[k];
        }
        if (st.fill) {
          if (flk[st.fill] == null) { flk[st.fill] = fills.length; fills.push(`<fill><patternFill patternType="solid"><fgColor rgb="FF${st.fill}"/><bgColor indexed="64"/></patternFill></fill>`); }
          fillId = flk[st.fill];
        }
        if (st.border) borderId = 1;
        if (st.fmt) {
          if (builtin[st.fmt] != null) numId = builtin[st.fmt];
          else { if (nk[st.fmt] == null) { nk[st.fmt] = nid++; numFmts.push(`<numFmt numFmtId="${nk[st.fmt]}" formatCode="${esc(st.fmt)}"/>`); } numId = nk[st.fmt]; }
        }
        const al = st.align ? `<alignment${st.align.h ? ` horizontal="${st.align.h}"` : ""}${st.align.v ? ` vertical="${st.align.v}"` : ""}${st.align.wrap ? ' wrapText="1"' : ""}/>` : "";
        xfs.push(`<xf numFmtId="${numId}" fontId="${fontId}" fillId="${fillId}" borderId="${borderId}" xfId="0"${numId ? ' applyNumberFormat="1"' : ""}${fontId ? ' applyFont="1"' : ""}${fillId ? ' applyFill="1"' : ""}${borderId ? ' applyBorder="1"' : ""}${al ? ' applyAlignment="1">' + al + "</xf>" : "/>"}`);
      }
      return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">` +
        (numFmts.length ? `<numFmts count="${numFmts.length}">${numFmts.join("")}</numFmts>` : "") +
        `<fonts count="${fonts.length}">${fonts.join("")}</fonts><fills count="${fills.length}">${fills.join("")}</fills><borders count="${borders.length}">${borders.join("")}</borders>` +
        `<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="${xfs.length}">${xfs.join("")}</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
    }
    async blob() {
      const z = new JSZip();
      z.file("[Content_Types].xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${this.sheets.map((s, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join("")}</Types>`);
      z.file("_rels/.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`);
      z.file("xl/workbook.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${this.sheets.map((s, i) => `<sheet name="${esc(s.name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join("")}</sheets><calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>`);
      z.file("xl/_rels/workbook.xml.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${this.sheets.map((s, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join("")}<Relationship Id="rId${this.sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`);
      this.sheets.forEach((s, i) => z.file(`xl/worksheets/sheet${i + 1}.xml`, s.xml()));
      z.file("xl/styles.xml", this.stylesXml());
      return z.generateAsync({ type: "blob", mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", compression: "DEFLATE" });
    }
  }

  class Sheet {
    constructor(book, name) { this.book = book; this.name = name.slice(0, 31); this.rows = new Map(); this.merges = []; this.widths = {}; this.heights = {}; this.frz = null; }
    set(r, c, v, st) {
      if (!this.rows.has(r)) this.rows.set(r, new Map());
      this.rows.get(r).set(c, { v, s: this.book.sid(st) });
    }
    merge(r1, c1, r2, c2) { this.merges.push(ref(r1, c1) + ":" + ref(r2, c2)); }
    width(c, w) { this.widths[c] = w; }
    height(r, h) { this.heights[r] = h; }
    freeze(r, c) { this.frz = { r, c }; }
    xml() {
      let out = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">`;
      if (this.frz) {
        const { r, c } = this.frz;
        out += `<sheetViews><sheetView workbookViewId="0"><pane${c > 1 ? ` xSplit="${c - 1}"` : ""}${r > 1 ? ` ySplit="${r - 1}"` : ""} topLeftCell="${ref(r, c)}" activePane="bottomRight" state="frozen"/></sheetView></sheetViews>`;
      }
      const cs = Object.keys(this.widths).map(Number).sort((a, b) => a - b);
      if (cs.length) out += "<cols>" + cs.map((c) => `<col min="${c}" max="${c}" width="${this.widths[c]}" customWidth="1"/>`).join("") + "</cols>";
      out += "<sheetData>";
      const rs = [...this.rows.keys()].sort((a, b) => a - b);
      for (const r of rs) {
        const h = this.heights[r];
        out += `<row r="${r}"${h ? ` ht="${h}" customHeight="1"` : ""}>`;
        const cells = [...this.rows.get(r).entries()].sort((a, b) => a[0] - b[0]);
        for (const [c, { v, s }] of cells) {
          const a = ref(r, c), sa = s ? ` s="${s}"` : "";
          if (v === null || v === undefined || v === "") out += `<c r="${a}"${sa}/>`;
          else if (typeof v === "number") out += Number.isFinite(v) ? `<c r="${a}"${sa}><v>${v}</v></c>` : `<c r="${a}"${sa}/>`;
          else if (v instanceof Date) { const ser = (Date.UTC(v.getFullYear(), v.getMonth(), v.getDate()) - Date.UTC(1899, 11, 30)) / 864e5; out += `<c r="${a}"${sa}><v>${ser}</v></c>`; }
          else if (typeof v === "object" && v.f) out += `<c r="${a}"${sa}><f>${esc(v.f)}</f></c>`;
          else out += `<c r="${a}"${sa} t="inlineStr"><is><t xml:space="preserve">${esc(v)}</t></is></c>`;
        }
        out += "</row>";
      }
      out += "</sheetData>";
      if (this.merges.length) out += `<mergeCells count="${this.merges.length}">${this.merges.map((m) => `<mergeCell ref="${m}"/>`).join("")}</mergeCells>`;
      return out + "</worksheet>";
    }
  }
  // ===== Xuất 1 bảng HTML ra Excel, GIỮ ĐÚNG MÀU đang hiển thị trên trang =====
  const _pc = (s) => { const m = /rgba?\(([^)]+)\)/.exec(s || ""); if (!m) return null; const p = m[1].split(",").map((x) => parseFloat(x)); return { r: p[0] || 0, g: p[1] || 0, b: p[2] || 0, a: p[3] == null ? 1 : p[3] }; };
  const _h2 = (n) => ("0" + Math.max(0, Math.min(255, Math.round(n))).toString(16)).slice(-2).toUpperCase();
  const _blend = (c) => _h2(c.r * c.a + 255 * (1 - c.a)) + _h2(c.g * c.a + 255 * (1 - c.a)) + _h2(c.b * c.a + 255 * (1 - c.a));
  const _rgb = (c) => _h2(c.r) + _h2(c.g) + _h2(c.b);
  const _white = (c) => c.a < 0.04 || (c.r > 245 && c.g > 245 && c.b > 245);
  function fromTable(table, opts) {
    opts = opts || {}; const wb = new Book(), ws = wb.sheet((opts.sheet || "Bảng").replace(/[\\/?*\[\]:]/g, "-")), W = globalThis.getComputedStyle;
    const widths = {}; let maxCol = 0, r = 0;
    for (const tr of table.querySelectorAll("tr")) {
      const cells = [...tr.children].filter((el) => el.tagName === "TD" || el.tagName === "TH");
      if (!cells.length) continue; r++; let c = 1;
      for (const cell of cells) {
        const span = parseInt(cell.getAttribute("colspan") || "1", 10) || 1;
        const txt = (cell.innerText || "").replace(/\s+/g, " ").trim();
        const kids = [cell, ...cell.querySelectorAll("*")];
        let bg = null; for (const el of kids) { const p = _pc(W(el).backgroundColor); if (p && p.a > 0.04 && !_white(p)) bg = p; }
        let te = cell; for (const el of kids) { if (!el.children.length && (el.textContent || "").trim()) te = el; }
        const cs = W(te), col = _pc(cs.color), bold = (parseInt(cs.fontWeight, 10) || 400) >= 600, isH = cell.tagName === "TH";
        const ar = W(cell).textAlign, al = ar === "right" || ar === "end" ? "right" : ar === "center" ? "center" : "left";
        const st = { font: { name: "Arial", size: 10, bold: bold || isH }, border: true, align: { h: al } };
        if (bg) st.fill = _blend(bg); else if (isH) st.fill = "EEF1F7";
        if (col) { const L = (0.2126 * col.r + 0.7152 * col.g + 0.0722 * col.b) / 255; st.font.color = (L > 0.72 && !st.fill) ? "444B59" : _rgb(col); }
        if (isH) { st.align.v = "center"; st.align.wrap = true; }
        let val = txt;
        if (/^-?[\d.\s,]+$/.test(txt) && /\d/.test(txt) && txt.replace(/\D/g, "").length <= 15) { const cl = txt.replace(/\s/g, "").replace(/\./g, "").replace(/,/g, "."); const n = Number(cl); if (Number.isFinite(n)) { val = n; st.fmt = Number.isInteger(n) ? "#,##0" : "#,##0.00"; } }
        ws.set(r, c, val === "" ? null : val, st);
        if (span > 1) ws.merge(r, c, r, c + span - 1);
        for (let i = 0; i < span; i++) widths[c + i] = Math.max(widths[c + i] || 8, Math.min(44, Math.max(8, (txt.length / span || 2) * 1.15 + (isH ? 2 : 0))));
        c += span; maxCol = Math.max(maxCol, c - 1);
      }
    }
    for (const k in widths) ws.width(+k, widths[k]);
    if (r > 1) ws.freeze(2, maxCol > 4 ? 2 : 1);
    return wb;
  }
  const _slug = (s) => String(s).normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/gi, "d").replace(/[^a-z0-9]+/gi, "_").replace(/^_|_$/g, "").slice(0, 48) || "bang";
  async function download(table, name) {
    // đọc màu theo giao diện SÁNG để file luôn rõ chữ (nếu đang ở nền Tối, tạm chuyển rồi trả lại — không nháy vì đọc xong mới await)
    const bd = document.body, prev = bd && bd.dataset ? bd.dataset.skin : null, chg = bd && prev !== "b";
    if (chg) bd.dataset.skin = "b";
    let wb; try { wb = fromTable(table, { sheet: (name || "Bảng").slice(0, 31) }); } finally { if (chg) { if (prev == null || prev === "") delete bd.dataset.skin; else bd.dataset.skin = prev; } }
    const blob = await wb.blob();
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob);
    const d = new Date(); a.download = _slug(name) + "_" + ("0" + d.getDate()).slice(-2) + ("0" + (d.getMonth() + 1)).slice(-2) + ".xlsx";
    document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
  }
  // ===== Tải biểu đồ (SVG/canvas) ra ảnh PNG, kèm tiêu đề + chú thích, giữ màu như trên trang =====
  function _chartSvg(card) {
    const s = card.querySelector('svg[role="img"], svg[aria-label]'); if (s) return s;
    return [...card.querySelectorAll("svg")].find((x) => { const vb = x.viewBox && x.viewBox.baseVal; return vb && vb.width >= 200 && !x.classList.contains("wave"); }) || null;
  }
  function _inlineSvg(src, dst) {
    const PR = ["fill", "stroke", "stroke-width", "opacity", "stroke-dasharray", "font-size", "font-family", "font-weight", "text-anchor"];
    const ss = src.querySelectorAll("*"), ds = dst.querySelectorAll("*");
    const put = (s, d) => { const cs = getComputedStyle(s); let st = ""; for (const p of PR) { const v = cs.getPropertyValue(p); if (v) st += p + ":" + v + ";"; } d.setAttribute("style", st); };
    put(src, dst); for (let i = 0; i < ss.length && i < ds.length; i++) put(ss[i], ds[i]);
  }
  function _dl(blob, fname) { const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = fname; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500); }
  async function chartImg(card, name) {
    const bd = document.body, prev = bd && bd.dataset ? bd.dataset.skin : null, chg = bd && prev !== "b";
    if (chg) bd.dataset.skin = "b";
    try {
      const svg = _chartSvg(card), cvs = card.querySelector("canvas:not(#bgfx-cv)");
      const legend = [...card.querySelectorAll(".legend span, .leg span")].map((sp) => { const i = sp.querySelector("i, b, em"); return { c: i ? getComputedStyle(i).backgroundColor : "#64748b", t: (sp.textContent || "").replace(/\s+/g, " ").trim() }; }).filter((x) => x.t);
      let w, h, src = null;
      if (svg) {
        const vb = svg.viewBox && svg.viewBox.baseVal; w = vb && vb.width ? vb.width : (svg.clientWidth || 560); h = vb && vb.height ? vb.height : (svg.clientHeight || 210);
        const clone = svg.cloneNode(true); _inlineSvg(svg, clone); clone.setAttribute("xmlns", "http://www.w3.org/2000/svg"); clone.setAttribute("width", w); clone.setAttribute("height", h);
        const xml = new XMLSerializer().serializeToString(clone);
        src = "data:image/svg+xml;base64," + btoa(unescape(encodeURIComponent(xml)));
      } else if (cvs) { w = cvs.width; h = cvs.height; src = cvs.toDataURL("image/png"); }
      else throw new Error("không tìm thấy biểu đồ");
      const sc = 2, pad = 16, titleH = name ? 26 : 6, legH = legend.length ? 24 : 6;
      const CW = w + pad * 2, CH = h + titleH + legH + pad;
      const cv = document.createElement("canvas"); cv.width = Math.round(CW * sc); cv.height = Math.round(CH * sc);
      const cx = cv.getContext("2d"); cx.scale(sc, sc); cx.fillStyle = "#ffffff"; cx.fillRect(0, 0, CW, CH);
      if (name) { cx.fillStyle = "#16202f"; cx.font = "bold 15px Arial,sans-serif"; cx.textBaseline = "alphabetic"; cx.fillText(name, pad, 20); }
      await new Promise((res, rej) => { const im = new Image(); im.onload = () => { try { cx.drawImage(im, pad, titleH, w, h); res(); } catch (e) { rej(e); } }; im.onerror = () => rej(new Error("render SVG lỗi")); im.src = src; });
      if (legend.length) { let lx = pad; const ly = titleH + h + 16; cx.font = "12px Arial,sans-serif"; for (const it of legend) { cx.fillStyle = it.c; cx.fillRect(lx, ly - 9, 11, 11); lx += 15; cx.fillStyle = "#334155"; cx.fillText(it.t, lx, ly); lx += cx.measureText(it.t).width + 16; } }
      const blob = await new Promise((r) => cv.toBlob(r, "image/png"));
      const d = new Date();
      _dl(blob, _slug(name) + "_" + ("0" + d.getDate()).slice(-2) + ("0" + (d.getMonth() + 1)).slice(-2) + ".png");
    } finally { if (chg) { if (prev == null || prev === "") delete bd.dataset.skin; else bd.dataset.skin = prev; } }
  }
  // Gắn nút vào mỗi thẻ: bảng -> "Excel"; biểu đồ -> "Ảnh" (bỏ qua thẻ đã có nút tải sẵn)
  function injectButtons(root) {
    (root || document).querySelectorAll(".card").forEach((card) => {
      if (card.querySelector(":scope .xls-gen")) return;
      const hd = card.querySelector(".card-h"); if (!hd) return;
      const table = card.querySelector("table"), chart = table ? null : (_chartSvg(card) || card.querySelector("canvas:not(#bgfx-cv)"));
      if (!table && !chart) return;
      if ([...card.querySelectorAll("button, a, .bbtn")].some((b) => /tải excel|xuất excel|tải xuống|tải dữ liệu|tải ảnh/i.test(b.textContent || ""))) return;
      const btn = document.createElement("button"); btn.className = "xls-gen"; btn.type = "button";
      if (table) { btn.title = "Tải bảng này ra Excel — giữ đúng màu như trên trang"; btn.innerHTML = '<svg viewBox="0 0 24 24" width="13" height="13" aria-hidden="true"><path d="M12 3v12M7 10l5 5 5-5M4 21h16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>Excel'; }
      else { btn.title = "Tải biểu đồ này ra ảnh PNG — giống như trên trang"; btn.innerHTML = '<svg viewBox="0 0 24 24" width="13" height="13" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="2" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="8.5" cy="9.5" r="1.6" fill="currentColor"/><path d="M4 18l5-5 4 4 3-3 4 4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>Ảnh'; }
      btn.addEventListener("click", async (e) => { e.stopPropagation(); if (btn.disabled) return; btn.disabled = true; const h3 = card.querySelector("h3"); const nm = h3 ? h3.textContent.trim() : "bieu_do"; try { if (table) await download(table, nm); else await chartImg(card, nm); } catch (err) { btn.title = "Lỗi: " + (err && err.message || ""); } finally { btn.disabled = false; } });
      hd.appendChild(btn);
    });
  }
  return { Book, col, ref, fromTable, download, chartImg, injectButtons };
})();
