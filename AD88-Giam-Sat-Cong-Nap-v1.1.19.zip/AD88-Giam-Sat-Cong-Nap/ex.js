// Xuất bảng ra Excel GIỐNG GIAO DIỆN: đọc đúng màu nền, màu chữ, đậm/lợt, canh lề đang hiển thị của từng ô.
// Tự gắn nút "Tải Excel" vào mỗi thẻ (card) có bảng. Dùng chung cho trang Nạp và trang Xuất. Không dùng eval (hợp CSP MV3).
const TableXL = (() => {
  const parseRGB = (s) => { const m = /rgba?\(([^)]+)\)/.exec(s || ""); if (!m) return null; const p = m[1].split(",").map((x) => parseFloat(x)); return { r: p[0] || 0, g: p[1] || 0, b: p[2] || 0, a: p[3] == null ? 1 : p[3] }; };
  const over = (fg, bg) => { const a = fg.a; return { r: fg.r * a + bg.r * (1 - a), g: fg.g * a + bg.g * (1 - a), b: fg.b * a + bg.b * (1 - a), a: 1 }; };
  const toHex = (c) => [c.r, c.g, c.b].map((v) => ("0" + Math.round(Math.max(0, Math.min(255, v))).toString(16)).slice(-2)).join("").toUpperCase();
  function effBg(el) { const chain = []; let e = el; while (e) { chain.push(e); if (e === document.body) break; e = e.parentElement; } let base = { r: 255, g: 255, b: 255, a: 1 }; for (let i = chain.length - 1; i >= 0; i--) { const c = parseRGB(getComputedStyle(chain[i]).backgroundColor); if (c && c.a > 0) base = over(c, base); } return base; }
  // ô: tìm nền thực tế (có thể nằm ở span con tô nhiệt), màu chữ và độ đậm
  function cellStyle(td, isHead) {
    // nền: nếu ô chỉ có 1 con và con đó có nền (ô tô nhiệt) thì lấy nền con, không thì lấy nền ô
    let bgEl = td; const kids = [...td.children];
    if (kids.length === 1) { const c = parseRGB(getComputedStyle(kids[0]).backgroundColor); if (c && c.a > 0) bgEl = kids[0]; }
    const bg = effBg(bgEl);
    // màu chữ: lấy ở phần tử mang chữ sâu nhất
    let txtEl = td; const tk = [...td.querySelectorAll("*")].filter((k) => k.childNodes.length && [...k.childNodes].some((n) => n.nodeType === 3 && n.textContent.trim()));
    if (tk.length) txtEl = tk[0];
    const cs = getComputedStyle(txtEl), col = parseRGB(cs.color) || { r: 0, g: 0, b: 0 };
    const bold = isHead || +cs.fontWeight >= 600 || txtEl.tagName === "B" || txtEl.tagName === "TH";
    let al = (getComputedStyle(td).textAlign || "left"); if (al === "start") al = "left"; if (al === "end") al = "right";
    const st = { font: { name: "Arial", size: 10, bold }, border: true, align: { h: al, v: "center" } };
    if (!(bg.r >= 250 && bg.g >= 250 && bg.b >= 250) || isHead) st.fill = toHex(bg);
    if (!(col.r <= 45 && col.g <= 45 && col.b <= 45)) st.font.color = toHex(col);
    return st;
  }
  const num = (t) => { if (/^-?\d{1,3}(\.\d{3})+$/.test(t)) return parseInt(t.replace(/\./g, ""), 10); if (/^-?\d{1,9}$/.test(t)) return parseInt(t, 10); return null; };
  function sheetName(s) { return (s || "Bảng").replace(/[\\/?*\[\]:]/g, "-").trim().slice(0, 31) || "Bảng"; }
  function fileName(s) { return (s || "bang").normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/gi, "d").replace(/[^A-Za-z0-9]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 60) || "bang"; }

  async function fromTable(tbl, title) {
    const wb = new XLSXW.Book(), ws = wb.sheet(sheetName(title));
    const widths = {}; let rIdx = 0, headRows = 0;
    for (const tr of tbl.rows) {
      rIdx++; const isHead = tr.parentElement && tr.parentElement.tagName === "THEAD";
      if (isHead) headRows = rIdx;
      let c = 1;
      for (const cell of tr.cells) {
        const span = cell.colSpan || 1, txt = (cell.textContent || "").replace(/\s+/g, " ").trim();
        const stv = cellStyle(cell, isHead || cell.tagName === "TH");
        const n = !isHead && cell.tagName !== "TH" ? num(txt) : null;
        if (n != null) { stv.fmt = "#,##0"; ws.set(rIdx, c, n, stv); } else ws.set(rIdx, c, txt, stv);
        if (span > 1) ws.merge(rIdx, c, rIdx, c + span - 1);
        for (let k = 0; k < span; k++) widths[c + k] = Math.max(widths[c + k] || 6, Math.min(34, Math.ceil(txt.length / span) + 2));
        c += span;
      }
    }
    Object.keys(widths).forEach((c) => ws.width(+c, widths[c]));
    if (headRows) { ws.freeze(headRows + 1, 2); ws.height(headRows, 26); }
    const blob = await wb.blob();
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob);
    const now = new Date(), stamp = `${String(now.getDate()).padStart(2, "0")}-${String(now.getMonth() + 1).padStart(2, "0")}_${String(now.getHours()).padStart(2, "0")}h${String(now.getMinutes()).padStart(2, "0")}`;
    a.download = `${fileName(title)}_${stamp}.xlsx`; document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
  }

  const ICON = '<span class="ic sm"><svg viewBox="0 0 24 24"><path d="M12 3v12M7 10l5 5 5-5M4 21h16"/></svg></span>Tải Excel';
  function mount(root) {
    (root || document).querySelectorAll(".card").forEach((card) => {
      const h = card.querySelector(".card-h"); const tbl = card.querySelector("table");
      if (!h || !tbl || h.querySelector(".xl-btn")) return;
      if (/Tải Excel/i.test(h.textContent)) return;   // đã có nút xuất riêng thì thôi
      const b = document.createElement("button"); b.type = "button"; b.className = "bbtn green xl-btn";
      b.innerHTML = ICON; b.style.cssText = "margin-left:auto;padding:4px 10px";
      b.onclick = () => { b.disabled = true; const t = (card.querySelector(".card-h h3") || {}).textContent || "Bang"; fromTable(card.querySelector("table"), t).catch((e) => console.warn("xuat excel:", e)).finally(() => (b.disabled = false)); };
      h.appendChild(b);
    });
  }
  return { fromTable, mount };
})();
