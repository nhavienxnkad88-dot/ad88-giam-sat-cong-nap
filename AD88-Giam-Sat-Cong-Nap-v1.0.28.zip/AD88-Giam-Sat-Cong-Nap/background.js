// AD88 Giám Sát Cổng Nạp — nền (service worker)
importScripts("config.js");

const DASH = "dashboard.html";

async function openDashboard() {
  const url = chrome.runtime.getURL(DASH);
  const tabs = await chrome.tabs.query({ url });
  if (tabs.length) {
    await chrome.tabs.update(tabs[0].id, { active: true });
    await chrome.windows.update(tabs[0].windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url });
  }
}
chrome.action.onClicked.addListener(openDashboard);

async function getDomain() {
  const s = await chrome.storage.local.get("boDomain");
  return (s.boDomain || CFG.BO_DOMAIN).trim();
}

// Cho request của tool mang Origin/Referer giống trang BO
async function applyHeaderRules() {
  const domain = await getDomain();
  const rule = {
    id: 1,
    priority: 1,
    action: {
      type: "modifyHeaders",
      requestHeaders: [
        { header: "origin", operation: "set", value: "https://" + domain },
        { header: "referer", operation: "set", value: "https://" + domain + "/" }
      ]
    },
    condition: {
      requestDomains: [domain],
      initiatorDomains: [chrome.runtime.id],
      resourceTypes: ["xmlhttprequest"]
    }
  };
  try {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: [1], addRules: [rule] });
  } catch (e) { console.warn("DNR", e); }
}

chrome.runtime.onInstalled.addListener(async (d) => {
  await applyHeaderRules();
  const s = await chrome.storage.local.get("reopenAfterUpdate");
  if (s.reopenAfterUpdate) {
    await chrome.storage.local.remove("reopenAfterUpdate");
    openDashboard();
  } else if (d.reason === "install") {
    openDashboard();
  }
});
chrome.runtime.onStartup.addListener(applyHeaderRules);

// Ghi nhớ header đăng nhập mà trang BO gửi đi (Authorization, token…)
const SKIP = new Set(["cookie", "content-length", "host", "origin", "referer", "user-agent", "accept-encoding",
  "connection", "content-type", "accept", "accept-language", "priority", "pragma", "cache-control"]);
chrome.webRequest.onSendHeaders.addListener(
  async (det) => {
    try {
      if (det.initiator && det.initiator.startsWith("chrome-extension://")) return;
      const u = new URL(det.url);
      const headers = {};
      for (const h of det.requestHeaders || []) {
        const n = h.name.toLowerCase();
        if (SKIP.has(n) || n.startsWith("sec-")) continue;
        headers[h.name] = h.value;
      }
      const prev = (await chrome.storage.local.get("boAuth")).boAuth || {};
      const same = prev.domain === u.host && JSON.stringify(prev.headers) === JSON.stringify(headers);
      if (!same || Date.now() - (prev.at || 0) > 60000) {
        await chrome.storage.local.set({ boAuth: { domain: u.host, headers, at: Date.now() } });
      }
    } catch (e) { /* bỏ qua */ }
  },
  { urls: ["https://*/api/*"], types: ["xmlhttprequest"] },
  ["requestHeaders", "extraHeaders"]
);

// Ghi nhớ nội dung request của trang Cài đặt nạp tiền (tab Cấu hình chính và tab Kênh bị vô hiệu hóa) để tool gọi y hệt
chrome.webRequest.onBeforeRequest.addListener(
  (det) => {
    try {
      if (det.initiator && det.initiator.startsWith("chrome-extension://")) return;
      const rb = det.requestBody; let txt = "";
      if (rb && rb.raw && rb.raw[0] && rb.raw[0].bytes) txt = new TextDecoder().decode(rb.raw[0].bytes);
      const key = det.url.includes("/paySetOnlineStop/") ? "paySetStopBody" : "paySetBody";
      chrome.storage.local.set({ [key]: txt || "{}" });
    } catch (e) { /* bỏ qua */ }
  },
  { urls: ["https://*/api/finance/paySettingOnline/getPaySettingList*", "https://*/api/finance/paySetOnlineStop/getPaySettingList*"], types: ["xmlhttprequest"] },
  ["requestBody"]
);

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg && msg.type === "applyRules") { applyHeaderRules().then(() => reply({ ok: true })); return true; }
  if (msg && msg.type === "notify") {
    chrome.notifications.create("", { type: "basic", iconUrl: "assets/icon128.png", title: msg.title || "AD88 Giám Sát", message: msg.text || "", priority: 2 });
    reply({ ok: true });
  }
});
