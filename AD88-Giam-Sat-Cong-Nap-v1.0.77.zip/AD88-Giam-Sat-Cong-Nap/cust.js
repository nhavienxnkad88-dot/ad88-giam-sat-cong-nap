// Thống kê khách theo ngày / tháng (dùng chung cho trang NẠP và trang XUẤT).
// Mỗi ngày lưu 1 bản tóm tắt trong máy: kv "cust:YYYY-MM-DD" = { v, n, ok, e, amt, acc: [tài khoản], okAcc: số khách thành công }.
// Bản tóm tắt không bị xóa theo hạn giữ đơn, nên xem lại được cả tháng / các tháng trước.
const Cust = (() => {
  const P2 = (n) => String(n).padStart(2, "0");
  const F = (n) => Math.round(n || 0).toLocaleString("vi-VN");
  const DAYS = (ym) => { const [y, m] = ym.split("-").map(Number); return new Date(y, m, 0).getDate(); };
  const addM = (ym, d) => { const [y, m] = ym.split("-").map(Number); const t = new Date(y, m - 1 + d, 1); return t.getFullYear() + "-" + P2(t.getMonth() + 1); };

  // f = { acc(o), ok(o), bad(o), amt(o) }
  function sum(list, f) {
    const acc = new Set(), okA = new Set(); let n = 0, ok = 0, e = 0, amt = 0;
    for (const o of list) { n++; const a = f.acc(o); if (a) acc.add(a); if (f.ok(o)) { ok++; amt += f.amt(o); if (a) okA.add(a); } else if (f.bad(o)) e++; }
    return { v: 2, n, ok, e, amt, acc: [...acc], okA: [...okA] };
  }

  // tải bản tóm tắt các ngày trong tháng; ngày chưa có tóm tắt thì tính từ đơn còn lưu trong máy
  async function load(store, ym, today, todaySum, fromOrders) {
    const M = {}, n = DAYS(ym);
    for (let d = 1; d <= n; d++) {
      const dk = ym + "-" + P2(d);
      if (dk > today) { M[dk] = undefined; continue; }
      if (dk === today) { M[dk] = todaySum; continue; }
      let s = await store.kvGet("cust:" + dk).catch(() => null); if (s && s.v !== 2) s = null;
      // bản lưu trong ngày (chưa chốt) → tính lại từ đơn đầy đủ của ngày đó nếu máy còn giữ
      if ((!s || !s.fin) && fromOrders) { const L = await fromOrders(dk).catch(() => null); if (L && L.n && (!s || L.n >= s.n)) { s = { ...L, fin: 1 }; store.kvSet("cust:" + dk, s).catch(() => {}); } }
      M[dk] = s || null;
    }
    return M;
  }

  function total(M) {
    const okA = new Set(); let n = 0, ok = 0, e = 0, amt = 0, days = 0, dsum = 0;
    for (const s of Object.values(M)) { if (!s) continue; days++; n += s.n; ok += s.ok; e += s.e; amt += s.amt; dsum += s.okA.length; for (const a of s.okA) okA.add(a); }
    return { n, ok, e, amt, days, okAcc: okA.size, accDay: days ? dsum / days : 0, okDay: days ? ok / days : 0, rate: n ? ok / n * 100 : null };
  }

  const rc = (r) => (r == null ? "" : r >= 85 ? "ok" : r >= 60 ? "warn" : "bad");
  // opt = { ym, M, P (tháng trước), unit: "đơn nạp", who: "khách nạp", okName: "thành công", today }
  function html(opt) {
    const { ym, M, P, unit, who, okName, today } = opt, n = DAYS(ym), T = total(M);
    // so cùng kỳ: tháng đang chạy thì chỉ lấy tháng trước tới cùng ngày
    const cut = ym === today.slice(0, 7) ? +today.slice(8) : 99, TP = P ? total(Object.fromEntries(Object.entries(P).filter(([k]) => +k.slice(8) <= cut))) : null;
    const cmp = (a, b) => (b && a != null && b > 0 ? (a >= b ? `<span class="ok">▲ ${((a - b) / b * 100).toFixed(0)}%</span>` : `<span class="bad">▼ ${((b - a) / b * 100).toFixed(0)}%</span>`) + ` <span class="mut">so với ${cut < 99 ? "cùng kỳ " : ""}tháng trước</span>` : `<span class="mut">tháng trước chưa có dữ liệu</span>`);
    const tile = (k, t, v, sub) => `<div class="cm-k" style="--k:${k}"><small>${t}</small><b>${v}</b><span>${sub}</span></div>`;
    const rk = T.rate == null ? "#64748b" : T.rate >= 85 ? "#16a34a" : T.rate >= 60 ? "#d98a00" : "#e2364a";
    let h = `<div class="cm-tiles">${tile("#16a34a", unit + " " + okName + " trong tháng", F(T.ok), cmp(T.ok, TP && TP.ok))}${tile("#7c3aed", who + " " + okName + " trong tháng", F(T.okAcc), "mỗi tài khoản tính 1 lần · " + cmp(T.okAcc, TP && TP.okAcc))}${tile("#0891b2", "Trung bình mỗi ngày", F(T.okDay) + " " + unit, F(T.accDay) + " " + who + " / ngày · " + T.days + " ngày có dữ liệu")}${tile(rk, "Tỷ lệ " + okName + " tháng", T.rate == null ? "—" : T.rate.toFixed(1) + "%", F(T.ok) + " / " + F(T.n) + " " + unit + " · " + F(T.amt) + " ₫")}</div>`;
    // biểu đồ 1 cột / ngày: cột = số đơn (xanh thành công, đỏ không thành công, vàng còn lại) · chấm xanh dương = số khách
    const mx = Math.max(1, ...Object.values(M).map((s) => (s ? s.ok : 0))), step = [1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000].find((s) => mx / s <= 5) || 50000, top = Math.ceil(mx / step) * step;
    const W = 760, H = 270, L = 46, R = 8, Tp = 14, B = 34, cw = (W - L - R) / n, y = (v) => Tp + (H - Tp - B) * (1 - v / top);
    let s = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${unit} theo ngày">`;
    for (let v = 0; v <= top; v += step) s += `<line class="gl" x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}"/><text x="${L - 6}" y="${y(v) + 3}" text-anchor="end">${F(v)}</text>`;
    const pts = [];
    for (let d = 1; d <= n; d++) {
      const dk = ym + "-" + P2(d), x = M[dk], cx = L + (d - 0.5) * cw, bw = cw * 0.7, bx = cx - bw / 2, wd = new Date(dk + "T00:00:00").getDay();
      s += `<text x="${cx.toFixed(1)}" y="${H - 19}" text-anchor="middle" class="${dk === today ? "cm-td" : wd === 0 ? "cm-su" : ""}">${d}</text><text x="${cx.toFixed(1)}" y="${H - 7}" text-anchor="middle" class="cm-wd">${["CN", "T2", "T3", "T4", "T5", "T6", "T7"][wd]}</text>`;
      if (x === undefined) continue;
      if (!x) { s += `<rect x="${bx.toFixed(1)}" y="${(y(0) - 18).toFixed(1)}" width="${bw.toFixed(1)}" height="18" class="cm-miss" rx="2"><title>${d}/${ym.slice(5)}: máy chưa có dữ liệu ngày này</title></rect>`; continue; }
      const r = x.n ? x.ok / x.n * 100 : null, tip = `${P2(d)}/${ym.slice(5)}: ${F(x.ok)} ${unit} ${okName} / ${F(x.n)} ${unit} (${r == null ? "—" : r.toFixed(1) + "%"}) · ${F(x.okA.length)} ${who} ${okName} / ${F(x.acc.length)} ${who} · ${F(x.amt)} ₫`;
      if (x.ok > 0) s += `<rect x="${bx.toFixed(1)}" y="${y(x.ok).toFixed(1)}" width="${bw.toFixed(1)}" height="${(y(0) - y(x.ok)).toFixed(1)}" class="cm-bar ${rc(r)}" rx="2"><title>${tip}</title></rect>`;
      const yt = y(x.ok), inside = y(0) - yt > 46;
      s += `<text class="cm-v${inside ? " in" : ""}" transform="translate(${(cx + 3.5).toFixed(1)},${(inside ? yt + 5 : yt - 4).toFixed(1)}) rotate(-90)" text-anchor="${inside ? "end" : "start"}">${F(x.ok)}</text>`;
      pts.push([cx, y(x.okA.length), x.okA.length, d]);
    }
    if (pts.length) s += `<polyline points="${pts.map((p) => p[0].toFixed(1) + "," + p[1].toFixed(1)).join(" ")}" fill="none" stroke="#2563eb" stroke-width="1.6" stroke-dasharray="3 2"/>` + pts.map((p) => `<circle cx="${p[0].toFixed(1)}" cy="${p[1].toFixed(1)}" r="2.6" fill="#2563eb" stroke="var(--panel)" stroke-width="1.2"><title>${P2(p[3])}/${ym.slice(5)}: ${F(p[2])} ${who}</title></circle>`).join("");
    h += `<div class="cm-chart chart">${s}</svg></div><div class="legend cm-leg"><span><i style="background:var(--b1)"></i>Cột = ${unit} ${okName} (màu theo tỷ lệ: xanh ≥ 85% · vàng 60–85% · đỏ &lt; 60%)</span><span><i style="background:#2563eb;border-radius:50%"></i>Số ${who} ${okName}</span><span><i class="cm-miss-i"></i>Máy chưa có dữ liệu ngày đó</span><span class="mut">Số trên mỗi cột = số ${unit} ${okName} trong ngày · rê chuột vào cột để xem chi tiết</span></div>`;
    return h;
  }

  // gắn khung tháng vào 1 thẻ: el.innerHTML gồm đầu thẻ có nút ‹ tháng ›
  function mount(box, cfg) {
    // cfg: { store, today(), todaySum(), fromOrders(dk), unit, who, okName, title }
    const S = { ym: cfg.today().slice(0, 7), M: null, P: null, at: 0, ym0: null, busy: false };
    box.innerHTML = `<div class="card-h"><h3>${cfg.title}</h3><span class="hint cm-hint"></span><div class="cm-nav"><button class="btn" data-m="-1">‹</button><b class="cm-ym"></b><button class="btn" data-m="1">›</button></div></div><div class="card-b cm-body"><div class="mut">Đang tải…</div></div>`;
    box.querySelector(".cm-nav").onclick = (e) => { const b = e.target.closest("[data-m]"); if (!b) return; const nx = addM(S.ym, +b.dataset.m); if (nx > cfg.today().slice(0, 7)) return; S.ym = nx; S.M = null; draw(true); };
    let saveAt = 0;
    async function draw(force) {
      const today = cfg.today(), ts = cfg.todaySum();
      box.querySelector(".cm-ym").textContent = "Tháng " + S.ym.slice(5) + "/" + S.ym.slice(0, 4);
      box.querySelector('[data-m="1"]').disabled = S.ym >= today.slice(0, 7);
      if (ts && Date.now() - saveAt > 300e3) { saveAt = Date.now(); cfg.store.kvSet("cust:" + today, ts).catch(() => {}); }
      if (S.busy) return;
      if (!S.M || S.ym0 !== S.ym || force || Date.now() - S.at > 600e3) {
        S.busy = true;
        try { S.ym0 = S.ym; S.M = await load(cfg.store, S.ym, today, ts, cfg.fromOrders); S.P = await load(cfg.store, addM(S.ym, -1), today, ts, null); S.at = Date.now(); } finally { S.busy = false; }
      }
      if (S.ym === today.slice(0, 7)) S.M[today] = ts;
      box.querySelector(".cm-hint").textContent = "1 cột = 1 ngày · mỗi ngày tool tự lưu lại số " + cfg.unit + " và số " + cfg.who;
      box.querySelector(".cm-body").innerHTML = html({ ym: S.ym, M: S.M, P: S.P, unit: cfg.unit, who: cfg.who, okName: cfg.okName, today });
    }
    return { draw };
  }
  return { sum, mount, html, total };
})();
