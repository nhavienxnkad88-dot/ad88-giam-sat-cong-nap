const Updater = (() => {
const cmp = (a, b) => { const x = a.split(".").map(Number), y = b.split(".").map(Number); for (let i = 0; i < Math.max(x.length, y.length); i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d; } return 0; };
const current = () => chrome.runtime.getManifest().version;
async function check() {
let j = null;
try {
const a = await fetch(`https://api.github.com/repos/${CFG.GH_OWNER}/${CFG.GH_REPO}/contents/${CFG.GH_DIR ? CFG.GH_DIR + "/" : ""}version.json?ref=${CFG.GH_BRANCH}&t=${Date.now()}`, { cache: "no-store", headers: { Accept: "application/vnd.github.raw+json" } });
if (a.ok) j = await a.json();
} catch (e) { }
if (!j) {
const r = await fetch(CFG.UPDATE_BASE + "version.json?t=" + Date.now(), { cache: "no-store" });
if (!r.ok) throw new Error("Không đọc được version.json trên GitHub (HTTP " + r.status + ").");
j = await r.json();
}
return { latest: j.version, notes: j.notes || "", zip: j.zip, sha256: j.sha256 || "", hasNew: cmp(j.version, current()) > 0, current: current() };
}
const IDB = () => new Promise((res, rej) => { const r = indexedDB.open("ad88gs-upd", 1); r.onupgradeneeded = () => r.result.createObjectStore("h"); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
async function getHandle() { const d = await IDB(); return new Promise((res) => { const q = d.transaction("h").objectStore("h").get("dir"); q.onsuccess = () => res(q.result || null); q.onerror = () => res(null); }); }
async function setHandle(h) { const d = await IDB(); return new Promise((res) => { const t = d.transaction("h", "readwrite"); t.objectStore("h").put(h, "dir"); t.oncomplete = res; }); }
async function pickFolder() {
if (!window.showDirectoryPicker) throw new Error("Chrome này không hỗ trợ ghi thư mục. Hãy cập nhật Chrome lên bản mới.");
const h = await window.showDirectoryPicker({ id: "ad88gs", mode: "readwrite" });
await verifyFolder(h);
await setHandle(h);
return h;
}
async function verifyFolder(h) {
let m;
try { m = JSON.parse(await (await (await h.getFileHandle("manifest.json")).getFile()).text()); }
catch (e) { throw new Error("Thư mục này không có manifest.json. Hãy chọn đúng thư mục đang cài tool (thư mục có file manifest.json)."); }
if (m.name !== chrome.runtime.getManifest().name) throw new Error("Thư mục này là của tool khác (" + m.name + "). Hãy chọn thư mục AD88 Giám Sát Cổng Nạp.");
}
async function ensureHandle() {
let h = await getHandle();
if (h) {
let p = await h.queryPermission({ mode: "readwrite" });
if (p !== "granted") p = await h.requestPermission({ mode: "readwrite" });
if (p === "granted") { try { await verifyFolder(h); return h; } catch (e) { } }
}
return pickFolder();
}
async function sha256(buf) { const d = await crypto.subtle.digest("SHA-256", buf); return [...new Uint8Array(d)].map((b) => b.toString(16).padStart(2, "0")).join(""); }
async function writeFile(root, path, buf) {
const parts = path.split("/"); const name = parts.pop(); let dir = root;
for (const p of parts) dir = await dir.getDirectoryHandle(p, { create: true });
const fh = await dir.getFileHandle(name, { create: true });
const w = await fh.createWritable(); await w.write(buf); await w.close();
}
async function run(info, onStep) {
const h = await ensureHandle();
onStep("Đang tải " + info.zip + "…");
const r = await fetch(CFG.UPDATE_BASE + encodeURIComponent(info.zip) + "?t=" + Date.now(), { cache: "no-store" });
if (!r.ok) throw new Error("Không tải được " + info.zip + " (HTTP " + r.status + ").");
const buf = await r.arrayBuffer();
if (info.sha256 && (await sha256(buf)) !== info.sha256) throw new Error("File tải về bị lỗi (sai mã kiểm tra). Thử lại sau ít phút.");
const z = await JSZip.loadAsync(buf);
let names = Object.keys(z.files).filter((n) => !z.files[n].dir);
const top = names[0].split("/")[0] + "/";
const strip = names.every((n) => n.startsWith(top)) && !names.includes("manifest.json") ? top : "";
const files = names.map((n) => [n, n.slice(strip.length)]).filter(([, p]) => p && !p.startsWith("__MACOSX"));
if (!files.some(([, p]) => p === "manifest.json")) throw new Error("File zip không có manifest.json.");
files.sort((a, b) => (a[1] === "manifest.json") - (b[1] === "manifest.json"));
let i = 0;
for (const [n, p] of files) { onStep(`Đang ghi ${++i}/${files.length}: ${p}`); await writeFile(h, p, await z.files[n].async("arraybuffer")); }
onStep("Đã nâng cấp lên " + info.latest + ". Tool đang khởi động lại…");
await chrome.storage.local.set({ reopenAfterUpdate: true });
setTimeout(() => chrome.runtime.reload(), 900);
}
return { check, run, current, pickFolder };
})();
