const License = (() => {
const b64uDec = (s) => {
s = s.replace(/-/g, "+").replace(/_/g, "/");
while (s.length % 4) s += "=";
return Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
};
const enc = new TextEncoder();
let pubKey = null;
async function key() {
if (!pubKey) pubKey = await crypto.subtle.importKey("jwk", CFG.PUBLIC_KEY, { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]);
return pubKey;
}
async function deviceId() {
const s = await chrome.storage.local.get("deviceId");
if (s.deviceId) return s.deviceId;
const A = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const r = crypto.getRandomValues(new Uint8Array(12));
let id = "";
r.forEach((v, i) => { id += A[v % A.length]; if (i % 4 === 3 && i < 11) id += "-"; });
await chrome.storage.local.set({ deviceId: id });
return id;
}
async function trustedNow() {
const s = await chrome.storage.local.get(["lastTrusted", "serverTime"]);
const local = Math.floor(Date.now() / 1000);
let t = Math.max(local, s.lastTrusted || 0);
if (s.serverTime && s.serverTime.at) {
const drift = Math.floor((Date.now() - s.serverTime.at) / 1000);
t = Math.max(t, s.serverTime.ts + drift);
}
if (t - (s.lastTrusted || 0) > 30) await chrome.storage.local.set({ lastTrusted: t });
return t;
}
async function noteServerTime(ms) {
if (!ms) return;
await chrome.storage.local.set({ serverTime: { ts: Math.floor(ms / 1000), at: Date.now() } });
}
async function revokedList(force) {
const s = await chrome.storage.local.get("revoked");
const c = s.revoked || { ids: [], at: 0 };
if (force || Date.now() - c.at > 20 * 60e3) { 
try {
const r = await fetch(CFG.UPDATE_BASE + "revoked.json?t=" + Date.now(), { cache: "no-store" });
if (r.ok) {
const j = await r.json();
const n = { ids: j.revoked || [], at: Date.now() };
await chrome.storage.local.set({ revoked: n });
return n.ids;
}
} catch (e) { }
}
return c.ids;
}
async function parse(str) {
str = (str || "").trim().replace(/\s+/g, "");
const m = /^AD88GS-([A-Za-z0-9_-]+)\.([A-Za-z0-9_-]+)$/.exec(str);
if (!m) throw new Error("Key không đúng định dạng.");
const body = m[1], sig = b64uDec(m[2]);
const ok = await crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" }, await key(), sig, enc.encode(body));
if (!ok) throw new Error("Key không hợp lệ (sai chữ ký).");
const p = JSON.parse(new TextDecoder().decode(b64uDec(body)));
if (p.p !== CFG.PRODUCT) throw new Error("Key này không dành cho tool Giám sát cổng nạp.");
return p;
}
async function check(str, force) {
if (!str) return { ok: false, reason: "Chưa nhập key." };
let p;
try { p = await parse(str); } catch (e) { return { ok: false, reason: e.message }; }
const dev = await deviceId();
if (p.d !== "*" && p.d !== dev) return { ok: false, reason: "Key này cấp cho máy khác (mã máy " + p.d + ").", info: p };
const ids = await revokedList(force);
if (ids.includes(p.k)) return { ok: false, reason: "Key đã bị thu hồi.", info: p };
const now = await trustedNow();
if (p.e && now > p.e) return { ok: false, reason: "Key đã hết hạn ngày " + new Date(p.e * 1000).toLocaleString("vi-VN") + ".", info: p };
if (p.dom) {
const dom = ((await chrome.storage.local.get("boDomain")).boDomain || CFG.BO_DOMAIN || "").trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, "");
const want = String(p.dom).toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, "");
if (want && dom !== want) return { ok: false, reason: "Key này chỉ dùng cho sân " + p.dom + " (BO đang đặt: " + (dom || "chưa đặt") + "). Vào Cài đặt đổi Tên miền BO cho đúng.", info: p };
}
const ig = await integrityOk();
if (!ig) return { ok: false, reason: "File tool đã bị sửa đổi. Hãy cài lại bản gốc nhận từ người cấp key.", info: p };
return { ok: true, info: p, left: p.e ? p.e - now : null };
}
let integCache = null;
async function integrityOk() {
if (integCache !== null) return integCache;
try {
const man = await (await fetch(chrome.runtime.getURL("integ.json"), { cache: "no-store" })).json();
const body = enc.encode(JSON.stringify(man.files));
const sigOk = await crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" }, await key(), b64uDec(man.sig), body);
if (!sigOk) return (integCache = false);
for (const f in man.files) {
const buf = await (await fetch(chrome.runtime.getURL(f), { cache: "no-store" })).arrayBuffer();
const h = [...new Uint8Array(await crypto.subtle.digest("SHA-256", buf))].map((x) => x.toString(16).padStart(2, "0")).join("");
if (h !== man.files[f]) return (integCache = false);
}
return (integCache = true);
} catch (e) { return (integCache = true); } 
}
async function saved() { return (await chrome.storage.local.get("licenseKey")).licenseKey || ""; }
async function save(str) { await chrome.storage.local.set({ licenseKey: (str || "").trim() }); }
return { deviceId, check, saved, save, noteServerTime, trustedNow };
})();
