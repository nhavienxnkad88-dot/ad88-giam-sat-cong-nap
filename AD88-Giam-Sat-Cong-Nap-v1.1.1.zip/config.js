const CFG = {
PRODUCT: "gs", 
BO_DOMAIN: "8f75lftex8h.cg.ink", 
GH_OWNER: "nhavienxnkad88-dot", 
GH_REPO: "ad88-giam-sat-cong-nap", 
GH_BRANCH: "main",
GH_DIR: "", 
SCAN_SEC: 30, 
RESYNC_MIN: 30, 
BAL_MIN: 2, 
PAGE_SIZE: 500, 
PAGE_SIZE_MIN: 200,
INC_WINDOW_MIN: 45, 
TICK_BUDGET_SEC: 25, 
REQ_GAP_MS: 1200, 
KEEP_DAYS: 35, 
STALE: 300, ABANDON: 1800, RED: 15, AMBER: 8,
PUBLIC_KEY: {"kty": "EC", "crv": "P-256", "x": "MrJDaVuXtlZsbK8Qc2FlOsDXA0B1qn_cxbvVtz2Z4N8", "y": "6k3eYvmR3be_X3vyqM4IRbKm8dNotO6Xp2PA5S39Ux4"}
};
CFG.UPDATE_BASE = `https://raw.githubusercontent.com/${CFG.GH_OWNER}/${CFG.GH_REPO}/${CFG.GH_BRANCH}/` + (CFG.GH_DIR ? CFG.GH_DIR + "/" : "");
if (typeof self !== "undefined") self.CFG = CFG;
