// AD88 Giám Sát XUẤT KHOẢN — đọc Lệnh rút tiền, nhà thứ 3 bên rút, FK
(() => {
const $ = (id) => document.getElementById(id);
const pad = (n) => String(n).padStart(2, "0");
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmt = (n) => Math.round(n || 0).toLocaleString("vi-VN");
const nk = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[đĐ]/g, "d").toLowerCase().replace(/[^a-z0-9]/g, "");
const dayKey = (d) => d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
const dayStartOf = (key) => { const [y, m, d] = key.split("-").map(Number); return Math.floor(new Date(y, m - 1, d).getTime() / 1000); };
const nowU = () => Math.floor(Date.now() / 1000);
const clock = (t) => [Math.floor(t / 3600), Math.floor((t % 3600) / 60), t % 60].map((v) => pad(Math.floor(v))).join(":");
const hms = (s) => clock(Math.max(0, Math.min(86399, s)));
const parseHms = (v) => { const p = String(v || "").split(":").map((x) => parseInt(x, 10) || 0); return Math.min(23, p[0] || 0) * 3600 + Math.min(59, p[1] || 0) * 60 + Math.min(59, p[2] || 0); };
const durTxt = (s) => (s == null || s < 0 ? "—" : s >= 3600 ? Math.floor(s / 3600) + "g " + pad(Math.floor((s % 3600) / 60)) + "p" : Math.floor(s / 60) + "'" + pad(Math.round(s % 60)) + '"');
const dtTxt = (u) => (u ? new Date(u * 1000).toLocaleString("vi-VN", { hour12: false }) : "—");
const tod = (u, D0) => (u ? clock(u - D0) : "—");
// thời gian BO trả có thể là giây, mili-giây hoặc chuỗi "2026-10-13 12:00:00"
const toU = (v) => { if (v == null || v === "" || v === 0 || v === "0") return 0; if (typeof v === "number" || /^\d+$/.test(String(v))) { const n = Number(v); return n > 1e11 ? Math.floor(n / 1000) : n; } const d = new Date(String(v).replace(" ", "T")); return isNaN(d) ? 0 : Math.floor(d.getTime() / 1000); };

// ===== Tình trạng đơn rút (ô Tình trạng đơn hàng trên BO) =====
const STN = { 1: "Đang chờ chuyển tiền", 101: "Đang chờ chuyển tiền (không bị khóa)", 102: "Đang chờ chuyển tiền (bị khóa)", 3: "Chờ thanh toán bên thứ ba", 5: "Thanh toán không thành công", 9: "Thanh toán không thành công", 7: "Đã hủy", 2: "Đã từ chối", 4: "Đã thanh toán", 8: "Đã bắt buộc chuyển tiền" };
const grp = (st) => ([1, 101, 102].includes(st) ? "wait" : st === 3 ? "third" : st === 4 || st === 8 ? "ok" : st === 5 || st === 9 ? "fail" : st === 7 || st === 2 ? "cancel" : "wait");
const GRP = [["all", "Tất cả lệnh", ""], ["wait", "Chờ XNK chuyển tiền", "warn"], ["third", "Chờ bên thứ 3", "warn"], ["ok", "Đã thanh toán", "ok"], ["fail", "Thanh toán không thành công", "bad"], ["cancel", "Đã hủy / từ chối", ""]];
const PILL = { wait: "warnp", third: "warnp", ok: "on", fail: "badp", cancel: "" };

// ===== Trạng thái =====
let DAY = dayKey(new Date()), D0 = dayStartOf(DAY);
let VIEW = null;                     // ngày cũ đang xem
const ORD = new Map();               // số lệnh -> đơn (hôm nay)
const VORD = new Map();              // đơn ngày cũ
let FKMAP = {};                      // số lệnh -> {u, t} ghi nhận từ trang Đánh giá kiểm soát rủi ro
let MERCH = [], merchAt = 0, merchErr = "";
let QT = null;                       // queryType dùng được (5 có cột FK, 3 không)
let scanning = false, lastFull = 0, lastScanAt = 0, licensed = false;
const st = { tab: "home", lg: "all", lh: "", page: 0, from: 0, to: 86399, basis: "ct", tf: "day" };
const SRC = () => (VIEW ? VORD : ORD);
const V0 = () => (VIEW ? dayStartOf(VIEW) : D0);
const NOWS = () => (VIEW ? 86399 : nowU() - D0);

function norm(r, dk) {
  const t = r.time || {};
  const ct = toU(t.create_time ?? r.createTime), at = toU(t.apply_time ?? r.optTime), ft = toU(t.cach_time);
  const s = Number(r.status);
  const merch = typeof r.merch === "string" ? r.merch : "";
  const fkU = r.auditUser || "", fkT = toU(r.auditTime);
  return {
    no: String(r.order_no ?? r.orderNo), day: dk, acc: r.platform_id || r.account || "", uid: String(r.username || r.userIdx || ""),
    amt: Number(r.realAmount) || (Number(r.money) || 0) * 1000, cur: r.currencyCode || "VND",
    st: s, ct, at, ft: ft || (grp(s) === "ok" ? at : 0), dur: Number(r.cashDuration) || 0,
    op: r.operator || "", lock: r.lockUser || "", merch, remark: r.remark || "", fkU, fkT, rv: Number(r.review_count) || 0,
    bank: r.card_bank || "", first: !!r.is_first
  };
}
// gắn FK từ trang rủi ro nếu BO không trả auditUser/auditTime
const fkOf = (o) => { if (o.fkU && o.fkT) return { u: o.fkU, t: o.fkT }; const f = FKMAP[o.no]; return f ? { u: o.fkU || f.u, t: o.fkT || f.t } : { u: o.fkU, t: o.fkT }; };
const tTotal = (o) => (o.ft && o.ct ? o.ft - o.ct : null);
const tFK = (o) => { const f = fkOf(o); return f.t && o.ct ? Math.max(0, f.t - o.ct) : null; };
const tXNK = (o) => { const f = fkOf(o); return o.ft && f.t ? Math.max(0, o.ft - f.t) : null; };
const houseOf = (o) => o.merch || (grp(o.st) === "ok" ? "Thanh toán thủ công" : "");

// ===== giao diện chung =====
function sysmsg(text, kind, actions) { const el = $("sysmsg"); if (!text) { el.hidden = true; return; } el.hidden = false; el.className = "sysmsg " + (kind || "info"); el.innerHTML = `<span>${text}</span>` + (actions || ""); }
function runState(kind, txt) { const r = $("bnRun"); r.className = "bn-run" + (kind === "ok" ? "" : kind === "err" ? " err" : " idle"); $("bnRunTxt").textContent = txt; }
const THU = ["Chủ nhật", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"];
setInterval(() => { const d = new Date(); $("bnClock").textContent = d.toLocaleTimeString("vi-VN", { hour12: false }); $("bnDate").textContent = THU[d.getDay()] + ", " + pad(d.getDate()) + "/" + pad(d.getMonth() + 1) + "/" + d.getFullYear(); }, 1000);
$("verTxt").textContent = "v" + chrome.runtime.getManifest().version;
// phông, cỡ chữ, giao diện dùng chung với trang nhập
try { const f = localStorage.getItem("font"); if (f) document.body.dataset.font = f; const z = localStorage.getItem("size"); if (z) document.body.dataset.size = z; } catch (e) {}
const BG = (() => { let k = 0; const list = () => [...document.querySelectorAll(".bn-bg")].filter((e) => e.dataset.mode === (document.body.dataset.skin === "b" ? "light" : "dark")); function show(i) { const l = list(); if (!l.length) return; k = ((i % l.length) + l.length) % l.length; document.querySelectorAll(".bn-bg").forEach((e) => e.classList.toggle("on", e === l[k])); } setInterval(() => show(k + 1), 8000); return { reset: () => show(0) }; })();
let SKIN = "auto";
const autoSkin = () => { const h = new Date().getHours(); return h >= 6 && h < 18 ? "b" : "a"; };
function applySkin() { const w = SKIN === "auto" ? autoSkin() : SKIN; if (document.body.dataset.skin !== w) { document.body.dataset.skin = w; BG.reset(); } }
document.querySelector('[aria-label="Giao diện"]').addEventListener("click", (e) => { const b = e.target.closest("button"); if (!b) return; SKIN = b.dataset.skin; b.parentNode.querySelectorAll("button").forEach((x) => x.setAttribute("aria-pressed", x === b)); applySkin(); try { localStorage.setItem("skin", SKIN); } catch (_) {} });
try { SKIN = localStorage.getItem("skin") || "auto"; } catch (_) {}
document.querySelector(`[aria-label="Giao diện"] [data-skin="${SKIN}"]`)?.setAttribute("aria-pressed", "true"); applySkin(); setInterval(applySkin, 60000);

// ===== khung thời gian dùng chung =====
const TF = [["1h", "1 giờ", 3600], ["3h", "3 giờ", 10800], ["6h", "6 giờ", 21600], ["day", "00:00 → nay", 0]];
function range() { const N = NOWS(); if (st.tf === "custom") return [Math.min(st.from, st.to), Math.max(st.from, st.to)]; const f = TF.find((x) => x[0] === st.tf) || TF[3]; return f[2] ? [Math.max(0, N - f[2]), N] : [0, N]; }
function rangeLabel() { const [a, b] = range(); return `${(VIEW || DAY).split("-").reverse().join("/")} · ${clock(a)} → ${clock(b)} · theo ${st.basis === "ct" ? "thời gian yêu cầu" : "thời gian hoàn thành"}`; }
function inRange() { const [a, b] = range(), z = V0(); return [...SRC().values()].filter((o) => { const v = st.basis === "ct" ? o.ct : o.ft; return v && v - z >= a && v - z <= b; }); }
function segs() {
  $("xSeg").innerHTML = TF.map((f) => `<button aria-pressed="${st.tf === f[0]}" data-v="${f[0]}">${f[1]}</button>`).join("") + `<button aria-pressed="${st.tf === "custom"}" data-v="custom">Tự chọn</button>`;
  const [a, b] = range(); $("xFrom").value = hms(a); $("xTo").value = hms(b); $("xDay").max = DAY; $("xDay").value = VIEW || DAY;
}
$("xSeg").onclick = (e) => { const b = e.target.closest("button"); if (!b) return; if (b.dataset.v === "custom") { st.from = parseHms($("xFrom").value); st.to = parseHms($("xTo").value); } st.tf = b.dataset.v; st.page = 0; segs(); render(); };
const fmtIn = (v) => String(v).replace(/\D/g, "").slice(0, 6).replace(/^(\d{2})(\d)/, "$1:$2").replace(/^(\d{2}:\d{2})(\d)/, "$1:$2");
["xFrom", "xTo"].forEach((id) => { const i = $(id); i.addEventListener("input", () => (i.value = fmtIn(i.value))); i.addEventListener("blur", () => (i.value = hms(parseHms(i.value)))); i.addEventListener("keydown", (e) => { if (e.key === "Enter") $("xGo").click(); }); });
$("xGo").onclick = async () => { const d = $("xDay").value || DAY; st.from = parseHms($("xFrom").value); st.to = parseHms($("xTo").value); st.tf = "custom"; st.page = 0; if (d !== (VIEW || DAY)) await setView(d); segs(); render(); };
$("xToday").onclick = async () => { st.tf = "day"; await setView(null); segs(); render(); };
$("xBasis").onchange = () => { st.basis = $("xBasis").value; st.page = 0; render(); };

// ===== thống kê =====
function stat(L) {
  const a = { n: L.length, amt: 0, ok: 0, okAmt: 0, wait: 0, third: 0, fail: 0, cancel: 0, tot: [], fk: [], xnk: [] };
  for (const o of L) {
    const g = grp(o.st); a[g]++; a.amt += o.amt;
    if (g === "ok") { a.okAmt += o.amt; const t = tTotal(o); if (t != null) a.tot.push(t); const x = tXNK(o); if (x != null) a.xnk.push(x); }
    const f = tFK(o); if (f != null) a.fk.push(f);
  }
  const avg = (v) => (v.length ? v.reduce((s, x) => s + x, 0) / v.length : null);
  const pct = (v, lo, hi) => (v.length ? v.filter((x) => x > lo && x <= hi).length / v.length * 100 : 0);
  a.avgTot = avg(a.tot); a.avgFK = avg(a.fk); a.avgXNK = avg(a.xnk);
  a.p1 = pct(a.tot, -1, 60); a.p3 = pct(a.tot, 60, 180); a.p10 = pct(a.tot, 180, 600); a.pOver = pct(a.tot, 600, 1e9);
  a.max = a.tot.length ? Math.max(...a.tot) : null;
  return a;
}
const kpi = (lab, val, sub, cls, go) => `<div class="kpi ${cls || ""}${go ? " go" : ""}"${go ? ` data-go="${go}"` : ""}><div class="lab">${lab}</div><div class="val">${val}</div><div class="sub">${sub || ""}</div></div>`;
const vnd = (n) => fmt(n) + " ₫";
function merchFind(name) { const k = nk(name).replace(/vnd$/, ""); return MERCH.find((m) => nk(m.merchName) === k || nk(m.channelName).startsWith(k)) || null; }

function alerts(L) {
  const N = nowU(), out = [];
  if (VIEW) return out;
  const byH = {};
  for (const o of ORD.values()) { const g = grp(o.st); if (g === "third" && N - o.ct > 600) (byH[o.merch || "?"] ??= []).push(o); }
  for (const h in byH) out.push({ lv: "bad", t: `${h}: ${byH[h].length} lệnh chờ bên thứ 3 quá 10 phút`, d: "Lâu nhất " + durTxt(N - Math.min(...byH[h].map((o) => o.ct))) + " · " + byH[h].slice(0, 4).map((o) => o.no).join(", "), act: "Kiểm tra nhà" });
  const w = [...ORD.values()].filter((o) => grp(o.st) === "wait" && N - o.ct > 900);
  if (w.length) out.push({ lv: "warn", t: `${w.length} lệnh chờ XNK chuyển tiền quá 15 phút`, d: w.slice(0, 5).map((o) => `${o.no} (${durTxt(N - o.ct)}${o.lock ? " · " + o.lock : ""})`).join(", "), act: "Xử lý" });
  for (const m of MERCH) {
    const bal = Number(m.balance);
    if (m.status === 1 && m.payCurrency === "VND" && m.balance != null && bal < 20e6) out.push({ lv: "warn", t: `${m.merchName}: số dư thấp ${vnd(bal)}`, d: "Nhà đang bật nhưng số dư dưới 20 triệu", act: "Nạp quỹ" });
  }
  const failH = {}; for (const o of L) if (grp(o.st) === "fail") (failH[o.merch || "?"] ??= 0), failH[o.merch || "?"]++;
  for (const h in failH) if (failH[h] >= 3) out.push({ lv: "bad", t: `${h}: ${failH[h]} lệnh thanh toán không thành công`, d: "Trong khung thời gian đang xem", act: "Xem lệnh" });
  return out;
}

function renderHome() {
  const L = inRange(), a = stat(L);
  $("h-kpis").innerHTML = [
    kpi("Tổng lệnh rút", fmt(a.n), vnd(a.amt), "", "all"),
    kpi("Đã thanh toán", fmt(a.ok), vnd(a.okAmt), "ok", "ok"),
    kpi("Chờ XNK chuyển tiền", fmt(a.wait), "đang chờ / đang khóa", a.wait ? "warn" : "", "wait"),
    kpi("Chờ bên thứ 3", fmt(a.third), "đã đẩy sang nhà", a.third ? "warn" : "", "third"),
    kpi("Không thành công", fmt(a.fail), "thanh toán lỗi", a.fail ? "bad" : "", "fail"),
    kpi("Hủy / từ chối", fmt(a.cancel), "", "", "cancel"),
    kpi("Tốc độ xuất khoản TB", durTxt(a.avgTot), `≤1': ${a.p1.toFixed(0)}% · >10': ${a.pOver.toFixed(0)}%`, ""),
    kpi("TB FK", durTxt(a.avgFK), fmt(a.fk.length) + " lệnh có FK", ""),
    kpi("TB XNK + bên thứ 3", durTxt(a.avgXNK), "từ lúc FK note đến hoàn thành", "")
  ].join("");
  const al = alerts(L); $("cnt-alert").textContent = al.length;
  $("h-alerts").innerHTML = al.length ? al.map((x) => `<div class="alert ${x.lv}"><span class="lvl">${x.lv === "bad" ? "ĐỎ" : "VÀNG"}</span><span class="t">${esc(x.t)}</span><span class="act">${x.act}</span><span class="d">${esc(x.d)}</span></div>`).join("") : `<div class="empty">Không có gì bất thường.</div>`;
  $("h-hint").textContent = rangeLabel();
  $("h-tbl").innerHTML = houseTable(L, true);
}
function houseRows(L) {
  const by = {}; for (const o of L) { const h = houseOf(o); if (h) (by[h] ??= []).push(o); }
  return Object.entries(by).map(([h, l]) => ({ h, a: stat(l), m: merchFind(h) })).sort((x, y) => y.a.ok - x.a.ok);
}
function houseTable(L, short) {
  const rows = houseRows(L), N = nowU();
  let t = `<thead><tr><th class="l">Nhà thứ 3</th><th class="l">BO</th><th>Số dư (₫)</th><th>Đã chi</th><th>Tiền đã chi (₫)</th><th>Chờ bên thứ 3</th><th>Không thành công</th><th>TB tổng</th><th>TB XNK + nhà</th><th>≤ 1'</th><th>1–3'</th><th>3–10'</th><th>&gt; 10'</th><th>Chậm nhất</th></tr></thead><tbody>`;
  for (const { h, a, m } of rows) {
    const waitOld = [...SRC().values()].filter((o) => o.merch === h && grp(o.st) === "third").map((o) => N - o.ct);
    t += `<tr class="${a.fail >= 3 || (waitOld.length && Math.max(...waitOld) > 600 && !VIEW) ? "rbad" : a.pOver > 5 ? "rwarn" : ""}"><td class="name">${esc(h)}</td><td class="l">${m ? (m.status === 1 ? '<span class="pill on">Bật</span>' : '<span class="pill badp">Tắt</span>') : '<span class="mut">—</span>'}</td><td>${m && m.balance != null ? fmt(m.balance) : "—"}</td><td class="ok gocell" data-go="ok" data-h="${esc(h)}">${fmt(a.ok)}</td><td>${fmt(a.okAmt)}</td><td class="${a.third ? "warn" : "mut"} gocell" data-go="third" data-h="${esc(h)}">${fmt(a.third)}${waitOld.length && !VIEW ? ` <small>(lâu nhất ${durTxt(Math.max(...waitOld))})</small>` : ""}</td><td class="${a.fail ? "bad" : "mut"} gocell" data-go="fail" data-h="${esc(h)}">${fmt(a.fail)}</td><td>${durTxt(a.avgTot)}</td><td>${durTxt(a.avgXNK)}</td><td>${a.p1.toFixed(0)}%</td><td>${a.p3.toFixed(0)}%</td><td>${a.p10.toFixed(0)}%</td><td class="${a.pOver ? "bad" : ""}">${a.pOver.toFixed(1)}%</td><td>${durTxt(a.max)}</td></tr>`;
  }
  if (!rows.length) t += `<tr><td class="l mut" colspan="14">Chưa có lệnh rút trong khung thời gian này</td></tr>`;
  return t + "</tbody>";
}
function renderHouse() {
  const L = inRange();
  $("ho-hint").textContent = rangeLabel();
  $("ho-tbl").innerHTML = houseTable(L);
  $("bal-hint").textContent = merchErr ? "Lỗi đọc số dư: " + merchErr : merchAt ? "Cập nhật " + new Date(merchAt).toLocaleTimeString("vi-VN", { hour12: false }) + " · đọc lại mỗi 2 phút" : "Đang đọc…";
  let t = `<thead><tr><th class="l">Nhà thứ 3</th><th class="l">Kênh</th><th class="l">Trạng thái</th><th>Số dư</th><th class="l">Tiền tệ</th><th>Rút tối thiểu</th><th>Rút tối đa</th><th>Thứ tự</th></tr></thead><tbody>`;
  for (const m of [...MERCH].sort((a, b) => (b.weight || 0) - (a.weight || 0))) {
    const lim = m.withdrawAmountLimits ? Object.values(m.withdrawAmountLimits)[0] || {} : {};
    t += `<tr class="${m.status === 1 ? "" : "rbad"}"><td class="name">${esc(m.merchName)}</td><td class="l mut">${esc(m.channelName)}</td><td class="l">${m.status === 1 ? '<span class="stp on"><i></i>ĐANG BẬT</span>' : '<span class="stp off"><i></i>ĐANG TẮT</span>'}</td><td>${m.balance != null ? fmt(m.balance) : "—"}</td><td class="l">${esc(m.payCurrency)}</td><td>${fmt(lim.min)}</td><td>${fmt(lim.max)}</td><td>${m.weight ?? ""}</td></tr>`;
  }
  if (!MERCH.length) t += `<tr><td class="l mut" colspan="8">Chưa đọc được danh sách nhà bên rút</td></tr>`;
  $("bal-tbl").innerHTML = t + "</tbody>";
}
function staffTable(L, kind) {
  const by = {};
  for (const o of L) {
    if (kind === "fk") { const f = fkOf(o), d = tFK(o); if (!f.u || d == null) continue; (by[f.u] ??= []).push([d, o]); }
    else { if (grp(o.st) !== "ok" || !o.op) continue; const d = tXNK(o) ?? tTotal(o); if (d == null) continue; (by[o.op] ??= []).push([d, o]); }
  }
  const rows = Object.entries(by).map(([u, l]) => { const v = l.map((x) => x[0]); return { u, n: l.length, amt: l.reduce((s, x) => s + x[1].amt, 0), avg: v.reduce((s, x) => s + x, 0) / v.length, min: Math.min(...v), max: Math.max(...v), slow: v.filter((x) => x > (kind === "fk" ? 300 : 600)).length }; }).sort((a, b) => b.n - a.n);
  let t = `<thead><tr><th class="l">Nhân viên</th><th>Số lệnh</th><th>Tổng tiền (₫)</th><th>Trung bình</th><th>Nhanh nhất</th><th>Chậm nhất</th><th>${kind === "fk" ? "&gt; 5 phút" : "&gt; 10 phút"}</th></tr></thead><tbody>`;
  for (const r of rows) t += `<tr><td class="name">${esc(r.u)}</td><td>${fmt(r.n)}</td><td>${fmt(r.amt)}</td><td>${durTxt(r.avg)}</td><td>${durTxt(r.min)}</td><td class="${r.max > (kind === "fk" ? 300 : 600) ? "bad" : ""}">${durTxt(r.max)}</td><td class="${r.slow ? "bad" : "mut"}">${fmt(r.slow)}</td></tr>`;
  if (!rows.length) t += `<tr><td class="l mut" colspan="7">${kind === "fk" ? "Chưa có dữ liệu FK (BO chưa trả cột FK; tool đang ghi nhận từ trang Đánh giá kiểm soát rủi ro)" : "Chưa có lệnh đã thanh toán"}</td></tr>`;
  return t + "</tbody>";
}
function renderStaff() { const L = inRange(); $("fk-tbl").innerHTML = staffTable(L, "fk"); $("xnk-tbl").innerHTML = staffTable(L, "xnk"); }
let LCUR = [];
function renderList() {
  const L = inRange(), N = nowU();
  const cnt = { all: L.length }; for (const o of L) { const g = grp(o.st); cnt[g] = (cnt[g] || 0) + 1; }
  $("lst").innerHTML = GRP.map(([k, n, c]) => `<button class="stab ${c}" aria-pressed="${st.lg === k}" data-v="${k}"><small>${n}</small><b>${fmt(cnt[k] || 0)}</b><span>${vnd(L.filter((o) => k === "all" || grp(o.st) === k).reduce((s, o) => s + o.amt, 0))}</span></button>`).join("");
  const hs = [...new Set(L.map(houseOf).filter(Boolean))].sort();
  $("lh").innerHTML = `<button class="chip" aria-pressed="${!st.lh}" data-v="">Tất cả</button>` + hs.map((h) => `<button class="chip" aria-pressed="${st.lh === h}" data-v="${esc(h)}">${esc(h)}</button>`).join("");
  const q = ($("lq").value || "").trim().toLowerCase();
  let list = L.filter((o) => (st.lg === "all" || grp(o.st) === st.lg) && (!st.lh || houseOf(o) === st.lh) && (!q || [o.no, o.acc, o.op, o.lock, fkOf(o).u, o.merch].some((x) => String(x || "").toLowerCase().includes(q))));
  list.sort((a, b) => b.ct - a.ct); LCUR = list;
  $("l-h").textContent = (GRP.find((x) => x[0] === st.lg) || GRP[0])[1];
  $("l-hint").textContent = rangeLabel(); $("l-sum").textContent = fmt(list.length) + " lệnh · " + vnd(list.reduce((s, o) => s + o.amt, 0));
  const PG = 100, pages = Math.max(1, Math.ceil(list.length / PG)); st.page = Math.min(st.page, pages - 1);
  const z = V0();
  let t = `<thead><tr><th class="l">Số lệnh</th><th class="l">Tài khoản</th><th>Số tiền (₫)</th><th>Yêu cầu</th><th class="l">FK</th><th>FK note</th><th class="l">XNK</th><th class="l">Bên thứ 3</th><th>Hoàn thành</th><th>FK mất</th><th>XNK + nhà</th><th>Tổng</th><th class="l">Tình trạng</th><th class="l">Ghi chú</th></tr></thead><tbody>`;
  for (const o of list.slice(st.page * PG, st.page * PG + PG)) {
    const f = fkOf(o), g = grp(o.st), open = g === "wait" || g === "third";
    t += `<tr class="${g === "fail" ? "rbad" : open && !VIEW && N - o.ct > 600 ? "rwarn" : ""}"><td class="l">${esc(o.no)}</td><td class="name">${esc(o.acc)}</td><td>${fmt(o.amt)}</td><td>${tod(o.ct, z)}</td><td class="l">${esc(f.u || "—")}</td><td>${f.t ? tod(f.t, z) : "—"}</td><td class="l">${esc(o.op || "—")}</td><td class="l">${esc(o.merch || "—")}</td><td>${o.ft ? tod(o.ft, z) : open && !VIEW ? `<span class="warn">chờ ${durTxt(N - o.ct)}</span>` : "—"}</td><td>${durTxt(tFK(o))}</td><td>${durTxt(tXNK(o))}</td><td>${durTxt(tTotal(o))}</td><td class="l"><span class="pill ${PILL[g]}">${esc(STN[o.st] || "Mã " + o.st)}</span></td><td class="l mut">${esc(o.remark)}</td></tr>`;
  }
  if (!list.length) t += `<tr><td class="l mut" colspan="14">Không có lệnh</td></tr>`;
  $("l-tbl").innerHTML = t + "</tbody>";
  $("l-pg").innerHTML = pages > 1 ? `<button ${st.page ? "" : "disabled"} data-p="${st.page - 1}">‹ Trước</button><span>Trang ${st.page + 1} / ${pages} · 100 lệnh mỗi trang</span><button ${st.page < pages - 1 ? "" : "disabled"} data-p="${st.page + 1}">Sau ›</button>` : "";
  $("cnt-wait").textContent = [...ORD.values()].filter((o) => { const g = grp(o.st); return g === "wait" || g === "third"; }).length;
}
$("lst").onclick = (e) => { const b = e.target.closest(".stab"); if (b) { st.lg = b.dataset.v; st.page = 0; render(); } };
$("lh").onclick = (e) => { const b = e.target.closest(".chip"); if (b) { st.lh = b.dataset.v; st.page = 0; render(); } };
$("lq").addEventListener("input", () => { st.page = 0; render(); });
$("l-pg").onclick = (e) => { const b = e.target.closest("button[data-p]"); if (b) { st.page = +b.dataset.p; render(); } };
document.addEventListener("click", (e) => { const g = e.target.closest("[data-go]"); if (!g) return; st.lg = g.dataset.go; st.lh = g.dataset.h || ""; st.page = 0; go("list"); });

// ===== Tải Excel để dán vào biểu =====
const XL = [
  ["don", "1 · Tốc độ xuất khoản trung bình → ĐƠN XUẤT KHOẢN", "Số thứ tự · Tốc độ xử lý · Thời gian đăng ký · Thời gian xử lý · Tên người dùng trả · Số tiền xuất khoản · Nhân viên xử lý · Ghi chú", "Chỉ lệnh Đã thanh toán. Tốc độ xử lý = thời gian xử lý − thời gian đăng ký."],
  ["fk", "2 · Tốc độ xuất khoản trung bình → DATA FK", "Số lệnh · Thời gian xem xét rủi ro · Nhân viên FK", "Lệnh có FK xem xét, lọc theo ngày đang chọn."],
  ["kl", "3 · Khối lượng công việc → 1_NƠI DÁN DỮ LIỆU", "SỐ LỆNH · TÀI KHOẢN · NHÂN VIÊN FK · THỜI GIAN XEM XÉT RỦI RO · THỜI GIAN YÊU CẦU · THỜI GIAN THÀNH CÔNG · SỐ TIỀN RÚT · NHÂN VIÊN XNK · BÊN THỨ 3", "Chỉ lệnh Đã thanh toán."],
  ["tb", "4 · 2026 Tốc độ xuất khoản TB → NƠI DÁN DỮ LIỆU", "Số thứ tự · Hội viên · Thời gian yêu cầu · Thời gian hoạt động", "Chỉ lệnh Đã thanh toán."]
];
function renderXls() {
  $("x-hint").textContent = rangeLabel() + " · dùng ô Ngày / từ / đến / Lọc theo ở trên";
  const L = inRange(), ok = L.filter((o) => grp(o.st) === "ok"), fk = L.filter((o) => fkOf(o).t);
  const n = { don: ok.length, fk: fk.length, kl: ok.length, tb: ok.length };
  $("xgrid").innerHTML = XL.map(([k, t, cols, note]) => `<div class="xcard"><h4>${t}</h4><p>Cột: <code>${cols}</code></p><p>${note}</p><button class="bbtn green" data-x="${k}"><span class="ic sm"><svg viewBox="0 0 24 24"><path d="M12 3v12M7 10l5 5 5-5M4 21h16"/></svg></span>Tải (${fmt(n[k])} dòng)</button></div>`).join("");
}
$("xgrid").addEventListener("click", async (e) => {
  const b = e.target.closest("[data-x]"); if (!b) return;
  const k = b.dataset.x, L = inRange().sort((a, b) => a.ct - b.ct), F = "Times New Roman";
  const S = (o) => Object.assign({ font: { name: F, size: 10 } }, o || {});
  const H = S({ font: { name: F, size: 10, bold: true } });
  const tz = new Date().getTimezoneOffset() * 60, xdt = (u) => (u ? (u - tz) / 86400 + 25569 : null), xt = (u) => (u ? ((u - tz) % 86400 + 86400) % 86400 / 86400 : null), xd = (s) => (s == null ? null : Math.round(s) / 86400);
  let head, rows, fm;
  const ok = L.filter((o) => grp(o.st) === "ok");
  if (k === "don") { head = ["Số thứ tự", "Tốc độ xử lý", "Thời gian đăng ký", "Thời gian xử lý", "Tên người dùng trả", "Số tiền xuất khoản", "Nhân viên xử lý", "Ghi chú"]; rows = ok.map((o) => [o.no, xd(tTotal(o)), xt(o.ct), xt(o.ft), o.merch, o.amt, o.op, o.remark]); fm = [null, "hh:mm:ss", "hh:mm:ss", "hh:mm:ss", null, "#,##0", null, null]; }
  else if (k === "fk") { head = ["Số lệnh", "Thời gian xem xét rủi ro", "Nhân viên FK"]; rows = L.filter((o) => fkOf(o).t).sort((a, b) => fkOf(a).t - fkOf(b).t).map((o) => [o.no, xdt(fkOf(o).t), fkOf(o).u]); fm = [null, "dd/mm/yyyy hh:mm", null]; }
  else if (k === "kl") { head = ["SỐ LỆNH", "TÀI KHOẢN", "NHÂN VIÊN FK", "THỜI GIAN XEM XÉT RỦI RO", "THỜI GIAN YÊU CẦU", "THỜI GIAN THÀNH CÔNG", "SỐ TIỀN RÚT", "NHÂN VIÊN XNK", "BÊN THỨ 3"]; rows = ok.map((o) => { const f = fkOf(o); return [o.no, o.acc, f.u, xdt(f.t), xdt(o.ct), xdt(o.ft), o.amt, o.op, o.merch]; }); fm = [null, null, null, "dd/mm/yyyy hh:mm", "dd/mm/yyyy hh:mm", "dd/mm/yyyy hh:mm", "0", null, null]; }
  else { head = ["Số thứ tự", "Hội viên", "Thời gian yêu cầu", "Thời gian hoạt động"]; rows = ok.map((o) => [o.no, o.acc, xdt(o.ct), xdt(o.ft)]); fm = [null, null, "yyyy/mm/dd hh:mm:ss", "yyyy/mm/dd hh:mm:ss"]; }
  if (!rows.length) { sysmsg("Không có dòng nào trong khung thời gian này.", "info"); setTimeout(() => sysmsg(""), 3000); return; }
  const wb = new XLSXW.Book(), ws = wb.sheet("Dữ liệu");
  head.forEach((h, i) => { ws.set(1, i + 1, h, H); ws.width(i + 1, i === 0 ? 24 : 18); });
  rows.forEach((r, i) => r.forEach((v, j) => ws.set(i + 2, j + 1, v, S(fm[j] ? { fmt: fm[j] } : {}))));
  ws.freeze(2, 1);
  const blob = await wb.blob(), dk = VIEW || DAY, [a, z] = range();
  const el = document.createElement("a"); el.href = URL.createObjectURL(blob);
  el.download = `XK_${{ don: "DON_XUAT_KHOAN", fk: "DATA_FK", kl: "KHOI_LUONG_CONG_VIEC", tb: "TOC_DO_XK_TB" }[k]}_${dk.slice(8)}-${dk.slice(5, 7)}_${clock(a).slice(0, 5).replace(":", "h")}-${clock(z).slice(0, 5).replace(":", "h")}.xlsx`;
  document.body.appendChild(el); el.click(); el.remove(); setTimeout(() => URL.revokeObjectURL(el.href), 4000);
});
$("lxls").onclick = async () => {
  if (!LCUR.length) return;
  const wb = new XLSXW.Book(), ws = wb.sheet("Lệnh rút"), F = "Times New Roman";
  const tz = new Date().getTimezoneOffset() * 60, xdt = (u) => (u ? (u - tz) / 86400 + 25569 : null), xd = (s) => (s == null ? null : Math.round(s) / 86400);
  const H = ["Số lệnh", "Tài khoản", "Số tiền (₫)", "Thời gian yêu cầu", "Nhân viên FK", "FK note lúc", "Nhân viên XNK", "Bên thứ 3", "Hoàn thành lúc", "FK mất", "XNK + nhà", "Tổng thời gian", "Tình trạng", "Ghi chú"];
  const fm = [null, null, "#,##0", "dd/mm/yyyy hh:mm:ss", null, "dd/mm/yyyy hh:mm:ss", null, null, "dd/mm/yyyy hh:mm:ss", "[h]:mm:ss", "[h]:mm:ss", "[h]:mm:ss", null, null];
  H.forEach((h, i) => { ws.set(1, i + 1, h, { font: { name: F, size: 10, bold: true, color: "FFFFFF" }, fill: "0B2A55", border: true }); ws.width(i + 1, i === 0 ? 24 : 15); });
  LCUR.forEach((o, r) => { const f = fkOf(o); [o.no, o.acc, o.amt, xdt(o.ct), f.u, xdt(f.t), o.op, o.merch, xdt(o.ft), xd(tFK(o)), xd(tXNK(o)), xd(tTotal(o)), STN[o.st] || o.st, o.remark].forEach((v, j) => ws.set(r + 2, j + 1, v, { font: { name: F, size: 10 }, border: true, fmt: fm[j] || undefined })); });
  ws.freeze(2, 2);
  const blob = await wb.blob(), now = new Date();
  const el = document.createElement("a"); el.href = URL.createObjectURL(blob); el.download = `Lenh_rut_${st.lg}_${pad(now.getDate())}-${pad(now.getMonth() + 1)}_${pad(now.getHours())}h${pad(now.getMinutes())}.xlsx`; document.body.appendChild(el); el.click(); el.remove();
};

// ===== điều hướng =====
function render() { ({ home: renderHome, house: renderHouse, staff: renderStaff, list: renderList, xls: renderXls })[st.tab](); if (st.tab !== "list") renderCounts(); }
function renderCounts() { $("cnt-wait").textContent = [...ORD.values()].filter((o) => { const g = grp(o.st); return g === "wait" || g === "third"; }).length; if (st.tab !== "home") $("cnt-alert").textContent = alerts(inRange()).length; }
function go(tab) { st.tab = tab; document.querySelectorAll(".nav button").forEach((b) => b.setAttribute("aria-selected", b.dataset.tab === tab)); document.querySelectorAll(".page").forEach((p) => (p.hidden = p.id !== "p-" + tab)); render(); try { localStorage.setItem("xtab", tab); } catch (e) {} }
document.querySelector(".nav").onclick = (e) => { const b = e.target.closest("button[data-tab]"); if (b) go(b.dataset.tab); };

// ===== đọc BO =====
async function fetchRange(from, to, onProg) {
  const out = [];
  let page = 1, pages = 1, size = 200;
  while (page <= pages) {
    let d;
    if (QT == null) {
      // lần đầu: thử kiểu "Xuất báo cáo" (queryType 5) xem BO có trả cột FK không
      try { d = await BO.withdrawList(from, to, 1, size, 5); const L = (d && d.data) || []; QT = L.some((r) => r.auditUser || r.auditTime) ? 5 : 3; if (QT === 3) d = null; }
      catch (e) { if (e.kind === "login" || e.kind === "net") throw e; QT = 3; }
      chrome.storage.local.set({ wdQT: QT });
    }
    if (!d) d = await BO.withdrawList(from, to, page, size, QT);
    const L = (d && d.data) || [], total = Number(d && d.total) || 0;
    if (page === 1) { if (L.length && L.length < size && total > L.length) size = L.length; pages = Math.max(1, Math.ceil(total / Math.max(1, size))); }
    out.push(...L);
    if (onProg) onProg(page, pages, out.length, total);
    if (!L.length) break;
    page++; d = null;
  }
  return out;
}
async function ingest(raw, map, dk) { const list = raw.map((r) => norm(r, dk)); for (const o of list) { const p = map.get(o.no); if (p && !o.fkU && p.fkU) { o.fkU = p.fkU; o.fkT = p.fkT; } map.set(o.no, o); } await StoreX.putOrders(list).catch(() => {}); return list.length; }
async function loadMerch() { try { MERCH = await BO.withdrawMerchs(); merchAt = Date.now(); merchErr = ""; } catch (e) { if (e.kind === "login" || e.kind === "net") throw e; merchErr = e.message; } }
async function pollRisk() {
  try {
    const d = await BO.withdrawRisk(1, 200), L = (d && d.data) || [];
    let ch = false;
    for (const r of L) {
      const op = r.operator || r.lockUser || ""; if (!op || op === "system") continue;
      const no = String(r.order_no ?? r.orderNo), t = toU((r.time || {}).apply_time) || nowU();
      const p = FKMAP[no]; if (!p || p.u !== op || t > p.t) { FKMAP[no] = { u: op, t }; ch = true; }
    }
    if (ch) StoreX.kvSet("fk:" + DAY, FKMAP).catch(() => {});
  } catch (e) { if (e.kind === "login" || e.kind === "net") throw e; }
}
let lastMerch = 0, lastWide = 0;
async function tick() {
  if (scanning || !licensed) return; scanning = true;
  try {
    const nd = dayKey(new Date()); if (nd !== DAY) { DAY = nd; D0 = dayStartOf(DAY); ORD.clear(); FKMAP = (await StoreX.kvGet("fk:" + DAY).catch(() => null)) || {}; lastFull = 0; }
    if (!lastMerch || Date.now() - lastMerch > 120e3) { lastMerch = Date.now(); await loadMerch(); }
    if (QT !== 5) await pollRisk();
    const N = nowU();
    if (!lastFull) {
      runState("idle", "ĐANG TẢI");
      const raw = await fetchRange(D0, D0 + 86399, (p, ps, got, total) => sysmsg(`Đang tải lệnh rút hôm nay: trang ${p}/${ps} · ${fmt(got)}/${fmt(total)} lệnh <span class="prog"><span style="width:${(p / ps * 100).toFixed(0)}%"></span></span>`, "info"));
      await ingest(raw, ORD, DAY); lastFull = Date.now(); lastWide = Date.now(); sysmsg("");
    } else {
      // đọc lại từ lệnh đang mở cũ nhất (chờ XNK / chờ bên thứ 3) hoặc 30 phút gần nhất; 30 phút một lần đọc lại cả ngày
      let from = N - 1800;
      for (const o of ORD.values()) { const g = grp(o.st); if ((g === "wait" || g === "third") && o.ct < from) from = o.ct; }
      if (Date.now() - lastWide > 30 * 60e3) { from = D0; lastWide = Date.now(); }
      from = Math.max(D0, from - 60);
      await ingest(await fetchRange(from, D0 + 86399), ORD, DAY);
    }
    lastScanAt = Date.now();
    $("lastScan").textContent = new Date().toLocaleTimeString("vi-VN", { hour12: false });
    if (!VIEW) { $("readCount").textContent = fmt(ORD.size); $("dayRange").textContent = DAY.slice(8) + "/" + DAY.slice(5, 7) + " 00:00 → " + new Date().toLocaleTimeString("vi-VN", { hour12: false }).slice(0, 5); }
    runState("ok", "ĐANG QUÉT" + (QT === 5 ? "" : " · FK ghi nhận trực tiếp"));
    StoreX.setDay(DAY, { day: DAY, complete: false, at: Date.now() }).catch(() => {});
    render();
  } catch (e) {
    if (e.kind === "login") { runState("err", "MẤT ĐĂNG NHẬP"); sysmsg("Mất đăng nhập BO. Mở BO, đăng nhập lại rồi vào trang Lệnh rút tiền một lần — tool sẽ tự quét lại.", "err"); }
    else { runState("err", "LỖI KẾT NỐI"); sysmsg(esc(e.message) + " · Tool tự thử lại sau 30 giây.", "err"); if (!["net", "rate", "http"].includes(e.kind)) console.warn(e); }
  } finally { scanning = false; }
}
async function setView(dk) {
  if (!dk || dk >= DAY) { VIEW = null; VORD.clear(); $("dayLbl").textContent = "Hôm nay"; $("readCount").textContent = fmt(ORD.size); sysmsg(""); return; }
  const d0 = dayStartOf(dk); VORD.clear();
  const info = await StoreX.getDay(dk).catch(() => null); let list = await StoreX.dayOrders(dk).catch(() => []);
  if (!info || !info.complete || !list.length) {
    try {
      const raw = await fetchRange(d0, d0 + 86399, (p, ps, got, total) => sysmsg(`Đang tải lệnh rút ngày ${dk.split("-").reverse().join("/")}: trang ${p}/${ps} · ${fmt(got)}/${fmt(total)} lệnh`, "info"));
      const m = new Map(); await ingest(raw, m, dk); list = [...m.values()]; await StoreX.setDay(dk, { day: dk, complete: true, at: Date.now() });
    } catch (e) { sysmsg("Không tải được ngày này: " + esc(e.message), "err"); return; }
  }
  const fk = (await StoreX.kvGet("fk:" + dk).catch(() => null)) || {};
  for (const o of list) { if (!o.fkU && fk[o.no]) { o.fkU = fk[o.no].u; o.fkT = fk[o.no].t; } VORD.set(o.no, o); }
  VIEW = dk; $("dayLbl").textContent = "Ngày"; $("dayRange").textContent = dk.slice(8) + "/" + dk.slice(5, 7) + " 00:00 → 23:59"; $("readCount").textContent = fmt(VORD.size);
  sysmsg(`Đang xem lệnh rút <b>ngày ${dk.split("-").reverse().join("/")}</b> (${fmt(VORD.size)} lệnh).`, "info", ` <button class="btn" id="xReload">Đọc lại ngày này từ BO</button>`);
  const r = $("xReload"); if (r) r.onclick = async () => { await StoreX.setDay(dk, { day: dk, complete: false }); VIEW = null; await setView(dk); render(); };
}
$("btn-ref").onclick = () => { lastMerch = 0; tick(); };
BO.onWait = (sec) => runState("idle", "BO BẮT CHỜ " + sec + "S");

(async function boot() {
  const r = await License.check(await License.saved());
  if (!r.ok) { $("lock").hidden = false; $("lockMsg").textContent = r.reason || "Chưa có key."; runState("idle", "CHƯA CÓ KEY"); return; }
  licensed = true;
  const p = r.info; $("keyChip").textContent = "Key: " + (p.n ? p.n + " · " : "") + (p.e ? "hết " + new Date(p.e * 1000).toLocaleDateString("vi-VN") : "vĩnh viễn");
  QT = (await chrome.storage.local.get("wdQT")).wdQT ?? null;
  FKMAP = (await StoreX.kvGet("fk:" + DAY).catch(() => null)) || {};
  const cached = await StoreX.dayOrders(DAY).catch(() => []); for (const o of cached) ORD.set(o.no, o);
  StoreX.prune(CFG.KEEP_DAYS).catch(() => {});
  segs();
  let t0 = "home"; try { t0 = localStorage.getItem("xtab") || "home"; } catch (e) {}
  go(t0);
  tick(); setInterval(tick, 30e3);
  setInterval(async () => { const x = await License.check(await License.saved()); if (!x.ok) { licensed = false; $("lock").hidden = false; $("lockMsg").textContent = x.reason; } }, 60e3);
})();
})();
