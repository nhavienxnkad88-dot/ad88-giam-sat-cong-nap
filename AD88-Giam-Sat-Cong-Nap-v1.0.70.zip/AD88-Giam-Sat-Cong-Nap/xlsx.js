// Bộ ghi file Excel (.xlsx) gọn nhẹ, có định dạng — dùng JSZip
const XLSXW = (() => {
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "");
  const col = (n) => { let s = ""; while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); } return s; };
  const ref = (r, c) => col(c) + r;

  class Book {
    constructor() { this.sheets = []; this.styles = [{}]; this.styleKey = { "{}": 0 }; }
    sheet(name) { const s = new Sheet(this, name); this.sheets.push(s); return s; }
    sid(st) {
      if (!st) return 0;
      const k = JSON.stringify(st);
      if (this.styleKey[k] == null) { this.styleKey[k] = this.styles.length; this.styles.push(st); }
      return this.styleKey[k];
    }
    stylesXml() {
      const fonts = ['<font><sz val="10"/><name val="Times New Roman"/></font>'], fk = { def: 0 };
      const fills = ['<fill><patternFill patternType="none"/></fill>', '<fill><patternFill patternType="gray125"/></fill>'], flk = {};
      const borders = ['<border><left/><right/><top/><bottom/><diagonal/></border>',
        '<border><left style="thin"><color rgb="FFBFBFBF"/></left><right style="thin"><color rgb="FFBFBFBF"/></right><top style="thin"><color rgb="FFBFBFBF"/></top><bottom style="thin"><color rgb="FFBFBFBF"/></bottom><diagonal/></border>'];
      const numFmts = [], nk = {}; let nid = 164;
      const builtin = { "General": 0, "0": 1, "0.00": 2, "#,##0": 3, "0%": 9, "0.00%": 10 };
      const xfs = [];
      for (const st of this.styles) {
        let fontId = 0, fillId = 0, borderId = 0, numId = 0;
        if (st.font) {
          const f = st.font, k = JSON.stringify(f);
          if (fk[k] == null) { fk[k] = fonts.length; fonts.push(`<font>${f.bold ? "<b/>" : ""}${f.italic ? "<i/>" : ""}<sz val="${f.size || 10}"/>${f.color ? `<color rgb="FF${f.color}"/>` : ""}<name val="${esc(f.name || "Times New Roman")}"/></font>`); }
          fontId = fk[k];
        }
        if (st.fill) {
          if (flk[st.fill] == null) { flk[st.fill] = fills.length; fills.push(`<fill><patternFill patternType="solid"><fgColor rgb="FF${st.fill}"/><bgColor indexed="64"/></patternFill></fill>`); }
          fillId = flk[st.fill];
        }
        if (st.border) borderId = 1;
        if (st.fmt) {
          if (builtin[st.fmt] != null) numId = builtin[st.fmt];
          else { if (nk[st.fmt] == null) { nk[st.fmt] = nid++; numFmts.push(`<numFmt numFmtId="${nk[st.fmt]}" formatCode="${esc(st.fmt)}"/>`); } numId = nk[st.fmt]; }
        }
        const al = st.align ? `<alignment${st.align.h ? ` horizontal="${st.align.h}"` : ""}${st.align.v ? ` vertical="${st.align.v}"` : ""}${st.align.wrap ? ' wrapText="1"' : ""}/>` : "";
        xfs.push(`<xf numFmtId="${numId}" fontId="${fontId}" fillId="${fillId}" borderId="${borderId}" xfId="0"${numId ? ' applyNumberFormat="1"' : ""}${fontId ? ' applyFont="1"' : ""}${fillId ? ' applyFill="1"' : ""}${borderId ? ' applyBorder="1"' : ""}${al ? ' applyAlignment="1">' + al + "</xf>" : "/>"}`);
      }
      return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">` +
        (numFmts.length ? `<numFmts count="${numFmts.length}">${numFmts.join("")}</numFmts>` : "") +
        `<fonts count="${fonts.length}">${fonts.join("")}</fonts><fills count="${fills.length}">${fills.join("")}</fills><borders count="${borders.length}">${borders.join("")}</borders>` +
        `<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="${xfs.length}">${xfs.join("")}</cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
    }
    async blob() {
      const z = new JSZip();
      z.file("[Content_Types].xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${this.sheets.map((s, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join("")}</Types>`);
      z.file("_rels/.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`);
      z.file("xl/workbook.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${this.sheets.map((s, i) => `<sheet name="${esc(s.name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join("")}</sheets><calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>`);
      z.file("xl/_rels/workbook.xml.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${this.sheets.map((s, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join("")}<Relationship Id="rId${this.sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`);
      this.sheets.forEach((s, i) => z.file(`xl/worksheets/sheet${i + 1}.xml`, s.xml()));
      z.file("xl/styles.xml", this.stylesXml());
      return z.generateAsync({ type: "blob", mimeType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", compression: "DEFLATE" });
    }
  }

  class Sheet {
    constructor(book, name) { this.book = book; this.name = name.slice(0, 31); this.rows = new Map(); this.merges = []; this.widths = {}; this.heights = {}; this.frz = null; }
    set(r, c, v, st) {
      if (!this.rows.has(r)) this.rows.set(r, new Map());
      this.rows.get(r).set(c, { v, s: this.book.sid(st) });
    }
    merge(r1, c1, r2, c2) { this.merges.push(ref(r1, c1) + ":" + ref(r2, c2)); }
    width(c, w) { this.widths[c] = w; }
    height(r, h) { this.heights[r] = h; }
    freeze(r, c) { this.frz = { r, c }; }
    xml() {
      let out = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">`;
      if (this.frz) {
        const { r, c } = this.frz;
        out += `<sheetViews><sheetView workbookViewId="0"><pane${c > 1 ? ` xSplit="${c - 1}"` : ""}${r > 1 ? ` ySplit="${r - 1}"` : ""} topLeftCell="${ref(r, c)}" activePane="bottomRight" state="frozen"/></sheetView></sheetViews>`;
      }
      const cs = Object.keys(this.widths).map(Number).sort((a, b) => a - b);
      if (cs.length) out += "<cols>" + cs.map((c) => `<col min="${c}" max="${c}" width="${this.widths[c]}" customWidth="1"/>`).join("") + "</cols>";
      out += "<sheetData>";
      const rs = [...this.rows.keys()].sort((a, b) => a - b);
      for (const r of rs) {
        const h = this.heights[r];
        out += `<row r="${r}"${h ? ` ht="${h}" customHeight="1"` : ""}>`;
        const cells = [...this.rows.get(r).entries()].sort((a, b) => a[0] - b[0]);
        for (const [c, { v, s }] of cells) {
          const a = ref(r, c), sa = s ? ` s="${s}"` : "";
          if (v === null || v === undefined || v === "") out += `<c r="${a}"${sa}/>`;
          else if (typeof v === "number") out += Number.isFinite(v) ? `<c r="${a}"${sa}><v>${v}</v></c>` : `<c r="${a}"${sa}/>`;
          else if (v instanceof Date) { const ser = (Date.UTC(v.getFullYear(), v.getMonth(), v.getDate()) - Date.UTC(1899, 11, 30)) / 864e5; out += `<c r="${a}"${sa}><v>${ser}</v></c>`; }
          else if (typeof v === "object" && v.f) out += `<c r="${a}"${sa}><f>${esc(v.f)}</f></c>`;
          else out += `<c r="${a}"${sa} t="inlineStr"><is><t xml:space="preserve">${esc(v)}</t></is></c>`;
        }
        out += "</row>";
      }
      out += "</sheetData>";
      if (this.merges.length) out += `<mergeCells count="${this.merges.length}">${this.merges.map((m) => `<mergeCell ref="${m}"/>`).join("")}</mergeCells>`;
      return out + "</worksheet>";
    }
  }
  return { Book, col, ref };
})();
