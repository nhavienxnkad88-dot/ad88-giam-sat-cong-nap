// Bấm tiêu đề cột của bất kỳ bảng nào để sắp xếp: lần 1 thấp → cao, lần 2 cao → thấp, lần 3 về thứ tự mặc định.
// Bảng tự vẽ lại (30 giây/lần) vẫn giữ cách sắp xếp đã chọn.
(() => {
  const ST = {};      // khóa bảng -> { c: cột, d: 1 | -1 }
  const FULL = {};    // id bảng -> hàm vẽ lại (bảng có chia trang: sắp xếp cả danh sách chứ không chỉ trang đang xem)
  let busy = false;

  function keyOf(t) {
    if (t.id) return "#" + t.id;
    const sec = t.closest("section[id], .page[id], [id]");
    const all = sec ? [...sec.querySelectorAll("table")] : [...document.querySelectorAll("table")];
    return (sec ? sec.id : "doc") + ":" + all.indexOf(t);
  }
  function headRow(t) {
    for (const r of t.rows) if (r.cells.length && [...r.cells].every((c) => c.tagName === "TH")) return r;
    return null;
  }
  // vị trí cột thực (tính cả colspan)
  function colOf(th) { let c = 0; for (const x of th.parentElement.cells) { if (x === th) return c; c += x.colSpan || 1; } return c; }
  function cellAt(r, col) { let c = 0; for (const x of r.cells) { if (c === col) return x; c += x.colSpan || 1; if (c > col) return null; } return null; }

  function val(td) {
    if (!td) return null;
    if (td.dataset && td.dataset.sort != null) { const n = Number(td.dataset.sort); return isNaN(n) ? td.dataset.sort : n; }
    const s = (td.textContent || "").replace(/\s+/g, " ").trim();
    if (!s || s === "—" || s === "-" || s === "…") return null;
    let m;
    if ((m = s.match(/^(\d+)\s*(?:g|giờ|h)\s*(\d+)\s*(?:p|phút|')?/i))) return +m[1] * 3600 + +m[2] * 60;
    if ((m = s.match(/^(\d+)'(\d+)"/))) return +m[1] * 60 + +m[2];
    if ((m = s.match(/^\(?(\d+)\s*Phút\s*(\d+)\s*Giây/i))) return +m[1] * 60 + +m[2];
    if ((m = s.match(/^\(?(\d+)\s*Giây/i))) return +m[1];
    if ((m = s.match(/^chờ\s+(\d+)'(\d+)"/i))) return +m[1] * 60 + +m[2];
    if ((m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:\D+(\d{1,2}):(\d{2})(?::(\d{2}))?)?/))) return new Date(+m[3], +m[2] - 1, +m[1], +(m[4] || 0), +(m[5] || 0), +(m[6] || 0)).getTime() / 1000;
    if ((m = s.match(/^(\d{4})-(\d{2})-(\d{2})(?:\D+(\d{1,2}):(\d{2})(?::(\d{2}))?)?/))) return new Date(+m[1], +m[2] - 1, +m[3], +(m[4] || 0), +(m[5] || 0), +(m[6] || 0)).getTime() / 1000;
    if ((m = s.match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?(?!\d)/))) return +m[1] * 3600 + +m[2] * 60 + +(m[3] || 0);
    if ((m = s.match(/^([-+−]?)(\d[\d.,]*)\s*%/))) return (m[1] ? -1 : 1) * parseFloat(m[2].replace(",", "."));
    if ((m = s.match(/^([-+−]?)(\d{1,3}(?:\.\d{3})+)(?:,(\d+))?(?![\d.])/))) return (m[1] ? -1 : 1) * parseFloat(m[2].replace(/\./g, "") + (m[3] ? "." + m[3] : ""));
    if ((m = s.match(/^([-+−]?)(\d+(?:[.,]\d+)?)(?![\d:/])/))) return (m[1] ? -1 : 1) * parseFloat(m[2].replace(",", "."));
    return s.toLowerCase();
  }
  function cmp(a, b, d) {
    if (a == null && b == null) return 0; if (a == null) return 1; if (b == null) return -1;   // ô trống luôn ở cuối
    const na = typeof a === "number", nb = typeof b === "number";
    if (na && nb) return (a - b) * d;
    if (na) return -1; if (nb) return 1;
    return a.localeCompare(b, "vi", { numeric: true }) * d;
  }
  const isTotal = (r) => /^(tổng|tong cong|cộng)/i.test((r.cells[0] && r.cells[0].textContent || "").trim());

  function marks(t, s) {
    const h = headRow(t); if (!h) return;
    for (const th of h.cells) { th.dataset.ts = s && colOf(th) === s.c ? (s.d > 0 ? "asc" : "desc") : ""; }
  }
  function apply(t) {
    const s = ST[keyOf(t)]; marks(t, s);
    if (!s || FULL[t.id]) return;
    const h = headRow(t); if (!h) return;
    const rows = [...t.rows].filter((r) => r !== h && r.cells.length && ![...r.cells].some((c) => c.tagName === "TH" || (c.colSpan || 1) > 1 && r.cells.length === 1));
    if (rows.length < 2) return;
    const par = rows[0].parentElement, body = rows.filter((r) => r.parentElement === par && !isTotal(r)), tot = rows.filter((r) => r.parentElement === par && isTotal(r));
    const v = body.map((r, i) => [r, val(cellAt(r, s.c)), i]);
    v.sort((x, y) => cmp(x[1], y[1], s.d) || x[2] - y[2]);
    const want = v.map((x) => x[0]).concat(tot);
    const cur = [...par.children].filter((r) => want.includes(r));
    if (cur.every((r, i) => r === want[i])) return;
    busy = true; for (const r of want) par.appendChild(r); busy = false;
  }

  document.addEventListener("click", (e) => {
    const th = e.target.closest("th"); if (!th || e.target.closest("button, a, input, select, label")) return;
    const t = th.closest("table"), h = t && headRow(t); if (!h || th.parentElement !== h) return;
    if (th.dataset.nosort != null || !(th.textContent || "").trim()) return;
    const k = keyOf(t), c = colOf(th), s = ST[k];
    ST[k] = !s || s.c !== c ? { c, d: 1 } : s.d === 1 ? { c, d: -1 } : null;
    if (!ST[k]) delete ST[k];
    try { sessionStorage.setItem("tsort", JSON.stringify(ST)); } catch (x) {}
    if (FULL[t.id]) { FULL[t.id](); marks(t, ST[k]); } else apply(t);
  });

  let q = false;
  new MutationObserver(() => {
    if (busy || q) return; q = true;
    queueMicrotask(() => { q = false; for (const t of document.querySelectorAll("table")) { const k = keyOf(t); if (ST[k] || t.querySelector("th[data-ts='asc'],th[data-ts='desc']")) apply(t); } });
  }).observe(document.documentElement, { childList: true, subtree: true });
  try { Object.assign(ST, JSON.parse(sessionStorage.getItem("tsort") || "{}")); } catch (x) {}

  window.TSort = {
    // bảng có chia trang: đăng ký hàm vẽ lại; khi vẽ gọi TSort.sort(id, list, keys) để sắp cả danh sách
    full(id, rerender) { FULL[id] = rerender; },
    sort(id, list, keys) {
      const s = ST["#" + id]; if (!s || !keys[s.c]) return list;
      const f = keys[s.c], v = list.map((o, i) => [o, f(o), i]);
      v.sort((x, y) => cmp(x[1] === "" || x[1] === undefined || (typeof x[1] === "number" && isNaN(x[1])) ? null : typeof x[1] === "string" ? x[1].toLowerCase() : x[1], y[1] === "" || y[1] === undefined || (typeof y[1] === "number" && isNaN(y[1])) ? null : typeof y[1] === "string" ? y[1].toLowerCase() : y[1], s.d) || x[2] - y[2]);
      return v.map((x) => x[0]);
    },
  };
})();
