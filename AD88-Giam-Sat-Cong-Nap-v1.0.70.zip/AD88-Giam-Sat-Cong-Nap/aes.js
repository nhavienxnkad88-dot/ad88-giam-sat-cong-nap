// AES giải mã (ECB/CBC) gọn, dùng để giải mật khẩu file BO
const AESD = (() => {
  const S = new Uint8Array(256), SI = new Uint8Array(256);
  { let p = 1, q = 1; do { p = p ^ ((p << 1) & 0xff) ^ (p & 0x80 ? 0x1b : 0); q ^= q << 1; q ^= q << 2; q ^= q << 4; q &= 0xff; if (q & 0x80) q ^= 0x09; const x = q ^ ((q << 1) | (q >> 7)) ^ ((q << 2) | (q >> 6)) ^ ((q << 3) | (q >> 5)) ^ ((q << 4) | (q >> 4)); const v = (x ^ 0x63) & 0xff; S[p] = v; SI[v] = p; } while (p !== 1); S[0] = 0x63; SI[0x63] = 0; }
  const xt = (a) => ((a << 1) ^ (a & 0x80 ? 0x1b : 0)) & 0xff;
  const mul = (a, b) => { let r = 0; while (b) { if (b & 1) r ^= a; a = xt(a); b >>= 1; } return r; };
  function expand(key) {
    const nk = key.length / 4, nr = nk + 6, w = new Uint8Array(16 * (nr + 1)); w.set(key);
    let rc = 1;
    for (let i = nk; i < 4 * (nr + 1); i++) {
      let t = w.slice((i - 1) * 4, i * 4);
      if (i % nk === 0) { t = new Uint8Array([S[t[1]] ^ rc, S[t[2]], S[t[3]], S[t[0]]]); rc = xt(rc); }
      else if (nk > 6 && i % nk === 4) t = t.map((b) => S[b]);
      for (let j = 0; j < 4; j++) w[i * 4 + j] = w[(i - nk) * 4 + j] ^ t[j];
    }
    return { w, nr };
  }
  function dblock(b, { w, nr }) {
    const s = b.slice(); const ark = (r) => { for (let i = 0; i < 16; i++) s[i] ^= w[r * 16 + i]; };
    ark(nr);
    for (let r = nr - 1; r >= 0; r--) {
      // inv shift rows
      let t = s[13]; s[13] = s[9]; s[9] = s[5]; s[5] = s[1]; s[1] = t;
      t = s[2]; s[2] = s[10]; s[10] = t; t = s[6]; s[6] = s[14]; s[14] = t;
      t = s[3]; s[3] = s[7]; s[7] = s[11]; s[11] = s[15]; s[15] = t;
      for (let i = 0; i < 16; i++) s[i] = SI[s[i]];
      ark(r);
      if (r) for (let c = 0; c < 4; c++) { const a = s.slice(c * 4, c * 4 + 4); s[c * 4] = mul(a[0], 14) ^ mul(a[1], 11) ^ mul(a[2], 13) ^ mul(a[3], 9); s[c * 4 + 1] = mul(a[0], 9) ^ mul(a[1], 14) ^ mul(a[2], 11) ^ mul(a[3], 13); s[c * 4 + 2] = mul(a[0], 13) ^ mul(a[1], 9) ^ mul(a[2], 14) ^ mul(a[3], 11); s[c * 4 + 3] = mul(a[0], 11) ^ mul(a[1], 13) ^ mul(a[2], 9) ^ mul(a[3], 14); }
    }
    return s;
  }
  // mode: "ecb" | "cbc"; trả về Uint8Array đã bỏ padding PKCS7, hoặc null nếu padding sai
  function decrypt(ct, key, mode, iv) {
    if (![16, 24, 32].includes(key.length) || ct.length % 16) return null;
    const ks = expand(key), out = new Uint8Array(ct.length);
    for (let i = 0; i < ct.length; i += 16) { const p = dblock(ct.subarray(i, i + 16), ks); const prev = mode === "cbc" ? (i ? ct.subarray(i - 16, i) : iv) : null; for (let j = 0; j < 16; j++) out[i + j] = prev ? p[j] ^ prev[j] : p[j]; }
    const n = out[out.length - 1]; if (n < 1 || n > 16) return null; for (let i = out.length - n; i < out.length; i++) if (out[i] !== n) return null;
    return out.subarray(0, out.length - n);
  }
  return { decrypt };
})();
if (typeof module !== "undefined") module.exports = AESD;
