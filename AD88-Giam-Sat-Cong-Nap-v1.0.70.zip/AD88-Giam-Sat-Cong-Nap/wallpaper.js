// Ảnh nền banner lấy từ kho ảnh Unsplash theo từ khóa (ảnh ngày cho giao diện Sáng, ảnh đêm cho giao diện Tối).
// Theo quy định của Unsplash: dùng đúng link ảnh họ trả về, ghi tên tác giả, báo lượt tải khi ảnh được hiển thị.
// Không có mã / mất mạng / lỗi → giữ bộ ảnh có sẵn trong tool.
(() => {
  const DEF = { src: "local", key: "", qDay: "Saigon city day", qNight: "city night skyline" };
  const REFRESH_MS = 12 * 3600e3;
  const $ = (id) => document.getElementById(id);
  let W = { ...DEF }, shown = new Set();

  async function load() { const s = await chrome.storage.local.get(["wall", "wallCache"]); W = { ...DEF, ...(s.wall || {}) }; return s.wallCache || null; }

  async function fetchSet(q, n) {
    const u = "https://api.unsplash.com/photos/random?orientation=landscape&content_filter=high&count=" + n + "&query=" + encodeURIComponent(q);
    const r = await fetch(u, { headers: { Authorization: "Client-ID " + W.key, "Accept-Version": "v1" } });
    if (r.status === 401) throw new Error("Mã Unsplash không đúng");
    if (r.status === 403) throw new Error("Unsplash tạm hết lượt trong giờ này");
    if (!r.ok) throw new Error("Unsplash lỗi " + r.status);
    const a = await r.json();
    return (Array.isArray(a) ? a : [a]).map((p) => ({
      img: p.urls.raw + (p.urls.raw.includes("?") ? "&" : "?") + "w=2400&q=80&auto=format&fit=crop",
      by: (p.user && p.user.name) || "",
      byUrl: ((p.user && p.user.links && p.user.links.html) || "https://unsplash.com") + "?utm_source=ad88_giam_sat&utm_medium=referral",
      dl: p.links && p.links.download_location
    }));
  }

  const preload = (src) => new Promise((ok) => { const i = new Image(); i.onload = () => ok(true); i.onerror = () => ok(false); i.src = src; });

  function credit(p) {
    let el = $("bnCredit");
    if (!el) { el = document.createElement("a"); el.id = "bnCredit"; el.className = "bn-credit"; el.target = "_blank"; el.rel = "noopener"; (document.querySelector(".banner") || document.body).appendChild(el); }
    if (!p) { el.hidden = true; return; }
    el.hidden = false; el.href = p.byUrl; el.textContent = "Ảnh: " + p.by + " / Unsplash";
  }

  async function apply(cache) {
    const host = document.querySelector(".banner"); if (!host) return;
    host.querySelectorAll(".bn-bg[data-uns]").forEach((e) => e.remove());
    const locals = host.querySelectorAll(".bn-bg:not([data-uns])");
    if (W.src !== "unsplash" || !cache || !cache.day || !cache.night) {
      locals.forEach((e) => { if (e.dataset.keep) { e.dataset.mode = e.dataset.keep; delete e.dataset.keep; } });
      credit(null); return;
    }
    const first = host.querySelector(".bn-bg");
    let added = { light: 0, dark: 0 };
    for (const [mode, list] of [["light", cache.day], ["dark", cache.night]]) {
      for (const p of list) {
        if (!(await preload(p.img))) continue;
        const d = document.createElement("div");
        d.className = "bn-bg"; d.dataset.mode = mode; d.dataset.uns = "1"; d.setAttribute("aria-hidden", "true");
        d.style.backgroundImage = `url("${p.img.replace(/"/g, "%22")}")`; d._p = p;
        host.insertBefore(d, first); added[mode]++;
      }
    }
    // chỉ ẩn ảnh có sẵn của chế độ nào đã có ảnh Unsplash thay thế
    locals.forEach((e) => { const m = e.dataset.mode || e.dataset.keep; if (added[m]) { e.dataset.keep = m; e.dataset.mode = "off"; e.classList.remove("on"); } });
    const want = document.body.dataset.skin === "b" ? "light" : "dark";
    const l = [...host.querySelectorAll(".bn-bg")].filter((e) => e.dataset.mode === want);
    if (l.length) host.querySelectorAll(".bn-bg").forEach((e) => e.classList.toggle("on", e === l[0]));
    onShow();
  }

  // ghi tên tác giả + báo lượt tải cho ảnh đang hiện
  function onShow() {
    const cur = document.querySelector(".banner .bn-bg.on");
    const p = cur && cur._p; credit(p || null);
    if (p && p.dl && !shown.has(p.dl)) { shown.add(p.dl); fetch(p.dl, { headers: { Authorization: "Client-ID " + W.key } }).catch(() => {}); }
  }
  new MutationObserver(() => onShow()).observe(document.documentElement, { subtree: true, attributes: true, attributeFilter: ["class"] });

  async function refresh(force) {
    let cache = await load();
    if (W.src !== "unsplash" || !W.key) { await apply(null); return ""; }
    const stale = !cache || cache.key !== W.key || cache.qDay !== W.qDay || cache.qNight !== W.qNight || Date.now() - (cache.at || 0) > REFRESH_MS;
    let err = "";
    if (stale || force) {
      try {
        const [day, night] = await Promise.all([fetchSet(W.qDay, 6), fetchSet(W.qNight, 6)]);
        cache = { at: Date.now(), key: W.key, qDay: W.qDay, qNight: W.qNight, day, night };
        await chrome.storage.local.set({ wallCache: cache });
      } catch (e) { err = e.message; }
    }
    await apply(cache && cache.key === W.key ? cache : null);
    return err;
  }

  // ô cài đặt (chỉ có ở trang có hộp Cài đặt)
  function bindSettings() {
    if (!$("sBgSrc")) return;
    const fill = () => { $("sBgSrc").value = W.src; $("sUnsKey").value = W.key; $("sUnsDay").value = W.qDay; $("sUnsNight").value = W.qNight; $("sUnsBox").hidden = W.src !== "unsplash"; };
    fill();
    $("sBgSrc").onchange = () => { $("sUnsBox").hidden = $("sBgSrc").value !== "unsplash"; };
    const save = async (force) => {
      W = { src: $("sBgSrc").value, key: $("sUnsKey").value.trim(), qDay: $("sUnsDay").value.trim() || DEF.qDay, qNight: $("sUnsNight").value.trim() || DEF.qNight };
      await chrome.storage.local.set({ wall: W });
      $("sUnsMsg").textContent = W.src === "unsplash" ? (W.key ? "Đang lấy ảnh…" : "Chưa nhập mã Unsplash") : "";
      const err = await refresh(force);
      if (W.src === "unsplash" && W.key) $("sUnsMsg").textContent = err ? "Không lấy được ảnh: " + err + " — đang dùng ảnh có sẵn." : "Đã lấy ảnh mới từ Unsplash.";
    };
    $("setsave") && $("setsave").addEventListener("click", () => save(false));
    $("sUnsNow").onclick = () => save(true);
  }

  load().then(() => { bindSettings(); refresh(false); });
  setInterval(() => refresh(false), 3600e3);
})();
