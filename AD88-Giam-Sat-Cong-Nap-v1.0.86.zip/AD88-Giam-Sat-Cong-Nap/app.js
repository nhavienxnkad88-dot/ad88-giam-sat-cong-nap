// AD88 Giám Sát Cổng Nạp — bảng điều khiển (dữ liệu thật từ BO)
(function () {
"use strict";
const $ = (id) => document.getElementById(id);
const nk = (s) => String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[đĐ]/g, "d").toLowerCase().replace(/[^a-z0-9]/g, "");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const pad = (n) => String(n).padStart(2, "0");
const dayKey = (d) => d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
const dayStartOf = (key) => { const [y, m, d] = key.split("-").map(Number); return Math.floor(new Date(y, m - 1, d).getTime() / 1000); };
const nowU = () => Math.floor(Date.now() / 1000);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

// Tiếng báo: mở thiết bị âm thanh chỉ trong lúc kêu rồi đóng lại ngay (không giữ loa/micro của Chrome).
// Bỏ qua khi tab đang ẩn quá lâu hoặc thiết bị âm thanh đang lỗi — không bao giờ làm treo trang.
let beeping = false;
function beep(freq, at, dur) {
  if (beeping) return; beeping = true;
  let c = null; const done = () => { beeping = false; if (c && c.state !== "closed") c.close().catch(() => {}); c = null; };
  try {
    c = new AudioContext();
    c.onerror = done;
    const go = () => { at.forEach((t) => { const o = c.createOscillator(), g = c.createGain(); o.frequency.value = freq; o.connect(g); g.connect(c.destination); g.gain.setValueAtTime(0.15, c.currentTime + t); g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + t + dur); o.start(c.currentTime + t); o.stop(c.currentTime + t + dur + 0.02); }); setTimeout(done, (Math.max(...at) + dur + 0.3) * 1000); };
    (c.state === "suspended" ? c.resume() : Promise.resolve()).then(go, done);
    setTimeout(done, 5000);
  } catch (e) { done(); }
}
// ===== Cài đặt =====
const SET = { usdt: true, rRed: 20, rWarn: 50, rOk: 80, minN: 5, stale: CFG.STALE / 60, sound: true };
async function loadSettings() {
  const s = await chrome.storage.local.get(["settings", "boDomain"]);
  Object.assign(SET, s.settings || {});
  SET.domain = s.boDomain || CFG.BO_DOMAIN;
}
const STALE = () => SET.stale * 60, ABANDON = CFG.ABANDON;

// ===== Dữ liệu =====
let DAY = dayKey(new Date()), DAY0 = dayStartOf(DAY);
const ORD = new Map();          // đơn hôm nay
let orders = [];                // đơn dùng để thống kê cổng (đã bỏ lệnh ảo)
let ALL = [];                   // tất cả đơn (kể cả lệnh ảo)
let FAKESET = new Set();        // tài khoản lệnh ảo (đã đánh dấu + rất nghi ngờ)
let HOUSES = [], HIDX = {};     // nhà thứ 3
let GATES = [], GIDX = {};      // cổng nạp
let COMBO = {};                 // "h_g" -> {fee, chs:Set}
let BAL = {};                   // nk(merchName) -> bản ghi listV2
let balAt = 0;
const GATE_SHORT = { "quetmanganhang": "QR ngân hàng", "napnhanh": "Chuyển khoản", "momopay": "Momo", "zalopay": "Zalo Pay", "thecao": "Thẻ cào" };
const GATE_ORDER = ["quetmanganhang", "napnhanh", "momopay", "zalopay", "thecao"];
// Xem ngày cũ: VIEW = "YYYY-MM-DD" (null = hôm nay, trực tiếp)
let VIEW = null, VIEW0 = 0; const VORD = new Map();
const V0 = () => (VIEW ? VIEW0 : DAY0);
const NOWS = () => (VIEW ? 86399 : nowU() - DAY0);
// "U2Pay2 - USDT", "RCPay(USDT)" ghép chung với "U2Pay2", "RCPay" trong danh sách số dư
const hkey = (name) => { const k = nk(name); const b = k.replace(/usdt$/, ""); return b || k || "khac"; };

const SRC = () => (VIEW ? VORD : ORD);
function rebuild() {
  const hs = {}, gs = {};
  for (const o of SRC().values()) {
    const hk = hkey(o.merch), gk = nk(o.gate) || "khac";
    (hs[hk] ??= { k: hk, n: o.merch, cnt: 0, cur: o.cur }).cnt++;
    (gs[gk] ??= { k: gk, raw: o.gate, n: GATE_SHORT[gk] || o.gate, cnt: 0 }).cnt++;
  }
  // nhà có trong listV2 nhưng hôm nay chưa có đơn vẫn hiện số dư
  for (const k in BAL) if (!hs[k]) { const r = BAL[k]; hs[k] = { k, n: r.merchName, cnt: 0, cur: r.payCurrency || "VND" }; }
  HOUSES = Object.values(hs).sort((a, b) => b.cnt - a.cnt).map((h) => {
    const r = BAL[h.k];
    return { k: h.k, n: h.n, mid: r ? r.id : null, berr: r ? BALERR[r.id] : null, cnt: h.cnt, cur: r ? r.payCurrency || "VND" : h.cur, bal: r && r.balance != null ? Number(r.balance) : null, balAt: r ? r.balAt : 0, on: r ? r.status === 1 : null, mid: r ? r.id : null };
  });
  HIDX = {}; HOUSES.forEach((h, i) => (HIDX[h.k] = i));
  GATES = Object.values(gs).sort((a, b) => {
    const ia = GATE_ORDER.indexOf(a.k), ib = GATE_ORDER.indexOf(b.k);
    return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib) || b.cnt - a.cnt;
  });
  GIDX = {}; GATES.forEach((g, i) => (GIDX[g.k] = i));
  COMBO = {};
  orders = [];
  const sorted = [...SRC().values()].sort((a, b) => a.ts - b.ts);
  for (const o of sorted) {
    o.h = HIDX[hkey(o.merch)]; o.g = GIDX[nk(o.gate) || "khac"]; o.t = o.ts - V0();
    const c = (COMBO[o.h + "_" + o.g] ??= { fee: o.fee, chs: new Set() });
    c.fee = o.fee; if (o.ch) c.chs.add(o.ch);
    orders.push(o);
  }
  ALL = orders;
  try { FAKESET = new Set(fakeRows(ALL).filter((r) => r.lv === "mark" || r.lv === "high").map((r) => r.acc)); } catch (e) { FAKESET = new Set(); }
  orders = SET.exFake !== false ? ALL.filter((o) => !FAKESET.has(o.acc)) : ALL;
}
const combo = (hi, gi) => COMBO[hi + "_" + gi] || null;
const chText = (c) => (c ? [...c.chs].slice(0, 3).join(", ") + (c.chs.size > 3 ? "…" : "") : "");

// ===== Tính toán =====
function agg(list) {
  const N = NOWS(), S = STALE();
  const a = { n: 0, ok: 0, pend: 0, stale: 0, aband: 0, err: 0, amt: 0, okAmt: 0, fee: 0, spSum: 0, s3: 0, s10: 0, sOver: 0, sps: [] };
  for (const o of list) {
    a.n++; a.amt += o.amt;
    if (o.st === 2) { a.ok++; a.okAmt += o.amt; a.fee += o.amt * o.fee / 100; if (o.mk === 3) { a.forced = (a.forced || 0) + 1; continue; } a.spN = (a.spN || 0) + 1; a.spSum += o.sp; a.sps.push(o.sp); if (o.sp <= 180) a.s3++; else if (o.sp <= 600) a.s10++; else a.sOver++; }   // đơn ép (callback trễ) không tính vào tốc độ
    else if (o.st === 3) a.err++;
    else if (o.st === 4 || o.st === 5) a.aband++;
    else { const age = N - o.t; if (age > ABANDON) a.aband++; else { a.pend++; if (age > S) a.stale++; } }
  }
  a.rate = a.n ? a.ok / a.n * 100 : null;   // tỷ lệ = đơn thành công / tổng đơn nạp
  a.sp = a.spN ? a.spSum / a.spN : 0;
  a.sps.sort((x, y) => x - y); a.p90 = a.sps.length ? a.sps[Math.floor(a.sps.length * 0.9)] : 0; a.med = a.sps.length ? a.sps[Math.floor(a.sps.length / 2)] : 0;
  a.waiting = a.pend + a.aband; return a;
}
const fmt = (n) => Math.round(n).toLocaleString("vi-VN");
const vnd = (k) => fmt(k * 1000);
const pct = (r) => (r == null ? "—" : r.toFixed(1) + "%");
const mmss = (s) => { s = Math.round(s); return Math.floor(s / 60) + "'" + pad(s % 60) + '"'; };
const clock = (t) => [Math.floor(t / 3600), Math.floor(t % 3600 / 60), t % 60].map((v) => pad(Math.floor(v))).join(":");
const rc = (r) => (r == null ? "mut" : r >= SET.rOk ? "ok" : r > SET.rWarn ? "mid" : r >= SET.rRed ? "warn" : "bad");
let day, BASE, byCell, LV, win30;
function derive() {
  day = agg(orders);
  byCell = {}; for (const o of orders) (byCell[o.h + "_" + o.g] ??= []).push(o);
  BASE = {}; for (const k in byCell) BASE[k] = agg(byCell[k]).rate;
  const N = NOWS();
  win30 = {}; for (const o of orders) if (o.t >= N - 1800) (win30[o.h + "_" + o.g] ??= []).push(o);
  LV = {}; for (const k in win30) LV[k] = level(agg(win30[k]), k);
}
// Trạng thái theo tỷ lệ thành công (thành công / tổng đơn):
//  dưới 20% = Cảnh báo (đỏ) · 20%–50% = Theo dõi (vàng) · trên 50% đến dưới 80% = Tạm ổn định · từ 80% = Ổn định
function level(a, key) {
  if (!a || !a.n) return "na";
  const r = a.rate;
  return r < SET.rRed ? "bad" : r <= SET.rWarn ? "warn" : r < SET.rOk ? "mid" : "ok";
}
const PILL = { bad: '<span class="pill badp">Cảnh báo</span>', warn: '<span class="pill warnp">Theo dõi</span>', mid: '<span class="pill midp">Tạm ổn định</span>', ok: '<span class="pill on">Ổn định</span>', na: '<span class="pill" style="background:var(--panel2);color:var(--muted)">Chưa có đơn</span>' };
const RANK = { na: 0, ok: 0, mid: 1, slow: 1, warn: 2, bad: 3 };
// trạng thái hiển thị: lấy mức xấu hơn giữa 30 phút gần nhất và khung thời gian đang xem
const lvBoth = (k, a) => { const x = LV[k] || "ok", y = level(a, k); return RANK[y] > RANK[x] ? y : x; };
const houseLv = (hi) => { let l = "ok"; for (const k in LV) if (k.startsWith(hi + "_")) { if (LV[k] === "bad") return "bad"; if (LV[k] === "warn") l = "warn"; } return l; };
const TF = () => [["1h", "1 giờ", 3600], ["3h", "3 giờ", 10800], ["6h", "6 giờ", 21600], ["day", "00:00 → nay", NOWS()]];
const st = { tab: "home", house: -1, gate: -1, speedH: -1, speedG: -1, pendH: -1, pendG: -1, pendMin: 0, ostat: "pend", page: 0, q: "", feeH: -1, feeMon: null, tf: { house: "day", gate: "day", speed: "3h", list: "day", fake: "day", maint: "day" }, maintH: -1 };
// khung giờ tự chọn: st.cust[key] = {a, b} tính bằng giây từ 00:00
st.cust = {};
const hms = (s) => clock(Math.max(0, Math.min(86399, s)));
const parseHms = (v) => { const p = String(v || "").split(":").map(Number); return (p[0] || 0) * 3600 + (p[1] || 0) * 60 + (p[2] || 0); };
const tfRange = (key) => {
  const N = NOWS();
  if (st.tf[key] === "custom") { const c = st.cust[key] || { a: 0, b: N }; return [Math.min(c.a, c.b), Math.max(c.a, c.b)]; }
  const f = TF().find((x) => x[0] === st.tf[key]) || TF()[3]; return [N - f[2], N];
};
const tfSec = (key) => { const [x, y] = tfRange(key); return y - x; };
const inTf = (key) => { const [from, to] = tfRange(key); return (key === "list" || key === "fake" ? ALL : orders).filter((o) => o.t >= from && o.t <= to); };
const tfLabel = (key) => { if (st.tf[key] === "custom") { const [x, y] = tfRange(key); return "Từ " + hms(x) + " đến " + hms(y); } const f = TF().find((x) => x[0] === st.tf[key]); const N = NOWS(); return f[0] === "day" ? "Từ 00:00 đến " + clock(N).slice(0, 5) : f[1] + " gần nhất (" + clock(Math.max(0, N - f[2])).slice(0, 5) + " → " + clock(N).slice(0, 5) + ")"; };
const rateBar = (a) => { const t = Math.max(1, a.n); return `<span class="rate"><span class="${rc(a.rate)}">${pct(a.rate)}</span><span class="track"><span style="width:${a.ok / t * 100}%;background:var(--b1)"></span><span style="width:${a.waiting / t * 100}%;background:var(--b3)"></span><span style="width:${a.err / t * 100}%;background:var(--b5)"></span></span></span>`; };
const balTxt = (h) => (h.bal == null ? (h.on == null ? "—" : h.berr ? "lỗi: " + h.berr.slice(0, 40) : "đang lấy…") : fmt(h.bal) + (h.cur && h.cur !== "VND" ? " " + h.cur : " ₫"));
const statusPill = (h) => (h.on == null ? '<span class="pill" style="background:var(--panel2);color:var(--muted)">Chưa ghép số dư</span>' : h.on ? '<span class="pill on">Bật</span>' : '<span class="pill off">Rút tắt</span>');
// Hạn mức số dư tối đa từng nhà (đỏ khi vượt). Dưới 30% hạn mức: vàng · dưới 15%: đỏ. Nhà USDT tính theo USDT.
const BLIM_DEF = { gopay: 100e6, okpay: [2e9, 30e6, 15e6], "33pay": 70e6, pppay: [2e9, 30e6, 15e6], vn196pay: [500e6, 30e6, 15e6], v6pay: 100e6, vippay: 100e6, "888pay": 100e6, bb168pay: 800e6, fastpay: [500e6, 30e6, 15e6], a8pay: 70e6, payopay: 80e6, jypay: 80e6, "rcpay|USDT": 50000, "u2pay2|USDT": 50000 };
// mỗi nhà: số = hạn mức tối đa (vàng dưới 30%, đỏ dưới 15%) · [tối đa, vàng dưới, đỏ dưới] = ngưỡng riêng
const blimAll = () => { const L = { ...BLIM_DEF }; for (const [k, v] of Object.entries(SET.blim || {})) { const d = BLIM_DEF[k]; L[k] = typeof v === "number" && Array.isArray(d) && v === d[0] ? d : v; } return L; };
const blimOf = (h) => { const L = blimAll(), k = hkey(h.n), v = h.cur && h.cur !== "VND" ? L[k + "|USDT"] : L[k]; if (!v) return null; const [max, w, r] = Array.isArray(v) ? v : [v]; return { max, w: w || max * 0.3, r: r || max * 0.15, own: !!w }; };
// → {lv: ok|warn|bad, tag, why, max, p}
function balSt(h) {
  if (h.bal == null) return null; const L = blimOf(h), u = h.cur && h.cur !== "VND" ? " " + h.cur : " ₫";
  if (!L) return { lv: "", tag: "", why: "", max: null, p: null };
  const { max, w, r } = L, x = h.bal, o = { max, w, r, p: x / max };
  // vị trí kim trên thanh: đỏ 0–12% · vàng 12–24% · xanh 24–80% · vượt 80–100%
  o.pos = x <= 0 ? 1 : x < r ? 12 * x / r : x < w ? 12 + 12 * (x - r) / (w - r) : x < max ? 24 + 56 * (x - w) / (max - w) : Math.min(99, 80 + 20 * (x - max) / (max * 0.25));
  if (x >= max) return { ...o, lv: "bad", hi: 1, tag: "VƯỢT HẠN MỨC", why: `Vượt hạn mức ${fmt(max)}${u} — cần rút bớt` };
  if (x <= 0) return { ...o, lv: "bad", lo: 1, tag: "HẾT TIỀN", why: "Hết tiền — cần nạp quỹ ngay" };
  if (x < r) return { ...o, lv: "bad", lo: 1, tag: "SỐ DƯ RẤT THẤP", why: `Dưới ${fmt(r)}${u} — cần nạp quỹ` };
  if (x < w) return { ...o, lv: "warn", lo: 1, tag: "SỐ DƯ THẤP", why: `Dưới ${fmt(w)}${u} — chuẩn bị nạp` };
  return { ...o, lv: "ok", tag: "BÌNH THƯỜNG", why: "" };
}
const balPill = (h) => { const b = balSt(h); if (!b || !b.lv) return `<span class="bal">${balTxt(h)}</span>`; return `<span class="bal bp ${b.lv}${b.hi ? " hi" : b.lo && b.lv === "bad" ? " lo" : ""}" title="Hạn mức tối đa ${fmt(b.max)} · vàng dưới ${fmt(b.w)} · đỏ dưới ${fmt(b.r)} hoặc vượt hạn mức">${balTxt(h)}</span>`; };
const empty = (t) => `<div class="empty">${t}</div>`;

// ===== TỔNG QUAN =====
function renderHome() {
  const HN = Math.floor(NOWS() / 3600) + 1;
  const vndH = HOUSES.filter((h) => h.cur === "VND" && h.bal != null);
  const kp = [[VIEW ? "Tổng đơn ngày " + VIEW.slice(8) + "/" + VIEW.slice(5, 7) : "Tổng đơn hôm nay", fmt(day.n), "Tổng tiền " + vnd(day.amt) + " ₫", ""],
    ["Thành công", fmt(day.ok), pct(day.rate) + " tỷ lệ thành công", "ok"],
    ["Đang chờ", fmt(day.pend), "Tạo trong 30 phút gần nhất", "warn"],
    ["Chờ quá " + SET.stale + " phút", fmt(day.stale), "Tín hiệu cổng có vấn đề", "bad"],
    ["Thất bại", fmt(day.err), (day.n ? day.err / day.n * 100 : 0).toFixed(1) + "% tổng đơn", "bad"],
    ["Tiền đã lên điểm", (day.okAmt / 1e6).toLocaleString("vi-VN", { maximumFractionDigits: 2 }) + " tỷ", vnd(day.okAmt) + " ₫ · phí ~" + (day.fee / 1000).toLocaleString("vi-VN", { maximumFractionDigits: 1 }) + " tr", "ok"],
    ["Thời gian lên điểm", day.ok ? mmss(day.sp) : "—", "Trung bình · " + (day.ok ? (day.s3 / day.ok * 100).toFixed(0) : 0) + "% đơn dưới 3 phút", ""],
    ["Tổng số dư nhà thứ 3", (vndH.reduce((a, h) => a + h.bal, 0) / 1e6).toLocaleString("vi-VN", { maximumFractionDigits: 1 }) + " tr", vndH.length + " nhà VND · cập nhật " + (balAt ? new Date(balAt).toLocaleTimeString("vi-VN").slice(0, 5) : "—"), ""]];
  const KIC = ['<svg viewBox="0 0 24 24"><path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6"/></svg>', '<svg viewBox="0 0 24 24"><path d="M5 12l5 5 9-10"/></svg>', '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><path d="M12 8v4l3 2"/></svg>', '<svg viewBox="0 0 24 24"><path d="M12 7v6M12 17h.01"/></svg>', '<svg viewBox="0 0 24 24"><path d="M7 7l10 10M17 7L7 17"/></svg>', '<svg viewBox="0 0 24 24"><path d="M12 4v16M16 8c0-1.7-1.8-3-4-3s-4 1.3-4 3 1.8 2.6 4 3 4 1.3 4 3-1.8 3-4 3-4-1.3-4-3"/></svg>', '<svg viewBox="0 0 24 24"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l2 2M10 2h4"/></svg>', '<svg viewBox="0 0 24 24"><path d="M3 10l9-6 9 6M5 10v8M9 10v8M15 10v8M19 10v8M3 20h18"/></svg>'];
  const TINT = ["#2e8bff", "#22c97a", "#f2a516", "#ff3b4f", "#b45cff", "#19c7b0", "#3d8bff", "#6b5cff"];
  const N = NOWS(), S = STALE();
  const hr = (f) => { const b = new Array(Math.max(2, HN)).fill(0); for (const o of orders) if (f(o)) b[Math.min(b.length - 1, Math.floor(o.t / 3600))]++; return b; };
  const spH = () => { const s = new Array(Math.max(2, HN)).fill(0), c = new Array(Math.max(2, HN)).fill(0); for (const o of orders) if (o.st === 2) { const i = Math.min(s.length - 1, Math.floor(o.t / 3600)); s[i] += o.sp; c[i]++; } return s.map((v, i) => (c[i] ? v / c[i] : 0)); };
  const SER = [hr(() => 1), hr((o) => o.st === 2), hr((o) => o.st === 1 && N - o.t <= ABANDON), hr((o) => o.st === 1 && N - o.t > S && N - o.t <= ABANDON), hr((o) => o.st === 3), hr((o) => o.st === 2), spH(), hr(() => 1)];
  const wave = (arr, c) => {
    const W = 300, H = 38, mx = Math.max(...arr), mn = Math.min(...arr), r = mx - mn || 1;
    const pts = arr.map((v, i) => [i * W / (arr.length - 1), H - 6 - (v - mn) / r * (H - 14)]);
    let d = `M${pts[0][0]} ${pts[0][1]}`; for (let i = 1; i < pts.length; i++) { const [x0, y0] = pts[i - 1], [x1, y1] = pts[i], cx = (x0 + x1) / 2; d += ` C${cx} ${y0} ${cx} ${y1} ${x1} ${y1}`; }
    const id = "g" + Math.random().toString(36).slice(2, 7);
    return `<svg class="wave" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${c}" stop-opacity=".45"/><stop offset="1" stop-color="${c}" stop-opacity="0"/></linearGradient></defs><path d="${d} L${W} ${H} L0 ${H}Z" fill="url(#${id})"/><path d="${d}" fill="none" stroke="${c}" stroke-width="2" style="filter:drop-shadow(0 0 4px ${c})"/></svg>`;
  };
  const GOH = [{ s: "all" }, { s: "ok" }, { s: "pend" }, { s: "pend", m: 5 }, { s: "err" }, { s: "ok" }, { s: "ok" }, null];
  $("kpis").innerHTML = kp.map((k, i) => `<div class="kpi ${k[3]}${GOH[i] ? " go" : ""}" style="--t:${TINT[i]}"${GOH[i] ? ` data-go-list='${JSON.stringify({ ...GOH[i], tf: "day" })}' title="Bấm để xem danh sách đơn"` : ""}><span class="kic">${KIC[i]}</span><div class="lab">${k[0]}</div><div class="val">${k[1]}</div><div class="sub">${k[2]}</div>${wave(SER[i], TINT[i])}</div>`).join("");
  const al = alerts();
  $("cnt-alert").textContent = al.length;
  $("alerts").innerHTML = al.length ? al.map((x) => `<button class="alert ${x.lv === "fake" ? "slow" : x.lv}" ${x.tab ? `data-go-tab="${x.tab}"` : `data-go-house="${x.hi}"`}><span class="lvl">${x.lv === "bad" ? "ĐỎ" : x.lv === "warn" ? "VÀNG" : x.lv === "fake" ? "ẢO" : "CHẬM"}</span><span class="t">${esc(x.t)}</span><span class="act">${x.act}</span><span class="d">${esc(x.d)}</span></button>`).join("") : empty("Không có cổng nào bất thường trong 30 phút gần nhất.");
  const rows = HOUSES.map((h, hi) => ({ h, hi, a: agg(orders.filter((o) => o.h === hi)) })).sort((x, y) => y.a.n - x.a.n);
  $("hcards").innerHTML = rows.length ? rows.map(({ h, hi, a }) => {
    const lv = houseLv(hi);
    const gt = GATES.map((g, gi) => { if (!combo(hi, gi)) return ""; const c = agg(byCell[hi + "_" + gi] || []); const l = LV[hi + "_" + gi] || "ok"; return `<span class="gtag ${l === "bad" || l === "warn" ? l : ""}">${esc(g.n)} <b>${pct(c.rate)}</b></span>`; }).join("");
    return `<button class="hc ${lv === "ok" ? "" : lv}" data-go-house="${hi}">
      <div class="hc-top"><b>${esc(h.n)}</b>${statusPill(h)}<span class="bal">${balTxt(h)}</span></div>
      <div class="hc-stats"><div><small>Đơn</small><span>${fmt(a.n)}</span></div><div><small>Thành công</small><span class="ok">${fmt(a.ok)}</span></div><div><small>Chờ &gt;${SET.stale}'</small><span class="${a.stale ? "warn" : ""}">${fmt(a.stale)}</span></div><div><small>Thất bại</small><span class="${a.err ? "bad" : ""}">${fmt(a.err)}</span></div></div>
      <div style="display:flex;justify-content:space-between;align-items:center">${rateBar(a)}<span class="mut" style="font-size:11.5px">Lên điểm TB <b class="mono" style="color:var(--fg)">${a.ok ? mmss(a.sp) : "—"}</b></span></div>
      <div class="hc-gates">${gt}</div></button>`;
  }).join("") : empty("Chưa có đơn nào hôm nay.");
}
function alerts() {
  const al = [];
  for (const k in LV) {
    if (LV[k] !== "bad" && LV[k] !== "warn") continue;
    const [hi, gi] = k.split("_").map(Number); const a = agg(win30[k]);
    if (a.n < SET.minN) continue;
    al.push({ k, lv: LV[k], hi, t: `${HOUSES[hi].n} · ${GATES[gi].n}`, d: `30 phút gần nhất: thành công ${a.ok}/${a.n} đơn = ${pct(a.rate)} · đang chờ ${a.pend} (quá ${SET.stale}' : ${a.stale}) · hết hạn/huỷ ${a.aband} · kênh ${chText(combo(hi, gi))}`, act: LV[k] === "bad" ? "Cảnh báo" : "Theo dõi" });
  }
  // đơn "Đặt cọc không thành công" của khách thật trong 30 phút = lỗi cổng (sai cấu hình, bảo trì, đóng cổng)
  for (const k in win30) {
    const errs = win30[k].filter(isMaint); if (!errs.length) continue;
    const lastE = Math.max(...errs.map((o) => o.t));
    if (win30[k].some((o) => o.st === 2 && o.t > lastE)) continue; // đã có khách nạp thành công sau đó = hết bảo trì
    const [hi, gi] = k.split("_").map(Number), why = errs[errs.length - 1].why || "BO không ghi lý do";
    const ex = al.find((x) => x.k === k);
    const d = `${errs.length} đơn "Đặt cọc không thành công" trong 30 phút · lý do BO: ${why}`;
    if (ex) { ex.d = d + " · " + ex.d; ex.lv = "bad"; ex.act = "Lỗi cổng"; }
    else al.push({ k, lv: "bad", hi, t: `${HOUSES[hi].n} · ${GATES[gi].n}`, d, act: "Lỗi cổng" });
  }
  const N = NOWS(), w3 = {}; for (const o of orders) if (o.t >= N - 10800) (w3[o.h + "_" + o.g] ??= []).push(o);
  for (const k in w3) {
    const a = agg(w3[k]);
    if (a.ok >= 15 && a.med > 240 && (LV[k] || "ok") !== "bad" && LV[k] !== "warn") {
      const [hi, gi] = k.split("_").map(Number);
      al.push({ k, lv: "slow", hi, t: `${HOUSES[hi].n} · ${GATES[gi].n}`, d: `Lên điểm chậm 3 giờ gần nhất: trung vị ${mmss(a.med)} · ${a.sOver} đơn trên 10 phút · ${(a.s3 / a.ok * 100).toFixed(0)}% dưới 3 phút`, act: "Lên điểm chậm" });
    }
  }
  // lệnh ảo: báo riêng, không tính vào cổng
  const fr = fakeRows(ALL.filter((o) => o.t >= N - 1800)).filter((r) => r.lv !== "mark");
  if (fr.length) al.push({ k: "fake", lv: "fake", hi: -1, tab: "fake", t: `${fr.length} tài khoản nghi tạo lệnh ảo (30 phút)`, d: fr.slice(0, 6).map((r) => r.acc).join(", ") + (fr.length > 6 ? "…" : "") + " · đã bỏ khỏi thống kê cổng", act: "Chặn khách" });
  const ord = { bad: 0, warn: 1, slow: 2, fake: 3 }; al.sort((x, y) => ord[x.lv] - ord[y.lv]);
  return al;
}

// ===== bộ lọc dùng chung =====
function chips(el, list, cur, onPick, withLv, only) {
  $(el).innerHTML = `<button class="chip" aria-pressed="${cur === -1}" data-v="-1">Tất cả</button>` + list.map((x, i) => only && !only.has(i) && cur !== i ? "" : `<button class="chip" aria-pressed="${cur === i}" data-v="${i}">${withLv ? `<i class="${HOUSES[i].on === false ? "off" : houseLv(i)}"></i>` : ""}${esc(x.n)}</button>`).join("");
  $(el).onclick = (e) => { const b = e.target.closest(".chip"); if (b) onPick(+b.dataset.v); };
}
function segs() {
  document.querySelectorAll("[data-tf]").forEach((el) => {
    const key = el.dataset.tf;
    const c = st.cust[key] || { a: Math.max(0, NOWS() - 3600), b: NOWS() };
    el.innerHTML = TF().map((f) => `<button aria-pressed="${st.tf[key] === f[0]}" data-v="${f[0]}">${f[1]}</button>`).join("") +
      `<button aria-pressed="${st.tf[key] === "custom"}" data-v="custom" title="Tự chọn giờ:phút:giây">Tự chọn</button>` +
      "";
    el.onclick = (e) => { const b = e.target.closest("button"); if (!b) return;
      if (b.dataset.v === "custom") { const r = document.querySelector(`.qrow[data-k="${key}"]`); if (r) return qFind(r); }
      st.tf[key] = b.dataset.v; st.page = 0; segs(); render(); };
  });
  syncRows();
}
// hàng Ngày + từ giờ:phút:giây đến giờ:phút:giây + nút Tìm trong từng mục
function syncRows() {
  document.querySelectorAll(".qrow").forEach((r) => {
    const [a, b] = tfRange(r.dataset.k);
    r.querySelector(".qa").value = hms(a); r.querySelector(".qb").value = hms(b);
  });
}
async function qFind(r) {
  const k = r.dataset.k, d = r.querySelector(".dayPick").value || DAY;
  const a = parseHms(normHms(r.querySelector(".qa").value)), b = parseHms(normHms(r.querySelector(".qb").value));
  if (d !== (VIEW || DAY)) await setView(d);
  st.cust[k] = { a: Math.min(a, b), b: Math.max(a, b) }; st.tf[k] = "custom"; st.page = 0;
  segs(); render();
}
// ô giờ 24h (00:00:00 → 23:59:59): gõ số là tự thêm dấu ":"; mũi tên lên/xuống để tăng giảm
const fmtHmsIn = (v) => { const d = String(v).replace(/\D/g, "").slice(0, 6); return d.replace(/^(\d{2})(\d)/, "$1:$2").replace(/^(\d{2}:\d{2})(\d)/, "$1:$2"); };
const normHms = (v) => { const p = String(v || "").split(":").map((x) => parseInt(x, 10) || 0); return hms(Math.min(23, p[0] || 0) * 3600 + Math.min(59, p[1] || 0) * 60 + Math.min(59, p[2] || 0)); };
document.querySelectorAll(".qrow .qa, .qrow .qb").forEach((i) => {
  i.addEventListener("input", () => { const c = i.selectionStart === i.value.length; i.value = fmtHmsIn(i.value); if (c) i.selectionStart = i.selectionEnd = i.value.length; });
  i.addEventListener("blur", () => { i.value = normHms(i.value); });
  i.addEventListener("focus", () => i.select());
  i.addEventListener("keydown", (e) => {
    if (e.key !== "ArrowUp" && e.key !== "ArrowDown") return; e.preventDefault();
    const pos = i.selectionStart ?? 0, unit = pos <= 2 ? 3600 : pos <= 5 ? 60 : 1, t = parseHms(normHms(i.value)) + (e.key === "ArrowUp" ? unit : -unit);
    i.value = hms(Math.max(0, Math.min(86399, t))); i.setSelectionRange(pos <= 2 ? 0 : pos <= 5 ? 3 : 6, pos <= 2 ? 2 : pos <= 5 ? 5 : 8);
  });
});
document.querySelectorAll(".qrow").forEach((r) => {
  r.querySelector(".qgo").onclick = () => qFind(r);
  r.querySelectorAll("input").forEach((i) => i.addEventListener("keydown", (e) => { if (e.key === "Enter") qFind(r); }));
});

// ===== NHÀ THỨ 3 =====
function gateBlock(hi, gi, list) {
  const g = GATES[gi], c0 = combo(hi, gi), a = agg(list), l = lvBoth(hi + "_" + gi, a);
  return `<div class="gate ${l === "bad" || l === "warn" ? l : ""}"><div class="gate-h"><b>${esc(g.n)}</b>${boTag(hi, gi)}<small>${esc(chText(c0))}</small><span class="fee">phí ${c0 ? c0.fee : "—"}%</span></div>
   <div class="gate-g">${[["Đơn", "all", a.n, ""], ["Thành công", "ok", a.ok, "ok"], ["Chờ", "pend", a.waiting, a.stale ? "warn" : ""], ["Thất bại", "err", a.err, a.err ? "bad" : ""]].map(([l, s, v, cl]) => `<div class="gocell" data-go-list='${JSON.stringify({ s, h: hi, g: gi, tf: st.tf.house })}' title="Bấm để xem danh sách đơn"><small>${l}</small><span class="${cl}">${fmt(v)}</span></div>`).join("")}</div>
   <div style="display:flex;justify-content:space-between;align-items:center">${rateBar(a)}<span class="mut" style="font-size:11px">TB ${a.ok ? mmss(a.sp) : "—"}</span></div></div>`;
}
function renderHouse() {
  if (st.house >= HOUSES.length) st.house = -1;
  chips("hf", HOUSES, st.house, (v) => { st.house = v; render(); }, true);
  const list = inTf("house"); const by = {}; for (const o of list) (by[o.h + "_" + o.g] ??= []).push(o);
  if (!HOUSES.length) { $("house-body").innerHTML = empty("Chưa có dữ liệu."); return; }
  if (st.house === -1) {
    const rows = HOUSES.map((h, hi) => ({ h, hi, a: agg(list.filter((o) => o.h === hi)), b: balSt(h) }));
    const cnt = { ok: 0, warn: 0, lo: 0, hi: 0 }; let tot = 0, usd = 0;
    for (const r of rows) { if (r.h.bal != null) { if (r.h.cur && r.h.cur !== "VND") usd += r.h.bal; else tot += r.h.bal; } if (!r.b || !r.b.lv) continue; if (r.b.hi) cnt.hi++; else if (r.b.lv === "bad") cnt.lo++; else if (r.b.lv === "warn") cnt.warn++; else cnt.ok++; }
    const F = st.nbF || "", O = st.nbO || "st";
    const keep = (r) => !F || (F === "hi" ? r.b && r.b.hi : F === "lo" ? r.b && r.b.lv === "bad" && !r.b.hi : r.b && r.b.lv === F);
    const rk = (r) => (!r.b || !r.b.lv ? 3 : r.b.lv === "bad" ? 0 : r.b.lv === "warn" ? 1 : 2);
    const L = rows.filter(keep).sort(O === "bal" ? (x, y) => (y.h.bal || 0) - (x.h.bal || 0) : O === "n" ? (x, y) => y.a.n - x.a.n : (x, y) => rk(x) - rk(y) || y.a.n - x.a.n);
    const sh = (v) => (v >= 1e9 ? (v / 1e9).toLocaleString("vi-VN", { maximumFractionDigits: 2 }) + " tỷ" : v >= 1e6 ? (v / 1e6).toLocaleString("vi-VN", { maximumFractionDigits: 1 }) + " tr" : fmt(v));
    const sumC = [["", "Tổng số dư nhà thứ 3", (tot / 1e6).toLocaleString("vi-VN", { maximumFractionDigits: 1 }) + " tr ₫", HOUSES.length + " nhà" + (usd ? " · " + fmt(usd) + " USDT" : "") + (balAt ? " · cập nhật " + new Date(balAt).toLocaleTimeString("vi-VN").slice(0, 5) : ""), "#2563eb"], ["ok", "Bình thường", cnt.ok, "trên ngưỡng vàng", "#14a05a"], ["warn", "Số dư thấp", cnt.warn, "dưới ngưỡng vàng", "#d98a00"], ["lo", "Số dư rất thấp / hết", cnt.lo, "dưới ngưỡng đỏ", "#e2364a"], ["hi", "Vượt hạn mức", cnt.hi, "cần rút bớt", "#e2364a"]];
    $("house-body").innerHTML = `<div class="nb-sum">${sumC.map(([k, a1, b1, c1, col]) => `<button class="nb-s ${F === k && k ? "on" : ""}" data-nbf="${k}" style="--k:${col}"><small>${a1}</small><b>${b1}</b><span>${c1}</span></button>`).join("")}</div>
    <div class="nb-bar"><span class="mut">${tfLabel("house")} · bấm ô tổng để lọc · bấm tên nhà để mở chi tiết</span><span class="mut" style="margin-left:auto">Sắp xếp</span><div class="seg" id="nbO">${[["st", "Cần chú ý trước"], ["bal", "Số dư"], ["n", "Số đơn"]].map(([k, n]) => `<button aria-pressed="${O === k}" data-nbo="${k}">${n}</button>`).join("")}</div></div>
    <div class="nb-grid">${L.map(({ h, hi, a, b }) => {
      const u = h.cur && h.cur !== "VND" ? " " + h.cur : " ₫", pos = b && b.max ? Math.max(1, Math.min(99, b.pos)) : null;
      const gr = GATES.map((g, gi) => { if (!combo(hi, gi)) return ""; const c = agg(by[hi + "_" + gi] || []), v = combo(hi, gi), r = c.rate, cl = r == null ? "mut" : r >= 85 ? "ok" : r >= 60 ? "warn" : "bad"; return `<tr class="${cl === "bad" ? "e" : cl === "warn" ? "w" : ""}"><td class="l"><b>${esc(g.n)}</b> ${boTag(hi, gi)}<small>${esc(chText(v))} · phí ${v.fee}%</small></td><td>${fmt(c.n)}</td><td class="${c.stale ? "warn" : "mut"}">${fmt(c.stale)}</td><td><span class="nb-rt"><b class="${cl}">${pct(r)}</b><i><em style="width:${r || 0}%;background:var(--nb-${cl})"></em></i></span></td><td class="mut">${c.ok ? mmss(c.sp) : "—"}</td></tr>`; }).join("");
      return `<div class="nb-c ${b && b.lv ? b.lv : ""}" style="--hc:${hColor(h.n)}"><div class="nb-top"><div class="nb-nm"><button class="nb-name" data-pick-house="${hi}">${esc(h.n)}</button>${statusPill(h)}${b && b.tag ? `<span class="nb-tag">${b.tag}</span>` : ""}</div>
        <div class="nb-bal"><div class="v"><b>${balTxt(h)}</b><span>${h.balAt ? "cập nhật " + new Date(h.balAt).toLocaleTimeString("vi-VN").slice(0, 5) : ""}</span></div>
        ${pos != null ? `<div class="nb-meter"><i style="left:calc(${pos}% - 2px)"></i></div><div class="nb-lim"><span>đỏ dưới ${sh(b.r)}</span><span>vàng dưới ${sh(b.w)}</span><span>tối đa: ${sh(b.max)}${u}</span></div>` : `<div class="nb-lim"><span>Chưa đặt hạn mức (Cài đặt → Hạn mức số dư)</span></div>`}
        ${b && b.why ? `<div class="nb-why">⚠ ${esc(b.why)}</div>` : ""}</div>
        <div class="nb-st"><div><small>Đơn</small><b>${fmt(a.n)}</b></div><div><small>Thành công</small><b class="ok">${fmt(a.ok)}</b></div><div><small>Chờ &gt;${SET.stale}'</small><b class="${a.stale ? "warn" : ""}">${fmt(a.stale)}</b></div><div><small>Tỷ lệ</small><b class="${rc(a.rate)}">${pct(a.rate)}</b></div></div></div>
        ${gr ? `<table class="nb-gt"><thead><tr><th class="l">Cổng · kênh</th><th>Đơn</th><th>Chờ</th><th>Tỷ lệ</th><th>TB</th></tr></thead><tbody>${gr}</tbody></table>` : `<div class="mut" style="padding:12px 14px">Không có đơn trong khung thời gian này.</div>`}</div>`;
    }).join("") || empty("Không có nhà nào.")}</div>`;
    $("house-body").querySelectorAll("[data-nbf]").forEach((x) => (x.onclick = () => { st.nbF = st.nbF === x.dataset.nbf ? "" : x.dataset.nbf; render(); }));
    $("house-body").querySelectorAll("[data-nbo]").forEach((x) => (x.onclick = () => { st.nbO = x.dataset.nbo; render(); }));
  } else {
    const hi = st.house, h = HOUSES[hi]; const a = agg(list.filter((o) => o.h === hi));
    const kp = [["Số dư", balTxt(h), h.on == null ? "Chưa ghép với listV2" : h.on ? "Rút đang bật" : "Rút đang tắt", ""], ["Tổng đơn", fmt(a.n), vnd(a.amt) + " ₫", ""], ["Thành công", fmt(a.ok), pct(a.rate), "ok"], ["Đang chờ / hết hạn", fmt(a.waiting), a.stale + " đơn chờ quá " + SET.stale + "'", "warn"], ["Thất bại", fmt(a.err), "", a.err ? "bad" : ""], ["Lên điểm TB", a.ok ? mmss(a.sp) : "—", (a.ok ? (a.s3 / a.ok * 100).toFixed(0) : 0) + "% dưới 3 phút", ""], ["Phí ước tính", vnd(a.fee), "₫ · TB " + (a.okAmt ? (a.fee / a.okAmt * 100).toFixed(2) : "0") + "%", ""]];
    let t = `<thead><tr><th class="l">Cổng nạp</th><th class="l">Kênh</th><th>Phí %</th><th>Đơn</th><th>Thành công</th><th>Đang chờ</th><th>Chờ &gt;${SET.stale}'</th><th>Hết hạn/huỷ</th><th>Thất bại</th><th>Tỷ lệ</th><th>Lên điểm TB</th><th>&lt; 3'</th><th>&gt; 10'</th><th>Tiền lên điểm (₫)</th><th>Phí ước tính (₫)</th><th class="l">Trạng thái</th></tr></thead><tbody>`;
    GATES.forEach((g, gi) => {
      const v = combo(hi, gi); if (!v) return; const c = agg(by[hi + "_" + gi] || []); const l = lvBoth(hi + "_" + gi, c);
      t += `<tr class="${l === "bad" ? "rbad" : l === "warn" ? "rwarn" : ""}"><td class="name">${esc(g.n)} ${boTag(hi, gi)}<small>${esc(g.raw)}</small></td><td class="l">${esc([...v.chs].join(", "))}</td><td>${v.fee}%</td>${[["all", c.n, ""], ["ok", c.ok, "ok"], ["pend", c.pend, ""], ["pend5", c.stale, c.stale ? "warn" : "mut"], ["aband", c.aband, "mut"], ["err", c.err, c.err ? "bad" : "mut"]].map(([s, v, cl]) => `<td class="${cl} gocell" data-go-list='${JSON.stringify({ s: s === "pend5" ? "pend" : s, m: s === "pend5" ? 5 : 0, h: hi, g: gi, tf: st.tf.house })}' title="Bấm để xem danh sách đơn">${fmt(v)}</td>`).join("")}<td>${rateBar(c)}</td><td>${c.ok ? mmss(c.sp) : "—"}</td><td>${c.ok ? (c.s3 / c.ok * 100).toFixed(0) + "%" : "—"}</td><td class="${c.sOver ? "bad" : "mut"}">${fmt(c.sOver)}</td><td>${vnd(c.okAmt)}</td><td>${vnd(c.fee)}</td><td class="l">${PILL[l]}</td></tr>`;
    });
    t += `</tbody><tfoot><tr><td class="l">Tổng ${esc(h.n)}</td><td></td><td>${a.okAmt ? (a.fee / a.okAmt * 100).toFixed(2) + "%" : "—"}</td><td>${fmt(a.n)}</td><td class="ok">${fmt(a.ok)}</td><td>${fmt(a.pend)}</td><td>${fmt(a.stale)}</td><td>${fmt(a.aband)}</td><td>${fmt(a.err)}</td><td>${rateBar(a)}</td><td>${a.ok ? mmss(a.sp) : "—"}</td><td>${a.ok ? (a.s3 / a.ok * 100).toFixed(0) + "%" : "—"}</td><td>${fmt(a.sOver)}</td><td>${vnd(a.okAmt)}</td><td>${vnd(a.fee)}</td><td></td></tr></tfoot>`;
    $("house-body").innerHTML = `<div class="page-h"><h2>${esc(h.n)}</h2><p>${tfLabel("house")} · từng cổng nạp của ${esc(h.n)}</p></div>
     <div class="kpis">${kp.map((k, i) => { const g = [null, "all", "ok", "pend", "err", "ok", "ok"][i]; return `<div class="kpi ${k[3]}${g ? " go" : ""}"${g ? ` data-go-list='${JSON.stringify({ s: g, h: hi, tf: st.tf.house })}' title="Bấm để xem danh sách đơn"` : ""}><div class="lab">${k[0]}</div><div class="val">${k[1]}</div><div class="sub">${k[2]}</div></div>`; }).join("")}</div>
     <div class="card"><div class="card-h"><h3>Cổng nạp của ${esc(h.n)}</h3><span class="hint">Kéo ngang nếu bảng dài</span></div><div class="scroll"><table class="tbl">${t}</table></div></div>
     <div class="card chart"><div class="card-h"><h3>Đơn theo giờ · ${esc(h.n)}</h3></div><div class="card-b">${hourChart(orders.filter((o) => o.h === hi))}</div></div>`;
  }
}

// ===== CỔNG NẠP =====
function hourChart(list) {
  const HN = Math.max(1, Math.floor(NOWS() / 3600) + 1);
  const b = Array.from({ length: HN }, () => ({ ok: 0, p: 0, e: 0 }));
  for (const o of list) { const i = Math.min(HN - 1, Math.floor(o.t / 3600)); if (o.st === 2) b[i].ok++; else if (o.st === 3) b[i].e++; else b[i].p++; }
  const mx = Math.max(1, ...b.map((x) => x.ok + x.p + x.e)); const step = [1, 2, 5, 10, 20, 50, 100, 200, 250, 500, 1000, 2000].find((s) => mx / s <= 5) || 5000; const top = Math.ceil(mx / step) * step;
  const W = 560, H = 210, L = 44, R = 8, T = 10, B = 24, cw = (W - L - R) / Math.max(HN, 8), y = (v) => T + (H - T - B) * (1 - v / top);
  let s = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Số đơn theo giờ">`;
  for (let v = 0; v <= top; v += step) s += `<line class="gl" x1="${L}" x2="${W - R}" y1="${y(v)}" y2="${y(v)}"/><text x="${L - 6}" y="${y(v) + 3}" text-anchor="end">${fmt(v)}</text>`;
  b.forEach((x, i) => {
    const bx = L + i * cw + cw * 0.18, bw = cw * 0.64; let base = 0;
    [["ok", "var(--b1)"], ["p", "var(--b3)"], ["e", "var(--b5)"]].forEach(([k, c]) => { const v = x[k]; if (!v) return; s += `<rect x="${bx.toFixed(1)}" y="${y(base + v).toFixed(1)}" width="${bw.toFixed(1)}" height="${(y(base) - y(base + v)).toFixed(1)}" fill="${c}" rx="1.5"><title>${pad(i)}h: ${v}</title></rect>`; base += v; });
    s += `<text x="${(L + i * cw + cw / 2).toFixed(1)}" y="${H - 7}" text-anchor="middle">${pad(i)}h</text>`;
  });
  return s + "</svg>";
}
const gCol = (g) => gColor(g.k);
// khách nạp theo ngày / tháng (chỉ tính đơn thật, bỏ tài khoản lệnh ảo)
const CUSTF = { acc: (o) => o.acc, ok: (o) => o.st === 2, bad: (o) => o.st === 3, amt: (o) => o.amt };
let CMT = { at: 0, s: null };
// lưu tóm tắt nạp hôm nay mỗi 5 phút (trang XUẤT dùng để tính nạp − rút)
setInterval(() => { try { if (!VIEW && ORD.size) { CMT = { at: Date.now(), s: Cust.sum([...ORD.values()].filter((o) => !FAKESET.has(o.acc) && !(o.t < 0)), CUSTF) }; Store.kvSet("cust:" + DAY, CMT.s).catch(() => {}); } } catch (e) {} }, 300e3);
setTimeout(() => { try { if (!VIEW && ORD.size) Store.kvSet("cust:" + DAY, Cust.sum([...ORD.values()].filter((o) => !FAKESET.has(o.acc) && !(o.t < 0)), CUSTF)).catch(() => {}); } catch (e) {} }, 60e3);
const CMD = Cust.mount($("cm-dep"), {
  store: Store, unit: "đơn nạp", who: "khách nạp", okName: "thành công", title: "Đơn nạp thành công theo ngày",
  today: () => DAY,
  todaySum: () => { if (!ORD.size) return CMT.s; if (Date.now() - CMT.at > 60e3) { CMT = { at: Date.now(), s: Cust.sum([...ORD.values()].filter((o) => !FAKESET.has(o.acc) && !(o.t < 0)), CUSTF) }; } return CMT.s; },
  fromOrders: async (dk) => { const L = await Store.dayOrders(dk).catch(() => []); for (const o of L) if (o.st == null || o.ps != null) o.st = BO.stCode(Number(o.ps), o.psl); return L.length ? Cust.sum(L, CUSTF) : null; }
});
function renderGate() {
  if (!$("gstat").open) try { renderGstat(); } catch (e) {}
  if (!$("ghouse").open) try { renderGhouse(); } catch (e) {}
  if (st.gate >= GATES.length) st.gate = -1;
  const list = inTf("gate");
  // hàng thẻ cổng nạp
  const all = agg(list);
  $("gcards").innerHTML = `<button class="cg-g ${st.gate === -1 ? "on" : ""}" data-gi="-1" style="--c:#334155"><b>Tất cả</b><span>${HOUSES.length} nhà</span><span class="r">${fmt(all.n)}</span></button>` + GATES.map((g, gi) => { const gl = list.filter((o) => o.g === gi), a = agg(gl), nh = HOUSES.filter((h, hi) => combo(hi, gi)).length; return `<button class="cg-g ${st.gate === gi ? "on" : ""}" data-gi="${gi}" style="--c:${gCol(g)}"><b>${esc(g.n)}</b><span>${nh} nhà · <b class="${rc(a.rate)}" style="display:inline;font-size:12px">${pct(a.rate)}</b></span><span class="r">${fmt(a.n)}</span></button>`; }).join("");
  $("gcards").onclick = (e) => { const b = e.target.closest("[data-gi]"); if (b) { st.gate = +b.dataset.gi; render(); } };
  const gl = st.gate === -1 ? list : list.filter((o) => o.g === st.gate), A = agg(gl), gc = st.gate === -1 ? "#334155" : gCol(GATES[st.gate]);
  $("gkpis").innerHTML = [["Tổng đơn", fmt(A.n), st.gate === -1 ? "tất cả cổng" : GATES[st.gate].n, "#2563eb", "all"], ["Thành công", fmt(A.ok), pct(A.rate) + " tỷ lệ", "#16a34a", "ok"], ["Chờ quá " + SET.stale + " phút", fmt(A.stale), "tín hiệu cổng có vấn đề", "#d98a00", "pend"], ["Hết hạn / huỷ", fmt(A.aband), "khách bỏ dở", "#64748b", "aband"], ["Lên điểm TB", A.ok ? mmss(A.sp) : "—", (A.ok ? (A.s3 / A.ok * 100).toFixed(0) : 0) + "% đơn dưới 3 phút", "#0891b2", "ok"], ["Tiền lên điểm", A.okAmt >= 1e9 ? (A.okAmt / 1e9).toLocaleString("vi-VN", { maximumFractionDigits: 2 }) + " tỷ" : (A.okAmt / 1e6).toLocaleString("vi-VN", { maximumFractionDigits: 1 }) + " tr", vnd(A.okAmt) + " ₫", "#7c3aed", "ok"]]
    .map(([a1, b1, c1, k, s1]) => `<div class="cg-k" style="--k:${k}" data-go-list='${JSON.stringify({ s: s1, m: s1 === "pend" ? SET.stale : 0, g: st.gate, tf: st.tf.gate })}' title="Bấm để xem danh sách đơn"><small>${a1}</small><b>${b1}</b><span>${esc(c1)}</span></div>`).join("");
  // bảng theo nhà
  $("gtcard").style.setProperty("--c", gc);
  $("gtH").textContent = (st.gate === -1 ? "Tất cả cổng" : GATES[st.gate].n) + " theo nhà";
  $("gate-hint").textContent = tfLabel("gate") + " · bấm tên nhà để mở chi tiết · bấm tiêu đề cột để sắp xếp";
  const R = HOUSES.map((h, hi) => ({ h, hi, a: agg(gl.filter((o) => o.h === hi)) })).filter((r) => r.a.n || (st.gate === -1 ? GATES.some((g, gi) => combo(r.hi, gi)) : combo(r.hi, st.gate))).sort((p, q) => q.a.n - p.a.n);
  const ev = (r) => (r == null ? ["mut", "Chưa có đơn"] : r >= 85 ? ["ok", "Ổn định"] : r >= 60 ? ["warn", "Theo dõi"] : ["bad", "Cần xem"]);
  let t = `<thead><tr><th class="l">Nhà thứ 3</th>${st.gate === -1 ? "" : "<th class=\"l\">Kênh</th><th>Phí %</th>"}<th>Đơn</th><th>Thành công</th><th>Chờ &gt;${SET.stale}'</th><th>Hết hạn / huỷ</th><th>Thất bại</th><th class="l">Tỷ lệ thành công</th><th>Lên điểm TB</th><th>Tiền lên điểm (₫)</th><th class="l">Đánh giá</th></tr></thead><tbody>`;
  for (const { h, hi, a } of R) {
    const e = ev(a.rate), v = st.gate === -1 ? null : combo(hi, st.gate), ng = GATES.filter((g, gi) => combo(hi, gi)).length;
    t += `<tr><td class="l cg-h" style="--hc:${hColor(h.n)}"><button class="nb-name" data-pick-house2="${hi}">${esc(h.n)}</button>${st.gate === -1 ? `<small>${ng} cổng</small>` : boTag(hi, st.gate)}</td>${st.gate === -1 ? "" : `<td class="l mut">${esc(chText(v))}</td><td>${v ? v.fee + "%" : "—"}</td>`}<td><b>${fmt(a.n)}</b></td><td class="ok">${fmt(a.ok)}</td><td class="${a.stale ? "warn" : "mut"}">${fmt(a.stale)}</td><td class="mut">${fmt(a.aband)}</td><td class="${a.err ? "bad" : "mut"}">${fmt(a.err)}</td><td class="l">${rateBar(a)}</td><td>${a.ok ? mmss(a.sp) : "—"}</td><td>${vnd(a.okAmt)}</td><td class="l"><span class="cg-ev ${e[0]}">${e[1]}</span></td></tr>`;
  }
  t += `</tbody><tfoot><tr><td class="l">Tổng ${R.length} nhà</td>${st.gate === -1 ? "" : "<td></td><td></td>"}<td>${fmt(A.n)}</td><td class="ok">${fmt(A.ok)}</td><td>${fmt(A.stale)}</td><td>${fmt(A.aband)}</td><td>${fmt(A.err)}</td><td class="l">${rateBar(A)}</td><td>${A.ok ? mmss(A.sp) : "—"}</td><td>${vnd(A.okAmt)}</td><td></td></tr></tfoot>`;
  $("gate-tbl").innerHTML = t;
  $("gate-tbl").onclick = (e) => { const b = e.target.closest("[data-pick-house2]"); if (b) { st.house = +b.dataset.pickHouse2; go("house"); window.scrollTo({ top: 0 }); } };
  $("gate-chart-hint").textContent = (st.gate === -1 ? "Tất cả cổng" : GATES[st.gate].n) + " · hôm nay";
  $("gate-chart").innerHTML = hourChart(st.gate === -1 ? orders : orders.filter((o) => o.g === st.gate));
  try { CMD.draw(); } catch (e) {}
  // ma trận nhà × cổng
  const GS = GATES.map((g, gi) => ({ g, gi })).filter(({ gi }) => HOUSES.some((h, hi) => combo(hi, gi)));
  $("gate-mx").innerHTML = `<thead><tr><th class="l">Nhà</th>${GS.map(({ g }) => `<th style="text-align:center;color:${gCol(g)}">${esc(g.n)}</th>`).join("")}</tr></thead><tbody>` +
    HOUSES.map((h, hi) => ({ h, hi })).filter(({ hi }) => GS.some(({ gi }) => combo(hi, gi))).map(({ h, hi }) => `<tr><td class="l cg-h" style="--hc:${hColor(h.n)}"><span class="cg-hn">${esc(h.n)}</span></td>${GS.map(({ gi }) => { if (!combo(hi, gi)) return `<td class="cg-x mut">·</td>`; const c = agg(list.filter((o) => o.h === hi && o.g === gi)); if (!c.n) return `<td class="cg-x mut" title="Chưa có đơn">0</td>`; const e = ev(c.rate); return `<td class="cg-x ${e[0]}" title="${fmt(c.ok)}/${fmt(c.n)} đơn" data-go-list='${JSON.stringify({ s: "all", h: hi, g: gi, tf: st.tf.gate })}'>${Math.round(c.rate)}%</td>`; }).join("")}</tr>`).join("") + "</tbody>";
}

// ===== TỐC ĐỘ =====
function renderSpeed() {
  if (st.speedH >= HOUSES.length) st.speedH = -1;
  if (st.speedG >= GATES.length) st.speedG = -1;
  const base = inTf("speed");
  // cổng nạp (Momo, ngân hàng, Zalo…) → chỉ hiện các nhà thứ 3 có cổng đó
  chips("sg", GATES, st.speedG, (v) => { st.speedG = v; if (v !== -1 && st.speedH !== -1 && !base.some((o) => o.g === v && o.h === st.speedH)) st.speedH = -1; render(); }, false);
  const hs = st.speedG === -1 ? null : new Set(base.filter((o) => o.g === st.speedG).map((o) => o.h));
  chips("sf", HOUSES, st.speedH, (v) => { st.speedH = v; render(); }, true, hs);
  const list = base.filter((o) => (st.speedH === -1 || o.h === st.speedH) && (st.speedG === -1 || o.g === st.speedG)); const a = agg(list);
  const kp = [["Tổng đơn", fmt(a.n), tfLabel("speed"), ""], ["Dưới 3 phút", fmt(a.s3), (a.ok ? (a.s3 / a.ok * 100).toFixed(1) : 0) + "% đơn thành công", "ok"], ["3–10 phút", fmt(a.s10), (a.ok ? (a.s10 / a.ok * 100).toFixed(1) : 0) + "%", "warn"], ["Trên 10 phút", fmt(a.sOver), (a.ok ? (a.sOver / a.ok * 100).toFixed(1) : 0) + "%", "bad"], ["Chưa lên điểm", fmt(a.waiting), "Đang chờ + bỏ dở", ""], ["Thất bại", fmt(a.err), "", "slow"], ["Trung vị / P90", a.ok ? mmss(a.med) : "—", "90% đơn lên trong " + (a.ok ? mmss(a.p90) : "—"), ""]];
  const GOS = [{ s: "all" }, { s: "ok" }, { s: "ok" }, { s: "ok" }, { s: "pend" }, { s: "err" }, { s: "ok" }];
  $("speed-kpis").innerHTML = kp.map((k, i) => `<div class="kpi ${k[3]} go" data-go-list='${JSON.stringify({ ...GOS[i], h: st.speedH, g: st.speedG, tf: st.tf.speed })}' title="Bấm để xem danh sách đơn"><div class="lab">${k[0]}</div><div class="val">${k[1]}</div><div class="sub">${k[2]}</div></div>`).join("");
  const rows = []; const by = {}; for (const o of list) (by[o.h + "_" + o.g] ??= []).push(o);
  for (const k in by) { const [hi, gi] = k.split("_").map(Number); rows.push({ hi, gi, a: agg(by[k]) }); }
  rows.sort((p, q) => (q.a.ok >= 5 ? q.a.med : 0) - (p.a.ok >= 5 ? p.a.med : 0));
  let t = `<thead><tr><th class="l">Nhà</th><th class="l">Cổng</th><th class="l">Kênh</th><th>Tổng đơn</th><th>&lt; 3 phút</th><th>3–10 phút</th><th>&gt; 10 phút</th><th>Chưa lên</th><th>Thất bại</th><th class="l">Phân bố</th><th>% dưới 3'</th><th>Trung vị</th><th>P90</th><th>Chậm nhất</th><th class="l">Đánh giá</th></tr></thead><tbody>`;
  for (const { hi, gi, a: c } of rows) {
    const T = Math.max(1, c.n); const r3 = c.ok ? c.s3 / c.ok * 100 : 0;
    const ev = c.ok < 5 ? '<span class="pill" style="background:var(--panel2);color:var(--muted)">Ít đơn</span>' : c.med > 300 || r3 < 50 ? '<span class="pill badp">Rất chậm</span>' : c.med > 150 || r3 < 75 ? '<span class="pill warnp">Chậm</span>' : '<span class="pill on">Nhanh</span>';
    t += `<tr><td class="name">${esc(HOUSES[hi].n)}</td><td class="l">${esc(GATES[gi].n)}</td><td class="l mut">${esc(chText(combo(hi, gi)))}</td><td>${fmt(c.n)}</td><td class="ok">${fmt(c.s3)}</td><td class="${c.s10 ? "warn" : "mut"}">${fmt(c.s10)}</td><td class="${c.sOver ? "bad" : "mut"}">${fmt(c.sOver)}</td><td class="mut">${fmt(c.waiting)}</td><td class="${c.err ? "slow" : "mut"}">${fmt(c.err)}</td>
    <td class="l"><span class="track wide"><span style="width:${c.s3 / T * 100}%;background:var(--b1)"></span><span style="width:${c.s10 / T * 100}%;background:var(--b3)"></span><span style="width:${c.sOver / T * 100}%;background:var(--b5)"></span><span style="width:${c.waiting / T * 100}%;background:var(--b6)"></span><span style="width:${c.err / T * 100}%;background:var(--slow)"></span></span></td>
    <td class="${rc(r3 >= 85 ? 80 : r3 >= 70 ? 60 : 40)}">${c.ok ? r3.toFixed(0) + "%" : "—"}</td><td>${c.ok ? mmss(c.med) : "—"}</td><td>${c.ok ? mmss(c.p90) : "—"}</td><td class="mut">${c.ok ? mmss(c.sps[c.sps.length - 1]) : "—"}</td><td class="l">${ev}</td></tr>`;
  }
  if (!rows.length) t += `<tr><td class="l mut" colspan="15">Chưa có đơn trong khung thời gian này</td></tr>`;
  $("speed-tbl").innerHTML = t + "</tbody>";
}

// ===== DANH SÁCH ĐƠN =====
const OST = [["pend", "Đang chờ thanh toán", "warn"], ["ok", "Thành công", "ok"], ["err", "Thất bại", "bad"], ["aband", "Hết hạn / huỷ / bỏ dở", ""], ["all", "Tất cả đơn", ""]];
const stOf = (o) => (o.st === 2 ? "ok" : o.st === 3 ? "err" : o.st >= 4 || NOWS() - o.t > ABANDON ? "aband" : "pend");
const PAGE = 50;
let LIST = [];
const NTAG = { first: "Lần đầu", second: "Lần 2" };
const nTxt = (o) => o.nAll == null ? '<span class="mut">—</span>' : `<span title="Thành công ${o.nOk} / tổng ${o.nAll} lần nạp">${fmt(o.nOk)}<span class="mut">/${fmt(o.nAll)}</span></span>${NTAG[o.ntag] ? ` <span class="pill ${o.ntag === "first" ? "on" : "low"}">${NTAG[o.ntag]}</span>` : ""}`;
TSort.full("pend-tbl", () => { st.page = 0; render(); });

// ===== Danh sách đơn theo mốc: Tạo thời gian / Thời gian thành công / Cập nhật thời gian (giống ô chọn trên BO) =====
st.lbasis = "create"; try { const v = localStorage.getItem("lbasis"); if (v && ["create", "ok", "upd"].includes(v)) st.lbasis = v; } catch (e) {}
const LB_NAME = { create: "tạo thời gian", ok: "thời gian thành công", upd: "cập nhật thời gian" };
let BX = { key: "", map: new Map(), from: 0, to: 0, full: false, busy: false, err: "", prev: null };
const hIdx = (o) => HIDX[hkey(o.merch)], gIdx = (o) => GIDX[nk(o.gate) || "khac"];
const hNm = (o) => (HOUSES[o.h] ? HOUSES[o.h].n : o.merch || "?"), gNm = (o) => (GATES[o.g] ? GATES[o.g].n : o.gate || "?");
function btOf(o, kind) {
  const okT = o.st === 2 ? (o.nt || o.ts + (o.sp || 0)) : 0;
  if (kind === "ok") return okT;
  const ut = o.ut > 1e11 ? Math.floor(o.ut / 1000) : o.ut;
  return ut || okT || o.ts;
}
async function loadBX(kind, dk, from, to) {
  const bx = BX; if (bx.busy) return; bx.busy = true; bx.err = "";
  const D0x = dayStartOf(dk);
  try {
    if (!bx.prev) bx.prev = await Store.dayOrders(dayKey(new Date((D0x - 43200) * 1000))).catch(() => []);
    // đã có từ bx.from đến bx.to → chỉ đọc thêm phần mới (đơn hôm nay), còn lại đọc cả khung
    let a = from; if (bx.full && bx.from <= from && bx.to >= from) a = Math.max(from, bx.to - 120);
    const tt = await findTimeType(kind, a, to);
    for (const cur of curs()) {
      let page = 1, pages = 1;
      while (page <= pages) {
        let d; try { d = await BO.listOrders(cur, a, to, page, 500, tt); } catch (e) { if (cur === "USDT" && e.kind === "api") break; throw e; }
        if (BX !== bx) return;
        const L = (d && d.list) || [], total = Number(d && d.total) || 0;
        if (page === 1) {
          pages = Math.max(1, Math.ceil(total / Math.max(1, L.length || 500)));
          if (cur === "VND" && total > Math.max(5000, ALL.length * 2 + 2000)) { await chrome.storage.local.remove(kind === "ok" ? "timeType_ok" : "timeType_upd"); throw new Error(`BO trả ${fmt(total)} đơn — sai mã mốc thời gian, tool đã bỏ mã này. Mở trang Tổng nạp nhanh trên BO, chọn "${BASIS[kind][0]}" rồi bấm Tìm kiếm một lần để tool học đúng mã`); }
        }
        for (const r of L) { const o = BO.norm(r, dk, D0x, cur); bx.map.set(o.no, o); }
        if (!bx.full && st.tab === "pend") $("pend-hint").textContent = `Đang đọc đơn theo ${LB_NAME[kind]} từ BO (${cur}): trang ${page}/${pages} · ${fmt(bx.map.size)} đơn…`;
        if (!L.length) break; page++;
      }
    }
    if (!bx.full || bx.from > from) { bx.from = from; }
    bx.to = Math.max(bx.to, to); bx.full = true;
  } catch (e) { bx.err = e.message || String(e); }
  finally { bx.busy = false; if (st.tab === "pend") render(); }
}
// danh sách đơn của khung đang chọn theo mốc thời gian; trả kèm trạng thái đọc BO
function basisBase() {
  const kind = st.lbasis, dk = VIEW || DAY, D0x = dayStartOf(dk), [a, b] = tfRange("list"), from = D0x + a, to = D0x + b;
  const key = kind + "|" + dk;
  if (BX.key !== key) BX = { key, map: new Map(), from: 0, to: 0, full: false, busy: false, err: "", prev: null };
  const covered = BX.full && BX.from <= from && BX.to >= Math.min(to, NOWS() + D0x - 60);
  if (BX.err && Date.now() - BX.errAt > 60e3) BX.err = "";
  if (!covered && !BX.busy && !BX.err) loadBX(kind, dk, from, to);
  else if (covered && !BX.busy && dk === DAY && to > BX.to + 25) loadBX(kind, dk, from, to);
  // đơn tạo tối hôm trước: đọc lại từ máy mỗi 2 phút (tool cập nhật tình trạng của chúng định kỳ)
  if (!BX.prevAt || Date.now() - BX.prevAt > 120e3) { BX.prevAt = Date.now(); const bx = BX; Store.dayOrders(dayKey(new Date((D0x - 43200) * 1000))).then((L) => { bx.prev = L; if (BX === bx && st.tab === "pend") render(); }).catch(() => {}); }
  // chưa đọc xong BO thì tạm dùng dữ liệu tool đã có (hôm nay + hôm trước)
  const src = covered ? [...BX.map.values()] : [...ALL, ...(BX.prev || []), ...BX.map.values()];
  const seen = new Map();
  for (const o0 of src) {
    const bt = btOf(o0, kind); if (!bt || bt < from || bt > to) continue;
    const o = { ...o0 }; o.h = hIdx(o); o.g = gIdx(o); o.t = (o.ts || bt) - D0x; o.bt = bt; seen.set(o.no, o);
  }
  return { list: [...seen.values()], exact: covered, busy: BX.busy, err: BX.err };
}

$("lbasis").value = st.lbasis;
$("lbasis").onchange = () => { st.lbasis = $("lbasis").value; st.page = 0; try { localStorage.setItem("lbasis", st.lbasis); } catch (e) {} render(); };
function renderPend() {
  $("pxlsTxt").textContent = "Tải Excel · " + OST.find((x) => x[0] === st.ostat)[1];
  const N = NOWS();
  const BB = st.lbasis === "create" ? null : basisBase();
  const base = (BB ? BB.list : inTf("list")).filter((o) => (st.pendH === -1 || o.h === st.pendH) && (st.pendG === -1 || o.g === st.pendG));
  const D0x = dayStartOf(VIEW || DAY), atTxt = (u) => { if (!u) return "—"; const d = u - D0x; return d >= 0 && d < 86400 ? clock(d) : new Date(u * 1000).toLocaleString("vi-VN", { hour12: false, day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" }); };
  const cnt = { pend: 0, ok: 0, err: 0, aband: 0, all: base.length }, amt = { pend: 0, ok: 0, err: 0, aband: 0, all: 0 };
  for (const o of base) { const k = stOf(o); cnt[k]++; amt[k] += o.amt; amt.all += o.amt; }
  $("ost").innerHTML = OST.map(([k, n, c]) => `<button class="stab ${c}" aria-pressed="${st.ostat === k}" data-v="${k}"><small>${n}</small><b>${fmt(cnt[k])}</b><span>${vnd(amt[k])} ₫</span></button>`).join("");
  $("ost").onclick = (e) => { const b = e.target.closest(".stab"); if (b) { st.ostat = b.dataset.v; st.page = 0; if (st.ostat !== "pend") st.pendMin = 0; render(); } };
  chips("pf", HOUSES, st.pendH, (v) => { st.pendH = v; st.page = 0; render(); }, true);
  chips("pg", GATES, st.pendG, (v) => { st.pendG = v; st.page = 0; render(); }, false);
  $("pwait").hidden = st.ostat !== "pend";
  const opts = [[0, "Tất cả"], [5, "> 5 phút"], [10, "> 10 phút"], [15, "> 15 phút"]];
  $("pseg").innerHTML = opts.map((o) => `<button aria-pressed="${st.pendMin === o[0]}" data-v="${o[0]}">${o[1]}</button>`).join("");
  $("pseg").onclick = (e) => { const b = e.target.closest("button"); if (b) { st.pendMin = +b.dataset.v; st.page = 0; render(); } };
  const q = st.q.trim().toLowerCase();
  const list = LIST = base.filter((o) => (st.ostat === "all" || stOf(o) === st.ostat) && (st.ostat !== "pend" || N - o.t >= st.pendMin * 60) && (!q || o.no.includes(q) || o.acc.toLowerCase().includes(q)));
  list.sort(st.ostat === "pend" ? (a, b) => a.t - b.t : (a, b) => b.t - a.t);
  { const K = [(o) => o.no, (o) => o.acc, (o) => o.nOk, hNm, gNm, (o) => o.ch, (o) => o.amt, (o) => o.ts || o.t]; if (st.lbasis === "upd") K.push((o) => o.bt);
    if (st.ostat === "pend") K.push((o) => N - o.t);
    else if (st.ostat === "ok") K.push((o) => o.t + o.sp, (o) => o.sp, (o) => o.fee, (o) => o.amt * o.fee / 100);
    else if (st.ostat === "all") K.push((o) => stOf(o), (o) => (o.st === 2 ? o.sp : null), (o) => o.why);
    else K.push((o) => stOf(o), (o) => o.why);
    const s2 = TSort.sort("pend-tbl", list, K); list.splice(0, list.length, ...s2); }
  const sum = list.reduce((x, o) => x + o.amt, 0);
  $("pend-h").textContent = OST.find((x) => x[0] === st.ostat)[1];
  $("pend-hint").textContent = tfLabel("list") + " · theo " + LB_NAME[st.lbasis] + (BB ? (BB.err ? " · ⚠ chưa đọc được BO: " + BB.err : BB.exact ? " · đúng số BO" : " · đang đọc BO, số tạm tính…") : "") + (st.ostat === "pend" ? " · chờ lâu nhất trên cùng" : " · mới nhất trên cùng");
  $("pend-sum").textContent = fmt(list.length) + " đơn · " + vnd(sum) + " ₫";
  const pages = Math.max(1, Math.ceil(list.length / PAGE)); st.page = Math.min(st.page, pages - 1);
  const rows = list.slice(st.page * PAGE, st.page * PAGE + PAGE);
  const tagOf = (o) => { const k = stOf(o); return k === "ok" ? '<span class="tag ok">Thành công</span>' : k === "err" ? `<span class="tag bad">${esc(o.psl || "Thất bại")}</span>` : k === "aband" ? `<span class="tag mut">${esc(o.st >= 4 ? o.psl || "Hết hạn" : "Chờ quá 30 phút")}</span>` : '<span class="tag warn">Đang chờ</span>'; };
  let t = `<thead><tr><th class="l">Số lệnh</th><th class="l">Tài khoản</th><th title="Số lần nạp thành công / tổng số lần nạp của khách (theo BO)">Số lần nạp</th><th class="l">Nhà</th><th class="l">Cổng</th><th class="l">Kênh</th><th>Số tiền</th><th>Tạo lúc</th>${st.lbasis === "upd" ? "<th>Cập nhật lúc</th>" : ""}`;
  if (st.ostat === "pend") t += `<th>Đã chờ</th>`;
  else if (st.ostat === "ok") t += `<th>Thành công lúc</th><th>Lên điểm sau</th><th>Phí %</th><th>Phí (₫)</th>`;
  else if (st.ostat === "all") t += `<th class="l">Tình trạng</th><th>Lên điểm sau</th><th class="l">Lý do (BO)</th>`;
  else t += `<th class="l">Tình trạng</th><th class="l">Lý do (BO)</th>`;
  t += `</tr></thead><tbody>`;
  for (const o of rows) {
    const age = N - o.t;
    t += `<tr><td class="l">${esc(o.no)}</td><td class="name" style="font-weight:500">${esc(o.acc)}${FAKESET.has(o.acc) ? ' <span class="pill badp">Lệnh ảo</span>' : ""}</td><td>${nTxt(o)}</td><td class="name">${esc(hNm(o))}</td><td class="l">${esc(gNm(o))}</td><td class="l mut">${esc(o.ch)}</td><td>${o.cur === "VND" ? vnd(o.amt) + " ₫" : fmt(o.raw) + " " + o.cur}</td><td>${atTxt(o.ts || D0x + o.t)}</td>${st.lbasis === "upd" ? `<td>${atTxt(o.bt)}</td>` : ""}`;
    if (st.ostat === "pend") t += `<td class="${age > 600 ? "bad" : age > 300 ? "warn" : "mut"}">${mmss(age)}</td>`;
    else if (st.ostat === "ok") t += `<td>${atTxt(o.nt || (o.ts || D0x + o.t) + o.sp)}</td><td class="${o.sp > 600 ? "bad" : o.sp > 180 ? "warn" : "ok"}">${mmss(o.sp)}</td><td>${o.fee}%</td><td>${vnd(o.amt * o.fee / 100)}</td>`;
    else if (st.ostat === "all") t += `<td class="l">${tagOf(o)}</td><td class="${o.st === 2 ? (o.sp > 600 ? "bad" : o.sp > 180 ? "warn" : "ok") : "mut"}">${o.st === 2 ? mmss(o.sp) : "—"}</td><td class="l mut why">${esc(o.why || "")}</td>`;
    else t += `<td class="l">${tagOf(o)}</td><td class="l why">${esc(o.why || "")}</td>`;
    t += `</tr>`;
  }
  if (!rows.length) t += `<tr><td class="l mut" colspan="12">Không có đơn nào khớp bộ lọc</td></tr>`;
  $("pend-tbl").innerHTML = t + "</tbody>";
  let rs = "";
  if (st.ostat === "err" && list.length) {
    const m = {}; for (const o of list) { const k = (o.why || "Không ghi lý do").replace(/[\d.]+/g, (x) => x); (m[k] ??= { n: 0, hs: new Set() }).n++; m[k].hs.add(HOUSES[o.h].n + " · " + GATES[o.g].n); }
    rs = `<div class="reasons"><b>Lý do lỗi theo BO:</b>` + Object.entries(m).sort((x, y) => y[1].n - x[1].n).slice(0, 8).map(([k, v]) => `<div><span class="pill badp">${fmt(v.n)} đơn</span> <span class="why">${esc(k)}</span> <small class="mut">${esc([...v.hs].slice(0, 4).join(", "))}</small></div>`).join("") + `</div>`;
  }
  $("pend-reasons").innerHTML = rs; $("pend-reasons").hidden = !rs;
  $("pager").innerHTML = `<button id="pg-prev" ${st.page ? "" : "disabled"}>‹ Trước</button><span>Trang <b class="mono">${st.page + 1}</b> / ${pages} · ${PAGE} đơn mỗi trang</span><button id="pg-next" ${st.page < pages - 1 ? "" : "disabled"}>Sau ›</button>`;
  $("pg-prev").onclick = () => { st.page--; render(); }; $("pg-next").onclick = () => { st.page++; render(); };
}
function pendBadge() { const N = NOWS(), S = STALE(); $("cnt-pend").textContent = orders.filter((o) => o.st === 1 && N - o.t > S && N - o.t <= ABANDON).length; }

// ===== PHÍ TRONG THÁNG (bot tự ghi lịch sử channelRate) =====
let FEEH = {};   // "merch|gate|kênh" -> {ngày: {r, ts}} (phí của đơn mới nhất trong ngày)
let feeDirty = false;
function noteFee(o) {
  const k = o.merch + "|" + o.gate + "|" + (o.ch || "");
  const m = (FEEH[k] ??= {});
  const e = m[o.day];
  if (!e || o.ts >= e.ts) { if (!e || e.r !== o.fee || e.ts !== o.ts) { m[o.day] = { r: o.fee, ts: o.ts }; feeDirty = true; } }
}
// chuyển thành danh sách các lần phí khác ngày trước
function feeArr(k) {
  const m = FEEH[k] || {}; const out = [];
  for (const d of Object.keys(m).sort()) { const r = m[d].r; if (!out.length || out[out.length - 1].r !== r) out.push({ day: d, r }); }
  return out;
}
async function saveFee() { if (feeDirty) { feeDirty = false; await Store.kvSet("feeHist", FEEH); } }
// ---- tính tiền phí theo cách của sổ: tự động · thẻ cào (công ty chịu) · USDT nhập · thủ công ----
const isCard = (o) => (nk(o.gate) || "").includes("thecao");
const okAt = (o) => (o.st === 2 ? o.nt || o.ts + (o.sp || 0) : 0);
// % phí khi BO ghi 0% (vd U2Pay2 - USDT, BB168Pay): 1) bạn tự đặt · 2) phí của kênh cùng nhà trong Cài đặt cổng · 3) phí đơn gần nhất cùng nhà
let FEEOV = {};   // tên nhà -> % phí tự đặt (lưu kv "feeOv")
const FEEOV_DEF = { "U2Pay2 - USDT": 0.35, "RCPay(USDT)": 0.4 };   // theo sổ của nhà: U2Pay nhập 0,35% (xuất 1 USDT / lệnh) · RCPay nhập 0,4% (thành công + thành công thủ công)
function rateOf(merch, gate, ch, r0) {
  const r = Number(r0) || 0; if (r > 0) return r;
  const ov = FEEOV[merch] ?? FEEOV_DEF[merch]; if (ov != null && ov !== "") return Number(ov) || 0;
  const c = (PSET || []).filter((c) => c.merch === merch && Number(c.fee) > 0); if (c.length) { const g = c.find((c) => c.desc === ch || c.gk === nk(gate)) || c[0]; return Number(g.fee); }
  let best = null; for (const k in FEEH) { if (k.split("|")[0] !== merch) continue; for (const d in FEEH[k]) { const e = FEEH[k][d]; if (Number(e.r) > 0 && (!best || e.ts > best.ts)) best = e; } }
  return best ? Number(best.r) : 0;
}
// phí XUẤT: chỉ nhà USDT thu, mỗi lệnh rút thành công 1 USDT (lệnh lỗi được nhà hoàn cả phí) → đọc lệnh rút đã lưu của trang Giám sát xuất
let FEEOUT = {};   // tên nhà -> USDT / lệnh rút (lưu kv "feeOut")
const outDef = (m) => (/^(u2pay|rcpay)/.test(hkey(m)) ? 1 : 0);
const outOf = (m) => { const v = FEEOUT[m]; return v != null && v !== "" ? Number(v) || 0 : outDef(m); };
// tên nhà bên xuất (vd "U2Pay2") → tên nhà bên nạp (vd "U2Pay2 - USDT") để gộp chung 1 dòng
function depName(wm) {
  const k = hkey(wm), names = new Set([...(PSET || []).map((c) => c.merch), ...HOUSES.map((h) => h.n), ...Object.keys(FEEOV_DEF), ...Object.keys(FEEH).map((x) => x.split("|")[0])]);
  for (const n of names) if (n && hkey(n) === k) return n;
  return wm;
}
const WDC = {};
async function wdFees(dk) {
  const ck = WDC[dk]; if (ck && Date.now() - ck.at < (dk === DAY ? 60e3 : 600e3)) return ck.R;
  const d0 = dayStartOf(dk), d1 = d0 + 86400, R = { n: 0, usdt: 0, fee: 0, h: {}, est: false };
  let L = []; try { L = [...(await StoreX.dayOrders(dk).catch(() => [])), ...(await StoreX.dayOrders(prevDay(dk)).catch(() => []))]; } catch (e) {}
  const seen = new Set(), xs = [];
  for (const o of L) if (o.usd > 0 && o.amt > 0) xs.push(o.amt / o.usd);
  for (const o of ORD.values()) if (o.xr > 1000) xs.push(o.xr);
  xs.sort((a, b) => a - b); let xr = xs.length ? xs[xs.length >> 1] : 0;
  if (xr > 1000) Store.kvSet("usdtRate", xr).catch(() => {}); else { xr = Number(await Store.kvGet("usdtRate").catch(() => 0)) || 26000; R.est = true; }
  R.xr = xr;
  for (const o of L) {
    if (seen.has(o.no) || !(o.st === 4 || o.st === 8) || !o.merch) continue; const t = o.ft || o.at; if (t < d0 || t >= d1) continue; seen.add(o.no);
    const m = depName(o.merch), u = outOf(m); if (!u) continue;
    const h = (R.h[m] ??= { n: 0, usdt: 0, fee: 0, amt: 0, wm: o.merch, u }); h.n++; h.usdt += u; h.fee += u * xr; h.amt += o.amt || 0;
    R.n++; R.usdt += u; R.fee += u * xr;
  }
  WDC[dk] = { at: Date.now(), R };
  return R;
}
function feeOf(o) {
  const r = rateOf(o.merch, o.gate, o.ch, o.fee);
  if (o.cur && o.cur !== "VND") { const fu = (Number(o.raw) || 0) * r / 100; return { kind: "usdt", fee: o.xr > 1000 ? fu * o.xr : 0, fu, usdt: Number(o.raw) || 0, vnd: o.xr > 1000 ? (Number(o.raw) || 0) * o.xr : 0, xr: o.xr }; }
  const got = (o.amt || 0) * 1000;
  // nhà USDT nhưng BO ghi đơn bằng VND (RCPay(USDT), U2Pay2 - USDT): vẫn xếp vào USDT nhập, phí = tiền VND × % phí
  if (/usdt/i.test(o.merch) || /usdt/i.test(o.gate)) { const xr = o.xr > 1000 ? o.xr : 0, fee = got * r / 100; return { kind: "usdt", fee, fu: xr ? fee / xr : 0, usdt: xr ? got / xr : 0, vnd: got, xr }; }
  if (isCard(o)) {
    let face = (Number(o.orig) || 0) * 1000; if (!face || face <= got) face = Math.round(got / 0.9);
    const hf = face * r / 100, cust = Math.max(0, face - got);
    return { kind: "card", face, got, hf, cust, fee: hf - cust };
  }
  return { kind: "auto", fee: got * r / 100, got };
}
// tổng hợp 1 ngày (tính theo giờ thành công)
function feeDayAgg(list, manual, dk) {
  const d0 = dayStartOf(dk), d1 = d0 + 86400, A = { auto: 0, autoN: 0, autoAmt: 0, card: 0, cardN: 0, usdt: 0, usdtN: 0, man: 0, manN: 0, h: {}, cardH: {}, usdtH: {} };
  const H = (m) => (A.h[m] ??= { auto: 0, card: 0, usdt: 0, man: 0, out: 0 });
  const seen = new Set();
  for (const o of list) {
    if (o.st !== 2 || seen.has(o.no)) continue; const t = okAt(o); if (t < d0 || t >= d1) continue; seen.add(o.no);
    const f = feeOf(o), m = o.merch;
    if (f.kind === "auto") { A.auto += f.fee; A.autoN++; A.autoAmt += f.got; H(m).auto += f.fee; }
    else if (f.kind === "card") { A.card += f.fee; A.cardN++; H(m).card += f.fee; const k = m + "|" + (o.ch || ""); const c = (A.cardH[k] ??= { n: 0, face: 0, got: 0, hf: 0, cust: 0, r: o.fee }); c.n++; c.face += f.face; c.got += f.got; c.hf += f.hf; c.cust += f.cust; c.r = o.fee; }
    else { A.usdt += f.fee; A.usdtN++; H(m).usdt += f.fee; const u = (A.usdtH[m] ??= { n: 0, usdt: 0, fu: 0, vnd: 0, fee: 0, r: o.fee }); u.n++; u.usdt += f.usdt; u.fu += f.fu; u.vnd += f.vnd; u.fee += f.fee; u.r = rateOf(o.merch, o.gate, o.ch, o.fee); }
  }
  for (const x of manual || []) { const fee = (x.amt || 0) * 1000 * rateOf(x.merch, x.gate, x.ch, x.fee) / 100; A.man += fee; A.manN++; H(x.merch || "?").man += fee; }
  A.out = 0; A.outN = 0; A.outU = 0; A.outH = {};
  A.total = A.auto + A.card + A.usdt + A.man;
  return A;
}
const FZ = { sub: "all", mode: "d", day: null, agg: {}, lists: {}, busy: false, pickRate: null };
try { const v = localStorage.getItem("fzSub"); if (v) FZ.sub = v; } catch (e) {}
const dayList = (dk) => { const [y, m] = dk.slice(0, 7).split("-").map(Number); const n = new Date(y, m, 0).getDate(); return Array.from({ length: n }, (_, i) => `${dk.slice(0, 7)}-${pad(i + 1)}`); };
const prevDay = (dk) => dayKey(new Date((dayStartOf(dk) - 43200) * 1000));
async function ordersOfDay(dk) {
  if (dk === DAY) return [...ORD.values()];
  if (dk === VIEW) return [...VORD.values()];
  if (FZ.lists[dk]) return FZ.lists[dk];
  const L = await Store.dayOrders(dk).catch(() => []); for (const o of L) if (o.st == null || o.ps != null) o.st = BO.stCode(Number(o.ps), o.psl);
  FZ.lists[dk] = L; const ks = Object.keys(FZ.lists); if (ks.length > 3) delete FZ.lists[ks[0]];
  return L;
}
async function aggOf(dk, force) {
  if (!force && dk !== DAY && FZ.agg[dk]) return FZ.agg[dk];
  if (!force && dk !== DAY) { const c = await Store.kvGet("feeAgg:" + dk).catch(() => null); if (c && c.v === 4) { FZ.agg[dk] = c; return c; } }
  const info = dk === DAY ? { complete: true } : await Store.getDay(dk).catch(() => null);
  const cur = await ordersOfDay(dk); if (!cur.length && dk !== DAY) return null;
  const prev = await ordersOfDay(prevDay(dk));
  const man = (await Store.kvGet("feeMan:" + dk).catch(() => null)) || [];
  const A = feeDayAgg([...cur, ...prev], man, dk); A.v = 4;
  const W = await wdFees(dk); A.wdOk = dk < DAY && !!((await StoreX.getDay(dk).catch(() => null)) || {}).complete; A.out = W.fee; A.outN = W.n; A.outU = W.usdt; A.outH = W.h; A.outXr = W.xr; A.outEst = W.est;
  for (const m in W.h) { (A.h[m] ??= { auto: 0, card: 0, usdt: 0, man: 0, out: 0 }).out = W.h[m].fee; } A.total += A.out;
  FZ.agg[dk] = A;
  if (dk < DAY && info && info.complete) Store.kvSet("feeAgg:" + dk, A).catch(() => {});
  return A;
}
const fzM = (v) => (v >= 1e9 ? (v / 1e9).toLocaleString("vi-VN", { maximumFractionDigits: 2 }) + " tỷ" : v >= 1e6 ? (v / 1e6).toLocaleString("vi-VN", { maximumFractionDigits: v >= 1e8 ? 0 : 1 }) + " tr" : v >= 1000 ? Math.round(v / 1000) + "k" : v ? fmt(v) : "—");
const fzV = (v) => fmt(Math.round(v || 0));
const fzHc = (m) => `class="l fzh" style="--hc:${hColor(m)}"`;
function renderFee() {
  // tháng & ngày
  const FA = {}; for (const k in FEEH) FA[k] = feeArr(k);
  const months = new Set([DAY.slice(0, 7)]); for (const k in FA) for (const e of FA[k]) months.add(e.day.slice(0, 7));
  const ml = [...months].sort().reverse();
  if (!st.feeMon || !months.has(st.feeMon)) st.feeMon = (VIEW || DAY).slice(0, 7);
  $("fmon").innerHTML = ml.map((m) => `<button aria-pressed="${m === st.feeMon}" data-v="${m}">${m.slice(5)}/${m.slice(0, 4)}</button>`).join("");
  $("fmon").onclick = (e) => { const b = e.target.closest("button"); if (b) { st.feeMon = b.dataset.v; FZ.day = null; render(); } };
  const days = dayList(st.feeMon + "-01").filter((d) => d <= DAY);
  if (!FZ.day || !FZ.day.startsWith(st.feeMon) || FZ.day > DAY) FZ.day = days.includes(VIEW || DAY) ? VIEW || DAY : days[days.length - 1];
  $("fday").innerHTML = days.slice().reverse().map((d) => `<option value="${d}" ${d === FZ.day ? "selected" : ""}>${d.slice(8)}/${d.slice(5, 7)}${d === DAY ? " (hôm nay)" : ""}</option>`).join("");
  $("fday").onchange = () => { FZ.day = $("fday").value; render(); };
  // nhà
  const hs = new Set(); for (const k in FEEH) hs.add(k.split("|")[0]); HOUSES.forEach((h) => hs.add(h.n));
  const merchs = [...hs].sort((a, b) => a.localeCompare(b));
  if (st.feeH >= merchs.length) st.feeH = -1;
  const FH = merchs.map((n) => ({ n }));
  chips("ff", FH, st.feeH, (v) => { st.feeH = v; render(); }, false);
  document.querySelectorAll("#ff .chip").forEach((b) => { const i = +b.dataset.v; if (i >= 0) b.style.cssText = `--c:${hColor(merchs[i])};border-color:color-mix(in srgb,var(--c) 45%,var(--line));color:${b.getAttribute("aria-pressed") === "true" ? "#fff" : "var(--c)"};background:${b.getAttribute("aria-pressed") === "true" ? "var(--c)" : "color-mix(in srgb,var(--c) 8%,var(--panel))"}`; });
  const selH = st.feeH === -1 ? null : merchs[st.feeH];
  // mục con
  document.querySelectorAll("#fsub button").forEach((b) => b.classList.toggle("on", b.dataset.s === FZ.sub));
  document.querySelectorAll("#p-fee [data-fp]").forEach((p) => (p.hidden = p.dataset.fp !== FZ.sub));
  if (FZ.sub === "rate") return renderFeeRate(FA, selH);
  fzRenderData(days, selH);
}
async function fzRenderData(days, selH) {
  if (FZ.busy) return; FZ.busy = true;
  try {
    const dk = FZ.day, A = await aggOf(dk);
    const keep = (m) => !selH || m === selH;
    if (FZ.sub === "all") {
      const sumH = (k) => { let v = 0; if (!A) return 0; for (const m in A.h) if (keep(m)) v += A.h[m][k]; return v; };
      const auto = sumH("auto"), card = sumH("card"), usdt = sumH("usdt"), man = sumH("man"), out = A ? Object.entries(A.h).reduce((s, [m, h]) => s + (keep(m) ? h.out || 0 : 0), 0) : 0, tot = auto + card + usdt + man + out;
      $("fbrkH").textContent = "Tổng tiền phí · " + dk.slice(8) + "/" + dk.slice(5, 7) + "/" + dk.slice(0, 4) + (selH ? " · " + selH : "");
      $("fbrk").innerHTML = !A ? `<div class="empty" style="grid-column:1/-1;padding:16px">Máy chưa lưu đơn của ngày này. Chọn ngày ở ô Ngày trên thanh trên cùng để tool đọc từ BO.</div>` :
        `<div class="fz-bk" style="--k:#2563eb"><small>Nhập tự động</small><b>${fzV(auto)}</b><span>${selH ? "" : fmt(A.autoN) + " đơn · " + fzV(A.autoAmt) + " ₫ · TB " + (A.autoAmt ? (A.auto / A.autoAmt * 100).toFixed(2) : 0) + "%"}</span></div>
         <div class="fz-bk" style="--k:#ea580c"><small>Thẻ cào · công ty chịu</small><b>${fzV(card)}</b><span>${fmt(Object.entries(A.cardH).filter(([k]) => keep(k.split("|")[0])).reduce((s, [, c]) => s + c.n, 0))} đơn · phí nhà − thu khách 10%</span></div>
         <div class="fz-bk" style="--k:#26a17b"><small>USDT nhập</small><b>${fzV(usdt)}</b><span>${Object.entries(A.usdtH).filter(([m]) => keep(m)).map(([m, u]) => esc(m) + " " + fzV(u.fee)).join(" · ") || "—"}</span></div>
         <div class="fz-bk" style="--k:#0f766e"><small>Phí xuất USDT</small><b>${fzV(out)}</b><span>${fmt(Object.entries(A.outH || {}).filter(([m]) => keep(m)).reduce((s, [, h]) => s + h.n, 0))} lệnh rút × 1 USDT · tỷ giá ${fmt(Math.round(A.outXr || 0))}${A.outEst ? " (ước tính)" : ""}</span></div>
         <div class="fz-bk" style="--k:#7c3aed"><small>Thủ công</small><b>${fzV(man)}</b><span>${fmt(A.manN)} đơn · gồm đơn callback trễ tool tự lấy và số lệnh bạn dán</span></div>
         <div class="fz-bk tot"><small>Tổng tiền phí</small><b>${fzV(tot)} ₫</b><span id="fbrkMon2">đang tính cả tháng…</span></div>`;
      // tiền phí mỗi nhà
      $("fmode").innerHTML = `<button aria-pressed="${FZ.mode === "d"}" data-v="d">Theo ngày</button><button aria-pressed="${FZ.mode === "m"}" data-v="m">Theo tháng</button>`;
      if (FZ.mode === "d") {
        const aggs = [];
        for (const d of days) { aggs.push(await aggOf(d)); if (st.tab !== "fee" || FZ.sub !== "all") return; }
        const ms = new Set(); aggs.forEach((a) => a && Object.keys(a.h).forEach((m) => keep(m) && ms.add(m)));
        const ML = [...ms].sort((a, b) => aggs.reduce((s, x) => s + (x && x.h[b] ? hT(x.h[b]) : 0), 0) - aggs.reduce((s, x) => s + (x && x.h[a] ? hT(x.h[a]) : 0), 0));
        const mx = Math.max(1, ...ML.flatMap((m) => aggs.map((x) => (x && x.h[m] ? hT(x.h[m]) : 0))));
        const nd = aggs.filter(Boolean).length;
        let t = `<thead><tr><th class="l">Nhà</th>${days.map((d) => `<th class="${d === dk ? "tot" : ""}" style="cursor:pointer" data-fd="${d}">${d.slice(8)}/${d.slice(5, 7)}</th>`).join("")}<th class="tot">Cả tháng</th><th class="tot">TB / ngày</th></tr></thead><tbody>`;
        for (const m of ML) { const v = aggs.map((x) => (x ? (x.h[m] ? hT(x.h[m]) : 0) : null)), s = v.reduce((a, b) => a + (b || 0), 0); t += `<tr><td ${fzHc(m)}><span class="hn">${esc(m)}</span></td>${v.map((x) => `<td class="heat">${x == null ? '<span class="mut">·</span>' : `<span style="background:rgba(226,54,74,${(x / mx * 0.3).toFixed(2)})" title="${fzV(x)} ₫">${fzM(x)}</span>`}</td>`).join("")}<td class="tot">${fzM(s)}</td><td class="tot">${fzM(nd ? s / nd : 0)}</td></tr>`; }
        const col = aggs.map((x) => (x ? ML.reduce((s, m) => s + (x.h[m] ? hT(x.h[m]) : 0), 0) : null)), S = col.reduce((a, b) => a + (b || 0), 0);
        t += `<tr class="sum"><td class="l">Tổng</td>${col.map((x) => `<td>${x == null ? "·" : fzM(x)}</td>`).join("")}<td class="tot">${fzM(S)}</td><td class="tot">${fzM(nd ? S / nd : 0)}</td></tr>`;
        if (!ML.length) t += `<tr><td class="l mut" colspan="${days.length + 3}">Chưa có dữ liệu phí trong tháng này.</td></tr>`;
        $("fhouse").innerHTML = t + "</tbody>";
        $("fhouseH").textContent = `Tháng ${st.feeMon.slice(5)}/${st.feeMon.slice(0, 4)} · mỗi ô = tiền phí nhà trả trong ngày (đậm = cao) · bấm ngày để xem tổng ngày đó · "·" = máy chưa lưu ngày đó`;
        const e2 = document.getElementById("fbrkMon2"); if (e2) e2.textContent = `tháng ${st.feeMon.slice(5)}: ${fzM(S)} · ${nd} ngày có dữ liệu`;
      } else {
        const MON = []; { let [y, m] = st.feeMon.split("-").map(Number); for (let i = 0; i < 6; i++) { MON.unshift(`${y}-${pad(m)}`); m--; if (!m) { m = 12; y--; } } }
        const per = {}; const amtM = {};
        for (const mo of MON) {
          per[mo] = {}; amtM[mo] = { fee: 0, amt: 0, n: 0 };
          for (const d of dayList(mo + "-01")) { if (d > DAY) break; const x = d === DAY || d === VIEW ? await aggOf(d) : FZ.agg[d] || (await Store.kvGet("feeAgg:" + d).catch(() => null)); if (!x) continue; amtM[mo].n++; amtM[mo].amt += x.autoAmt || 0; amtM[mo].fee += x.auto || 0; for (const m in x.h) if (keep(m)) per[mo][m] = (per[mo][m] || 0) + hT(x.h[m]); }
          if (st.tab !== "fee") return;
        }
        const ms = new Set(); MON.forEach((mo) => Object.keys(per[mo]).forEach((m) => ms.add(m)));
        const ML = [...ms].sort((a, b) => (per[MON[5]][b] || 0) - (per[MON[5]][a] || 0));
        const mx = Math.max(1, ...ML.flatMap((m) => MON.map((mo) => per[mo][m] || 0)));
        const cur = MON[5], nCur = amtM[cur].n, est = (v) => (nCur ? v / nCur * dayList(cur + "-01").length : v);
        let t = `<thead><tr><th class="l">Nhà</th>${MON.map((m) => `<th>${m.slice(5)}/${m.slice(0, 4)}</th>`).join("")}<th class="tot">So tháng trước</th></tr></thead><tbody>`;
        for (const m of ML) { const v = MON.map((mo) => per[mo][m] || 0), d = est(v[5]) - v[4]; t += `<tr><td ${fzHc(m)}><span class="hn">${esc(m)}</span></td>${v.map((x) => `<td class="heat"><span style="background:rgba(226,54,74,${(x / mx * 0.3).toFixed(2)})">${fzM(x)}</span></td>`).join("")}<td class="tot ${v[4] ? (d > 0 ? "up" : "down") : "mut"}">${v[4] ? (d > 0 ? "▲ " : "▼ ") + fzM(Math.abs(d)) : "—"}<br><small class="mut">ước cả tháng</small></td></tr>`; }
        t += `<tr class="sum"><td class="l">Tổng</td>${MON.map((mo) => `<td>${fzM(ML.reduce((s, m) => s + (per[mo][m] || 0), 0))}<br><small class="mut">${amtM[mo].amt ? "TB " + (amtM[mo].fee / amtM[mo].amt * 100).toFixed(2) + "% · " + amtM[mo].n + " ngày" : "chưa có"}</small></td>`).join("")}<td class="tot"></td></tr>`;
        $("fhouse").innerHTML = t + "</tbody>";
        $("fhouseH").textContent = "6 tháng gần nhất · tiền phí từng nhà · dòng Tổng kèm tỷ lệ phí TB của đơn tự động · chỉ tính những ngày máy đã lưu";
        const e2 = document.getElementById("fbrkMon2"); if (e2) e2.textContent = `tháng ${cur.slice(5)}: ${fzM(ML.reduce((s, m) => s + (per[cur][m] || 0), 0))}`;
      }
    } else if (FZ.sub === "card") {
      const rows = A ? Object.entries(A.cardH).filter(([k]) => keep(k.split("|")[0])).sort((a, b) => b[1].fee - a[1].fee || b[1].n - a[1].n) : [];
      const T = rows.reduce((s, [, c]) => ({ n: s.n + c.n, face: s.face + c.face, got: s.got + c.got, hf: s.hf + c.hf, cust: s.cust + c.cust }), { n: 0, face: 0, got: 0, hf: 0, cust: 0 });
      $("fcardK").innerHTML = [["Đơn thẻ cào", fmt(T.n), "thành công trong ngày", "#2563eb"], ["Tổng mệnh giá", fzV(T.face), "khách được cộng " + fzV(T.got), "#0891b2"], ["Phí nhà thứ 3", fzV(T.hf), "TB " + (T.face ? (T.hf / T.face * 100).toFixed(1) : 0) + "% mệnh giá", "#ea580c"], ["Thu khách 10%", fzV(T.cust), "trừ vào số khách được cộng", "#16a34a"], ["Công ty chịu", fzV(T.hf - T.cust), "= phí nhà − thu khách", "#e2364a"]]
        .map(([a, b, c, k]) => `<div class="fz-k" style="--k:${k}"><small>${a}</small><b>${b}</b><span>${c}</span></div>`).join("");
      $("fcardH").innerHTML = `<thead><tr><th class="l">Nhà · kênh</th><th>Đơn</th><th>Mệnh giá thẻ</th><th>Khách được cộng</th><th>% nhà</th><th>Phí nhà thứ 3</th><th>Thu khách 10%</th><th>Công ty chịu</th></tr></thead><tbody>` +
        rows.map(([k, c]) => { const [m, ch] = k.split("|"); return `<tr><td ${fzHc(m)}><span class="hn">${esc(m)}</span> <small class="mut">${esc(ch)}</small></td><td>${fmt(c.n)}</td><td>${fzV(c.face)}</td><td>${fzV(c.got)}</td><td>${c.r}%</td><td>${fzV(c.hf)}</td><td>${fzV(c.cust)}</td><td class="up"><b>${fzV(c.hf - c.cust)}</b></td></tr>`; }).join("") +
        `<tr class="sum"><td class="l">Tổng</td><td>${fmt(T.n)}</td><td>${fzV(T.face)}</td><td>${fzV(T.got)}</td><td></td><td>${fzV(T.hf)}</td><td>${fzV(T.cust)}</td><td class="up">${fzV(T.hf - T.cust)}</td></tr></tbody>`;
      const L = await fzCardList(dk, keep);
      FZ.cardL = L;
      $("fcardLH").textContent = `Tất cả đơn thẻ cào · ${dk.slice(8)}/${dk.slice(5, 7)}/${dk.slice(0, 4)}`;
      const q = ($("fcardQ").value || "").trim().toLowerCase(), LL = q ? L.filter((x) => x.o.no.includes(q) || String(x.o.acc).toLowerCase().includes(q)) : L;
      $("fcardL").innerHTML = `<thead><tr><th class="l">Mã đơn hàng</th><th class="l">Hội viên</th><th>Thời gian</th><th class="l">Nhà · kênh</th><th>Mệnh giá thẻ</th><th>Khách được cộng</th><th>% nhà</th><th>Phí nhà thứ 3</th><th>Thu khách</th><th>Công ty chịu</th></tr></thead><tbody>` +
        LL.slice(0, 1500).map(({ o, f }) => `<tr><td class="l mono">${esc(o.no)}</td><td class="l">${esc(o.acc)}</td><td>${new Date(okAt(o) * 1000).toLocaleTimeString("vi-VN", { hour12: false })}</td><td ${fzHc(o.merch)}><span class="hn">${esc(o.merch)}</span> <small class="mut">${esc(o.ch)}</small></td><td>${fzV(f.face)}</td><td>${fzV(f.got)}</td><td>${rateOf(o.merch, o.gate, o.ch, o.fee)}%</td><td>${fzV(f.hf)}</td><td>${fzV(f.cust)}</td><td class="up"><b>${fzV(f.fee)}</b></td></tr>`).join("") +
        (LL.length ? "" : `<tr><td class="l mut" colspan="10">Không có đơn thẻ cào.</td></tr>`) + "</tbody>";
    } else if (FZ.sub === "usdt") {
      const rows = A ? Object.entries(A.usdtH).filter(([m]) => keep(m)) : [];
      const T = rows.reduce((s, [, u]) => ({ n: s.n + u.n, usdt: s.usdt + u.usdt, fu: s.fu + u.fu, vnd: s.vnd + u.vnd, fee: s.fee + u.fee }), { n: 0, usdt: 0, fu: 0, vnd: 0, fee: 0 });
      const u4 = (v) => Number(v || 0).toLocaleString("vi-VN", { maximumFractionDigits: 4 });
      $("fusdtH").innerHTML = `<thead><tr><th class="l">Nhà</th><th>Đơn</th><th>Nhận USDT</th><th>% phí</th><th>Phí USDT</th><th>Nhận VND</th><th>Phí VND</th></tr></thead><tbody>` + rows.map(([m, u]) => `<tr><td ${fzHc(m)}><span class="hn">${esc(m)}</span></td><td>${fmt(u.n)}</td><td>${u.usdt ? u4(u.usdt) : '<span class="mut" title="BO ghi đơn bằng VND, không có tỷ giá">—</span>'}</td><td>${u.r}%</td><td>${u.fu ? u4(u.fu) : '<span class="mut">—</span>'}</td><td>${fzV(u.vnd)}</td><td><b>${fzV(u.fee)}</b></td></tr>`).join("") +
        `<tr class="sum"><td class="l">Tổng</td><td>${fmt(T.n)}</td><td>${u4(T.usdt)}</td><td></td><td>${u4(T.fu)}</td><td>${fzV(T.vnd)}</td><td>${fzV(T.fee)}</td></tr></tbody>`;
      const OR = A ? Object.entries(A.outH || {}).filter(([m]) => keep(m)) : [], OT = OR.reduce((s, [, h]) => ({ n: s.n + h.n, u: s.u + h.usdt, a: s.a + h.amt, f: s.f + h.fee }), { n: 0, u: 0, a: 0, f: 0 });
      $("fusdtO").innerHTML = `<thead><tr><th class="l">Nhà</th><th>Lệnh rút thành công</th><th>Tiền rút (₫)</th><th>Phí / lệnh</th><th>Phí USDT</th><th>Tỷ giá</th><th>Phí VND</th></tr></thead><tbody>` + (OR.map(([m, h]) => `<tr><td ${fzHc(m)}><span class="hn">${esc(m)}</span>${h.wm !== m ? ` <small class="mut">(bên xuất: ${esc(h.wm)})</small>` : ""}</td><td>${fmt(h.n)}</td><td>${fzV(h.amt)}</td><td>${h.u} USDT</td><td>${u4(h.usdt)}</td><td>${fmt(Math.round(A.outXr || 0))}${A.outEst ? " *" : ""}</td><td><b>${fzV(h.fee)}</b></td></tr>`).join("") || `<tr><td class="l mut" colspan="7">Không có lệnh rút qua nhà USDT trong ngày (hoặc máy chưa mở trang Giám sát xuất ngày này).</td></tr>`) +
        `<tr class="sum"><td class="l">Tổng</td><td>${fmt(OT.n)}</td><td>${fzV(OT.a)}</td><td></td><td>${u4(OT.u)}</td><td></td><td>${fzV(OT.f)}</td></tr></tbody>`;
      const d0 = dayStartOf(dk), all = [...(await ordersOfDay(dk)), ...(await ordersOfDay(prevDay(dk)))];
      const L = all.filter((o) => o.st === 2 && feeOf(o).kind === "usdt" && keep(o.merch) && okAt(o) >= d0 && okAt(o) < d0 + 86400);
      const seen = new Set();
      $("fusdtL").innerHTML = `<thead><tr><th class="l">Nhà</th><th class="l">Mã đơn hàng</th><th>Tỷ giá</th><th>Nhận USDT</th><th>Phí USDT</th><th>Nhận VND</th><th>Phí VND</th></tr></thead><tbody>` +
        L.filter((o) => !seen.has(o.no) && seen.add(o.no)).map((o) => { const f = feeOf(o); return `<tr><td ${fzHc(o.merch)}><span class="hn">${esc(o.merch)}</span></td><td class="l mono">${esc(o.no)}</td><td>${o.xr > 1000 ? fmt(o.xr) : '<span class="mut">—</span>'}</td><td>${f.usdt ? u4(f.usdt) : '<span class="mut">—</span>'}</td><td>${f.fu ? u4(f.fu) : '<span class="mut">—</span>'}</td><td>${fzV(f.vnd)}</td><td>${fzV(f.fee)}</td></tr>`; }).join("") + (L.length ? "" : `<tr><td class="l mut" colspan="7">Không có đơn USDT nhập.</td></tr>`) + "</tbody>";
    } else if (FZ.sub === "man") await fzRenderMan(dk, keep);
  } catch (e) { sysmsg("Không tính được tiền phí: " + esc(e.message), "err"); }
  finally { FZ.busy = false; }
}
const hT = (x) => x.auto + x.card + x.usdt + x.man + (x.out || 0);
async function fzCardList(dk, keep) {
  const d0 = dayStartOf(dk), seen = new Set(), out = [];
  for (const o of [...(await ordersOfDay(dk)), ...(await ordersOfDay(prevDay(dk)))]) { if (o.st !== 2 || !isCard(o) || seen.has(o.no) || !keep(o.merch)) continue; const t = okAt(o); if (t < d0 || t >= d0 + 86400) continue; seen.add(o.no); out.push({ o, f: feeOf(o) }); }
  return out.sort((a, b) => okAt(b.o) - okAt(a.o));
}
$("fsub").onclick = (e) => { const b = e.target.closest("[data-s]"); if (!b) return; FZ.sub = b.dataset.s; try { localStorage.setItem("fzSub", FZ.sub); } catch (_) {} render(); };
$("fmode").onclick = (e) => { const b = e.target.closest("[data-v]"); if (!b) return; FZ.mode = b.dataset.v; render(); };
$("fhouse").onclick = (e) => { const th = e.target.closest("[data-fd]"); if (th) { FZ.day = th.dataset.fd; render(); } };
$("fcardQ").addEventListener("input", () => render());
$("fcardX").onclick = async () => {
  const L = FZ.cardL || []; if (!L.length) return;
  const F = "Times New Roman", S = (o) => Object.assign({ border: true, font: { name: F, size: 10 }, align: { v: "center" } }, o || {});
  const wb = new XLSXW.Book(), ws = wb.sheet("Thẻ cào");
  const H = ["Mã Đơn Hàng", "Tên Hội Viên", "Tổng Nhập Khoản", "Thời Gian", "Tên nền tảng thanh toán bên thứ ba", "Tên kênh", "Tiền Sau 10% BO", "Phí Nhà Thứ 3", "Công ty chịu"], W = [24, 18, 14, 18, 18, 14, 16, 14, 14];
  H.forEach((h, i) => { ws.set(1, i + 1, h, S({ font: { name: F, size: 10, bold: true, color: "FFFFFF" }, fill: "0B2A55", align: { h: "center", v: "center", wrap: true } })); ws.width(i + 1, W[i]); });
  const tz = new Date().getTimezoneOffset() * 60;
  L.forEach(({ o, f }, i) => [o.no, o.acc, f.face, (okAt(o) - tz) / 86400 + 25569, o.merch, o.ch, f.got, f.hf, f.fee].forEach((v, j) => ws.set(i + 2, j + 1, v, S(j === 3 ? { fmt: "dd/mm/yyyy hh:mm" } : [2, 6, 7, 8].includes(j) ? { fmt: "0" } : {}))));
  ws.freeze(2, 2);
  const blob = await wb.blob(), dk = FZ.day;
  const el = document.createElement("a"); el.href = URL.createObjectURL(blob); el.download = `The_cao_${dk.slice(8)}-${dk.slice(5, 7)}.xlsx`; document.body.appendChild(el); el.click(); el.remove();
};
// ---- phí thủ công: chỉ các số lệnh bạn dán ----
async function fzRenderMan(dk, keep) {
  const L = (await Store.kvGet("feeMan:" + dk).catch(() => null)) || [];
  $("fmanH").textContent = `Phí thủ công · ${dk.slice(8)}/${dk.slice(5, 7)}/${dk.slice(0, 4)}`;
  const opts = (sel, arr) => arr.map((x) => `<option ${x === sel ? "selected" : ""}>${esc(x)}</option>`).join("");
  const hsN = [...new Set((PSET || []).map((c) => c.merch).concat(HOUSES.map((h) => h.n)))].sort();
  let t = `<thead><tr><th class="l">Số lệnh</th><th class="l">Tài khoản</th><th class="l">Nhà · kênh</th><th>Số tiền</th><th>% phí</th><th>Tiền phí</th><th class="l">Tình trạng BO</th><th></th></tr></thead><tbody>`, sum = 0, n = 0;
  L.forEach((x, i) => {
    if (!keep(x.merch)) return; const xr = rateOf(x.merch, x.gate, x.ch, x.fee), fee = (x.amt || 0) * 1000 * xr / 100; sum += fee; n++;
    if (x.hand) {
      const chs = (PSET || []).filter((c) => c.merch === x.merch).map((c) => c.desc);
      t += `<tr class="man"><td class="l mono">${esc(x.no)}</td><td class="l mut">không phải số lệnh BO</td><td class="l"><select class="fz-in" data-mi="${i}" data-f="merch"><option value="">— chọn nhà —</option>${opts(x.merch, hsN)}</select> <select class="fz-in" data-mi="${i}" data-f="ch"><option value="">— kênh —</option>${opts(x.ch, chs)}</select></td><td><input class="fz-in" data-mi="${i}" data-f="amt" value="${x.amt ? fmt(x.amt * 1000) : ""}" placeholder="số tiền"></td><td>${x.fee != null ? x.fee + "%" : "—"}</td><td><b>${fzV(fee)}</b></td><td class="l mut">nhập tay</td><td><button class="btn" data-mdel="${i}">Xoá</button></td></tr>`;
    } else t += `<tr><td class="l mono">${esc(x.no)}</td><td class="l">${esc(x.acc || "")}</td><td ${fzHc(x.merch)}><span class="hn">${esc(x.merch)}</span> <small class="mut">${esc(x.ch || "")}</small></td><td>${fzV((x.amt || 0) * 1000)}</td><td>${xr}%${Number(x.fee) > 0 ? "" : ' <small class="mut" title="BO ghi 0% → lấy % phí tự đặt / phí kênh cùng nhà">*</small>'}</td><td><b>${fzV(fee)}</b></td><td class="l"><span class="pill${x.cb ? " cbp" : ""}">${esc(x.psl || "")}</span></td><td><button class="btn" data-mdel="${i}">Xoá</button></td></tr>`;
  });
  t += `<tr class="sum"><td class="l" colspan="5">Tổng phí thủ công (${fmt(n)} đơn)</td><td>${fzV(sum)}</td><td colspan="2"></td></tr>`;
  $("fmanL").innerHTML = t + "</tbody>";
}
async function fzManSave(dk, L) { await Store.kvSet("feeMan:" + dk, L); delete FZ.agg[dk]; Store.kvSet("feeAgg:" + dk, null).catch(() => {}); }
$("fmanL").addEventListener("change", async (e) => {
  const el = e.target.closest("[data-mi]"); if (!el) return; const dk = FZ.day, L = (await Store.kvGet("feeMan:" + dk).catch(() => null)) || [], x = L[+el.dataset.mi]; if (!x) return;
  if (el.dataset.f === "amt") x.amt = (Number(String(el.value).replace(/\D/g, "")) || 0) / 1000; else x[el.dataset.f] = el.value;
  if (el.dataset.f === "merch") x.ch = "";
  const c = (PSET || []).find((c) => c.merch === x.merch && c.desc === x.ch); x.fee = c ? Number(c.fee) || 0 : null;
  await fzManSave(dk, L); render();
});
$("fmanL").addEventListener("click", async (e) => { const b = e.target.closest("[data-mdel]"); if (!b) return; const dk = FZ.day, L = (await Store.kvGet("feeMan:" + dk).catch(() => null)) || []; L.splice(+b.dataset.mdel, 1); await fzManSave(dk, L); render(); });
$("fmanGo").onclick = async () => {
  const ids = [...new Set(($("fmanIn").value || "").split(/[\s,;]+/).map((x) => x.trim()).filter(Boolean))]; if (!ids.length) return;
  const dk = FZ.day, L = (await Store.kvGet("feeMan:" + dk).catch(() => null)) || [], have = new Set(L.map((x) => x.no));
  const btn = $("fmanGo"); btn.disabled = true; let found = 0, hand = 0, dup = 0;
  // tìm trong đơn đã lưu: ngày đang chọn và 7 ngày trước
  const pool = new Map(); { let d = dk; for (let i = 0; i < 8; i++) { for (const o of await ordersOfDay(d)) pool.set(o.no, o); d = prevDay(d); } }
  for (const no of ids) {
    if (have.has(no)) { dup++; continue; }
    let o = pool.get(no);
    if (!o && /^\d{15,}$/.test(no)) { try { const d = await BO.call("/api/finance/payOrderOnline/list", { method: "POST", body: { memberCurrency: "VND", timeType: 0, current: 1, size: 10, orderNo: no, isRefresh: false } }); const r = ((d && d.list) || []).find((r) => String(r.orderNo) === no); if (r) o = BO.norm(r, dk, dayStartOf(dk), "VND"); } catch (e) {} }
    if (o) { L.push({ no, acc: o.acc, merch: o.merch, ch: o.ch, gate: o.gate, amt: o.amt || (Number(o.raw) || 0), fee: Number(o.fee) || 0, psl: o.psl }); found++; }
    else { L.push({ no, hand: 1, merch: "", ch: "", amt: 0, fee: null }); hand++; }
    have.add(no);
  }
  await fzManSave(dk, L); btn.disabled = false; $("fmanIn").value = "";
  $("fmanMsg").textContent = `Đã thêm ${found} đơn tra được${hand ? `, ${hand} mã cần nhập tay` : ""}${dup ? `, ${dup} mã đã có` : ""}.`;
  render();
};
// ---- tỷ lệ phí theo tháng ----
async function fzManMonth(selH) {
  const mo = st.feeMon, days = dayList(mo + "-01").filter((d) => d <= DAY), H = {};
  for (const d of days) { const L = (await Store.kvGet("feeMan:" + d).catch(() => null)) || []; for (const x of L) { if (selH && x.merch !== selH) continue; const k = (x.merch || "?") + "|" + (x.ch || ""); const h = (H[k] ??= { m: x.merch || "?", ch: x.ch || "", n: 0, cb: 0, amt: 0, fee: 0, r: x.fee }); h.n++; if (x.cb) h.cb++; const xr = rateOf(x.merch, x.gate, x.ch, x.fee); h.amt += (x.amt || 0) * 1000; h.fee += (x.amt || 0) * 1000 * xr / 100; h.r = xr; } }
  if (st.tab !== "fee" || FZ.sub !== "rate") return;
  const R = Object.values(H).sort((a, b) => b.fee - a.fee), T = R.reduce((a, h) => ({ n: a.n + h.n, cb: a.cb + h.cb, amt: a.amt + h.amt, fee: a.fee + h.fee }), { n: 0, cb: 0, amt: 0, fee: 0 });
  $("fee-man-h").textContent = "Phí thủ công theo nhà · tháng " + mo.slice(5) + "/" + mo.slice(0, 4);
  $("fee-man-m").innerHTML = `<thead><tr><th class="l">Nhà · kênh</th><th>% phí</th><th>Số đơn</th><th>Tool tự lấy (callback trễ)</th><th>Dán tay</th><th>Tiền nạp (₫)</th><th>Tiền phí (₫)</th><th>% trên tổng phí thủ công</th></tr></thead><tbody>` +
    (R.map((h) => `<tr><td ${fzHc(h.m)}><span class="hn">${esc(h.m)}</span> <small class="mut">${esc(h.ch)}</small></td><td>${h.r != null ? h.r + "%" : "—"}</td><td>${fmt(h.n)}</td><td>${fmt(h.cb)}</td><td class="mut">${fmt(h.n - h.cb)}</td><td>${fzV(h.amt)}</td><td><b>${fzV(h.fee)}</b></td><td>${T.fee ? (h.fee / T.fee * 100).toFixed(1) + "%" : "—"}</td></tr>`).join("") || `<tr><td class="l mut" colspan="8">Tháng này chưa có đơn thủ công.</td></tr>`) +
    `<tr class="sum"><td class="l">Tổng</td><td>${T.amt ? (T.fee / T.amt * 100).toFixed(2) + "%" : "—"}</td><td>${fmt(T.n)}</td><td>${fmt(T.cb)}</td><td>${fmt(T.n - T.cb)}</td><td>${fzV(T.amt)}</td><td>${fzV(T.fee)}</td><td></td></tr></tbody>`;
}
function renderFeeOv() {
  // các nhà BO đang ghi phí 0% → cho đặt % phí để tính tiền phí
  const hs = new Set((PSET || []).filter((c) => !(Number(c.fee) > 0)).map((c) => c.merch)); Object.keys(FEEOV_DEF).forEach((m) => hs.add(m)); Object.keys(FEEOV).forEach((m) => hs.add(m));
  for (const m of [...hs]) if ((PSET || []).some((c) => c.merch === m && Number(c.fee) > 0)) hs.delete(m);
  const L = [...hs].filter(Boolean).sort();
  $("fee-ov").innerHTML = `<thead><tr><th class="l">Nhà</th><th>Phí BO ghi</th><th>% phí nhập (tính tiền)</th><th>Phí xuất / lệnh rút</th><th class="l">Ghi chú</th></tr></thead><tbody>` + (L.map((m) => { const v = FEEOV[m] ?? FEEOV_DEF[m] ?? ""; return `<tr><td ${fzHc(m)}><span class="hn">${esc(m)}</span></td><td class="mut">0%</td><td><input class="fz-in" style="width:80px;text-align:right" data-ov="${esc(m)}" value="${v}" placeholder="vd 0.35"> %</td><td><input class="fz-in" style="width:64px;text-align:right" data-out="${esc(m)}" value="${outOf(m) || ""}" placeholder="0"> USDT</td><td class="l mut">${FEEOV[m] != null ? "bạn tự đặt" : FEEOV_DEF[m] != null ? "mặc định theo sổ của nhà" : "chưa đặt → phí đang tính 0"}</td></tr>`; }).join("") || `<tr><td class="l mut" colspan="5">Không có nhà nào bị BO ghi phí 0%.</td></tr>`) + "</tbody>";
}
$("fee-ov").addEventListener("change", async (e) => {
  const el = e.target.closest("[data-ov],[data-out]"); if (!el) return; const v = String(el.value).replace(",", ".").trim();
  if (el.dataset.out != null) { FEEOUT[el.dataset.out] = v === "" ? 0 : Number(v) || 0; await Store.kvSet("feeOut", FEEOUT).catch(() => {}); for (const k in WDC) delete WDC[k]; }
  else { if (v === "") delete FEEOV[el.dataset.ov]; else FEEOV[el.dataset.ov] = Number(v) || 0; await Store.kvSet("feeOv", FEEOV).catch(() => {}); } FZ.agg = {}; for (const d of dayList((st.feeMon || DAY.slice(0, 7)) + "-01")) Store.kvSet("feeAgg:" + d, null).catch(() => {});
  render();
});
function renderFeeRate(FA, selH) {
  fzManMonth(selH); renderFeeOv();
  const MON = []; { let [y, m] = st.feeMon.split("-").map(Number); for (let i = 0; i < 3; i++) { MON.unshift(`${y}-${pad(m)}`); m--; if (!m) { m = 12; y--; } } }
  const endOf = (k, mo) => { let v = null; for (const e of FA[k]) if (e.day.slice(0, 7) <= mo) v = e.r; return v; };
  const keys = Object.keys(FEEH).filter((k) => !selH || k.split("|")[0] === selH);
  const rows = keys.map((k) => { const v = MON.map((mo) => endOf(k, mo)); const lg = FA[k].filter((e, i) => i > 0 && e.day.startsWith(st.feeMon)); const a = v.find((x) => x != null), c = v[2]; return { k, v, d: a != null && c != null ? +(c - (v[1] ?? a)).toFixed(3) : 0, lg }; })
    .filter((r) => r.v.some((x) => x != null)).sort((a, b) => Math.abs(b.d) - Math.abs(a.d) || b.lg.length - a.lg.length);
  if (!FZ.pickRate || !rows.some((r) => r.k.split("|")[0] === FZ.pickRate)) FZ.pickRate = rows[0] ? rows[0].k.split("|")[0] : null;
  $("fee-tbl").innerHTML = `<thead><tr><th class="l">Nhà · cổng · kênh</th>${MON.map((m) => `<th>${m.slice(5)}/${m.slice(0, 4)}</th>`).join("")}<th>Thay đổi</th><th>Lần đổi</th></tr></thead><tbody>` +
    rows.map((r) => { const [mc, g, ch] = r.k.split("|"); return `<tr class="${mc === FZ.pickRate ? "pick" : ""}" data-rk="${esc(mc)}" style="cursor:pointer"><td ${fzHc(mc)}><span class="hn">${esc(mc)}</span><small class="mut" style="display:block">${esc(GATE_SHORT[nk(g)] || g)} · ${esc(ch)}</small></td>${r.v.map((x) => `<td>${x == null ? "—" : x + "%"}</td>`).join("")}<td class="${r.d > 0 ? "up" : r.d < 0 ? "down" : "mut"}">${r.d > 0 ? "▲ +" + r.d : r.d < 0 ? "▼ " + r.d : "—"}</td><td>${r.lg.length || "—"}</td></tr>`; }).join("") +
    (rows.length ? "" : `<tr><td class="l mut" colspan="6">Chưa có dữ liệu phí. Tool ghi phí từ ngày cài đặt.</td></tr>`) + "</tbody>";
  $("fee-tbl").onclick = (e) => { const tr = e.target.closest("[data-rk]"); if (tr) { FZ.pickRate = tr.dataset.rk; render(); } };
  const [y, m] = st.feeMon.split("-").map(Number), upto = st.feeMon === DAY.slice(0, 7) ? +DAY.slice(8) : new Date(y, m, 0).getDate();
  const days = Array.from({ length: upto }, (_, i) => `${st.feeMon}-${pad(i + 1)}`);
  const series = (k) => { const arr = FA[k]; let v = null; return days.map((d) => { for (const e of arr) if (e.day <= d) v = e.r; return v; }); };
  const ks = rows.filter((r) => r.k.split("|")[0] === FZ.pickRate).slice(0, 6).map((r) => ({ k: r.k, s: series(r.k) })).filter((r) => r.s.some((v) => v != null));
  $("fee-chart-h").textContent = "Diễn biến phí" + (FZ.pickRate ? " · " + FZ.pickRate : "");
  const cols = ["#2563eb", "#16a34a", "#ea580c", "#7c3aed", "#e11d48", "#0891b2"];
  if (!ks.length) { $("fee-chart").innerHTML = empty("Chưa có dữ liệu."); $("fee-legend").innerHTML = ""; }
  else {
    const all = ks.flatMap((r) => r.s.filter((v) => v != null)); let mn = Math.min(...all), mx = Math.max(...all); if (mx - mn < 0.2) { mn = Math.max(0, mn - 0.1); mx = mx + 0.1; }
    const D = days.length, W = 560, Hh = 210, Lf = 44, R = 12, T = 12, B = 24, x = (i) => Lf + i * (W - Lf - R) / Math.max(1, D - 1), yv = (v) => T + (Hh - T - B) * (1 - (v - mn) / (mx - mn));
    let s = `<svg viewBox="0 0 ${W} ${Hh}" role="img" aria-label="Diễn biến phí">`;
    for (let i = 0; i <= 4; i++) { const v = mn + (mx - mn) * i / 4; s += `<line class="gl" x1="${Lf}" x2="${W - R}" y1="${yv(v)}" y2="${yv(v)}"/><text x="${Lf - 6}" y="${yv(v) + 3}" text-anchor="end">${v.toFixed(2)}%</text>`; }
    for (let d = 0; d < D; d += D > 16 ? 2 : 1) s += `<text x="${x(d)}" y="${Hh - 7}" text-anchor="middle">${pad(d + 1)}</text>`;
    ks.forEach((r, j) => { let p = "", started = false; r.s.forEach((v, i) => { if (v == null) return; p += started ? `H${x(i).toFixed(1)}V${yv(v).toFixed(1)}` : `M${x(i).toFixed(1)} ${yv(v).toFixed(1)}`; started = true; }); const lv = r.s[r.s.length - 1]; s += `<path d="${p}" fill="none" stroke="${cols[j]}" stroke-width="2.2"/>${lv != null ? `<circle cx="${x(D - 1)}" cy="${yv(lv)}" r="3" fill="${cols[j]}"/>` : ""}`; });
    $("fee-chart").innerHTML = s + "</svg>";
    $("fee-legend").innerHTML = ks.map((r, j) => { const [, g, ch] = r.k.split("|"); return `<span><i style="background:${cols[j]}"></i>${esc(GATE_SHORT[nk(g)] || g)} ${esc(ch)} · ${r.s[r.s.length - 1]}%</span>`; }).join("");
  }
  const lg = rows.flatMap((r) => r.lg.map((e) => { const arr = FA[r.k], i = arr.indexOf(e); return { k: r.k, day: e.day, from: arr[i - 1].r, to: e.r }; })).sort((a, b) => (a.day < b.day ? 1 : -1));
  $("fee-log").innerHTML = `<thead><tr><th class="l">Ngày</th><th class="l">Nhà</th><th class="l">Cổng</th><th class="l">Kênh</th><th>Phí cũ</th><th>Phí mới</th><th>Chênh lệch</th></tr></thead><tbody>` + (lg.length ? lg.map((l) => { const [mc, g, ch] = l.k.split("|"); const dd = +(l.to - l.from).toFixed(3); return `<tr><td class="l">${l.day.split("-").reverse().join("/")}</td><td ${fzHc(mc)}><span class="hn">${esc(mc)}</span></td><td class="l">${esc(GATE_SHORT[nk(g)] || g)}</td><td class="l mut">${esc(ch)}</td><td>${l.from}%</td><td><b>${l.to}%</b></td><td class="${dd > 0 ? "up" : "down"}">${dd > 0 ? "▲ +" + dd : "▼ " + dd}</td></tr>`; }).join("") : `<tr><td class="l mut" colspan="7">Chưa có lần đổi phí nào trong tháng</td></tr>`) + "</tbody>";
}

// ===== LỆNH ẢO =====
// Danh sách tài khoản quản lý đã xác nhận là lệnh ảo (thêm tay) và đã bỏ qua
const FAKE_SEED = ["hophat787sloni","trancong6480zi","lycong60neavtk","phamtien401uwk","hominh347gazcp","ngoanh327clewy","lybao211dvyrky","dohung14ctvchs","lehong534gyqek","huynhthao6477q","lythinh24ysimm","phamhai5743yvx","lyphat54nqqvps","hohuy332hxbojf","hoangthin84csv","vuhuu98bcwuepe"];
let FMARK = {}, FIGN = {};   // tài khoản -> thời điểm đánh dấu / bỏ qua
const HO = ["nguyen","tran","le","pham","hoang","huynh","phan","vu","vo","dang","bui","do","ho","ngo","duong","ly","dinh","mai","truong","cao","lam","luong","trinh","dao","doan","ha","kieu","ta","quach","to","thai","chau","la","tang","van","khuc","lu","mac","tieu","hua","giang","phung","tu","au","lai","nghiem","ong","son","tong","vuong","chu","luu","dam","diep","hong","nong","thach","than","trieu","ung","yen"];
const BIG = 50000;   // 50 triệu VND (số tiền trên BO tính theo nghìn)
// tên kiểu "họ + tên + số + chuỗi chữ lung tung": hophat787sloni, huynhthao6477q, dohung14ctvchs
function nameScore(acc) {
  const s = String(acc || "").toLowerCase();
  const m = /^([a-z]{3,14})(\d{1,4})([a-z]{1,8})$/.exec(s);
  if (!m) return 0;
  const head = m[1], tail = m[3];
  if (!HO.some((h) => head.startsWith(h) && head.length - h.length >= 2)) return 0;
  const vowels = (tail.match(/[aeiouy]/g) || []).length;
  return tail.length >= 3 && vowels / tail.length <= 0.5 ? 2 : 1;   // đuôi càng ít nguyên âm càng giống chữ ngẫu nhiên
}
function fakeRows(list) {
  const by = {};
  for (const o of list) { if (!o.acc) continue; (by[o.acc] ??= []).push(o); }
  const rows = [];
  for (const acc in by) {
    const os = by[acc].sort((x, y) => x.ts - y.ts);
    const ok = os.filter((o) => o.st === 2).length, n = os.length;
    const big = os.filter((o) => o.cur === "VND" && o.amt >= BIG).length;
    const maxAmt = Math.max(...os.map((o) => o.amt));
    const last = os[os.length - 1];
    const nm = nameScore(acc);
    const fails = n >= 3 && ok === 0;
    const neverOk = last.nOk === 0;
    const sig = [];
    if (nm) sig.push(["Tên lung tung", nm === 2 ? "bad" : "warn"]);
    if (big) sig.push([`${big} lệnh ≥ 50 triệu`, "bad"]);
    if (fails) sig.push([`${n} lệnh, 0 thành công`, "bad"]);
    if (neverOk && last.nAll >= 2) sig.push([`BO: chưa nạp thành công lần nào (${last.nAll} lần)`, "warn"]);
    let score = (nm ? 1 : 0) + (big ? 1 : 0) + (fails ? 1 : 0) + (neverOk && last.nAll >= 3 ? 0.5 : 0);
    const marked = !!FMARK[acc] || FAKE_SEED.includes(acc);
    if (FIGN[acc]) continue;
    let lv = marked ? "mark" : score >= 2.5 ? "high" : score >= 2 ? "mid" : null;
    if (!lv) continue;
    rows.push({ acc, lv, score, sig, n, ok, big, maxAmt, sum: os.reduce((s, o) => s + o.amt, 0), first: os[0].ts, lastTs: last.ts, nOk: last.nOk, nAll: last.nAll, hs: [...new Set(os.map((o) => HOUSES[o.h].n))], gs: [...new Set(os.map((o) => GATES[o.g].n))] });
  }
  const R = { mark: 0, high: 1, mid: 2 };
  return rows.sort((x, y) => R[x.lv] - R[y.lv] || y.score - x.score || y.lastTs - x.lastTs);
}
// tài khoản đã đánh dấu nhưng hôm nay chưa tạo lệnh vẫn nằm trong danh sách để sao chép
function markedNoOrder(seen) { return [...new Set([...FAKE_SEED, ...Object.keys(FMARK)])].filter((a) => !seen.has(a) && !FIGN[a]); }
const FLV = [["all", "Tất cả nghi ngờ", ""], ["high", "Rất nghi ngờ", "bad"], ["mid", "Nghi ngờ", "warn"], ["mark", "Đã đánh dấu", "ok"]];
let FLIST = [];
function renderFake() {
  const list = inTf("fake");
  let rows = fakeRows(list);
  const seen = new Set(rows.map((r) => r.acc));
  const cnt = { all: rows.length, high: 0, mid: 0, mark: 0 }; rows.forEach((r) => cnt[r.lv]++);
  const extra = markedNoOrder(new Set(list.map((o) => o.acc)));
  cnt.mark += extra.length; cnt.all += extra.length;
  st.fakeLv ??= "all";
  $("fst").innerHTML = FLV.map(([k, n, c]) => `<button class="stab ${c}" aria-pressed="${st.fakeLv === k}" data-v="${k}"><small>${n}</small><b>${fmt(cnt[k])}</b><span>${k === "mark" ? "đã xác nhận" : k === "all" ? "tài khoản" : "tài khoản trong khung giờ"}</span></button>`).join("");
  $("fst").onclick = (e) => { const b = e.target.closest(".stab"); if (b) { st.fakeLv = b.dataset.v; render(); } };
  const q = ($("fsearch").value || "").trim().toLowerCase();
  let show = rows.filter((r) => (st.fakeLv === "all" || r.lv === st.fakeLv) && (!q || r.acc.includes(q)));
  if (st.fakeLv === "all" || st.fakeLv === "mark") show = show.concat(extra.filter((a) => !q || a.includes(q)).map((acc) => ({ acc, lv: "mark", sig: [["Hôm nay chưa tạo lệnh", "mut"]], n: 0, ok: 0, sum: 0, maxAmt: 0, hs: [], gs: [], none: true })));
  FLIST = show;
  $("cnt-fake").textContent = rows.filter((r) => r.lv !== "mark").length;
  $("fake-hint").textContent = tfLabel("fake");
  $("fake-sum").textContent = fmt(show.length) + " tài khoản";
  const LVT = { mark: '<span class="pill badp">Đã đánh dấu</span>', high: '<span class="pill badp">Rất nghi ngờ</span>', mid: '<span class="pill warnp">Nghi ngờ</span>' };
  let t = `<thead><tr><th class="l">Tài khoản</th><th class="l">Mức</th><th class="l">Dấu hiệu</th><th>Lệnh</th><th>Thành công</th><th>Lệnh lớn nhất (₫)</th><th>Tổng tiền đặt (₫)</th><th title="Số lần nạp thành công / tổng theo BO">Số lần nạp (BO)</th><th class="l">Nhà · cổng</th><th>Lệnh đầu</th><th>Lệnh cuối</th><th class="l"></th></tr></thead><tbody>`;
  for (const r of show.slice(0, 500)) {
    t += `<tr class="${r.lv === "mark" || r.lv === "high" ? "rbad" : ""}"><td class="name">${esc(r.acc)}</td><td class="l">${LVT[r.lv]}</td><td class="l">${r.sig.map(([s, c]) => `<span class="tag ${c}">${esc(s)}</span>`).join(" ")}</td>
      <td>${r.none ? "—" : fmt(r.n)}</td><td class="${r.ok ? "ok" : "bad"}">${r.none ? "—" : fmt(r.ok)}</td><td>${r.none ? "—" : vnd(r.maxAmt)}</td><td>${r.none ? "—" : vnd(r.sum)}</td><td>${r.nAll == null ? "—" : fmt(r.nOk) + "/" + fmt(r.nAll)}</td>
      <td class="l mut">${esc(r.hs.join(", "))}${r.gs.length ? " · " + esc(r.gs.join(", ")) : ""}</td><td>${r.none ? "—" : clock(r.first - V0())}</td><td>${r.none ? "—" : clock(r.lastTs - V0())}</td>
      <td class="l" style="white-space:nowrap">${r.none ? "" : `<button class="btn" data-fview="${esc(r.acc)}">Xem lệnh</button> `}${r.lv === "mark" ? `<button class="btn" data-funmark="${esc(r.acc)}">Bỏ đánh dấu</button>` : `<button class="btn" data-fmark="${esc(r.acc)}">Đánh dấu</button> <button class="btn" data-fign="${esc(r.acc)}">Không phải</button>`}</td></tr>`;
  }
  if (!show.length) t += `<tr><td class="l mut" colspan="12">Không có tài khoản nghi ngờ trong khung thời gian này</td></tr>`;
  $("fake-tbl").innerHTML = t + "</tbody>";
}
async function saveFake() { await chrome.storage.local.set({ fakeMark: FMARK, fakeIgn: FIGN }); }
document.addEventListener("click", async (e) => {
  const b = e.target.closest("[data-fview],[data-fmark],[data-funmark],[data-fign]"); if (!b) return;
  if (b.dataset.fview) { st.ostat = "all"; st.pendH = -1; st.pendG = -1; st.pendMin = 0; st.tf.list = "day"; st.page = 0; st.q = b.dataset.fview; $("psearch").value = st.q; go("pend"); return; }
  if (b.dataset.fmark) { FMARK[b.dataset.fmark] = Date.now(); delete FIGN[b.dataset.fmark]; }
  if (b.dataset.funmark) { const a = b.dataset.funmark; delete FMARK[a]; if (FAKE_SEED.includes(a)) FIGN[a] = Date.now(); }
  if (b.dataset.fign) { FIGN[b.dataset.fign] = Date.now(); delete FMARK[b.dataset.fign]; }
  await saveFake(); rebuild(); render();
});
$("fsearch").addEventListener("input", () => render());
$("faddb").onclick = async () => { const xs = $("fadd").value.split(/[\s,;]+/).map((x) => x.trim()).filter(Boolean); xs.forEach((x) => { FMARK[x] = Date.now(); delete FIGN[x]; }); $("fadd").value = ""; await saveFake(); rebuild(); render(); };
$("fcopy").onclick = async () => {
  const txt = FLIST.map((r) => r.acc).join(",");
  try { await navigator.clipboard.writeText(txt); sysmsg(`Đã sao chép ${FLIST.length} tài khoản (cách nhau dấu phẩy). Dán vào ô "Tài khoản thành viên" trên BO, mỗi lần tối đa 200 tài khoản.`, "info"); }
  catch (e) { sysmsg("Không sao chép được: " + esc(e.message), "err"); }
  setTimeout(() => sysmsg(""), 6000);
};
$("fxls").onclick = async () => {
  const F = "Times New Roman", S = (o) => Object.assign({ border: true, font: { name: F, size: 10 }, align: { v: "center" } }, o || {});
  const wb = new XLSXW.Book(), ws = wb.sheet("Lệnh ảo");
  const H = ["Tài khoản", "Mức", "Dấu hiệu", "Số lệnh", "Thành công", "Lệnh lớn nhất (₫)", "Tổng tiền đặt (₫)", "Nạp thành công (BO)", "Tổng lần nạp (BO)", "Nhà thứ 3", "Cổng nạp"];
  const W = [20, 14, 50, 9, 10, 16, 18, 12, 12, 24, 24];
  H.forEach((h, i) => { ws.set(1, i + 1, h, S({ font: { name: F, size: 10, bold: true, color: "FFFFFF" }, fill: "0B2A55", align: { h: "center", v: "center", wrap: true } })); ws.width(i + 1, W[i]); });
  const L = { mark: "Đã đánh dấu", high: "Rất nghi ngờ", mid: "Nghi ngờ" };
  FLIST.forEach((r, i) => [r.acc, L[r.lv], r.sig.map((s) => s[0]).join("; "), r.n, r.ok, r.maxAmt * 1000, r.sum * 1000, r.nOk ?? null, r.nAll ?? null, r.hs.join(", "), r.gs.join(", ")]
    .forEach((v, j) => ws.set(i + 2, j + 1, v, S(j >= 3 && j <= 8 ? { fmt: "0" } : {}))));
  ws.freeze(2, 2); ws.height(1, 30);
  const blob = await wb.blob(), now = new Date();
  const el = document.createElement("a"); el.href = URL.createObjectURL(blob); el.download = `Lenh_ao_${pad(now.getDate())}-${pad(now.getMonth() + 1)}_${pad(now.getHours())}h${pad(now.getMinutes())}.xlsx`; document.body.appendChild(el); el.click(); el.remove();
};


// ===== TRẠNG THÁI KÊNH TRÊN BO (Dừng/bật) =====
let PSFIRST = 0, PSET = null, PSAT = 0, PSERR = "", PSTATE = {}, PSW = [], PSWDAY = null, lastPS = 0;
const PS_MIN = 1; // đọc lại mỗi 1 phút
async function loadPaySet() {
  const d = await BO.paySettings();
  const now = nowU() - DAY0, list = [];
  for (const t of d) (t.channelList || []).forEach((c, ci) => {
    list.push({ rank: ci + 1, tw: Number(t.weight) || 0, w: Number(c.weight) || 0, key: (t.payTypeId || t.payTypeName) + "_" + c.id, type: t.payTypeName || c.paymentName || "", typeOn: t.switchStatus == null || Number(t.switchStatus) === 1,
      gk: nk(c.paymentName || t.payTypeName) || "khac", hk: hkey(c.merchName), merch: (c.merchName || "").trim(), desc: String(c.merchDesc || "").trim(),
      on: Number(c.status) === 1, min: Number(c.min) || 0, max: Number(c.max) || 0, rate: c.successRechargeRate, fee: c.channelRate, cur: c.payCurrency || "VND" });
  });
  if (PSWDAY !== DAY) { PSWDAY = DAY; PSW = (await Store.kvGet("psw:" + DAY).catch(() => null)) || []; }
  let changed = false;
  for (const c of list) {
    const p = PSTATE[c.key];
    if (!p) { PSTATE[c.key] = { on: c.on, since: null }; changed = true; continue; }
    if (p.on !== c.on) { PSW.push({ t: now, key: c.key, on: c.on, type: c.type, merch: c.merch, desc: c.desc, gk: c.gk, hk: c.hk }); PSTATE[c.key] = { on: c.on, since: DAY0 + now }; changed = true; }
  }
  PSET = list; PSAT = Date.now(); PSERR = ""; if (!PSFIRST) PSFIRST = nowU();
  if (changed) { Store.kvSet("pstate", PSTATE).catch(() => {}); Store.kvSet("psw:" + DAY, PSW).catch(() => {}); }
}
// trạng thái BO của 1 nhà × cổng: null = không có trong cài đặt, true = có kênh đang bật, false = tất cả đang dừng
function boState(hi, gi) {
  if (!PSET || VIEW || hi == null || gi == null || !HOUSES[hi] || !GATES[gi]) return null;
  const cs = PSET.filter((c) => c.hk === HOUSES[hi].k && c.gk === GATES[gi].k); if (!cs.length) return null;
  return cs.some((c) => c.on && c.typeOn);
}
const boTag = (hi, gi) => { const b = boState(hi, gi); return b == null ? "" : b ? '<span class="pill on" title="Trạng thái Dừng/bật trên BO">BO bật</span>' : '<span class="pill badp" title="Trạng thái Dừng/bật trên BO">BO tắt</span>'; };
const sinceTxt = (c) => { const p = PSTATE[c.key]; return p && p.since ? clock(p.since - DAY0 >= 0 ? p.since - DAY0 : 0) : ""; };
async function pswOf(dk) { if (!dk || dk === DAY) return PSW; return (await Store.kvGet("psw:" + dk).catch(() => null)) || []; }
let PSWV = [];

// ===== BẢO TRÌ CỔNG =====
// thời điểm đơn thành công đầu tiên của khách thật sau lúc t trên cùng nhà × cổng = cổng đã hoạt động lại
function okIndex() { const m = {}; for (const o of orders) if (o.st === 2) (m[o.h + "_" + o.g] ??= []).push(o.t); for (const k in m) m[k].sort((a, b) => a - b); return m; }
function okAfter(idx, k, t) { const a = idx[k]; if (!a) return null; let lo = 0, hi = a.length; while (lo < hi) { const md = (lo + hi) >> 1; if (a[md] > t) hi = md; else lo = md + 1; } return lo < a.length ? a[lo] : null; }
// Chỉ tính là bảo trì / lỗi cổng khi BO ghi lý do phía cổng (vd "Kênh này đang bảo trì").
// Không tính: BO không ghi lý do, hoặc lỗi do khách (số tiền dưới mức tối thiểu / vượt mức tối đa…)
const CUSTERR = /amount|less than|greater than|minimum|maximum|s[oố] ti[eề]n|t[oố]i thi[eể]u|t[oố]i [dđ]a|v[uượ][oợ]t|h[aạ]n m[uứ]c|limit/i;
const isMaint = (o) => o.st === 3 && !!(o.why && o.why.trim()) && !CUSTERR.test(o.why);
const MGAP = 900; // đơn lỗi cùng cổng cách nhau <= 15 phút = cùng 1 đợt
function maintEvents(errs) {
  const by = {}; for (const o of errs) (by[o.h + "_" + o.g] ??= []).push(o);
  const ev = [];
  for (const k in by) {
    const [hi, gi] = k.split("_").map(Number); let cur = null;
    for (const o of by[k].sort((a, b) => a.t - b.t)) {
      if (!cur || o.t - cur.b > MGAP) { cur = { k, hi, gi, a: o.t, b: o.t, list: [], why: {} }; ev.push(cur); }
      cur.b = o.t; cur.list.push(o); const w = o.why || "BO không ghi lý do"; cur.why[w] = (cur.why[w] || 0) + 1;
    }
  }
  return ev.sort((x, y) => y.b - x.b);
}
const whyTxt = (w) => Object.entries(w).sort((a, b) => b[1] - a[1]).map(([t, n]) => `${t}${n > 1 ? " (" + n + ")" : ""}`).join("; ");
let MEV = [], MROWS = [], MPSW = { dk: null, L: [] };
const gName = (gk, fb) => { const gi = GIDX[gk]; return gi != null ? GATES[gi].n : GATE_SHORT[gk] || fb || gk; };
const hName = (hk, fb) => { const hi = HIDX[hk]; return hi != null ? HOUSES[hi].n : fb || hk; };
// Các khoảng BO tắt (Dừng) của từng nhà × cổng trong ngày, dựng lại từ trạng thái hiện tại + lịch sử bật/tắt
function boOffSpans(L, today) {
  const keys = {};
  const add = (hk, gk, ck, desc, merch, type) => { const K = hk + "|" + gk; const r = (keys[K] ??= { hk, gk, merch, type, chs: {} }); return (r.chs[ck] ??= { desc, ev: [], cur: null }); };
  if (today && PSET) for (const c of PSET) add(c.hk, c.gk, c.key, c.desc, c.merch, c.type).cur = c.on && c.typeOn;
  for (const w of L) add(w.hk, w.gk, w.key, w.desc, w.merch, w.type).ev.push(w);
  const spans = [];
  for (const K in keys) {
    const r = keys[K], chs = Object.values(r.chs);
    for (const c of chs) { c.ev.sort((a, b) => a.t - b.t); c.init = c.ev.length ? !c.ev[0].on : c.cur == null ? true : c.cur; }
    const stAt = (c, t) => { let s = c.init; for (const e of c.ev) if (e.t <= t) s = e.on; return s; };
    const pts = [...new Set([0, ...chs.flatMap((c) => c.ev.map((e) => e.t))])].sort((a, b) => a - b);
    let cur = null;
    for (const t of pts) {
      const on = chs.some((c) => stAt(c, t));
      if (!on && !cur) { cur = { K, hk: r.hk, gk: r.gk, merch: r.merch, type: r.type, a: t, pre: t === 0, b: null, src: "bo", descs: chs.map((c) => c.desc) }; spans.push(cur); }
      else if (on && cur) { cur.b = t; cur = null; }
    }
  }
  return spans;
}
// Đợt bảo trì = BO tắt kênh, hoặc tool phát hiện đơn khách thật bị lỗi phía cổng.
// Hoàn tất khi BO bật lại (nếu đã tắt) VÀ có đơn thành công sau đó.
function buildIncidents(errs, L, today) {
  const OKI = okIndex();
  const inc = boOffSpans(L, today).map((s) => ({ ...s, list: [], why: {}, last: s.a }));
  for (const e of maintEvents(errs)) {
    const hk = HOUSES[e.hi].k, gk = GATES[e.gi].k, K = hk + "|" + gk;
    const m = inc.find((x) => x.K === K && x.src !== "err" && e.a <= (x.b == null ? 1e9 : x.b) && (e.b >= x.a - MGAP || (() => { const ok = okAfter(OKI, e.k, e.b); return ok == null || ok > x.a; })()));
    if (m) { m.src = "both"; if (!m.pre) m.a = Math.min(m.a, e.a); m.list.push(...e.list); for (const w in e.why) m.why[w] = (m.why[w] || 0) + e.why[w]; m.last = Math.max(m.last, e.b); }
    else inc.push({ K, hk, gk, merch: HOUSES[e.hi].n, type: GATES[e.gi].raw, a: e.a, b: null, pre: false, src: "err", list: [...e.list], why: { ...e.why }, last: e.b, descs: [...new Set(e.list.map((o) => o.ch).filter(Boolean))] });
  }
  for (const x of inc) {
    const hi = HIDX[x.hk], gi = GIDX[x.gk];
    x.hi = hi; x.gi = gi;
    x.resume = x.src === "err" ? x.last : x.b == null ? null : Math.max(x.b, x.last);
    x.ok = x.resume == null || hi == null || gi == null ? null : okAfter(OKI, hi + "_" + gi, x.resume);
    x.state = x.ok != null ? "done" : x.src !== "err" && x.b == null ? "off" : x.src !== "err" ? "wait" : "err";
  }
  return inc.sort((p, q) => (q.ok ?? q.b ?? 1e9) - (p.ok ?? p.b ?? 1e9) || q.a - p.a);
}
const MSRC = { bo: "BO tắt kênh", err: "Tool phát hiện lỗi", both: "Lỗi cổng + BO tắt" };
function mTag(x) {
  if (x.state === "done") return `<span class="pill on">Hoàn tất bảo trì ${clock(x.ok)}</span>`;
  if (x.state === "off") return `<span class="pill badp">Đang bảo trì · BO đang tắt</span>`;
  if (x.state === "wait") return `<span class="pill warnp">BO bật lại ${clock(x.b)} · chờ đơn thành công</span>`;
  return VIEW ? '<span class="pill warnp">Không thấy hoạt động lại</span>' : '<span class="pill badp">Đang bảo trì · tool phát hiện lỗi</span>';
}
const mStart = (x) => (x.pre ? (VIEW ? "Từ 00:00" : "Tắt từ trước") : clock(x.a));
const durTxt = (s) => (s >= 3600 ? Math.floor(s / 3600) + " giờ " + pad(Math.floor((s % 3600) / 60)) + " phút" : mmss(s));
const mDur = (x, N) => (x.pre ? "—" : x.state === "done" ? durTxt(x.ok - x.a) : VIEW ? "—" : durTxt(N - x.a) + "+");
function maintActive() { try { return buildIncidents(orders.filter(isMaint), PSW, true).filter((x) => x.state !== "done").length; } catch (e) { return 0; } }
function renderMaint() {
  if (st.maintH >= HOUSES.length) st.maintH = -1;
  chips("mf", HOUSES, st.maintH, (v) => { st.maintH = v; render(); }, true);
  const today = !VIEW;
  if (!today && MPSW.dk !== VIEW) { const dk = VIEW; pswOf(dk).then((L) => { MPSW = { dk, L }; if (st.tab === "maint") render(); }); }
  const L = today ? PSW : MPSW.dk === VIEW ? MPSW.L : [];
  const [from, to] = tfRange("maint"), N = NOWS();
  const allErr = orders.filter((o) => o.st === 3), errs = allErr.filter(isMaint);
  const skipped = allErr.filter((o) => o.t >= from && o.t <= to).length - errs.filter((o) => o.t >= from && o.t <= to).length;
  const hk0 = st.maintH >= 0 ? HOUSES[st.maintH].k : null;
  const inc = buildIncidents(errs, L, today).filter((x) => (!hk0 || x.hk === hk0) && x.a <= to && (x.ok ?? (x.state === "done" ? x.ok : N)) >= from);
  MEV = inc;
  const by = {};
  for (const x of inc) {
    const r = (by[x.K] ??= { K: x.K, hk: x.hk, gk: x.gk, hi: x.hi, gi: x.gi, merch: x.merch, type: x.type, n: 0, err: 0, acc: new Set(), amt: 0, a: x.a, pre: x.pre, why: {}, last: x, dur: 0, descs: new Set() });
    r.n++; r.err += x.list.length; x.list.forEach((o) => { r.acc.add(o.acc); r.amt += o.amt; }); x.descs.forEach((d) => r.descs.add(d));
    if (x.a < r.a) { r.a = x.a; r.pre = x.pre; }
    for (const w in x.why) r.why[w] = (r.why[w] || 0) + x.why[w];
    if ((x.ok ?? 1e9) >= (r.last.ok ?? 1e9) && x.a >= r.last.a) r.last = x;
    r.dur += x.pre ? 0 : x.state === "done" ? x.ok - x.a : today ? N - x.a : 0;
  }
  const rows = Object.values(by).sort((p, q) => (q.last.state !== "done") - (p.last.state !== "done") || q.n - p.n); MROWS = rows;
  const act = inc.filter((x) => x.state !== "done").length, done = inc.length - act;
  const errIn = inc.flatMap((x) => x.list), amt = errIn.reduce((s, o) => s + o.amt, 0);
  const kp = [["Số lần bảo trì", fmt(inc.length), tfLabel("maint"), ""], ["Đang bảo trì", fmt(act), act ? "cổng chưa hoạt động lại" : "không có cổng đang bảo trì", act ? "bad" : "ok"], ["Hoàn tất bảo trì", fmt(done), "BO bật lại + có đơn thành công", "ok"], ["Đơn khách thật bị lỗi", fmt(errIn.length), fmt(new Set(errIn.map((o) => o.acc)).size) + " khách", "slow"], ["Tiền khách nạp không vào", vnd(amt) + " ₫", "", "warn"]];
  $("maint-kpis").innerHTML = kp.map((k) => `<div class="kpi ${k[3]}"><div class="lab">${k[0]}</div><div class="val">${k[1]}</div><div class="sub">${k[2]}</div></div>`).join("");
  $("maint-hint").textContent = tfLabel("maint") + (skipped > 0 ? ` · không tính ${fmt(skipped)} đơn thất bại do khách hoặc BO không ghi lý do` : "");
  let t = `<thead><tr><th class="l">Nhà</th><th class="l">Cổng</th><th class="l">Kênh</th><th>Số lần bảo trì</th><th>Tổng thời gian</th><th>Đơn lỗi</th><th>Khách</th><th>Tiền (₫)</th><th>Bắt đầu lần đầu</th><th class="l">Lý do</th><th class="l">Hiện tại</th><th class="l"></th></tr></thead><tbody>`;
  for (const r of rows) t += `<tr class="${r.last.state === "done" ? "" : r.last.state === "wait" ? "rwarn" : "rbad"}"><td class="name">${esc(hName(r.hk, r.merch))}</td><td class="l">${esc(gName(r.gk, r.type))}</td><td class="l mut">${esc([...r.descs].join(", "))}</td><td class="bad" style="font-weight:700">${fmt(r.n)}</td><td>${r.dur ? durTxt(r.dur) : "—"}</td><td>${fmt(r.err)}</td><td>${fmt(r.acc.size)}</td><td>${vnd(r.amt)}</td><td class="mono">${r.pre ? (VIEW ? "00:00:00" : "Tắt từ trước") : clock(r.a)}</td><td class="l">${esc(whyTxt(r.why) || (r.last.src === "bo" ? "BO tắt kênh" : ""))}</td><td class="l">${mTag(r.last)}</td><td class="l">${r.hi != null && r.gi != null ? `<button class="btn gocell" data-go-list='${JSON.stringify({ s: r.err ? "err" : "all", h: r.hi, g: r.gi, tf: st.tf.maint })}'>Xem đơn</button>` : ""}</td></tr>`;
  if (!rows.length) t += `<tr><td class="l mut" colspan="12">Không có cổng nào bảo trì trong khung thời gian này</td></tr>`;
  $("maint-tbl").innerHTML = t + "</tbody>";
  let u = `<thead><tr><th class="l">Bắt đầu</th><th class="l">Nguồn</th><th class="l">Nhà</th><th class="l">Cổng</th><th class="l">Kênh</th><th>BO bật lại</th><th>Đơn thành công đầu tiên</th><th>Thời gian bảo trì</th><th class="l">Tình trạng</th><th>Đơn lỗi</th><th class="l">Lý do</th><th class="l">Tài khoản bị lỗi</th></tr></thead><tbody>`;
  for (const x of inc.slice(0, 500)) { const ac = [...new Set(x.list.map((o) => o.acc))]; u += `<tr class="${x.state === "done" ? "" : x.state === "wait" ? "rwarn" : "rbad"}"><td class="l mono">${mStart(x)}</td><td class="l">${MSRC[x.src]}</td><td class="name">${esc(hName(x.hk, x.merch))}</td><td class="l">${esc(gName(x.gk, x.type))}</td><td class="l mut">${esc(x.descs.join(", "))}</td><td class="mono">${x.b != null ? clock(x.b) : x.src === "err" ? "—" : "chưa"}</td><td class="mono">${x.ok != null ? clock(x.ok) : "chưa"}</td><td>${mDur(x, N)}</td><td class="l">${mTag(x)}</td><td class="${x.list.length ? "bad" : "mut"}">${fmt(x.list.length)}</td><td class="l">${esc(whyTxt(x.why) || (x.src === "bo" ? "BO tắt kênh" : ""))}</td><td class="l mut">${esc(ac.slice(0, 4).join(", "))}${ac.length > 4 ? "…" : ""}</td></tr>`; }
  if (!inc.length) u += `<tr><td class="l mut" colspan="12">Chưa có đợt nào</td></tr>`;
  $("maint-ev").innerHTML = u + "</tbody>";
  $("maint-sum").textContent = `${fmt(inc.length)} đợt · ${fmt(act)} đang bảo trì`;
  if (today) $("cnt-maint").textContent = act;
}
st.statDay = null; st.statF = "all";
function renderStat() {
  const dk = st.statDay || DAY, today = dk === DAY;
  $("statDay").max = DAY; $("statDay").value = dk;
  $("statF").innerHTML = [["all", "Tất cả"], ["off", "Đang tắt"], ["on", "Đang bật"]].map(([k, n]) => `<button aria-pressed="${st.statF === k}" data-v="${k}">${n}</button>`).join("");
  const off = PSET ? PSET.filter((c) => !c.on || !c.typeOn).length : 0;
  $("cnt-stat").textContent = off;
  const L = today ? PSW : PSWV;
  const kp = [["Tổng kênh nạp", PSET ? fmt(PSET.length) : "—", PSET ? "cập nhật " + new Date(PSAT).toLocaleTimeString("vi-VN", { hour12: false }) : "chưa đọc được", ""], ["Đang bật", PSET ? fmt(PSET.length - off) : "—", "khách nạp được", "ok"], ["Đang tắt (bảo trì)", PSET ? fmt(off) : "—", "Dừng trên BO", "bad"], ["Lần tắt " + (today ? "hôm nay" : dk.split("-").reverse().join("/")), fmt(L.filter((w) => !w.on).length), "ghi từ lúc tool chạy", "warn"], ["Lần bật lại", fmt(L.filter((w) => w.on).length), "", "ok"]];
  $("stat-kpis").innerHTML = kp.map((k) => `<div class="kpi ${k[3]}"><div class="lab">${k[0]}</div><div class="val">${k[1]}</div><div class="sub">${k[2]}</div></div>`).join("");
  renderBoSw(dk);
}
$("statF").addEventListener("click", (e) => { const b = e.target.closest("button"); if (b) { st.statF = b.dataset.v; render(); } });
$("statDay").addEventListener("change", async (e) => { const v = e.target.value; st.statDay = v && v < DAY ? v : null; PSWV = await pswOf(st.statDay || DAY); render(); });
$("statToday").onclick = () => { st.statDay = null; render(); };
async function statRefresh() {
  const b = $("statF5"); if (b.disabled) return; b.disabled = true; $("statF5t").textContent = "Đang đọc BO…";
  try { await loadPaySet(); lastPS = Date.now(); $("statF5t").textContent = "Đã cập nhật " + new Date().toLocaleTimeString("vi-VN", { hour12: false }); }
  catch (e) { PSERR = e.message; $("statF5t").textContent = "Lỗi: thử lại"; }
  finally { b.disabled = false; render(); setTimeout(() => ($("statF5t").textContent = "Làm mới (F5)"), 3000); }
}
$("statF5").onclick = statRefresh;
// F5 trong tab Trạng thái cổng = đọc lại BO ngay, không tải lại cả trang
document.addEventListener("keydown", (e) => { if (e.key === "F5" && st.tab === "stat" && !e.ctrlKey) { e.preventDefault(); statRefresh(); } });
function renderBoSw(dk) {
  const box = $("maint-bo"), past = dk !== DAY;
  if (past) box.innerHTML = `<div class="card-h"><h3>Trạng thái kênh trên BO</h3><span class="hint">Chỉ xem được trạng thái hiện tại khi xem hôm nay. Bên dưới là lịch sử bật/tắt đã ghi của ngày này.</span></div>`;
  else if (!PSET) box.innerHTML = `<div class="card-h"><h3>Trạng thái kênh trên BO</h3><span class="hint">${PSERR ? "Chưa đọc được: " + esc(PSERR) + ". " : "Đang đọc… "}Nếu lâu không hiện, mở trang <b>Cài đặt nạp tiền</b> (bật/dừng kênh) trên BO một lần để tool học cách đọc.</span></div>`;
  else {
    const types = []; for (const c of PSET) { let t = types.find((x) => x.n === c.type); if (!t) types.push((t = { n: c.type, typeOn: c.typeOn, cs: [] })); t.cs.push(c); }
    const off = PSET.filter((c) => !c.on || !c.typeOn).length;
    const F = (c) => st.statF === "all" || (st.statF === "off") === !(c.on && c.typeOn);
    box.innerHTML = `<div class="card-h"><h3>Trạng thái kênh trên BO</h3><span class="hint">Cập nhật ${new Date(PSAT).toLocaleTimeString("vi-VN", { hour12: false })}</span><span class="r mono"><span class="ok">${fmt(PSET.length - off)} bật</span> · <span class="bad">${fmt(off)} tắt</span></span></div>
      <div class="scroll"><table class="tbl sttbl"><thead><tr><th class="l">Hạng mục</th><th class="l">Nhà thứ 3</th><th class="l">Kênh</th><th class="l">Trạng thái</th><th title="Giờ tool thấy BO bật / tắt kênh này hôm nay">Đổi trạng thái lúc</th><th>% phí</th><th>Tối thiểu (₫)</th><th>Tối đa (₫)</th><th title="Cột Tỷ lệ nạp tiền thành công trên BO">Tỷ lệ thành công (BO)</th></tr></thead><tbody>${types.filter((t) => t.cs.some(F)).map((t) => { const n = t.cs.filter((c) => c.on && t.typeOn).length;
        return `<tr class="grp"><td class="l" colspan="9">${esc(t.n)} <span class="${n ? (n < t.cs.length ? "warn" : "ok") : "bad"}" style="margin-left:8px">${n}/${t.cs.length} bật</span>${t.typeOn ? "" : ' <span class="stp off">HẠNG MỤC TẮT</span>'}</td></tr>` +
          t.cs.filter(F).map((c) => { const on = c.on && t.typeOn, s0 = sinceTxt(c); return `<tr class="${on ? "" : "rbad"}"><td class="l mut">${esc(t.n)}</td><td class="name">${esc(c.merch)}</td><td class="l">${esc(c.desc)}</td><td class="l"><span class="stp ${on ? "on" : "off"}"><i></i>${on ? "ĐANG BẬT" : "ĐANG TẮT"}</span></td><td class="mono">${s0 || "—"}</td><td>${c.fee !== "" && c.fee != null ? esc(c.fee) + "%" : "—"}</td><td>${c.cur === "VND" ? fmt(c.min) : c.min}</td><td>${c.cur === "VND" ? fmt(c.max) : c.max}</td><td>${c.rate ? esc(c.rate) + "%" : "—"}</td></tr>`; }).join(""); }).join("")}</tbody></table></div>`;
  }
  $("stat-hint").textContent = past ? "Ngày " + dk.split("-").reverse().join("/") : "Hôm nay · ghi từ lúc tool chạy";
  pswOf(dk).then((L) => {
    PSWV = L; const rows = [...L].sort((a, b) => b.t - a.t);
    let t = `<thead><tr><th class="l">Giờ</th><th class="l">Hạng mục</th><th class="l">Nhà</th><th class="l">Kênh</th><th class="l">Thay đổi trên BO</th><th>Đã tắt trong</th></tr></thead><tbody>`;
    for (const w of rows) { const prev = w.on ? L.filter((x) => x.key === w.key && !x.on && x.t < w.t).map((x) => x.t).pop() : null; t += `<tr class="${w.on ? "" : "rbad"}"><td class="l mono">${clock(w.t)}</td><td class="l">${esc(w.type)}</td><td class="name">${esc(w.merch)}</td><td class="l">${esc(w.desc)}</td><td class="l">${w.on ? '<span class="pill on">Bật lại</span>' : '<span class="pill badp">Tắt (bảo trì)</span>'}</td><td>${prev != null ? mmss(w.t - prev) : "—"}</td></tr>`; }
    if (!rows.length) t += `<tr><td class="l mut" colspan="6">Chưa ghi nhận lần bật/tắt nào ${dk === DAY ? "từ lúc mở tool hôm nay" : "trong ngày này"}</td></tr>`;
    $("maint-sw").innerHTML = t + "</tbody>";
    const offN = {}; for (const w of L) if (!w.on) { const k = w.merch + " · " + w.type; offN[k] = (offN[k] || 0) + 1; }
    $("maint-sw-sum").textContent = `${fmt(L.filter((w) => !w.on).length)} lần tắt · ${fmt(L.filter((w) => w.on).length)} lần bật lại`;
  });
}
$("sxls").onclick = async () => {
  const F = "Times New Roman", S = (o) => Object.assign({ border: true, font: { name: F, size: 10 }, align: { v: "center", wrap: true } }, o || {});
  const HS = S({ font: { name: F, size: 10, bold: true, color: "FFFFFF" }, fill: "0B2A55", align: { h: "center", v: "center", wrap: true } });
  const dk = st.statDay || DAY, d = dk.split("-").reverse().join("/"), tv = (s) => Math.round(s) / 86400;
  const L = await pswOf(dk);
  const wb = new XLSXW.Book();
  const put = (ws, H, W, rows, fm) => { H.forEach((x, i) => { ws.set(1, i + 1, x, HS); ws.width(i + 1, W[i]); }); rows.forEach((r, i) => r.forEach((v, j) => ws.set(i + 2, j + 1, v, S(fm[j] ? { fmt: fm[j] } : {})))); ws.freeze(2, 1); ws.height(1, 30); };
  if (PSET && dk === DAY) put(wb.sheet("Trạng thái hiện tại"), ["Hạng mục", "Nhà thứ 3", "Kênh", "Trạng thái", "Đổi trạng thái lúc", "% phí", "Tối thiểu", "Tối đa", "Tỷ lệ thành công BO (%)"], [18, 16, 20, 10, 12, 8, 14, 16, 13],
    PSET.map((c) => [c.type, c.merch, c.desc, c.on && c.typeOn ? "Bật" : "Tắt", sinceTxt(c) || "", c.fee !== "" && c.fee != null ? Number(c.fee) : "", c.min, c.max, c.rate ? Number(c.rate) : ""]), [0, 0, 0, 0, 0, "0.00", "0", "0", "0.00"]);
  put(wb.sheet("Lịch sử bật tắt"), ["Ngày", "Giờ", "Hạng mục", "Nhà thứ 3", "Kênh", "Thay đổi"], [12, 10, 18, 16, 20, 12],
    [...L].sort((a, b) => b.t - a.t).map((w) => [d, tv(w.t), w.type, w.merch, w.desc, w.on ? "Bật lại" : "Tắt"]), [0, "hh:mm:ss"]);
  const blob = await wb.blob(), now = new Date();
  const el = document.createElement("a"); el.href = URL.createObjectURL(blob); el.download = `Trang_thai_cong_${dk.slice(8)}-${dk.slice(5, 7)}_${pad(now.getHours())}h${pad(now.getMinutes())}.xlsx`; document.body.appendChild(el); el.click(); el.remove();
};
$("mxls").onclick = async () => {
  if (!MEV.length) { sysmsg("Không có đợt bảo trì nào để tải.", "info"); setTimeout(() => sysmsg(""), 3000); return; }
  const F = "Times New Roman", S = (o) => Object.assign({ border: true, font: { name: F, size: 10 }, align: { v: "center", wrap: true } }, o || {});
  const HS = S({ font: { name: F, size: 10, bold: true, color: "FFFFFF" }, fill: "0B2A55", align: { h: "center", v: "center", wrap: true } });
  const tv = (s) => Math.round(s) / 86400, dk = VIEW || DAY, d = dk.split("-").reverse().join("/"), N = NOWS();
  const ST = { done: "Hoàn tất bảo trì", off: "Đang bảo trì (BO đang tắt)", wait: "BO đã bật lại, chờ đơn thành công", err: VIEW ? "Không thấy hoạt động lại" : "Đang bảo trì (tool phát hiện lỗi)" };
  const wb = new XLSXW.Book();
  const put = (ws, H, W, rows, fm) => { H.forEach((x, i) => { ws.set(1, i + 1, x, HS); ws.width(i + 1, W[i]); }); rows.forEach((r, i) => r.forEach((v, j) => ws.set(i + 2, j + 1, v, S(fm[j] ? { fmt: fm[j] } : {})))); ws.freeze(2, 3); ws.height(1, 30); };
  put(wb.sheet("Theo cổng"), ["Ngày", "Nhà thứ 3", "Cổng nạp", "Kênh", "Số lần bảo trì", "Tổng thời gian", "Đơn lỗi", "Khách", "Tiền (₫)", "Bắt đầu lần đầu", "Hiện tại", "Lý do"], [12, 16, 16, 18, 10, 11, 9, 9, 15, 12, 30, 50],
    MROWS.map((r) => [d, hName(r.hk, r.merch), gName(r.gk, r.type), [...r.descs].join(", "), r.n, r.dur ? tv(r.dur) : null, r.err, r.acc.size, r.amt * 1000, r.pre ? "Tắt từ trước" : tv(r.a), ST[r.last.state] + (r.last.ok != null ? " " + clock(r.last.ok) : ""), whyTxt(r.why)]), [0, 0, 0, 0, "0", "[h]:mm:ss", "0", "0", "0", "hh:mm:ss"]);
  put(wb.sheet("Từng đợt"), ["Ngày", "Nhà thứ 3", "Cổng nạp", "Kênh", "Nguồn", "Bắt đầu", "BO bật lại", "Đơn thành công đầu tiên", "Thời gian bảo trì", "Tình trạng", "Đơn lỗi", "Tiền (₫)", "Lý do", "Tài khoản"], [12, 16, 16, 18, 18, 12, 11, 13, 12, 30, 9, 15, 45, 50],
    MEV.map((x) => [d, hName(x.hk, x.merch), gName(x.gk, x.type), x.descs.join(", "), MSRC[x.src], x.pre ? "Tắt từ trước" : tv(x.a), x.b != null ? tv(x.b) : "", x.ok != null ? tv(x.ok) : "Chưa", x.pre ? null : x.state === "done" ? tv(x.ok - x.a) : VIEW ? null : tv(N - x.a), ST[x.state], x.list.length, x.list.reduce((s, o) => s + o.amt, 0) * 1000, whyTxt(x.why), [...new Set(x.list.map((o) => o.acc))].join(", ")]),
    [0, 0, 0, 0, 0, "hh:mm:ss", "hh:mm:ss", "hh:mm:ss", "[h]:mm:ss", 0, "0", "0"]);
  put(wb.sheet("Đơn lỗi"), ["Ngày", "Nhà thứ 3", "Cổng nạp", "Số lệnh", "Tài khoản", "Kênh", "Số tiền (₫)", "Tạo lúc", "Lý do BO"], [12, 16, 18, 24, 18, 14, 15, 10, 50],
    MEV.flatMap((x) => x.list).sort((a, b) => b.t - a.t).map((o) => [d, HOUSES[o.h].n, GATES[o.g].n, o.no, o.acc, o.ch, o.cur === "VND" ? o.amt * 1000 : o.raw, tv(o.t), o.why || ""]), [0, 0, 0, 0, 0, 0, "0", "hh:mm:ss"]);
  const blob = await wb.blob(), now = new Date();
  const el = document.createElement("a"); el.href = URL.createObjectURL(blob); el.download = `Bao_tri_cong_${dk.slice(8)}-${dk.slice(5, 7)}_${pad(now.getHours())}h${pad(now.getMinutes())}.xlsx`; document.body.appendChild(el); el.click(); el.remove();
};

// Mốc thời gian khi tải dữ liệu cổng nạp: Tạo thời gian (dữ liệu tool đã đọc) / Thời gian thành công / Cập nhật thời gian (đọc lại từ BO)
const BASIS = { create: ["Tạo thời gian", null], ok: ["Thời gian thành công", "nt"], upd: ["Cập nhật thời gian", "ut"] };
try { const v = localStorage.getItem("gbasis"); if (v && BASIS[v]) $("gbasis").value = v; } catch (e) {}
$("gbasis").addEventListener("change", () => { try { localStorage.setItem("gbasis", $("gbasis").value); } catch (e) {} });
// Dò mã timeType của BO cho từng mốc.
//  - Thời gian thành công: mã mà các đơn trả về đều có giờ thành công nằm trong khoảng đã chọn
//  - Cập nhật thời gian: mã còn lại mà trang BO đã gửi khi bạn chọn "Cập nhật thời gian" (tool tự ghi nhớ), hoặc mã khác 0 / khác mã thành công
async function findTimeType(kind, from, to) {
  const s = await chrome.storage.local.get(["timeType_ok", "timeType_upd", "orderTT"]);
  const seen = Object.keys(s.orderTT || {}).map(Number).filter((x) => x !== 0 && !isNaN(x));
  let baseTot = null;
  try { const d0 = await BO.listOrders("VND", from, to, 1, 10, 0); baseTot = Number(d0 && d0.total) || 0; } catch (e) {}
  // mã đúng phải trả số đơn cùng cỡ với số đơn tạo trong khung (không phải hàng trăm nghìn đơn của nhiều ngày)
  const sane = (d) => baseTot == null || (Number(d && d.total) || 0) <= baseTot * 1.5 + 300;
  const probe = async (tt) => { const d = await BO.listOrders("VND", from, to, 1, 50, tt).catch(() => null); return d && sane(d) ? d.list || [] : null; };
  const okTest = (L) => {
    // mã "Thời gian thành công": gần như mọi đơn trả về đã thành công và giờ thành công nằm trong khung (cho lệch nhẹ vài đơn bổ sung / làm tròn giây)
    const w = L.filter((r) => Number(r.notifyTime) > 0), inR = w.filter((r) => r.notifyTime >= from - 60 && r.notifyTime <= to + 60);
    return w.length > 0 && w.length >= L.length * 0.9 && inR.length >= w.length * 0.95;
  };
  let okTT = s.timeType_ok;
  if (okTT != null && !(await probe(okTT))) { okTT = null; await chrome.storage.local.remove("timeType_ok"); }
  if (s.timeType_upd != null && !(await probe(s.timeType_upd))) { s.timeType_upd = null; await chrome.storage.local.remove("timeType_upd"); }
  if (okTT == null || kind === "ok") {
    for (const tt of [...new Set([okTT, ...seen, 1, 2, 3, 4].filter((x) => x != null && x !== 0))]) {
      const L = await probe(tt); if (L && okTest(L)) { okTT = tt; await chrome.storage.local.set({ timeType_ok: tt }); break; }
    }
  }
  if (kind === "ok") { if (okTT != null) return okTT; throw new Error('Chưa dò được mã "Thời gian thành công" của BO. Mở trang Tổng nạp tiền trên BO, chọn "Thời gian thành công" rồi bấm Tìm kiếm một lần, sau đó thử lại.'); }
  if (s.timeType_upd != null) return s.timeType_upd;
  // BO xếp ô chọn theo thứ tự Tạo → Thành công → Cập nhật → Hết giờ, nên mã Cập nhật thường liền sau mã Thành công
  const cand = [...seen.filter((x) => x !== okTT), ...(okTT != null ? [okTT + 1] : []), ...[2, 1, 3].filter((x) => x !== okTT)];
  for (const tt of [...new Set(cand)]) {
    const L = await probe(tt);
    if (L && L.length) { if (seen.includes(tt)) await chrome.storage.local.set({ timeType_upd: tt }); return tt; }
  }
  throw new Error('Chưa dò được mã "Cập nhật thời gian" của BO. Mở trang Tổng nạp tiền trên BO, chọn "Cập nhật thời gian" rồi bấm Tìm kiếm một lần, sau đó thử lại.');
}
async function fetchByBasis(kind, dk, a, b) {
  const D0 = dayStartOf(dk), from = D0 + a, to = D0 + b, f = BASIS[kind][1];
  sysmsg(`Đang dò mốc <b>${BASIS[kind][0]}</b> trên BO…`, "info");
  const tt = await findTimeType(kind, from, to), out = [];
  for (const cur of curs()) {
    let page = 1, pages = 1;
    while (page <= pages) {
      let d;
      try { d = await BO.listOrders(cur, from, to, page, 500, tt); } catch (e) { if (cur === "USDT" && e.kind === "api") break; throw e; }
      const L = (d && d.list) || [], total = Number(d && d.total) || 0;
      if (page === 1) pages = Math.max(1, Math.ceil(total / Math.max(1, L.length || 500)));
      for (const r of L) {
        const o = BO.norm(r, dk, D0, cur), v = o[f];
        if (kind === "ok" && o.st === 2 && v && (v < from || v > to)) continue;   // chắc chắn đúng mốc thành công
        const bt = v && v >= from && v <= to ? v : o.ts;
        o.t = Math.max(0, Math.min(86399, bt - D0)); out.push(o);
      }
      sysmsg(`Đang tải đơn theo <b>${BASIS[kind][0]}</b> từ BO (${cur}): trang ${page}/${pages} · ${fmt(out.length)} đơn <span class="prog"><span style="width:${(page / pages * 100).toFixed(0)}%"></span></span>`, "info");
      if (!L.length) break; page++;
    }
  }
  return out;
}
// Ô chọn Tình trạng đơn hàng khi tải (giống ô "Tình trạng đơn hàng" trên BO)
const nTxt0 = (t) => String(t || "").normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/gi, "d").toLowerCase();
const OSTS = [
  ["pend", "Thanh toán đang chờ", (o, t) => t.includes("dang cho") || (!t && o.st === 1)],
  ["exp", "Hết thời gian nạp tiền", (o, t) => t.includes("het thoi gian") || (!t && o.st === 4)],
  ["fail", "Đặt cọc không thành công", (o, t) => t.includes("khong thanh cong") || (!t && o.st === 3)],
  ["ok", "Đặt cọc thành công", (o) => o.st === 2],
  ["mcancel", "Thành viên bị hủy", (o, t) => t.includes("thanh vien") && t.includes("huy")],
  ["bcancel", "Hủy trong nền", (o, t) => t.includes("huy trong nen") || (!t && o.st === 5)],
  ["review", "Bổ sung đang được xem xét", (o, t) => t.includes("xem xet")]
];
let GSTAT = new Set(["ok"]);
try { const v = JSON.parse(localStorage.getItem("gstat") || "null"); if (Array.isArray(v) && v.length) GSTAT = new Set(v); } catch (e) {}
const ostKey = (o) => { const t = nTxt0(o.psl); const m = OSTS.find(([, , f]) => f(o, t)); return m ? m[0] : ({ 1: "pend", 2: "ok", 3: "fail", 4: "exp", 5: "bcancel" })[o.st] || "pend"; };
function renderGstat() {
  const cnt = {}; for (const o of inTf("gate")) { if (st.gate !== -1 && o.g !== st.gate) continue; const k = ostKey(o); cnt[k] = (cnt[k] || 0) + 1; }
  const all = GSTAT.size === OSTS.length;
  $("gstatList").innerHTML = `<label class="all"><input type="checkbox" data-all ${all ? "checked" : ""}> Chọn tất cả</label>` + OSTS.map(([k, n]) => `<label><input type="checkbox" data-k="${k}" ${GSTAT.has(k) ? "checked" : ""}> ${n}<small>${cnt[k] ? fmt(cnt[k]) : ""}</small></label>`).join("");
  $("gstatTxt").textContent = all ? "Tất cả tình trạng" : GSTAT.size ? OSTS.filter(([k]) => GSTAT.has(k)).map((x) => x[1]).join(", ") : "Chưa chọn";
}
$("gstatList").addEventListener("change", (e) => {
  const i = e.target; if (i.dataset.all != null) GSTAT = new Set(i.checked ? OSTS.map((x) => x[0]) : []); else if (i.checked) GSTAT.add(i.dataset.k); else GSTAT.delete(i.dataset.k);
  try { localStorage.setItem("gstat", JSON.stringify([...GSTAT])); } catch (_) {}
  renderGstat();
});
$("gstat").addEventListener("toggle", () => { if ($("gstat").open) renderGstat(); });
document.addEventListener("click", (e) => { if ($("gstat").open && !e.target.closest("#gstat")) $("gstat").open = false; });
renderGstat();
// Ô chọn Nhà bên thứ 3 khi tải (giống ô "Nền tảng thanh toán của bên thứ 3" trên BO). Rỗng = tất cả nhà
let GHOUSE = new Set();
try { const v = JSON.parse(localStorage.getItem("ghouse") || "null"); if (Array.isArray(v)) GHOUSE = new Set(v); } catch (e) {}
function houseOpts() {
  const m = new Map(); HOUSES.forEach((h) => m.set(h.k, h.n));
  if (PSET) PSET.forEach((c) => { if (!m.has(c.hk)) m.set(c.hk, c.merch); });
  return [...m.entries()];
}
function renderGhouse() {
  const cnt = {}; for (const o of inTf("gate")) { if (st.gate !== -1 && o.g !== st.gate) continue; const k = HOUSES[o.h] ? HOUSES[o.h].k : ""; cnt[k] = (cnt[k] || 0) + 1; }
  const opts = houseOpts(), all = !GHOUSE.size || opts.every(([k]) => GHOUSE.has(k));
  $("ghouseList").innerHTML = `<label class="all"><input type="checkbox" data-all ${all ? "checked" : ""}> Chọn tất cả</label>` + opts.map(([k, n]) => `<label><input type="checkbox" data-k="${esc(k)}" ${all || GHOUSE.has(k) ? "checked" : ""}> ${esc(n)}<small>${cnt[k] ? fmt(cnt[k]) : ""}</small></label>`).join("");
  $("ghouseTxt").textContent = all ? "Tất cả nhà" : opts.filter(([k]) => GHOUSE.has(k)).map((x) => x[1]).join(", ") || "Chưa chọn";
}
$("ghouseList").addEventListener("change", (e) => {
  const i = e.target, opts = houseOpts().map((x) => x[0]);
  if (i.dataset.all != null) GHOUSE = new Set(i.checked ? [] : ["__none__"]);
  else { if (!GHOUSE.size) GHOUSE = new Set(opts); GHOUSE.delete("__none__"); if (i.checked) GHOUSE.add(i.dataset.k); else GHOUSE.delete(i.dataset.k); if (opts.every((k) => GHOUSE.has(k))) GHOUSE = new Set(); else if (!GHOUSE.size) GHOUSE = new Set(["__none__"]); }
  try { localStorage.setItem("ghouse", JSON.stringify([...GHOUSE])); } catch (_) {}
  renderGhouse();
});
$("ghouse").addEventListener("toggle", () => { if ($("ghouse").open) renderGhouse(); });
document.addEventListener("click", (e) => { if ($("ghouse").open && !e.target.closest("#ghouse")) $("ghouse").open = false; });
const houseOk = (o) => !GHOUSE.size || GHOUSE.has(hkey(o.merch));
renderGhouse();
// Tính theo Thời gian thành công / Cập nhật thời gian ngay từ dữ liệu đã lưu trong máy (không đọc lại BO):
// lấy đơn của ngày đang chọn + ngày hôm trước (đơn tạo tối hôm trước nhưng thành công sau 00:00)
async function localByBasis(kind, dk, a, b) {
  const D0 = dayStartOf(dk), from = D0 + a, to = D0 + b;
  const prev = dayKey(new Date((D0 - 43200) * 1000));
  const cur = dk === DAY ? [...ORD.values()] : dk === VIEW ? [...VORD.values()] : await Store.dayOrders(dk).catch(() => []);
  const old = await Store.dayOrders(prev).catch(() => []);
  const seen = new Set(), out = [];
  for (const o0 of [...cur, ...old]) {
    if (seen.has(o0.no)) continue; seen.add(o0.no);
    const o = { ...o0 }; if (o.st == null || o.ps != null) o.st = BO.stCode(Number(o.ps), o.psl);
    const okT = o.st === 2 ? o.ts + (o.sp || 0) : 0;
    const ut = o.ut > 1e11 ? Math.floor(o.ut / 1000) : o.ut;
    const bt = kind === "ok" ? okT : (ut >= D0 - 86400 && ut <= D0 + 2 * 86400 ? ut : 0) || okT || o.ts;
    if (!bt || bt < from || bt > to) continue;
    o.t = bt - D0; out.push(o);
  }
  GXNOTE = old.length ? "" : `Lưu ý: máy chưa lưu dữ liệu ngày ${prev.split("-").reverse().join("/")}, nên các đơn tạo tối hôm trước nhưng thành công sau 00:00 chưa được tính.`;
  return out;
}
let gxBusy = false, GXNOTE = "";
$("gxls").onclick = async () => {
  if (gxBusy) return; gxBusy = true;
  const btn = $("gxls"); btn.disabled = true;
  try {
    const kind = $("gbasis").value, dk = VIEW || DAY, [a, b] = tfRange("gate"), gn = st.gate >= 0 ? GATES[st.gate].n : "", gk = st.gate >= 0 ? GATES[st.gate].k : null;
    let list;
    if (kind === "create") list = inTf("gate").filter((o) => st.gate === -1 || o.g === st.gate);
    else list = (await localByBasis(kind, dk, a, b)).filter((o) => !gk || (nk(o.gate) || "khac") === gk).filter((o) => SET.exFake === false || !FAKESET.has(o.acc));
    sysmsg("");
    if (!GSTAT.size) { sysmsg("Chọn ít nhất 1 tình trạng đơn hàng.", "info"); setTimeout(() => sysmsg(""), 3000); return; }
    if (GHOUSE.has("__none__")) { sysmsg("Chọn ít nhất 1 nhà bên thứ 3.", "info"); setTimeout(() => sysmsg(""), 3000); return; }
    list = list.filter((o) => GSTAT.has(ostKey(o)) && houseOk(o));
    if (!list.length) { sysmsg("Không có đơn nào khớp tình trạng đã chọn trong khung thời gian này.", "info"); setTimeout(() => sysmsg(""), 3000); return; }
    const stTxt = GSTAT.size === OSTS.length ? "tất cả tình trạng" : OSTS.filter(([k]) => GSTAT.has(k)).map((x) => x[1]).join(", ");
    const hsTxt = GHOUSE.size ? houseOpts().filter(([k]) => GHOUSE.has(k)).map((x) => x[1]).join(", ") : "tất cả nhà";
    const title = `${BASIS[kind][0]} ${dk.split("-").reverse().join("/")} · ${clock(a)} → ${clock(b)}${gn ? " · cổng " + gn : " · tất cả cổng"} · ${hsTxt} · ${stTxt} · ${fmt(list.length)} đơn`;
    const blob = await Report.gateData(list, dk, { title, gate: gn, basis: BASIS[kind][0], status: stTxt });
    const el = document.createElement("a"); el.href = URL.createObjectURL(blob);
    el.download = `Du_lieu_cong_nap_${{ create: "tao", ok: "thanhcong", upd: "capnhat" }[kind]}_${dk.slice(8)}-${dk.slice(5, 7)}_${clock(a).slice(0, 5).replace(":", "h")}-${clock(b).slice(0, 5).replace(":", "h")}${gn ? "_" + nk(gn) : ""}.xlsx`;
    document.body.appendChild(el); el.click(); el.remove(); setTimeout(() => URL.revokeObjectURL(el.href), 4000);
    if (kind !== "create" && GXNOTE) { sysmsg(GXNOTE, "info"); setTimeout(() => sysmsg(""), 8000); }
  } catch (e) { sysmsg("Không tải được: " + esc(e.message), "err"); }
  finally { gxBusy = false; btn.disabled = false; }
};

// ===== XEM NGÀY CŨ =====
function viewBanner(extra) {
  sysmsg(`Đang xem dữ liệu <b>ngày ${VIEW.split("-").reverse().join("/")}</b> (${fmt(VORD.size)} đơn, đã lưu trong máy). Số dư và cảnh báo trực tiếp vẫn chạy nền cho hôm nay.${extra || ""}`, "info", ` <button class="btn" id="reloadDay" title="Đọc lại cả ngày từ BO để cập nhật đơn thành công muộn / bổ sung sau khi ngày kết thúc">Đọc lại ngày này từ BO</button> <button class="btn" id="backToday">Về hôm nay</button>`);
  const b = document.getElementById("backToday"); if (b) b.onclick = () => setView(null);
  const r = document.getElementById("reloadDay"); if (r) r.onclick = async () => { const dk = VIEW; await Store.setDay(dk, { day: dk, complete: false, at: Date.now() }); VIEW = null; await setView(dk); };
}
let viewLoading = false;
async function setView(dk) {
  if (!dk || dk >= DAY) { VIEW = null; VORD.clear(); syncPicks(); $("dayLbl").textContent = "Hôm nay"; sysmsg(""); rebuild(); render(); $("readCount").textContent = fmt(ORD.size); return; }
  if (viewLoading) return;
  viewLoading = true;
  try {
    const d0 = dayStartOf(dk);
    const info = await Store.getDay(dk);
    let list = await Store.dayOrders(dk);
    if (!info || !info.complete || !list.length) {
      // chưa có đủ trong máy -> tải 1 lần từ BO rồi lưu lại, lần sau mở ngay
      for (const cur of curs()) {
        try { await fetchRange(cur, dk, d0, d0 + 86399, 0, (p, ps, got, total) => sysmsg(`Đang tải dữ liệu ngày ${dk.split("-").reverse().join("/")} từ BO (${cur}): trang ${p}/${ps} · ${fmt(got)}/${fmt(total)} đơn <span class="prog"><span style="width:${(p / ps * 100).toFixed(0)}%"></span></span>`, "info")); }
        catch (e) { if (!(cur === "USDT" && e.kind === "api")) throw e; }
      }
      await verifyDay(dk);
      await Store.setDay(dk, { day: dk, complete: true, verified: 1, at: Date.now() });
      list = await Store.dayOrders(dk);
    } else if (!info.verified) {
      // ngày đã lưu từ bản cũ: đối chiếu từng giờ với BO một lần, giờ nào thiếu thì đọc lại
      const n = await verifyDay(dk); await Store.setDay(dk, { ...info, verified: 1 }); if (n) list = await Store.dayOrders(dk);
    }
    VIEW = dk; VIEW0 = d0; VORD.clear();
    for (const o of list) { o.st = BO.stCode(Number(o.ps), o.psl); VORD.set(o.no, o); }
    for (const k in st.tf) st.tf[k] = "day";
    $("dayLbl").textContent = "Ngày"; $("dayRange").textContent = dk.slice(8) + "/" + dk.slice(5, 7) + " 00:00 → 23:59"; $("readCount").textContent = fmt(VORD.size);
    syncPicks(); rebuild(); segs(); render(); viewBanner();
  } catch (e) { sysmsg("Không tải được dữ liệu ngày này: " + esc(e.message), "err"); }
  finally { viewLoading = false; }
}
// ô chọn ngày ở thanh trên và trong từng mục đều đồng bộ với nhau
const PICKS = () => [$("viewDay"), ...document.querySelectorAll(".dayPick")];
function syncPicks() { PICKS().forEach((p) => { p.max = DAY; p.value = VIEW || DAY; }); }
$("viewDay").addEventListener("change", (e) => setView(e.target.value)); // ô ngày trong từng mục chỉ áp dụng khi bấm Tìm
$("viewToday").onclick = () => setView(null);
document.querySelectorAll(".dayNow").forEach((b) => (b.onclick = async () => { const k = b.closest(".qrow").dataset.k; await setView(null); st.tf[k] = TF()[3][0]; segs(); render(); }));
syncPicks();

// ===== điều hướng =====
// ===== KIỂM SOÁT NẠP + THỨ TỰ CỔNG =====
// màu cố định cho từng nhà (theo tên) và từng cổng nạp
const HPAL = ["#2563eb", "#e11d48", "#7c3aed", "#0891b2", "#ea580c", "#16a34a", "#db2777", "#ca8a04", "#0d9488", "#9333ea", "#dc2626", "#4f46e5", "#65a30d", "#0284c7", "#c2410c", "#be185d", "#059669", "#7e22ce"];
const HFIX = { bb168pay: 0, gopay: 1, vippay: 2, jypay: 3, okpay: 4, fastpay: 5, "33pay": 6, "888pay": 7, v6pay: 8, payopay: 9, a8pay: 10, pppay: 11, vn196pay: 12, rcpay: 13, u2pay2: 14, whpay: 15 };
const hColor = (merch) => { const k = hkey(merch); if (HFIX[k] != null) return HPAL[HFIX[k]]; let h = 0; for (const c of k) h = (h * 31 + c.charCodeAt(0)) >>> 0; return HPAL[h % HPAL.length]; };
const GCOL = { quetmanganhang: "#2563eb", napnhanh: "#0d9488", thecao: "#ea580c", zalopay: "#0284c7", viettelpay: "#dc2626", momopay: "#a50064", momo: "#a50064", usdt: "#26a17b" };
const gColor = (gk) => GCOL[gk] || (gk && gk.includes("usdt") ? "#26a17b" : "#475569");
const ctl = { h: "", g: "", st: "all", every: 5, page: 0, seen: new Set(), first: true, liveAt: 0, rank: "" };
try { const v = +localStorage.getItem("ctlEvery"); if ([3, 5, 10].includes(v)) ctl.every = v; } catch (e) {}
const chKey = (merch, desc) => hkey(merch) + "|" + nk(desc);
// kênh đang bảo trì: BO tắt kênh / tắt cả hạng mục, hoặc tool phát hiện cổng lỗi (giống tab Bảo trì cổng)
let MTC = { at: 0, ch: new Map(), hg: new Map() };
function maintMap() {
  if (Date.now() - MTC.at < 20e3) return MTC;
  const ch = new Map(), hg = new Map();
  for (const c of PSET || []) if (!c.on || !c.typeOn) { const p = PSTATE[c.key]; ch.set(chKey(c.merch, c.desc), { why: !c.typeOn ? "BO đang tắt cả hạng mục " + c.type : "BO đang tắt kênh", since: p && p.since ? p.since : PSFIRST || nowU() }); }
  try { for (const x of buildIncidents(orders.filter(isMaint), PSW, true)) if (x.state === "err" || x.state === "off") hg.set(x.hk + "|" + x.gk, { why: x.state === "off" ? "BO đang tắt" : "Cổng lỗi (tool phát hiện) từ " + clock(x.a), since: DAY0 + x.a }); } catch (e) {}
  MTC = { at: Date.now(), ch, hg }; return MTC;
}
function maintOf(o) {
  const M = maintMap();
  const a = M.ch.get(chKey(o.merch, o.ch)); if (a && o.ts >= a.since) return a.why;
  const b = M.hg.get(hkey(o.merch) + "|" + (nk(o.gate) || "khac")); if (b && o.ts >= b.since) return b.why;
  return "";
}
const CST = [["all", "Tất cả"], ["pend", "Đang chờ"], ["ok", "Thành công"], ["bad", "Thất bại / hết hạn"]];
const ostTag = (o) => { const k = stOf(o); return k === "ok" ? `<span class="tag ok">${esc(o.psl || "Đặt cọc thành công")}</span>` : k === "pend" ? `<span class="tag warn">${esc(o.psl || "Thanh toán đang chờ")}</span>` : `<span class="tag ${k === "err" ? "bad" : "mut"}">${esc(o.psl || (k === "err" ? "Thất bại" : "Hết hạn"))}</span>`; };
function renderCtl() {
  if (VIEW) { $("ctlHint").textContent = "Tab này chỉ theo dõi hôm nay — bấm Hôm nay để quay lại."; }
  const N = NOWS(), now = nowU(), src = VIEW ? [...VORD.values()] : [...ORD.values()];
  const recent = src.filter((o) => now - o.ts <= 600);
  const pendOf = (o) => o.st === 1 && N - o.t <= ABANDON;
  // nhà: theo danh sách BO (PSET) + nhà có đơn hôm nay
  const hs = new Map();
  for (const c of PSET || []) if (!hs.has(hkey(c.merch))) hs.set(hkey(c.merch), c.merch);
  for (const o of src) if (!hs.has(hkey(o.merch))) hs.set(hkey(o.merch), o.merch);
  const hn = {}; for (const o of recent) { const k = hkey(o.merch); (hn[k] ??= [0, 0])[0]++; }
  for (const o of src) if (pendOf(o)) { const k = hkey(o.merch); (hn[k] ??= [0, 0])[1]++; }
  const tot = [recent.length, src.filter(pendOf).length];
  const hList = [...hs.entries()].sort((a, b) => ((hn[b[0]] || [0])[0] - (hn[a[0]] || [0])[0]) || a[1].localeCompare(b[1]));
  $("ctlH").innerHTML = `<button class="chb all ${!ctl.h ? "on" : ""}" data-ch=""><b>Tất cả</b><small>${fmt(tot[0])} đơn · chờ ${fmt(tot[1])}</small></button>` + hList.map(([k, n]) => {
    const [a, p] = hn[k] || [0, 0], off = PSET && !PSET.some((c) => hkey(c.merch) === k && c.on && c.typeOn);
    return `<button class="chb ${ctl.h === k ? "on" : ""}" data-ch="${esc(k)}" style="--hc:${hColor(n)}"><b><i class="d ${off ? "o" : p > 8 ? "r" : p > 3 ? "w" : ""}"></i>${esc(n)}</b><small>${fmt(a)} đơn · chờ ${fmt(p)}${off ? " · tắt" : ""}</small></button>`;
  }).join("");
  // cổng nạp (hạng mục) theo thứ tự BO
  const gs = new Map();
  for (const c of [...(PSET || [])].sort((a, b) => b.tw - a.tw)) if (!gs.has(c.gk)) gs.set(c.gk, c.type);
  for (const o of src) { const k = nk(o.gate) || "khac"; if (!gs.has(k)) gs.set(k, o.gate); }
  const inH = (o) => !ctl.h || hkey(o.merch) === ctl.h;
  // luôn hiện đủ các cổng; cổng nhà đang chọn không có kênh thì làm mờ. Số đơn = đơn hôm nay khớp bộ lọc nhà
  const gn = {}; for (const o of src) if (inH(o)) { const k = nk(o.gate) || "khac"; gn[k] = (gn[k] || 0) + 1; }
  const hasG = (k) => !ctl.h || (PSET || []).some((c) => c.gk === k && hkey(c.merch) === ctl.h) || gn[k] > 0;
  $("ctlG").innerHTML = `<button class="cgb ${!ctl.g ? "on" : ""}" data-cg="">Tất cả</button>` + [...gs.entries()].map(([k, n]) => `<button class="cgb ${ctl.g === k ? "on" : ""}" data-cg="${esc(k)}" style="${hasG(k) ? "" : "opacity:.45"}" title="${hasG(k) ? "" : "Nhà đang chọn không có kênh ở cổng này"}">${esc(n)}<small>${fmt(gn[k] || 0)} đơn</small></button>`).join("");
  // cảnh báo: đơn 30 phút gần nhất vào cổng đang bảo trì
  const mt = {}; let mtn = 0;
  for (const o of src) { if (now - o.ts > 1800) continue; const w = maintOf(o); if (!w) continue; const k = o.merch + " · " + (o.ch || o.gate); (mt[k] ??= { n: 0, w, last: 0 }).n++; mt[k].last = Math.max(mt[k].last, o.ts); mtn++; }
  const mk = Object.keys(mt).sort((a, b) => mt[b].last - mt[a].last);
  $("ctlAl").innerHTML = mk.length ? `<div class="ctl-alert"><span class="l">ĐỎ</span><div><strong>${fmt(mtn)} đơn khách nạp vào cổng đang bảo trì (30 phút gần nhất)</strong>${mk.map((k) => `<div>• <b>${esc(k)}</b>: ${mt[k].n} đơn, gần nhất ${clock(mt[k].last - DAY0)} — ${esc(mt[k].w)}. Cần tắt kênh hoặc kéo xuống trên BO.</div>`).join("")}</div></div>` : "";
  $("cnt-ctl").textContent = mtn;
  if (mk.length && SET.sound && !VIEW) { const sig = mk.map((k) => k + mt[k].n).join(); if (ctl.mtSig && ctl.mtSig !== sig && mtn > (ctl.mtN || 0)) { beep(660, [0], 0.4); } ctl.mtSig = sig; ctl.mtN = mtn; }
  // bảng đơn
  $("ctlSt").innerHTML = CST.map(([k, n]) => `<button aria-pressed="${ctl.st === k}" data-cs="${k}">${n}</button>`).join("");
  $("ctlEv").innerHTML = [3, 5, 10].map((v) => `<button aria-pressed="${ctl.every === v}" data-ce="${v}">${v}s</button>`).join("");
  const q = ($("ctlQ").value || "").trim().toLowerCase();
  let list = src.filter((o) => inH(o) && (!ctl.g || (nk(o.gate) || "khac") === ctl.g) && (ctl.st === "all" || (ctl.st === "pend" ? stOf(o) === "pend" : ctl.st === "ok" ? o.st === 2 : stOf(o) === "err" || stOf(o) === "aband")) && (!q || o.no.includes(q) || String(o.acc).toLowerCase().includes(q)));
  list.sort((a, b) => b.ts - a.ts || (b.no > a.no ? 1 : -1));
  const K = [(o) => o.no, (o) => o.acc, (o) => stOf(o), (o) => o.gate, (o) => o.merch, (o) => o.ch, (o) => o.orig ?? o.amt, (o) => o.amt, (o) => o.ts, (o) => o.nt || (o.st === 2 ? o.ts + o.sp : null), (o) => o.lvl, (o) => o.cur, (o) => o.op];
  list = TSort.sort("ctlTbl", list, K);
  const show = list.slice(0, ctl.limit || 300);
  const fresh = new Set(); if (!ctl.first) for (const o of show.slice(0, 60)) if (!ctl.seen.has(o.no)) fresh.add(o.no);
  for (const o of show.slice(0, 300)) ctl.seen.add(o.no); if (ctl.seen.size > 5000) ctl.seen = new Set(show.map((o) => o.no)); ctl.first = false;
  // chỉ hiện giờ:phút:giây; đơn của ngày khác mới kèm ngày/tháng để khỏi nhầm
  const D0c = VIEW ? VIEW0 : DAY0, dt = (u) => { if (!u) return "—"; const d = new Date(u * 1000), t = d.toLocaleTimeString("vi-VN", { hour12: false }); return u >= D0c && u < D0c + 86400 ? t : pad(d.getDate()) + "/" + pad(d.getMonth() + 1) + " " + t; };
  const money = (o, v) => (o.cur === "VND" ? fmt(v * 1000) : Number(v || 0).toLocaleString("vi-VN", { maximumFractionDigits: 2 }));
  let t = `<thead><tr><th class="l">Số lệnh</th><th class="l">Tài khoản thành viên</th><th class="l">Tình trạng đơn hàng</th><th class="l">Hạng mục nạp tiền</th><th class="l">Thanh toán ba bên</th><th class="l">Kênh</th><th>Số lượng ban đầu</th><th>Số tiền trên lệnh</th><th>Tạo thời gian</th><th>Thời gian thành công</th><th class="l">Cấp độ thành viên</th><th>Tiền tệ</th><th class="l">Người thao tác</th></tr></thead><tbody>`;
  for (const o of show) {
    const w = maintOf(o);
    t += `<tr class="${fresh.has(o.no) ? "new" : ""} ${w ? "mt" : ""}"${w ? ` title="${esc(w)}"` : ""}><td class="l mono">${esc(o.no)}</td><td class="name">${esc(o.acc)}</td><td class="l">${ostTag(o)}${w ? '<span class="tag mtt">CỔNG BẢO TRÌ</span>' : ""}</td><td class="l">${esc(o.gate)}</td><td class="l" style="--hc:${hColor(o.merch)}"><span class="hdot"></span><span class="hn">${esc(o.merch)}</span>${o.mc ? `<small>${esc(o.mc)}</small>` : ""}</td><td class="l">${esc(o.ch)}</td><td><b>${money(o, o.orig ?? o.raw)}</b></td><td>${Number(o.raw || 0).toLocaleString("vi-VN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td><td>${dt(o.ts)}</td><td>${dt(o.nt || (o.st === 2 ? o.ts + o.sp : 0))}</td><td class="l">${esc(o.lvl || "—")}</td><td>${esc(o.cur)}</td><td class="l">${esc(o.op || "—")}</td></tr>`;
  }
  if (!show.length) t += `<tr><td class="l mut" colspan="13">Chưa có đơn khớp bộ lọc.</td></tr>`;
  if (list.length > show.length) t += `<tr><td colspan="13" style="text-align:center;padding:12px"><button class="btn" data-cmore>Xem thêm ${fmt(Math.min(300, list.length - show.length))} đơn cũ hơn (còn ${fmt(list.length - show.length)})</button></td></tr>`;
  $("ctlTbl").innerHTML = t + "</tbody>";
  const hName = ctl.h ? (hs.get(ctl.h) || ctl.h) : "Tất cả nhà", gName = ctl.g ? (gs.get(ctl.g) || ctl.g) : "Tất cả cổng";
  if (!VIEW) $("ctlHint").textContent = `${hName} · ${gName} · hôm nay · mới nhất trên cùng${list.length > show.length ? ` · hiện ${fmt(show.length)} đơn mới nhất` : ""}`;
  $("ctlSum").textContent = `${fmt(list.length)} đơn · ${fmt(list.reduce((s, o) => s + (o.cur === "VND" ? o.amt : 0), 0) * 1000)} ₫${fresh.size ? ` · ${fresh.size} đơn mới` : ""}`;
  const lag = ctl.liveAt ? Math.round((Date.now() - ctl.liveAt) / 1000) : null;
  $("ctlLive").className = "ctl-live" + (lag == null || lag > ctl.every * 3 ? " lag" : "");
  $("ctlLive").textContent = ctl.liveAt ? "cập nhật " + new Date(ctl.liveAt).toLocaleTimeString("vi-VN", { hour12: false }) : "đang kết nối…";
}
$("ctlH").onclick = (e) => { const b = e.target.closest("[data-ch]"); if (b) { ctl.h = b.dataset.ch; ctl.g = ""; ctl.limit = 300; ctl.first = true; renderCtl(); } };
$("ctlG").onclick = (e) => { const b = e.target.closest("[data-cg]"); if (b) { ctl.g = b.dataset.cg; ctl.limit = 300; ctl.first = true; renderCtl(); } };
$("ctlSt").onclick = (e) => { const b = e.target.closest("[data-cs]"); if (b) { ctl.st = b.dataset.cs; ctl.limit = 300; ctl.first = true; renderCtl(); } };
$("ctlEv").onclick = (e) => { const b = e.target.closest("[data-ce]"); if (b) { ctl.every = +b.dataset.ce; try { localStorage.setItem("ctlEvery", ctl.every); } catch (_) {} renderCtl(); } };
$("ctlQ").addEventListener("input", () => { ctl.limit = 300; renderCtl(); });
$("ctlTbl").addEventListener("click", (e) => { if (e.target.closest("[data-cmore]")) { ctl.limit = (ctl.limit || 300) + 300; renderCtl(); } });
TSort.full("ctlTbl", () => renderCtl());
// đọc nhanh đơn mới nhất khi đang mở tab Kiểm soát nạp
let ctlBusy = false, ctlLast = 0;
setInterval(async () => {
  if (st.tab !== "ctl" || VIEW || !licensed || ctlBusy || document.hidden) return;
  if (Date.now() - ctlLast < ctl.every * 1000 - 200) return;
  ctlBusy = true; ctlLast = Date.now();
  try {
    for (const cur of curs()) {
      if (cur === "USDT" && !usdtOk) continue;
      let d; try { d = await BO.listOrders(cur, DAY0, DAY0 + 86399, 1, 50); } catch (e) { if (cur === "USDT" && e.kind === "api") continue; throw e; }
      const L = (d && d.list) || [];
      await ingest(L, cur, DAY, DAY0);
    }
    ctl.liveAt = Date.now();
  } catch (e) { /* lỗi đã báo ở lượt quét chính */ }
  finally { ctlBusy = false; if (st.tab === "ctl") renderCtl(); }
}, 1000);
// BO vừa đổi thứ tự / bật tắt kênh → đọc lại ngay
chrome.storage.onChanged.addListener((ch) => { if (ch.psMovedAt && licensed) { setTimeout(async () => { try { await loadPaySet(); MTC.at = 0; if (st.tab === "rank" || st.tab === "ctl" || st.tab === "stat") render(); } catch (e) {} }, 800); } });
setInterval(async () => { if ((st.tab === "rank" || st.tab === "ctl") && licensed && !document.hidden && Date.now() - PSAT > 20e3) { try { await loadPaySet(); MTC.at = 0; if (st.tab === "rank") renderRank(); } catch (e) {} } }, 5000);

function renderRank() {
  if (!PSET) { $("rkHd").innerHTML = ""; $("rkList").innerHTML = `<div class="empty" style="padding:20px">${PSERR ? "Không đọc được cấu hình kênh trên BO: " + esc(PSERR) : "Đang đọc cấu hình kênh trên BO…"}</div>`; return; }
  const M = maintMap(), now = nowU(), N = NOWS();
  const types = new Map();
  for (const c of [...PSET].sort((a, b) => b.tw - a.tw || a.rank - b.rank)) { if (!types.has(c.gk)) types.set(c.gk, { name: c.type, typeOn: c.typeOn, list: [] }); types.get(c.gk).list.push(c); }
  for (const T of types.values()) T.list.sort((a, b) => a.rank - b.rank);
  if (!ctl.rank || !types.has(ctl.rank)) ctl.rank = types.keys().next().value || "";
  const stat = {}; for (const o of ORD.values()) { const k = chKey(o.merch, o.ch); const s = (stat[k] ??= { n10: 0, pend: 0 }); if (now - o.ts <= 600) s.n10++; if (o.st === 1 && N - o.t <= ABANDON) s.pend++; }
  const mtOf = (c) => (M.ch.get(chKey(c.merch, c.desc)) || M.hg.get(hkey(c.merch) + "|" + c.gk) || {}).why || "";
  const headOf = (T) => T.list.find((c) => c.on && c.typeOn && !mtOf(c));
  $("rkHd").innerHTML = [...types.entries()].map(([k, T]) => { const h = headOf(T); return `<button class="rkh ${ctl.rank === k ? "on" : ""}" data-rk="${esc(k)}" style="--gc:${gColor(k)};--hc:${h ? hColor(h.merch) : "#94a3b8"}"><b>${esc(T.name)}</b><span class="h2"><i></i>Đầu: <em>${h ? esc(h.merch) : "—"}</em>${h ? " · " + esc(h.desc) : ""}</span><span class="sub">${T.list.length} kênh · ${T.list.filter((c) => c.on && c.typeOn).length} đang bật${T.typeOn ? "" : " · hạng mục đang tắt"}</span></button>`; }).join("");
  const T = types.get(ctl.rank); if (!T) return;
  $("rkT").textContent = T.name; $("rkT").style.color = gColor(ctl.rank);
  $("rkAt").textContent = PSAT ? "Đọc BO lúc " + new Date(PSAT).toLocaleTimeString("vi-VN", { hour12: false }) : "";
  const head = headOf(T);
  $("rkList").innerHTML = `<div class="rkr h"><span style="text-align:center">Thứ tự</span><span></span><span>Nhà · kênh</span><span>Trạng thái</span><span style="text-align:right">Đơn 10 phút</span><span style="text-align:right">Đang chờ</span></div>` + T.list.map((c) => {
    const w = mtOf(c), on = c.on && c.typeOn, first = c === head, s = stat[chKey(c.merch, c.desc)] || { n10: 0, pend: 0 };
    return `<div class="rkr ${first ? "first" : ""} ${on ? "" : "offr"} ${w && on ? "mtr" : ""}" style="--hc:${hColor(c.merch)}"><span class="n">${c.rank}</span><span class="cb"></span><span class="nm">${esc(c.merch)}${first ? '<span class="badge">ĐANG NHẬN ĐƠN</span>' : ""}<small>${esc(c.desc)}${c.fee != null && c.fee !== "" ? " · phí " + esc(c.fee) + "%" : ""}${c.rate != null && c.rate !== "" ? " · BO " + esc(c.rate) + "%" : ""}</small></span><span class="rks ${w && on ? "mt" : on ? "on" : "off"}" ${w ? `title="${esc(w)}"` : ""}>${w && on ? "BẢO TRÌ" : on ? "Đang bật" : "Đang tắt"}</span><span class="v">${fmt(s.n10)}</span><span class="v ${s.pend > 5 ? "bad" : ""}">${fmt(s.pend)}</span></div>`;
  }).join("");
}
$("rkHd").onclick = (e) => { const b = e.target.closest("[data-rk]"); if (b) { ctl.rank = b.dataset.rk; renderRank(); } };

function render() {
  derive(); pendBadge();
  ({ home: renderHome, cb: renderCb, house: renderHouse, gate: renderGate, speed: renderSpeed, pend: renderPend, fee: renderFee, fake: renderFake, maint: renderMaint, stat: renderStat, ctl: renderCtl, rank: renderRank })[st.tab]();
  if (st.tab !== "ctl") { try { let n = 0; const now = nowU(); for (const o of ORD.values()) if (now - o.ts <= 1800 && maintOf(o)) n++; $("cnt-ctl").textContent = n; } catch (e) {} }
  if (st.tab !== "stat") $("cnt-stat").textContent = PSET ? PSET.filter((c) => !c.on || !c.typeOn).length : 0;
  if (st.tab !== "maint") $("cnt-maint").textContent = maintActive();
  if (st.tab !== "fake") $("cnt-fake").textContent = fakeRows(ALL).filter((r) => r.lv !== "mark").length;
  if (st.tab !== "home") $("cnt-alert").textContent = alerts().length;
  if (st.tab !== "cb") { try { $("cnt-cb").textContent = cbItems().filter((x) => x.step <= 2).length; } catch (e) {} }
}
// chiều cao thanh tab đang dính trên cùng → tiêu đề cột bảng đơn dính ngay bên dưới
function setNavH() { const n = document.querySelector(".nav"); if (!n) return; const cs = getComputedStyle(n); const top = cs.position === "sticky" ? parseFloat(cs.top) || 0 : 0; document.documentElement.style.setProperty("--navh", (cs.position === "sticky" ? n.offsetHeight + top : 0) + "px"); }
addEventListener("resize", setNavH);
function go(tab) {
  st.tab = tab; document.body.dataset.tab = tab; setNavH(); document.querySelectorAll(".nav button").forEach((b) => b.setAttribute("aria-selected", b.dataset.tab === tab));
  document.querySelectorAll(".page").forEach((p) => (p.hidden = p.id !== "p-" + tab)); segs(); render();
  try { localStorage.setItem("tab", tab); } catch (e) {}
}
document.querySelector(".nav").addEventListener("click", (e) => { const b = e.target.closest("button"); if (b) go(b.dataset.tab); });
document.addEventListener("click", (e) => {
  const L = e.target.closest("[data-go-list]");
  if (L) {
    e.stopPropagation(); e.preventDefault();
    const o = JSON.parse(L.dataset.goList);
    st.ostat = o.s; st.pendMin = o.m || 0; st.pendH = o.h ?? -1; st.pendG = o.g ?? -1; st.tf.list = o.tf || "day"; if (o.tf === "custom") st.cust.list = o.cu || st.cust[st.tab] || st.cust.list; st.page = 0; st.q = ""; $("psearch").value = "";
    go("pend"); window.scrollTo({ top: document.querySelector(".nav").offsetTop - 8, behavior: "smooth" }); return;
  }
  const gt = e.target.closest("[data-go-tab]"); if (gt) { go(gt.dataset.goTab); window.scrollTo({ top: 0 }); return; }
  const g = e.target.closest("[data-go-house]"); if (g) { st.house = +g.dataset.goHouse; go("house"); window.scrollTo({ top: 0 }); return; }
  const p = e.target.closest("[data-pick-house]"); if (p) { st.house = +p.dataset.pickHouse; render(); }
});
$("psearch").addEventListener("input", (e) => { st.q = e.target.value; st.page = 0; render(); });

// ===== giao diện: phông, cỡ chữ, sáng/tối, ảnh nền =====
$("fontSel").addEventListener("change", (e) => { document.body.dataset.font = e.target.value; try { localStorage.setItem("font", e.target.value); } catch (_) {} });
document.querySelector('[aria-label="Cỡ chữ"]').addEventListener("click", (e) => { const b = e.target.closest("button"); if (!b) return; document.body.dataset.size = b.dataset.size; b.parentNode.querySelectorAll("button").forEach((x) => x.setAttribute("aria-pressed", x === b)); try { localStorage.setItem("size", b.dataset.size); } catch (_) {} });
try { const f = localStorage.getItem("font"); if (f) { $("fontSel").value = f; document.body.dataset.font = f; } const z = localStorage.getItem("size"); if (z) document.querySelector(`[data-size="${z}"]`)?.click(); } catch (_) {}
// Ảnh nền: giao diện Tối dùng ảnh đêm, giao diện Sáng dùng ảnh ban ngày; tự đổi mỗi 8 giây
const BG = (() => {
  let k = 0;
  const list = () => [...document.querySelectorAll(".bn-bg")].filter((e) => e.dataset.mode === (document.body.dataset.skin === "b" ? "light" : "dark"));
  function show(i) { const l = list(); k = ((i % l.length) + l.length) % l.length; document.querySelectorAll(".bn-bg").forEach((e) => e.classList.toggle("on", e === l[k])); }
  if (!matchMedia("(prefers-reduced-motion: reduce)").matches) setInterval(() => show(k + 1), 8000);
  return { reset: () => show(0) };
})();
// Tự động: 06:00–17:59 giao diện Sáng (ảnh ban ngày), còn lại giao diện Tối (ảnh đêm)
let SKIN = "auto";
const autoSkin = () => { const h = new Date().getHours(); return h >= 6 && h < 18 ? "b" : "a"; };
function applySkin() { const want = SKIN === "auto" ? autoSkin() : SKIN; if (document.body.dataset.skin !== want) { document.body.dataset.skin = want; BG.reset(); } }
document.querySelector('[aria-label="Giao diện"]').addEventListener("click", (e) => { const b = e.target.closest("button"); if (!b) return; SKIN = b.dataset.skin; b.parentNode.querySelectorAll("button").forEach((x) => x.setAttribute("aria-pressed", x === b)); applySkin(); BG.reset(); try { localStorage.setItem("skin", SKIN); } catch (_) {} });
try { const s = localStorage.getItem("skin"); document.querySelector(`[data-skin="${s || "auto"}"]`)?.click(); } catch (_) { $("sk-auto").click(); }
setInterval(applySkin, 60000);
const THU = ["Chủ nhật", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"];
function tickClock() { const d = new Date(); $("bnClock").textContent = d.toLocaleTimeString("vi-VN", { hour12: false }); $("bnDate").textContent = THU[d.getDay()] + ", " + pad(d.getDate()) + "/" + pad(d.getMonth() + 1) + "/" + d.getFullYear(); }
setInterval(tickClock, 1000); tickClock();
$("verTxt").textContent = "v" + chrome.runtime.getManifest().version;
$("scanEvery").textContent = CFG.SCAN_SEC;

// ===== thông báo hệ thống =====
function sysmsg(text, kind, actions) {
  const el = $("sysmsg");
  if (!text) { el.hidden = true; return; }
  el.hidden = false; el.className = "sysmsg " + (kind || "info");
  el.innerHTML = `<span>${text}</span>` + (actions || "");
}
function runState(kind, txt) { const r = $("bnRun"); r.className = "bn-run" + (kind === "ok" ? "" : kind === "err" ? " err" : " idle"); $("bnRunTxt").textContent = txt; }

// ===== quét đơn =====
let scanning = false, lastFull = 0, lastBal = 0, lastOk = 0, timer = null, alerted = new Set();
async function ingest(list, cur, dayK, d0) {
  const changed = [];
  for (const rec of list) {
    const o = BO.norm(rec, dayK, d0, cur);
    noteFee(o);
    if (dayK !== DAY) { changed.push(o); continue; }
    const prev = ORD.get(o.no);
    // đơn đã "Hết thời gian nạp tiền" rồi chuyển "Đặt cọc thành công" = đơn ÉP (callback trễ) — bắt kể cả khi lọt khỏi mục bất thường quá nhanh
    if (prev && (prev.st === 4 || prev.st === 5) && o.st === 2) { try { CB.flip.set(o.no, o.nt || nowU()); } catch (e) {} }
    if (!prev || prev.st !== o.st || prev.sp !== o.sp || prev.fee !== o.fee || prev.nOk !== o.nOk || prev.nAll !== o.nAll || prev.cbx !== o.cbx || prev.mk !== o.mk) { ORD.set(o.no, o); changed.push(o); }
  }
  if (changed.length) await Store.putOrders(changed.map(({ h, g, t, ...x }) => x));
  return changed.length;
}
// Đọc 1 trang đơn; tự nhận biết BO cho tối đa bao nhiêu đơn/trang
let pageSize = CFG.PAGE_SIZE;
async function getPage(cur, from, to, page) {
  let d;
  try { d = await BO.listOrders(cur, from, to, page, pageSize); }
  catch (e) { if (e.kind === "api" && pageSize > CFG.PAGE_SIZE_MIN && page === 1) { pageSize = CFG.PAGE_SIZE_MIN; d = await BO.listOrders(cur, from, to, page, pageSize); } else throw e; }
  const list = (d && d.list) || [], total = Number(d && d.total) || 0;
  if (page === 1 && list.length && list.length < pageSize && total > list.length) pageSize = list.length; // BO giới hạn số đơn/trang
  return { list, total, pages: Math.max(1, Math.ceil(total / pageSize)) };
}
async function fetchRange(cur, dayK, from, to, stopBefore, onProg) {
  const d0 = dayStartOf(dayK);
  let page = 1, pages = 1, got = 0;
  while (page <= pages) {
    const r = await getPage(cur, from, to, page); pages = r.pages;
    await ingest(r.list, cur, dayK, d0); got += r.list.length;
    if (onProg) onProg(page, pages, got, r.total);
    if (!r.list.length) break;
    if (stopBefore && Math.min(...r.list.map((x) => Number(x.createTime) || 0)) < stopBefore) break;
    page++;
  }
  return got;
}
function curs() { return SET.usdt ? ["VND", "USDT"] : ["VND"]; }
// ===== CHỐT SỔ NGÀY CŨ: tool tắt trước 0 giờ (hoặc nghỉ cả ngày) → lần mở sau tự đọc bù phần thiếu, chốt ngày, lưu tóm tắt phí + số khách =====
const CLOSE_DAYS = 7;   // tự chốt bù tối đa 7 ngày gần nhất
const CLS = { done: new Set(), st: null, msg: "" };
async function keepDays() { try { const v = (await chrome.storage.local.get("keepDays")).keepDays; return [35, 60, 90, 180].includes(+v) ? +v : 60; } catch (e) { return 60; } }
async function closeSummaries(dk) {
  const L = await Store.dayOrders(dk).catch(() => []); for (const o of L) if (o.st == null || o.ps != null) o.st = BO.stCode(Number(o.ps), o.psl);
  const d0 = dayStartOf(dk), mine = L.filter((o) => !FAKESET.has(o.acc) && o.ts >= d0);
  if (mine.length) await Store.kvSet("cust:" + dk, { ...Cust.sum(mine, CUSTF), fin: 1 }).catch(() => {});
  delete FZ.agg[dk]; delete FZ.lists[dk]; await aggOf(dk, true).catch(() => {});
}
async function closeOld(deadline) {
  for (let i = 1; i <= CLOSE_DAYS && Date.now() < deadline; i++) {
    const dk = dayKey(new Date((DAY0 - 86400 * i + 43200) * 1000)); if (CLS.done.has(dk)) continue;
    const info = await Store.getDay(dk).catch(() => null), d0 = dayStartOf(dk);
    if (info && info.complete) {
      // ngày đã đủ đơn: bảo đảm có tóm tắt phí (tính cả phí xuất khi trang xuất đã chốt ngày đó)
      const fa = await Store.kvGet("feeAgg:" + dk).catch(() => null);
      if (!fa || fa.v !== 4 || (!fa.wdOk && (await StoreX.getDay(dk).catch(() => null) || {}).complete)) await closeSummaries(dk);
      CLS.done.add(dk); continue;
    }
    // còn thiếu: có mốc quét cuối → đọc bù từ mốc đó (lùi 60 phút) · chưa từng mở ngày đó → đọc cả ngày (từng trang, mỗi lượt một ít)
    let stt = CLS.st && CLS.st.dk === dk ? CLS.st : (await Store.kvGet("close:" + dk).catch(() => null));
    if (!stt) {
      let from = info && info.at ? Math.max(d0, Math.floor(info.at / 1000) - 3600) : d0; const full = from === d0;
      if (!full) for (const o of await Store.dayOrders(dk).catch(() => [])) if (o.ts >= d0 && o.ts < from && BO.stCode(Number(o.ps), o.psl) === 1) from = o.ts - 60;   // đơn còn chờ lúc tắt máy → đọc lại để có tình trạng cuối
      stt = { dk, from, ci: 0, page: 1, pages: 1, full };
    }
    CLS.st = stt;
    while (Date.now() < deadline) {
      const cur = curs()[stt.ci];
      if (!cur) break;
      if (cur === "USDT" && !usdtOk) { stt.ci++; stt.page = 1; continue; }
      let r; try { r = await getPage(cur, stt.from, d0 + 86399, stt.page); } catch (e) { if (cur === "USDT" && e.kind === "api") { stt.ci++; stt.page = 1; continue; } throw e; }
      await ingest(r.list, cur, dk, d0); stt.pages = r.pages;
      CLS.msg = `Đang chốt sổ ngày ${dk.slice(8)}/${dk.slice(5, 7)}${stt.full ? " (máy không mở ngày này → đọc cả ngày)" : " · đọc bù từ " + new Date(stt.from * 1000).toLocaleTimeString("vi-VN", { hour12: false }).slice(0, 5)}: trang ${stt.page}/${r.pages}`;
      if (!r.list.length || stt.page >= r.pages) { stt.ci++; stt.page = 1; } else stt.page++;
      Store.kvSet("close:" + dk, stt).catch(() => {});
    }
    if (curs()[stt.ci]) return;   // chưa xong, lượt sau làm tiếp
    await Store.setDay(dk, { day: dk, complete: true, closed: Date.now(), at: Date.now() });
    Store.kvSet("close:" + dk, null).catch(() => {}); CLS.st = null; CLS.msg = "";
    await closeSummaries(dk); CLS.done.add(dk);
  }
}
let usdtOk = true;
// Tải toàn bộ đơn trong ngày theo từng lượt, lỗi giữa chừng thì lượt sau đọc tiếp từ trang đang dở
let job = null;
async function runJob(deadline) {
  while (job && Date.now() < deadline) {
    const cur = curs()[job.ci];
    if (!cur) {
      lastFull = Date.now(); job = null; Store.kvSet("job", null).catch(() => {});
      await Store.setDay(DAY, { day: DAY, complete: false, at: Date.now() });
      return true;
    }
    if (cur === "USDT" && !usdtOk) { job.ci++; job.page = 1; continue; }
    let r;
    try { r = await getPage(cur, DAY0, DAY0 + 86399, job.page); }
    catch (e) { if (cur === "USDT" && e.kind === "api") { usdtOk = false; job.ci++; job.page = 1; continue; } throw e; }
    await ingest(r.list, cur, DAY, DAY0);
    job.pages = r.pages; job.total = r.total; job.got += r.list.length;
    if (job.kind === "full") Store.kvSet("job", { day: DAY, ci: job.ci, page: job.page, pages: r.pages, at: Date.now() }).catch(() => {});
    if (job.kind === "full") {
      $("readCount").textContent = fmt(ORD.size);
      sysmsg(`${job.resumed ? "Đang tải tiếp" : "Đang tải"} đơn hôm nay (${cur}): trang ${job.page}/${r.pages} · ${fmt(ORD.size)}/${fmt(r.total)} đơn <span class="prog"><span style="width:${(job.page / r.pages * 100).toFixed(0)}%"></span></span>`, "info");
      if (job.page % 4 === 0) { rebuild(); render(); }
    }
    if (!r.list.length || job.page >= r.pages) { job.ci++; job.page = 1; } else job.page++;
  }
  return !job;
}
let catchUpFrom = 0, lastWide = Date.now();   // mở lại tool: đọc bù từ lần quét cuối, không tải lại cả ngày
let incPage = 0;   // trang đang đọc bù dở (giữ qua các lượt quét)
async function incremental(deadline) {
  const stop = Math.min(nowU() - CFG.INC_WINDOW_MIN * 60, catchUpFrom || Infinity);
  for (const cur of curs()) {
    if (cur === "USDT" && !usdtOk) continue;
    const resume = cur === "VND" && catchUpFrom && incPage > 1;
    for (let page = 1; Date.now() < deadline; page++) {
      if (resume && page === 2) page = Math.max(2, incPage);   // đọc trang mới nhất trước, rồi đọc tiếp chỗ dở
      let r;
      try { r = await getPage(cur, DAY0, DAY0 + 86399, page); }
      catch (e) { if (cur === "USDT" && e.kind === "api") { usdtOk = false; break; } throw e; }
      await ingest(r.list, cur, DAY, DAY0);
      if (cur === "VND" && catchUpFrom) incPage = page + 1;
      if (!r.list.length || page >= r.pages || Math.min(...r.list.map((x) => Number(x.createTime) || 0)) < stop) {
        if (cur === "VND") { catchUpFrom = 0; incPage = 0; }
        break;
      }
    }
    if (Date.now() >= deadline) break;
  }
}

// ===== Tự đối chiếu với BO theo từng giờ (tạo thời gian) =====
// BO trả "total" cho đúng khung giờ hỏi → giờ nào tool có ít đơn hơn BO thì đọc lại trọn giờ đó (khung giờ cố định nên không bị trôi trang).
let VER = { h: 0, at: 0, fixed: 0 };
let VERERR = "";
// BO trả kèm "total" (số đơn) và "realAmount" (tổng tiền đơn thành công) của đúng khung hỏi
async function boCount(cur, a, b) {
  let d;
  try { d = await BO.listOrders(cur, a, b, 1, 50); }
  catch (e) { if (cur === "USDT" && e.kind === "api") return null; if (e.kind !== "api") throw e; pageSize = CFG.PAGE_SIZE_MIN; d = await BO.listOrders(cur, a, b, 1, pageSize); }
  return { n: Number(d && d.total) || 0, k: d && d.realAmount != null ? Number(String(d.realAmount).replace(/,/g, "")) : null };
}
const okAmt = (o) => (o.st === 2 ? (o.cur === "VND" ? o.amt : o.raw) || 0 : 0);
// so số đơn + tổng tiền thành công của 1 giờ; lệch thì đọc lại giờ đó. Trả { bo, mine, added: [đơn mới / đổi tình trạng] }
async function verifyHour(cur, dk, a, b, have, force) {
  const bo = await boCount(cur, a, b); if (bo == null) return { bo: 0, mine: 0, added: [] };
  const before = new Map(); let k = 0;
  for (const o of have) if ((o.cur || "VND") === cur && o.ts >= a && o.ts <= b) { before.set(o.no, o.st); k += okAmt(o); }
  const same = bo.n <= before.size && (bo.k == null || Math.abs(bo.k - k) < 0.01);
  if (same && !force) return { bo: bo.n, mine: before.size, boK: bo.k, k, added: [] };
  const added = [], d0 = dayStartOf(dk);
  let page = 1, pages = 1;
  while (page <= pages) {
    const r = await getPage(cur, a, b, page); pages = r.pages;
    for (const x of r.list) { const no = String(x.orderNo), st0 = before.get(no); if (st0 == null || st0 !== BO.stCode(Number(x.payStatus), x.payStatusStr)) added.push(no); }
    await ingest(r.list, cur, dk, d0);
    if (!r.list.length) break; page++;
  }
  return { bo: bo.n, mine: before.size, boK: bo.k, k, added };
}
async function verifyStep(deadline, maxHours) {
  if (!lastFull) return;
  const N = nowU(), lastH = Math.floor((N - 120 - DAY0) / 3600);
  for (let n = 0; n < maxHours && Date.now() < deadline; n++) {
    if (VER.h > lastH) {
      if (Date.now() - VER.at < 5 * 60e3) return;
      VER = { h: 0, at: Date.now(), fixed: VER.fixed };
      // đơn tạo tối hôm qua nhưng thành công sau 00:00: đọc lại 2 giờ cuối của hôm qua để cập nhật tình trạng
      const pk = dayKey(new Date((DAY0 - 3600) * 1000));
      for (const cur of curs()) { if (cur === "USDT" && !usdtOk) continue; try { await fetchRange(cur, pk, DAY0 - 7200, DAY0 - 1); } catch (e) { if (!(cur === "USDT" && e.kind === "api")) throw e; } }
    }
    const a = DAY0 + VER.h * 3600, b = Math.min(a + 3599, N - 120);
    if (b > a) for (const cur of curs()) { if (cur === "USDT" && !usdtOk) continue; try { VER.fixed += (await verifyHour(cur, DAY, a, b, ORD.values())).added.length; VERERR = ""; } catch (e) { VERERR = e.message; if (e.kind === "login" || e.kind === "net") throw e; } }
    VER.h++;
  }
}
async function verifyDay(dk) {
  const d0 = dayStartOf(dk); let fixed = 0;
  for (let h = 0; h < 24; h++) {
    sysmsg(`Đang đối chiếu ngày ${dk.split("-").reverse().join("/")} với BO: ${pad(h)}:00 (${h + 1}/24)…`, "info");
    const have = await Store.dayOrders(dk).catch(() => []);
    for (const cur of curs()) fixed += (await verifyHour(cur, dk, d0 + h * 3600, d0 + h * 3600 + 3599, have)).added.length;
  }
  return fixed;
}
let preconBusy = false;
$("precon").onclick = async () => {
  if (preconBusy) return; preconBusy = true;
  const btn = $("precon"), out = $("precon-out"), dk = VIEW || DAY, d0 = dayStartOf(dk), N = nowU();
  const lastH = dk === DAY ? Math.floor((N - 60 - d0) / 3600) : 23;
  btn.disabled = true; const rows = []; let addAll = [];
  try {
    for (let h = 0; h <= lastH; h++) {
      const a = d0 + h * 3600, b = Math.min(a + 3599, dk === DAY ? N - 60 : a + 3599);
      out.innerHTML = `Đang đối chiếu ${pad(h)}:00 (${h + 1}/${lastH + 1})…` + (rows.length ? tbl() : "");
      const have = dk === DAY ? [...ORD.values()] : await Store.dayOrders(dk).catch(() => []);
      for (const cur of curs()) {
        if (cur === "USDT" && !usdtOk) continue;
        const r = await verifyHour(cur, dk, a, b, have);
        if (r.bo || r.mine) rows.push([`${pad(h)}:00 – ${pad(h)}:59`, cur, r.bo, r.mine, r.added.length, r.boK, r.k]);
        addAll = addAll.concat(r.added);
      }
    }
    if (dk !== DAY) { const list = await Store.dayOrders(dk); VORD.clear(); for (const o of list) { o.st = BO.stCode(Number(o.ps), o.psl); VORD.set(o.no, o); } }
    rebuild(); render();
    const bad = rows.filter((r) => r[4] > 0);
    out.innerHTML = `<div class="${bad.length ? "badc" : "okc"}">${bad.length ? `Lệch BO ở ${bad.length} khung giờ — đã đọc lại và sửa ${fmt(addAll.length)} đơn (đơn thiếu hoặc đơn đổi tình trạng sau này, ví dụ chờ → thành công).` : "Khớp BO từng giờ: số đơn và tổng tiền đơn thành công bằng đúng BO."}</div>` + tbl() +
      (addAll.length ? `<p>Đơn vừa bổ sung (${fmt(addAll.length)}): <span class="mono">${addAll.slice(0, 300).join(", ")}${addAll.length > 300 ? "…" : ""}</span></p>` : "");
  } catch (e) { out.innerHTML = `<span class="badc">Không đối chiếu được: ${esc(e.message)}</span>` + (rows.length ? tbl() : ""); }
  finally { preconBusy = false; btn.disabled = false; }
  function tbl() { return `<table class="tbl"><thead><tr><th class="l">Giờ (tạo đơn)</th><th>Tiền tệ</th><th>BO · đơn</th><th>Tool · đơn</th><th>BO · tiền thành công</th><th>Tool · tiền thành công</th><th>Đã sửa</th><th class="l"></th></tr></thead><tbody>${rows.map((r) => `<tr><td class="l">${r[0]}</td><td>${r[1]}</td><td>${fmt(r[2])}</td><td>${fmt(r[3])}</td><td>${r[5] == null ? "—" : vnd(r[5]) + " ₫"}</td><td>${vnd(r[6] || 0)} ₫</td><td>${fmt(r[4])}</td><td class="l ${r[4] ? "badc" : "okc"}">${r[4] ? "Đã sửa " + fmt(r[4]) + " đơn" : "Khớp"}</td></tr>`).join("")}</tbody></table>`; }
};
// Số dư: listV2 có lúc trả thiếu số dư (trống) cho một số nhà -> tool tự gọi "làm mới số dư" cho từng nhà
const BALT = {};   // id -> {bal, at} số dư đọc được gần nhất của từng nhà
let balQ = [];     // hàng đợi nhà cần làm mới số dư
async function loadBalances(refresh) {
  const recs = await BO.listBalances();
  for (const r of recs) {
    const v = r.balance;
    if (v != null && v !== "" && !refresh) { if (!BALT[r.id] || BALT[r.id].src !== "refresh" || Date.now() - BALT[r.id].at > 10 * 60e3) BALT[r.id] = { bal: Number(v), at: Date.now(), src: "list" }; }
    else if (!balQ.includes(r.id)) balQ.push(r.id);
  }
  if (refresh) {
    let i = 0;
    for (const r of recs) {
      sysmsg(`Đang làm mới số dư ${++i}/${recs.length}: ${esc(r.merchName)}…`, "info");
      await refreshOne(r.id);
    }
    balQ = [];
  }
  // Mỗi nhà có thể có nhiều bản ghi (kênh nạp, kênh rút). Số dư nằm ở bản ghi kênh RÚT (có balanceUrl / merchType 2).
  const score = (r) => (r.balanceUrl ? 8 : 0) + (r.merchType === 2 ? 4 : 0) + (r.withdrawUrl ? 2 : 0) + (r.status === 1 ? 1 : 0) + (BALT[r.id] ? 1 : 0);
  BAL = {}; for (const r of recs) { const k = hkey(r.merchName); if (!BAL[k] || score(r) > score(BAL[k])) BAL[k] = r; }
  applyBal(); balAt = Date.now(); lastBal = Date.now();
}
const BALERR = {};
async function refreshOne(id) {
  try {
    const v = await BO.refreshBalance(id);
    if (v != null && v !== "" && !isNaN(Number(v))) { BALT[id] = { bal: Number(v), at: Date.now(), src: "refresh" }; delete BALERR[id]; }
    else BALERR[id] = "BO không trả số dư";
  } catch (e) { if (e.kind === "login") throw e; BALERR[id] = e.message.replace(/^BO báo lỗi: /, ""); }
}
function applyBal() { for (const k in BAL) { const r = BAL[k], t = BALT[r.id]; r.balance = t ? t.bal : null; r.balAt = t ? t.at : 0; } Store.kvSet("balt", BALT).catch(() => {}); }
// mỗi lượt quét làm mới thêm vài nhà (ưu tiên nhà đang trống số dư), để mọi nhà đều có số dư mới
async function balanceStep(n) {
  const ids = Object.values(BAL).map((r) => r.id);
  balQ = balQ.filter((id) => ids.includes(id));
  for (const id of ids) if (!BALT[id] && !balQ.includes(id)) balQ.push(id);
  const order = [...balQ, ...ids.filter((id) => !balQ.includes(id)).sort((x, y) => (BALT[x]?.at || 0) - (BALT[y]?.at || 0))];
  for (const id of order.slice(0, n)) { await refreshOne(id); balQ = balQ.filter((x) => x !== id); }
  applyBal();
}
async function rollDay() {
  const today = dayKey(new Date());
  if (today === DAY) return false;
  // chốt ngày cũ: đối soát lại lần cuối
  try { const old = DAY, o0 = DAY0; for (const cur of curs()) await fetchRange(cur, old, o0, o0 + 86399, o0 + 86400 - 3600); await Store.setDay(old, { day: old, complete: true, at: Date.now() }); } catch (e) { /* bỏ qua */ }
  DAY = today; DAY0 = dayStartOf(DAY); ORD.clear(); lastFull = 0; job = null; alerted.clear();
  keepDays().then((n) => Store.prune(n)).catch(() => {});
  return true;
}
function notifyNew() {
  const al = alerts().filter((a) => a.lv === "bad");
  const fresh = al.filter((a) => !alerted.has(a.k));
  al.forEach((a) => alerted.add(a.k));
  for (const k of [...alerted]) if (!al.find((a) => a.k === k)) alerted.delete(k);
  if (fresh.length && SET.sound) {
    beep(880, [0, 0.25, 0.5], 0.2);
    chrome.runtime.sendMessage({ type: "notify", title: "Cổng nạp cần tắt", text: fresh.map((a) => a.t).join(", ") });
  }
}
async function tick() {
  if (scanning || !licensed) return;
  scanning = true;
  const deadline = Date.now() + CFG.TICK_BUDGET_SEC * 1000;
  try {
    if (await rollDay()) { rebuild(); render(); }
    if (!lastBal || Date.now() - lastBal > CFG.BAL_MIN * 60e3) { try { await loadBalances(false); } catch (e) { if (e.kind === "login" || e.kind === "net") throw e; if (e.kind === "perm") lastBal = Date.now(); } }
    if (!lastPS || Date.now() - lastPS > PS_MIN * 60e3) { lastPS = Date.now(); try { await loadPaySet(); } catch (e) { if (e.kind === "login" || e.kind === "net") throw e; PSERR = e.message; } }
    if (!lastFull) {
      if (!job || job.kind !== "full") job = { kind: "full", ci: 0, page: 1, pages: 1, total: 0, got: 0 };
      runState("idle", "ĐANG TẢI");
      if (catchUpFrom) await incremental(Math.min(deadline, Date.now() + 12000));   // đọc bù đơn mới vào trong lúc tool tắt
      if (job.page > 2) { try { await ingest((await getPage("VND", DAY0, DAY0 + 86399, 1)).list, "VND", DAY, DAY0); } catch (e) { if (e.kind !== "api") throw e; } }  // cập nhật đơn mới nhất trong lúc tải cả ngày
      if (balQ.length) { try { await balanceStep(4); } catch (e) { if (e.kind === "login") throw e; } }
      // callback trễ: đọc ngay cả khi đang tải đơn cả ngày (không phải chờ tải xong)
      if (!CB.at || Date.now() - CB.at > 60e3) { try { await loadCb(true); } catch (e) { if (e.kind === "login" || e.kind === "net") throw e; CB.err = e.message; } }
      const done = await runJob(deadline);
      rebuild(); render(); await saveFee();
      $("readCount").textContent = fmt(ORD.size);
      if (!done) { scanning = false; setTimeout(tick, 300); return; }   // tải tiếp ngay, không chờ 30 giây
    } else {
      if (!catchUpFrom && Date.now() - lastWide > CFG.RESYNC_MIN * 60e3) { catchUpFrom = nowU() - 3 * 3600; lastWide = Date.now(); }  // định kỳ đọc lại 3 giờ gần nhất
      await incremental(deadline);
      if (job) await runJob(deadline);
      try { await verifyStep(Date.now() + 15000, 4); } catch (e) { if (e.kind === "login" || e.kind === "net") throw e; }
      if (!job && !VIEW) { try { await closeOld(Math.min(deadline, Date.now() + 12000)); } catch (e) { if (e.kind === "login" || e.kind === "net") throw e; } }
    }
    try { await balanceStep(balQ.length ? 4 : 2); } catch (e) { if (e.kind === "login") throw e; if (e.kind === "perm") balQ = []; }
    try { await loadCb(); } catch (e) { if (e.kind === "login" || e.kind === "net") throw e; CB.err = e.message; }
    rebuild(); render(); await saveFee();
    lastOk = Date.now();
    if (lastFull) Store.setDay(DAY, { day: DAY, complete: false, at: Date.now(), full: lastFull }).catch(() => {});
    $("lastScan").textContent = new Date().toLocaleTimeString("vi-VN", { hour12: false });
    if (!VIEW) { $("readCount").textContent = fmt(ORD.size); $("dayRange").textContent = DAY.slice(8) + "/" + DAY.slice(5, 7) + " 00:00 → " + new Date().toLocaleTimeString("vi-VN", { hour12: false }).slice(0, 5); }
    runState("ok", "ĐANG QUÉT"); if (VIEW) viewBanner(); else sysmsg(job && job.kind === "resync" ? `Đang đối soát lại đơn trong ngày: trang ${job.page}/${job.pages}` : CLS.msg, "info");
    if (!VIEW) notifyNew();
  } catch (e) {
    if (!["login", "net", "rate", "http", "perm"].includes(e.kind)) console.warn(e);   // lỗi mạng / hết đăng nhập là chuyện bình thường, đã báo trên giao diện, không ghi vào trang Tiện ích
    const a = await BO.auth();
    const openBtn = ` <button class="btn" id="openBo">Mở BO</button>`;
    if (e.kind === "perm") {
      runState("err", "THIẾU QUYỀN BO");
      sysmsg(esc(e.message) + ". Tài khoản BO đang đăng nhập trên Chrome này chưa được cấp quyền xem trang đó, nên tool không đọc được đơn. Nhờ quản trị BO cấp quyền cho tài khoản này, hoặc đăng nhập tài khoản có quyền rồi vào trang Tổng nạp nhanh một lần.", "err", openBtn);
    } else if (e.kind === "login") {
      runState("err", "MẤT ĐĂNG NHẬP");
      sysmsg("Mất đăng nhập BO. Mở BO trên <b>đúng Chrome (đúng hồ sơ Chrome) đang cài tool</b>, đăng nhập rồi vào trang <b>Tổng nạp nhanh</b> một lần — tool sẽ tự quét lại." + (a ? ` <span class="mut">Chi tiết: ${esc(e.message)}</span>` : " (Tool chưa lấy được phiên đăng nhập: chưa thấy trang BO nào mở trên Chrome này.)"), "err", openBtn);
    } else {
      runState("err", "LỖI KẾT NỐI");
      sysmsg(esc(e.message) + " · Tool tự thử lại sau " + CFG.SCAN_SEC + " giây, dữ liệu đã đọc vẫn giữ nguyên" + (a ? "" : " · Nếu vừa cài tool: mở BO và vào trang Tổng nạp nhanh một lần để tool lấy phiên đăng nhập."), "err", openBtn);
    }
    const b = document.getElementById("openBo"); if (b) b.onclick = async () => chrome.tabs.create({ url: "https://" + (await BO.domain()) + "/" });
  } finally { scanning = false; }
}


// ===== Callback trễ: đơn hết hạn nhưng nhà thứ 3 báo đã nhận tiền (mục "Gọi lại thứ tự bất thường") =====
// ÉP: tạo bổ sung → duyệt → đơn gốc thành công (mark 3) · THỦ CÔNG: "Điền đơn hàng thủ công" (ghi số lệnh gốc trong ghi chú) → duyệt, đơn gốc vẫn hết hạn
// Cuối cùng bấm "Đã sửa thủ công" thì đơn mới rời mục. Tool CHỈ ĐỌC.
const CB = { ex: [], rep: [], man: [], seen: null, at: 0, at2: 0, err: "", ok: false, flip: new Map(), busy: false };
const cbWeek = () => [DAY0 - 6 * 86400, DAY0 + 86399];
async function cbPages(path, body, pick, max = 5) {
  const out = [];
  for (let p = 1; p <= max; p++) { const d = await BO.call(path, { method: "POST", body: { ...body, current: p, size: 100 } }); const L = pick(d) || []; out.push(...L); if (L.length < 100) break; }
  return out;
}
async function loadCb(force) {
  if (VIEW || CB.busy) return;
  CB.busy = true;
  try { await loadCb0(force); } finally { CB.busy = false; }
}
async function loadCb0(force) {
  CB.seen ??= (await Store.kvGet("cbx").catch(() => null)) || {};
  const [a, b] = cbWeek(), now = nowU();
  if (!force && Date.now() - CB.at < 18e3) return;
  CB.at = Date.now();
  const ex = await cbPages("/api/finance/payOrderCallException/list/masked", { memberCurrency: "VND", timeType: 0, startCreateTimeStr: a, endCreateTimeStr: b, isRefresh: false }, (d) => d && d.list);
  const cur = new Set(), fresh = [];
  for (const r of ex) {
    const no = String(r.orderNo), o = BO.norm(r, DAY, DAY0, "VND"); cur.add(no);
    const s = CB.seen[no]; if (!s) { CB.seen[no] = { o, first: now, last: now }; fresh.push(o); } else { s.o = o; s.last = now; delete s.closed; }
  }
  for (const [no, s] of Object.entries(CB.seen)) { if (!cur.has(no) && !s.closed) s.closed = now; if (now - (s.closed || s.last) > 8 * 86400) delete CB.seen[no]; }
  CB.ex = ex;
  // bổ sung (ép) & phiếu thủ công: đọc mỗi 2 phút, hoặc ngay khi có đơn mới
  if (force || fresh.length || Date.now() - CB.at2 > 120e3) {
    CB.at2 = Date.now();
    try { CB.rep = await cbPages("/api/finance/checkOrderAll/index", { memberCurrency: "VND", startApplyTime: a, endApplyTime: b, isRefresh: false }, (d) => d && d.records); CB.eRep = ""; } catch (e) { if (e.kind === "login" || e.kind === "net") throw e; CB.eRep = e.message; }
    try { const L = await cbPages("/api/finance/manualCheckOrder/orderLogPage", { optType: 1, dealType: 24001, startTime: a, endTime: b, startCreateTime: a, endCreateTime: b, createTimeStart: a, createTimeEnd: b, isRefresh: false }, (d) => d && (d.records || d.list), 3); CB.man = L.filter((m) => Number(m.dealType) === 24001 && Number(m.createTime) >= a - 86400); CB.manAll = L.length; CB.eMan = ""; } catch (e) { if (e.kind === "login" || e.kind === "net") throw e; CB.eMan = e.message; }
  }
  await cbBackfill(a, b);
  await cbRefreshClosed(a, b);
  CB.ok = true; CB.err = "";
  Store.kvSet("cbx", CB.seen).catch(() => {});
  if (fresh.length && !CB.first) { beep(660, [0, 0.16, 0.32, 0.48], 0.14); chrome.runtime.sendMessage({ type: "notify", title: "Callback trễ – khách đã chuyển tiền", text: fresh.map((o) => `${o.acc} · ${o.merch} ${o.ch} · ${fmt(o.amt * 1000)} ₫`).join("\n") }); }
  CB.first = false;
  await cbFees();
}
CB.first = true;   // lần đọc đầu tiên khi mở tool: không kêu cho các đơn cũ
// đọc mục bất thường mỗi 20 giây, kể cả giữa các lượt quét đơn
setInterval(async () => { if (!licensed || VIEW || !CB.ok) return; try { await loadCb(); if (st.tab === "cb") render(); else $("cnt-cb").textContent = cbItems().filter((x) => x.step <= 2).length; } catch (e) {} }, 20e3);
// đơn đã xử lý xong trước khi tool kịp thấy trong mục bất thường: dựng lại từ bổ sung (ép), phiếu thủ công (số lệnh trong ghi chú) và đơn có dấu ép
async function cbLookup(no, a, b) {
  const d = await BO.call("/api/finance/payOrderAll/list/masked", { method: "POST", body: { memberCurrency: "VND", orderType: 0, timeType: 0, orderNo: no, current: 1, size: 10, startCreateTimeStr: a, endCreateTimeStr: b, isRefresh: true } });
  const r = ((d && d.list) || []).find((r) => String(r.orderNo) === no); return r ? BO.norm(r, DAY, DAY0, "VND") : null;
}
// đơn vừa rời mục bất thường: tra lại trên Tổng nạp tiền (theo số lệnh, 1 đơn 1 lần) để biết ép hay thủ công
async function cbRefreshClosed(a, b) {
  let n = 0;
  for (const [no, s] of Object.entries(CB.seen)) {
    if (!s.closed || s.chk) continue; if (n++ >= 10) break;
    try { const o = await cbLookup(no, a - 7 * 86400, b); if (o) { s.o = o; s.chk = 1; } else s.chk = 1; } catch (e) { if (e.kind === "login" || e.kind === "net") throw e; }
  }
}
async function cbBackfill(a, b) {
  const want = new Map();
  for (const r of CB.rep) if (r.payOrderNo) want.set(String(r.payOrderNo), Number(r.reviewTime) || Number(r.applyTime) || 0);
  for (const m of CB.man) for (const no of String(m.remark || m.backRemark || "").match(/\d{18,}/g) || []) want.set(no, Number(m.reviewTime) || Number(m.createTime) || 0);
  // mọi đơn từng rơi vào mục bất thường đều mang callbackExceptionType > 0 (kể cả khi đã ép / đã lên thủ công)
  for (const o of ORD.values()) if (o.mk === 3 || o.cbx > 0) want.set(o.no, o.mk === 3 ? o.nt || 0 : 0);
  for (const [no, t] of CB.flip) want.set(no, t);
  let n = 0;
  for (const [no, t] of want) {
    if (CB.seen[no]) continue;
    let o = ORD.get(no);
    if (!o) { if (n++ >= 12) break; try { o = await cbLookup(no, a - 86400, b); } catch (e) { if (e.kind === "login" || e.kind === "net") throw e; } }
    if (!o) continue;
    const m = CB.man.find((x) => String(x.remark || x.backRemark || "").includes(no)), r = CB.rep.find((x) => String(x.payOrderNo) === no);
    const at = t || (m && (Number(m.reviewTime) || Number(m.createTime))) || (r && (Number(r.reviewTime) || Number(r.applyTime))) || (o.st === 2 ? o.nt : 0) || o.ut || o.ts;
    CB.seen[no] = { o, first: o.ut || o.ts, last: at, closed: at, past: 1, chk: 1 };
  }
}
// ghép đơn gốc ↔ bổ sung / phiếu thủ công, xác định bước
function cbItems() {
  const now = nowU(), items = [];
  const repBy = {}; for (const r of CB.rep) { const k = String(r.payOrderNo || ""); if (k && (!repBy[k] || Number(r.applyTime) > Number(repBy[k].applyTime))) repBy[k] = r; }
  const usedMan = new Set(), manOf = (o) => {
    let m = CB.man.find((x) => String(x.remark || x.backRemark || "").includes(o.no));
    if (m) return { m, tmp: false };
    m = CB.man.find((x) => !usedMan.has(x.id) && String(x.account) === o.acc && Math.abs(Number(x.amount) - (o.amt || Number(o.raw))) < 0.01 && Number(x.createTime) >= o.ts);
    return m ? { m, tmp: true } : null;
  };
  for (const [no, s] of Object.entries(CB.seen || {})) {
    const o0 = s.o, live = ORD.get(no), o = live && live.st === 2 ? { ...o0, st: 2, mk: live.mk, nt: live.nt, why2: live.why2 || o0.why2, op: live.op } : o0;
    const rep = repBy[no], mm = rep ? null : manOf(o); if (mm) usedMan.add(mm.m.id);
    const man = mm && mm.m;
    // đã rời mục & đã tra lại: đơn gốc thành công / có dấu ép → ÉP, vẫn hết hạn → THỦ CÔNG (đơn vào mục này đều phải ép hoặc lên thủ công)
    const inf = !rep && !man && s.closed && s.chk ? (o.mk === 3 || o.st === 2 ? "ep" : "man") : "";
    const type = rep || o.mk === 3 ? "ep" : man ? "man" : inf;
    const repSt = rep ? Number(rep.reviewStatus) : 0, manSt = man ? Number(man.status) : 0;
    const credited = inf ? true : type === "ep" ? o.st === 2 || repSt === 3 : type === "man" ? manSt === 2 : false;
    const creditAt = inf ? (inf === "ep" ? o.nt || s.closed : s.closed) : type === "ep" ? Number(rep && rep.reviewTime) || o.nt || 0 : type === "man" ? Number(man.reviewTime) || Number(man.updateTime) || 0 : 0;
    let step, since;
    if (s.closed) { step = 4; since = s.closed; }
    else if (credited) { step = 3; since = creditAt || s.last; }
    else if (type) { step = 2; since = type === "ep" ? Number(rep.applyTime) || s.first : Number(man.createTime) || s.first; }
    else { step = 1; since = o.ut || s.first; }
    const remark = man ? String(man.remark || man.backRemark || "") : String(o.why2 || o.why || "");
    items.push({ no, o, s, rep, man, inf, tmp: mm && mm.tmp, type, step, since, wait: Math.max(0, now - since), credited, creditAt, closedAt: s.closed || 0, remark, chk: (type === "ep" || inf) && !remark ? null : cbCheck(remark, o, type),
      by: type === "ep" ? (rep && rep.applyUser) || "" : man ? man.operator || man.creator || "" : "", rv: type === "ep" ? (rep && rep.reviewUser) || (o.mk === 3 || o.st === 2 ? o.op : "") : man ? (man.reviewer && man.reviewer !== "system" ? man.reviewer : "") : "",
      lock: rep && repSt === 2 ? rep.lockedUser || rep.reviewUser || "" : "", repSt: rep ? rep.reviewStatusName || "" : "" });
  }
  return items;
}
function cbCheck(rm, o, type) {
  const t = nk(rm), fullT = String(rm || "").normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/gi, "d").toLowerCase();
  if (!type) return null;
  if (!t) return { c: "w", t: "thiếu ghi chú" };
  const says = /\bep\b/.test(fullT) ? "ep" : /thu cong/.test(fullT) ? "man" : "";
  const me = hkey(o.merch).replace(/pay$/, ""), others = [...new Set(HOUSES.map((h) => hkey(h.n).replace(/pay$/, "")))].filter((k) => k && k !== me && k.length >= 2);
  const hasMe = me && t.includes(me), other = !hasMe && others.find((k) => t.includes(k));
  if (other) return { c: "b", t: "sai nhà: đơn là " + o.merch };
  if (says && says !== type) return { c: "w", t: "sai loại: đơn này là " + (type === "ep" ? "ép" : "thủ công") };
  return { c: "ok", t: "khớp" };
}
// phí: đơn THỦ CÔNG đã duyệt → tự vào Phí thủ công của ngày duyệt (không trùng số lệnh đã dán tay)
async function cbFees() {
  const its = cbItems().filter((x) => x.type === "man" && x.credited && x.creditAt), byDay = {};   // gồm cả đơn suy ra THỦ CÔNG
  for (const x of its) (byDay[dayKey(new Date(x.creditAt * 1000))] ??= []).push(x);
  for (const [dk, L0] of Object.entries(byDay)) {
    const L = (await Store.kvGet("feeMan:" + dk).catch(() => null)) || [], have = new Set(L.map((x) => x.no)); let ch = false;
    for (const x of L0) {
      if (have.has(x.no)) continue; const o = x.o, c = (PSET || []).find((c) => c.merch === o.merch && (c.desc === o.ch || c.ch === o.ch));
      L.push({ no: x.no, acc: o.acc, merch: o.merch, ch: o.ch, gate: o.gate, amt: o.amt || Number(o.raw) || 0, fee: c ? Number(c.fee) || 0 : Number(o.fee) || 0, psl: "Callback trễ · lên thủ công", cb: 1 }); have.add(x.no); ch = true;
    }
    if (ch) await fzManSave(dk, L);
  }
}
const cbTy = (t) => (t === "ep" ? '<span class="cb-ty e">ÉP</span>' : t === "man" ? '<span class="cb-ty mc">THỦ CÔNG</span>' : "");
const cbCk = (c) => (c ? `<span class="cb-ck ${c.c}">${c.c === "ok" ? "✓" : "⚠"} ${esc(c.t)}</span>` : "");
const cbLv = (x) => { const w = x.wait / 60; return x.step === 4 ? "" : x.step === 3 ? (w > 10 ? "warn" : "") : w > 10 ? "bad" : w > 5 ? "warn" : ""; };
const tHM = (u) => (u ? new Date(u * 1000).toLocaleTimeString("vi-VN", { hour12: false }) : "—");
function renderCb() {
  const its = cbItems(), z = DAY0, today = (u) => u >= z;
  const S = [1, 2, 3, 4].map((k) => its.filter((x) => x.step === k && (k < 4 || today(x.closedAt))));
  const P = its.filter((x) => x.step < 4);
  $("cnt-cb").textContent = P.filter((x) => x.step <= 2).length;
  const urgent = S[0].filter((x) => x.wait > 600).sort((a, b) => b.wait - a.wait);
  $("cb-alert").hidden = !urgent.length;
  if (urgent.length) { const u = urgent[0]; $("cb-alert").innerHTML = `⚠ <b>${urgent.length} đơn khách đã chuyển tiền đang chờ quá 10 phút chưa ai xử lý</b> — lâu nhất: <b>${esc(u.o.acc)}</b> · ${esc(u.o.merch)} · ${fmt(u.o.amt * 1000)} ₫ · chờ ${mmss(u.wait)}`; }
  const sum = (L) => L.reduce((a, x) => a + (x.o.amt || 0) * 1000, 0), mx = (L) => (L.length ? mmss(Math.max(...L.map((x) => x.wait))) : "—");
  const doneT = its.filter((x) => x.credited && today(x.creditAt)), all7 = its;
  $("cb-k").innerHTML = [["#e2364a", "① Chờ xử lý", S[0].length, `${fmt(sum(S[0]))} ₫ · lâu nhất ${mx(S[0])}`], ["#d98a00", "② Chờ duyệt", S[1].length, `${fmt(sum(S[1]))} ₫ · ${S[1].filter((x) => x.type === "ep").length} ép · ${S[1].filter((x) => x.type === "man").length} thủ công`], ["#0891b2", "③ Đã lên tiền, chưa đóng", S[2].length, "chưa bấm “Đã sửa thủ công”"], ["#16a34a", "④ Xong hôm nay", S[3].length, `${fmt(sum(S[3]))} ₫ · ${S[3].filter((x) => x.type === "ep").length} ép · ${S[3].filter((x) => x.type === "man").length} thủ công`], ["#7c3aed", "Đã lên tiền hôm nay", doneT.length, `${fmt(sum(doneT))} ₫ · 7 ngày: ${all7.length} đơn`]]
    .map(([k, t, v, sub]) => `<div class="cb-k" style="--k:${k}"><small>${t}</small><b>${fmt(v)}</b><span>${sub}</span></div>`).join("");
  const src = (CB.err ? "LỖI: " + CB.err + " · " : "") + `Gọi lại bất thường: ${CB.ex.length} đơn đang nằm trong mục · bổ sung (ép): ${CB.eRep ? "LỖI – " + CB.eRep : CB.rep.length} · phiếu thủ công: ${CB.eMan ? "LỖI – " + CB.eMan : CB.man.length + (CB.manAll != null && CB.manAll !== CB.man.length ? "/" + CB.manAll : "")}`;
  $("cb-diag").innerHTML = `<summary>Dữ liệu tool đọc được từ BO (để kiểm tra khi thấy thiếu đơn)</summary><div class="cb-dg">
    <div><b>Mục gọi lại bất thường</b> (${CB.ex.length}): ${CB.ex.map((r) => esc(r.orderNo + " " + r.account + " " + r.merchName + " " + r.payStatusStr)).join(" · ") || "trống"}</div>
    <div><b>Duyệt lệnh nạp – bổ sung</b> (${CB.rep.length}${CB.eRep ? " · LỖI: " + esc(CB.eRep) : ""}): ${CB.rep.map((r) => esc(r.orderNo + " → " + r.payOrderNo + " " + r.username + " " + (r.reviewStatusName || r.reviewStatus))).join(" · ") || "trống"}</div>
    <div><b>Nhập khoản thủ công – Điền đơn hàng thủ công</b> (${CB.man.length}${CB.manAll != null ? "/" + CB.manAll + " phiếu đọc được" : ""}${CB.eMan ? " · LỖI: " + esc(CB.eMan) : ""}): ${CB.man.map((m) => esc(m.orderNo + " " + m.account + " " + m.amount + " · " + (m.remark || "(không ghi)") + " · tt " + m.status)).join(" · ") || "trống"}</div>
    <div><b>Đơn nạp hôm nay có dấu callback</b> (${[...ORD.values()].filter((o) => o.cbx > 0 || o.mk === 3).length}): ${[...ORD.values()].filter((o) => o.cbx > 0 || o.mk === 3).slice(0, 30).map((o) => esc(o.no + " " + o.acc + " " + o.psl + (o.mk === 3 ? " (ép)" : ""))).join(" · ") || "không có"}</div>
    <div><b>Đơn tool đang theo dõi</b> (${its.length}): ${its.map((x) => esc(`${x.no} ${x.o.acc} · ${x.o.psl || ""} · ${x.type ? (x.type === "ep" ? "ÉP" : "THỦ CÔNG") : "chưa rõ"} · bước ${x.step} · ${x.closedAt ? "đóng " + new Date(x.closedAt * 1000).toLocaleString("vi-VN", { hour12: false }) : "đang mở"}${x.s.chk ? "" : " · chưa tra lại"}`)).join(" | ") || "không có"}</div></div>`;
  $("cb-hint").textContent = src + " · " + (CB.ok ? "cập nhật " + new Date(CB.at).toLocaleTimeString("vi-VN", { hour12: false }) + " · " : "đang đọc… · ") + "đọc 7 ngày gần nhất mỗi 20 giây · viền xanh < 5' · vàng 5–10' · đỏ > 10' ở bước hiện tại · có đơn mới tool kêu chuông";
  const card = (x) => { const o = x.o; return `<div class="cb-o ${cbLv(x)}" data-cbgo="${esc(o.no)}" title="Bấm để tìm đơn trong Danh sách đơn"><div class="t">${cbTy(x.type)}<b>${esc(o.acc)}</b>${o.lvl ? `<span class="cb-tag">${esc(o.lvl.split(" ")[0])}</span>` : ""}<span class="amt">${fmt(o.amt * 1000)} ₫</span></div>
    <div class="m"><span class="hn" style="color:${hColor(o.merch)}">${esc(o.merch)}</span> · ${esc(o.ch)} · tạo ${tHM(o.ts)}${x.step === 1 ? " · hết hạn " + tHM(o.ut) : ""}</div>
    ${x.step === 2 && x.type === "ep" ? `<div class="m">Bổ sung ${esc(x.rep.orderNo)} · tạo: <b>${esc(x.by)}</b> ${tHM(Number(x.rep.applyTime))}${x.lock ? ` · <b>đang duyệt: ${esc(x.lock)}</b>` : ""}</div>` : ""}
    ${x.inf ? `<div class="m">${x.inf === "ep" ? "Đơn gốc đã thành công (ép)" : "Đơn gốc vẫn hết hạn → lên thủ công"}${x.rv ? " · thao tác: <b>" + esc(x.rv) + "</b>" : ""}</div>` : ""}
    ${x.man ? `<div class="m">Phiếu ${esc(x.man.orderNo)} · tạo: <b>${esc(x.by)}</b>${x.rv ? " · duyệt: <b>" + esc(x.rv) + "</b>" : ""}${x.tmp ? ' · <span class="warn">nối tạm</span>' : ""}</div>` : ""}
    ${x.step >= 3 && x.type === "ep" && x.rv && !x.inf ? `<div class="m">Duyệt: <b>${esc(x.rv)}</b> ${tHM(x.creditAt)}</div>` : ""}
    ${x.man || x.remark ? `<div class="rm">📝 ${x.remark ? esc(x.remark) : '<span class="mut">(không ghi)</span>'} ${cbCk(x.chk)}</div>` : ""}
    <div class="w">${x.step === 4 ? `✔ xong ${tHM(x.closedAt)} · tổng <b>${mmss(Math.max(0, x.closedAt - (o.ut || x.s.first)))}</b>` : `⏳ ${x.step === 3 ? "chưa đóng" : x.step === 2 ? "chờ duyệt" : "chờ"} <b>${mmss(x.wait)}</b>`}</div></div>`; };
  const COL = [["#e2364a", "① Chờ xử lý", "Nhà đã báo nhận tiền, chưa ai ép hay thêm thủ công"], ["#d98a00", "② Chờ duyệt", "Đã tạo bổ sung / phiếu thủ công, chờ người duyệt"], ["#0891b2", "③ Đã lên tiền, chưa đóng", "Khách đã nhận tiền nhưng chưa bấm “Đã sửa thủ công”"], ["#16a34a", "④ Xong hôm nay", "Đã lên tiền và đã đóng đơn"]];
  $("cb-board").innerHTML = COL.map(([c, h, sub], i) => { const L = S[i].slice().sort((a, b) => (i === 3 ? b.closedAt - a.closedAt : b.wait - a.wait)); return `<div class="cb-col" style="--cc:${c}"><h4>${h} <span class="n">${L.length}</span></h4><div class="sub">${sub}</div>${L.slice(0, i === 3 ? 6 : 30).map(card).join("") || '<div class="mut cb-empty">Không có</div>'}${i === 3 && L.length > 6 ? `<div class="mut cb-empty">+ ${L.length - 6} đơn nữa · xem bảng bên dưới</div>` : ""}</div>`; }).join("");
  // bảng đã lên tiền hôm nay
  const D = its.filter((x) => x.credited).sort((a, b) => b.creditAt - a.creditAt); let fs = 0, fm = 0;
  let t = `<thead><tr><th class="l">Số lệnh gốc</th><th class="l">Khách</th><th class="l">Nhà · kênh</th><th>Số tiền (₫)</th><th class="l">Loại</th><th class="l">Ghi chú nhân viên</th><th class="l">Kiểm tra ghi chú</th><th>Phí %</th><th>Phí (₫)</th><th class="l">Tạo / duyệt</th><th>Lên tiền lúc</th><th class="l">Đã đóng</th></tr></thead><tbody>`;
  for (const x of D) { const o = x.o, c = (PSET || []).find((c) => c.merch === o.merch && (c.desc === o.ch || c.ch === o.ch)), r = c ? Number(c.fee) || 0 : Number(o.fee) || 0, f = (o.amt || 0) * 1000 * r / 100; fs += f; if (x.type === "man") fm += f;
    t += `<tr><td class="l mut mono">${esc(o.no)}</td><td class="name">${esc(o.acc)}</td><td class="l"><span class="hn" style="color:${hColor(o.merch)};font-weight:700">${esc(o.merch)}</span> <small class="mut">${esc(o.ch)}</small></td><td>${fmt(o.amt * 1000)}</td><td class="l">${cbTy(x.type)}</td><td class="l">${x.remark ? esc(x.remark) : '<span class="mut">(không ghi)</span>'}</td><td class="l">${cbCk(x.chk)}${x.tmp ? ' <span class="cb-ck w">nối tạm theo tài khoản + số tiền</span>' : ""}</td><td>${r}</td><td>${fmt(f)}</td><td class="l">${esc(x.by || "—")} / ${esc(x.rv || "—")}</td><td>${x.creditAt ? (x.creditAt < z ? new Date(x.creditAt * 1000).toLocaleDateString("vi-VN", { day: "2-digit", month: "2-digit" }) + " " : "") + tHM(x.creditAt) : "—"}</td><td class="l ${x.step === 4 ? "ok" : "warn"}">${x.step === 4 ? "✓" : "chưa"}</td></tr>`; }
  if (!D.length) t += `<tr><td class="l mut" colspan="12">7 ngày qua chưa có đơn callback trễ nào được lên tiền.</td></tr>`;
  const bad = D.filter((x) => x.chk && x.chk.c !== "ok").length;
  $("cb-done").innerHTML = t + `</tbody><tfoot><tr><td class="l" colspan="3">Tổng ${D.length} đơn · ${D.filter((x) => x.type === "ep").length} ép · ${D.filter((x) => x.type === "man").length} thủ công</td><td>${fmt(sum(D))}</td><td></td><td></td><td class="l">${bad ? bad + " cần xem lại" : ""}</td><td></td><td>${fmt(fs)}</td><td class="l" colspan="3">phí thủ công ${fmt(fm)} ₫ → tab Phí</td></tr></tfoot>`;
  // theo nhà (7 ngày)
  const H = {}; for (const x of its) { const k = x.o.merch + "|" + x.o.ch; const h = (H[k] ??= { m: x.o.merch, ch: x.o.ch, n: 0, ep: 0, man: 0, amt: 0, wait: 0, tt: [] }); h.n++; if (x.type === "ep") h.ep++; if (x.type === "man") h.man++; h.amt += x.o.amt * 1000; if (x.step <= 2) h.wait++; if (x.credited && x.creditAt) h.tt.push(x.creditAt - (x.o.ut || x.s.first)); }
  $("cb-house").innerHTML = `<thead><tr><th class="l">Nhà · kênh</th><th>Số đơn</th><th>Ép / thủ công</th><th>Tiền (₫)</th><th>Đang chờ</th><th>TB lên tiền</th></tr></thead><tbody>` + (Object.values(H).sort((a, b) => b.n - a.n).map((h) => `<tr><td class="l"><span style="color:${hColor(h.m)};font-weight:700">${esc(h.m)}</span> <small class="mut">${esc(h.ch)}</small></td><td>${h.n}</td><td class="mut">${h.ep} / ${h.man}</td><td>${fmt(h.amt)}</td><td class="${h.wait ? "bad" : "mut"}">${h.wait}</td><td>${h.tt.length ? mmss(h.tt.reduce((a, b) => a + Math.max(0, b), 0) / h.tt.length) : "—"}</td></tr>`).join("") || `<tr><td class="l mut" colspan="6">7 ngày qua không có đơn callback trễ.</td></tr>`) + "</tbody>";
  // người xử lý
  const U = {}, u = (n) => (U[n] ??= { ep: 0, man: 0, rv: 0, tc: [], tr: [] });
  for (const x of its) {
    if (x.by) { const r = u(x.by); x.type === "ep" ? r.ep++ : r.man++; const t0 = x.type === "ep" ? Number(x.rep && x.rep.applyTime) : Number(x.man.createTime); if (t0) r.tc.push(t0 - (x.o.ut || x.s.first)); }
    if (x.rv) { const r = u(x.rv); r.rv++; const t0 = x.type === "ep" ? Number(x.rep && x.rep.applyTime) : Number(x.man.createTime); if (t0 && x.creditAt) r.tr.push(x.creditAt - t0); }
  }
  const av = (a) => (a.length ? mmss(a.reduce((s, v) => s + Math.max(0, v), 0) / a.length) : "—");
  $("cb-staff").innerHTML = `<thead><tr><th class="l">Nhân viên</th><th>Tạo (ép / thủ công)</th><th>Duyệt</th><th>TB tạo</th><th>TB duyệt</th></tr></thead><tbody>` + (Object.entries(U).sort((a, b) => b[1].ep + b[1].man + b[1].rv - a[1].ep - a[1].man - a[1].rv).map(([n, r]) => `<tr><td class="name">${esc(n)}${/^(system|tool)/i.test(n) ? ' <span class="cb-tag">tự động</span>' : ""}</td><td>${r.ep} / ${r.man}</td><td>${r.rv}</td><td>${av(r.tc)}</td><td>${av(r.tr)}</td></tr>`).join("") || `<tr><td class="l mut" colspan="5">Chưa có dữ liệu.</td></tr>`) + "</tbody>";
}
$("cb-add").onclick = async () => {
  const ids = [...new Set(($("cb-in").value || "").split(/[\s,;]+/).map((x) => x.trim()).filter((x) => /^\d{15,}$/.test(x)))]; if (!ids.length) return;
  const btn = $("cb-add"); btn.disabled = true; $("cb-msg").textContent = `Đang tra ${ids.length} số lệnh trên BO…`; CB.seen ??= (await Store.kvGet("cbx").catch(() => null)) || {};
  const [a, b] = cbWeek(); let ok = 0, miss = 0;
  for (const no of ids) { try { const o = ORD.get(no) || (await cbLookup(no, a - 7 * 86400, b)); if (o) { const at = o.st === 2 ? o.nt || o.ut : o.ut || o.ts; CB.seen[no] = { o, first: o.ut || o.ts, last: at, closed: at, past: 1, chk: 1, hand: 1 }; ok++; } else miss++; } catch (e) { miss++; } }
  await Store.kvSet("cbx", CB.seen).catch(() => {}); await cbFees(); btn.disabled = false; $("cb-in").value = "";
  $("cb-msg").textContent = `Đã thêm ${ok} đơn${miss ? ", " + miss + " số lệnh không tìm thấy trên BO" : ""}.`; render();
};
$("cb-board").addEventListener("click", (e) => { const c = e.target.closest("[data-cbgo]"); if (!c) return; st.ostat = "all"; st.pendH = -1; st.pendG = -1; st.pendMin = 0; st.tf.list = "day"; st.page = 0; st.q = c.dataset.cbgo; $("psearch").value = st.q; go("pend"); });
// ===== Xuất Excel =====
(function () {
  let mode = "upto";
  $("xh1").innerHTML = Array.from({ length: 24 }, (_, h) => `<option value="${h}">${pad(h)}:00 – ${h < 23 ? pad(h + 1) + ":00" : "23:59"}</option>`).join("");
  const nm = () => {
    const d1 = $("xd1").value, d2 = $("xd2").value; if (!d1 || !d2) return;
    const f = (d) => d.slice(8) + "-" + d.slice(5, 7);
    const k = mode === "day" ? "ca-ngay" : mode === "upto" ? "00h-" + $("xt").value.replace(":", "h") : pad($("xh1").value) + "h-" + pad(+$("xh1").value + 1) + "h";
    $("xname").textContent = `Toc_do_len_diem_${d1 === d2 ? f(d1) + "-" + d1.slice(0, 4) : f(d1) + "_" + f(d2) + "-" + d2.slice(0, 4)}_${k}.xlsx`;
  };
  $("xmode").onclick = (e) => { const b = e.target.closest("button"); if (!b) return; mode = b.dataset.v; $("xmode").querySelectorAll("button").forEach((x) => x.setAttribute("aria-pressed", x === b)); $("xupto").hidden = mode !== "upto"; $("xhour").hidden = mode !== "hour"; nm(); };
  $("xt").addEventListener("input", () => { const d = $("xt").value.replace(/\D/g, "").slice(0, 4); $("xt").value = d.replace(/^(\d{2})(\d)/, "$1:$2"); });
  $("xt").addEventListener("blur", () => { const p = $("xt").value.split(":").map((x) => parseInt(x, 10) || 0); $("xt").value = pad(Math.min(23, p[0] || 0)) + ":" + pad(Math.min(59, p[1] || 0)); nm(); });
  ["xd1", "xd2", "xt", "xh1"].forEach((i) => $(i).addEventListener("input", nm));
  $("btn-xls").onclick = () => {
    const now = new Date();
    $("xd1").value = $("xd1").value || DAY; $("xd2").value = $("xd2").value || DAY;
    $("xt").value = pad(now.getHours()) + ":" + pad(now.getMinutes()); $("xh1").value = String(Math.max(0, now.getHours() - 1));
    $("xback").hidden = false; $("xmsg").hidden = true; nm();
  };
  $("xclose").onclick = () => ($("xback").hidden = true);
  $("xback").onclick = (e) => { if (e.target.id === "xback") $("xback").hidden = true; };
  const msg = (t) => { $("xmsg").hidden = false; $("xmsg").innerHTML = t; };
  $("xgo").onclick = async () => {
    const d1 = $("xd1").value, d2 = $("xd2").value;
    if (!d1 || !d2 || d1 > d2) return msg("Chọn ngày bắt đầu và kết thúc hợp lệ.");
    const days = []; for (let d = new Date(d1); dayKey(d) <= d2; d.setDate(d.getDate() + 1)) days.push(dayKey(d));
    if (days.length > 31) return msg("Mỗi lần xuất tối đa 31 ngày.");
    $("xgo").disabled = true;
    try {
      let all = [];
      for (const dk of days) {
        let list;
        if (dk === DAY) list = [...ORD.values()];
        else {
          const info = await Store.getDay(dk);
          list = await Store.dayOrders(dk);
          if (!info || !info.complete) {
            msg(`Ngày ${dk.split("-").reverse().join("/")} chưa có đủ trong máy, đang tải từ BO…`);
            const d0 = dayStartOf(dk);
            for (const cur of curs()) {
              try { await fetchRange(cur, dk, d0, d0 + 86399, 0, (p, ps) => msg(`Đang tải ngày ${dk.split("-").reverse().join("/")} (${cur}): trang ${p}/${ps}…`)); }
              catch (e) { if (!(cur === "USDT" && e.kind === "api")) throw e; }
            }
            if (dk < DAY) await Store.setDay(dk, { day: dk, complete: true, at: Date.now() });
            list = await Store.dayOrders(dk);
          }
        }
        const d0 = dayStartOf(dk);
        all = all.concat(list.map((o) => ({ ...o, t: o.ts - d0 })));
      }
      let from = 0, to = 86400, suffix = "", title = "";
      if (mode === "upto") { const [h, m] = $("xt").value.split(":").map(Number); to = h * 3600 + m * 60 + 59; suffix = "00:00 - " + $("xt").value; }
      if (mode === "hour") { const h = +$("xh1").value; from = h * 3600; to = from + 3599; suffix = pad(h) + ":00 - " + (h < 23 ? pad(h + 1) + ":00" : "23:59"); }
      all = all.filter((o) => o.t >= from && o.t <= to);
      title = days[0].split("-").reverse().join("/") + (days.length > 1 ? " → " + days[days.length - 1].split("-").reverse().join("/") : "") + (suffix ? " · " + suffix : " · cả ngày");
      msg("Đang tạo file Excel…");
      const blob = await Report.build(all, days, { suffix, title });
      const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = $("xname").textContent; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 4000);
      msg("Đã tải file <b>" + esc($("xname").textContent) + "</b> (" + fmt(all.filter((o) => o.st === 2).length) + " đơn thành công).");
    } catch (e) { msg("Không xuất được: " + esc(e.message)); }
    finally { $("xgo").disabled = false; }
  };
})();

// ===== Tải Excel danh sách đơn đang xem =====
$("pxls").onclick = async () => {
  const list = LIST.slice(), kind = st.ostat, N = NOWS();
  if (!list.length) { sysmsg("Danh sách đang trống, không có gì để tải.", "info"); setTimeout(() => sysmsg(""), 3000); return; }
  const F = "Times New Roman", B = { border: true, align: { v: "center" } };
  const S = (o) => Object.assign({}, B, { font: { name: F, size: 10 } }, o || {});
  const H = S({ font: { name: F, size: 10, bold: true, color: "FFFFFF" }, fill: "0B2A55", align: { h: "center", v: "center", wrap: true } });
  const tz = new Date().getTimezoneOffset() * 60;
  const xdt = (ts) => (ts - tz) / 86400 + 25569;          // giờ Việt Nam -> số ngày Excel
  const dur = (s) => Math.round(s) / 86400;
  const stTxt = (o) => { const k = stOf(o); return k === "ok" ? "Thành công" : k === "err" ? o.psl || "Thất bại" : k === "aband" ? (o.st >= 4 ? o.psl || "Hết hạn" : "Chờ quá 30 phút") : "Đang chờ"; };
  const cols = [["Số lệnh", 24, (o) => o.no, S()], ["Tài khoản", 18, (o) => o.acc, S()], ["Số lần nạp thành công", 11, (o) => o.nOk, S({ fmt: "0", align: { h: "center", v: "center" } })], ["Tổng số lần nạp", 10, (o) => o.nAll, S({ fmt: "0", align: { h: "center", v: "center" } })], ["Nhãn", 9, (o) => NTAG[o.ntag] || "", S()], ["Nhà thứ 3", 14, hNm, S()], ["Cổng nạp", 16, gNm, S()], ["Kênh", 13, (o) => o.ch, S()],
    ["Tỷ lệ phí", 9, (o) => o.fee / 100, S({ fmt: "0.00%" })], ["Số tiền (₫)", 15, (o) => (o.cur === "VND" ? o.amt * 1000 : o.raw), S({ fmt: "0" })], ["Tạo lúc", 19, (o) => xdt(o.ts), S({ fmt: "dd/mm/yyyy hh:mm:ss" })]];
  if (st.lbasis === "upd") cols.push(["Cập nhật lúc", 19, (o) => (o.bt ? xdt(o.bt) : null), S({ fmt: "dd/mm/yyyy hh:mm:ss" })]);
  if (kind === "pend") cols.push(["Đã chờ", 11, (o) => dur(N - (o.ts ? o.ts - dayStartOf(VIEW || DAY) : o.t)), S({ fmt: "[h]:mm:ss" })]);
  else if (kind === "ok") cols.push(["Thành công lúc", 19, (o) => xdt(o.nt || o.ts + o.sp), S({ fmt: "dd/mm/yyyy hh:mm:ss" })], ["Lên điểm sau", 11, (o) => dur(o.sp), S({ fmt: "[h]:mm:ss" })], ["Phí (₫)", 12, (o) => (o.cur === "VND" ? o.amt * 1000 * o.fee / 100 : null), S({ fmt: "0" })]);
  else if (kind === "err") cols.push(["Tình trạng", 22, stTxt, S()], ["Lý do (BO)", 50, (o) => o.why || "", S({ align: { v: "center", wrap: true } })]);
  else if (kind === "aband") cols.push(["Tình trạng", 22, stTxt, S()], ["Thời gian từ lúc tạo", 13, (o) => dur(N - o.t), S({ fmt: "[h]:mm:ss" })]);
  else cols.push(["Tình trạng", 22, stTxt, S()], ["Thành công lúc", 19, (o) => (o.st === 2 ? xdt(o.ts + o.sp) : null), S({ fmt: "dd/mm/yyyy hh:mm:ss" })], ["Lên điểm sau", 11, (o) => (o.st === 2 ? dur(o.sp) : null), S({ fmt: "[h]:mm:ss" })], ["Đã chờ", 11, (o) => (stOf(o) === "pend" ? dur(N - o.t) : null), S({ fmt: "[h]:mm:ss" })], ["Lý do (BO)", 40, (o) => o.why || "", S()]);
  const wb = new XLSXW.Book(); const ws = wb.sheet(OST.find((x) => x[0] === kind)[1].replace(/[\\/?*\[\]:]/g, "-"));
  cols.forEach((c, i) => { ws.set(1, i + 1, c[0], H); ws.width(i + 1, c[1]); });
  list.forEach((o, r) => cols.forEach((c, i) => ws.set(r + 2, i + 1, c[2](o), c[3])));
  const last = list.length + 2, sc = cols.findIndex((c) => c[0] === "Số tiền (₫)") + 1;
  ws.set(last, 1, "Tổng " + fmt(list.length) + " đơn", S({ font: { name: F, size: 10, bold: true }, fill: "93C47D" }));
  ws.set(last, sc, { f: `SUM(${XLSXW.col(sc)}2:${XLSXW.col(sc)}${last - 1})` }, S({ font: { name: F, size: 10, bold: true }, fill: "93C47D", fmt: "0" }));
  ws.freeze(2, 2); ws.height(1, 30);
  const blob = await wb.blob();
  const now = new Date(), name = `Don_${{ pend: "dang-cho", ok: "thanh-cong", err: "that-bai", aband: "het-han-huy", all: "tat-ca" }[kind]}${st.pendH >= 0 ? "_" + nk(HOUSES[st.pendH].n) : ""}${st.pendG >= 0 ? "_" + nk(GATES[st.pendG].n) : ""}_${pad(now.getDate())}-${pad(now.getMonth() + 1)}_${pad(now.getHours())}h${pad(now.getMinutes())}.xlsx`;
  const el = document.createElement("a"); el.href = URL.createObjectURL(blob); el.download = name; document.body.appendChild(el); el.click(); el.remove();
  setTimeout(() => URL.revokeObjectURL(el.href), 4000);
};

// ===== Số dư =====
$("btn-bal").onclick = async () => {
  if (!licensed) return;
  while (scanning) await sleep(300);
  scanning = true;
  try { await loadBalances(true); rebuild(); render(); sysmsg("Đã làm mới số dư lúc " + new Date().toLocaleTimeString("vi-VN"), "info"); setTimeout(() => sysmsg(""), 4000); }
  catch (e) { sysmsg("Không làm mới được số dư: " + esc(e.message), "err"); }
  finally { scanning = false; }
};

// ===== Nâng cấp =====
let updInfo = null;
async function checkUpdate(show) {
  try {
    updInfo = await Updater.check();
    const b = $("btn-upd"); b.hidden = false;
    if (updInfo.hasNew) { b.classList.add("pulse"); $("updTxt").textContent = "Nâng cấp " + updInfo.latest; }
    else { b.classList.remove("pulse"); $("updTxt").textContent = "v" + updInfo.current + " ✓"; }
    if (show) return updInfo;
  } catch (e) { if (show) throw e; }
}
$("btn-upd").onclick = () => {
  $("updback").hidden = false; $("updmsg").hidden = true;
  const i = updInfo;
  if (!i) { $("updinfo").innerHTML = "Chưa kiểm tra được bản mới."; $("updgo").hidden = true; return; }
  $("updgo").hidden = !i.hasNew;
  $("updinfo").innerHTML = i.hasNew
    ? `<p>Có bản mới <b>${esc(i.latest)}</b> (đang dùng ${esc(i.current)}).</p>${i.notes ? `<p class="mut">${esc(i.notes)}</p>` : ""}<p class="mut">Lần đầu bấm, Chrome sẽ hỏi thư mục: chọn đúng thư mục đang cài tool (thư mục có file <b>manifest.json</b>) và bấm <b>Cho phép sửa</b>. Những lần sau chỉ cần bấm Nâng cấp.</p>`
    : `<p>Bạn đang dùng bản mới nhất <b>${esc(i.current)}</b>.</p>`;
};
$("updclose").onclick = () => ($("updback").hidden = true);
$("updgo").onclick = async () => {
  $("updgo").disabled = true;
  const m = (t) => { $("updmsg").hidden = false; $("updmsg").textContent = t; };
  try { await Updater.run(updInfo, m); }
  catch (e) { m(e.name === "AbortError" ? "Đã huỷ chọn thư mục." : "Nâng cấp lỗi: " + e.message); $("updgo").disabled = false; }
};

// ===== Cài đặt =====
$("btn-set").onclick = async () => {
  $("sBlim").value = Object.entries(blimAll()).map(([k, v]) => k + " = " + (Array.isArray(v) ? v.map(fmt).join(" / ") : fmt(v))).join("\n"); $("sDomain").value = SET.domain; $("sUsdt").checked = SET.usdt; $("sRed").value = SET.rRed; $("sAmber").value = SET.rWarn; $("sOkR").value = SET.rOk; $("sMinN").value = SET.minN; $("sStale").value = SET.stale; $("sSound").checked = SET.sound; keepDays().then((n) => { $("sKeep").value = String(n); }); $("sExFake").checked = SET.exFake !== false;
  $("sDev").textContent = await License.deviceId();
  const r = await License.check(await License.saved());
  $("sKeyInfo").textContent = r.ok ? keyText(r) : r.reason;
  $("sVer").textContent = "v" + chrome.runtime.getManifest().version;
  $("setmsg").hidden = true; $("setback").hidden = false;
};
$("setclose").onclick = () => ($("setback").hidden = true);
$("sCopyDev").onclick = () => navigator.clipboard.writeText($("sDev").textContent).catch(() => {});
$("sChangeKey").onclick = () => { $("setback").hidden = true; showLock("Nhập key mới."); };
$("sPickDir").onclick = async () => { try { await Updater.pickFolder(); $("setmsg").hidden = false; $("setmsg").textContent = "Đã lưu thư mục cài tool."; } catch (e) { $("setmsg").hidden = false; $("setmsg").textContent = e.name === "AbortError" ? "Đã huỷ." : e.message; } };
$("sCheckUpd").onclick = async () => { $("setmsg").hidden = false; $("setmsg").textContent = "Đang kiểm tra…"; try { const i = await checkUpdate(true); $("setmsg").textContent = i.hasNew ? "Có bản mới " + i.latest + ". Bấm nút Nâng cấp ở thanh trên." : "Đang là bản mới nhất."; } catch (e) { $("setmsg").textContent = e.message; } };
$("setsave").onclick = async () => {
  const dom = $("sDomain").value.trim().replace(/^https?:\/\//, "").replace(/\/.*$/, "");
  if (dom && dom !== SET.domain) {
    if (!/\.cg\.ink$/.test(dom)) {
      const ok = await chrome.permissions.request({ origins: ["https://" + dom + "/*"] }).catch(() => false);
      if (!ok) { $("setmsg").hidden = false; $("setmsg").textContent = "Cần cho phép tool truy cập tên miền mới."; return; }
    }
    await chrome.storage.local.set({ boDomain: dom }); SET.domain = dom;
    await chrome.runtime.sendMessage({ type: "applyRules" });
    ORD.clear(); lastFull = 0; lastBal = 0;
  }
  SET.usdt = $("sUsdt").checked; usdtOk = true;
  await chrome.storage.local.set({ keepDays: +$("sKeep").value || 60 });
  SET.rRed = Math.max(0, +$("sRed").value || 20); SET.rWarn = Math.max(SET.rRed, +$("sAmber").value || 50); SET.rOk = Math.max(SET.rWarn, +$("sOkR").value || 80); SET.minN = Math.max(1, +$("sMinN").value || 5); SET.stale = Math.max(1, +$("sStale").value || 5); SET.sound = $("sSound").checked; SET.exFake = $("sExFake").checked;
  SET.blim = {}; for (const ln of ($("sBlim").value || "").split("\n")) { const m = /^\s*([^=]+?)\s*=\s*([\d.,\s/]+)\s*$/.exec(ln); if (!m) continue; const k = m[1].toLowerCase().includes("|usdt") ? hkey(m[1].split("|")[0]) + "|USDT" : hkey(m[1]); const v = m[2].split("/").map((x) => Number(x.replace(/[.,\s]/g, "")) || 0); if (!(v[0] > 0)) continue; SET.blim[k] = v[1] > 0 ? [v[0], v[1], v[2] > 0 && v[2] < v[1] ? v[2] : v[1] / 2] : v[0]; }
  await chrome.storage.local.set({ settings: { blim: SET.blim, usdt: SET.usdt, rRed: SET.rRed, rWarn: SET.rWarn, rOk: SET.rOk, minN: SET.minN, stale: SET.stale, sound: SET.sound, exFake: SET.exFake } });
  $("setback").hidden = true; render(); tick();
};

// ===== Key bản quyền =====
let licensed = false;
function keyText(r) {
  const p = r.info; const who = p.n ? p.n + " · " : "";
  if (!p.e) return who + "vĩnh viễn";
  const d = Math.floor(r.left / 86400), h = Math.floor((r.left % 86400) / 3600);
  return who + "còn " + (d ? d + " ngày" : h + " giờ") + " (hết " + new Date(p.e * 1000).toLocaleDateString("vi-VN") + ")";
}
async function showLock(msg) {
  licensed = false;
  $("lock").hidden = false; $("lockMsg").className = "lock-msg"; $("lockMsg").textContent = msg || "Nhập key để sử dụng tool.";
  $("lockDev").textContent = await License.deviceId();
  runState("idle", "CHƯA CÓ KEY");
}
$("lockCopy").onclick = () => navigator.clipboard.writeText($("lockDev").textContent).catch(() => {});
$("lockGo").onclick = async () => {
  const k = $("lockKey").value;
  const r = await License.check(k);
  if (!r.ok) { $("lockMsg").className = "lock-msg"; $("lockMsg").textContent = r.reason; return; }
  await License.save(k);
  $("lockMsg").className = "lock-msg ok"; $("lockMsg").textContent = "Kích hoạt thành công: " + keyText(r);
  setTimeout(() => { $("lock").hidden = true; licensed = true; showKey(r); start(); }, 700);
};
function showKey(r) {
  const c = $("keyChip"); c.textContent = "Key: " + keyText(r);
  c.className = "bn-key" + (r.info.e && r.left < 3 * 86400 ? " warn" : "");
}
async function verifyLoop() {
  const r = await License.check(await License.saved());
  if (!r.ok) { if (licensed || $("lock").hidden) showLock(r.reason); return false; }
  showKey(r); return true;
}

// ===== Khởi động =====
let started = false;
async function start() {
  if (started) { tick(); return; }
  started = true;
  runState("idle", "ĐANG TẢI");
  const cached = await Store.dayOrders(DAY).catch(() => []);
  for (const o of cached) { o.st = BO.stCode(Number(o.ps), o.psl); ORD.set(o.no, o); }
  const info = await Store.getDay(DAY).catch(() => null);
  const sj = await Store.kvGet("job").catch(() => null);
  const needNo = cached.length && cached.some((o) => o.nAll === undefined);   // đơn cũ chưa có số lần nạp -> đọc lại dần cả ngày
  if (!(info && info.full) && sj && sj.day === DAY && cached.length) {
    // tool khởi động lại giữa lúc đang tải cả ngày (vd vừa nâng cấp): tải tiếp từ trang đang dở
    job = { kind: "full", ci: sj.ci, page: Math.max(1, sj.page), pages: sj.pages, total: 0, got: 0, resumed: true };
    if (Date.now() - sj.at > 120e3) catchUpFrom = Math.floor(sj.at / 1000) - 600;
    sysmsg(`Đang tải tiếp đơn hôm nay từ trang ${job.page}/${sj.pages} (đã có ${fmt(cached.length)} đơn trong máy)…`, "info");
  }
  if (info && info.full && cached.length && needNo) job = { kind: "resync", ci: 0, page: 1, pages: 1, total: 0, got: 0 };
  if (info && info.full && cached.length) {
    lastFull = info.full;
    if (Date.now() - info.at < 60 * 60e3) catchUpFrom = Math.floor(info.at / 1000) - 1800;   // tắt dưới 1 giờ: đọc bù
    else catchUpFrom = Math.floor(info.at / 1000) - 1800;                                     // tắt lâu: đọc bù dần từ lần quét cuối
  }
  keepDays().then((n) => Store.prune(n)).catch(() => {});
  rebuild(); segs();
  $("dayRange").textContent = DAY.slice(8) + "/" + DAY.slice(5, 7) + " 00:00 → " + new Date().toLocaleTimeString("vi-VN", { hour12: false }).slice(0, 5);
  let s0 = "home"; try { s0 = localStorage.getItem("tab") || "home"; } catch (e) {}
  go(s0);
  $("readCount").textContent = fmt(ORD.size);
  tick();
  timer = setInterval(tick, CFG.SCAN_SEC * 1000);
  setInterval(() => { if (licensed && !scanning) render(); }, 60e3);
}
BO.onWait = (sec) => { if (!lastFull) runState("idle", "BO BẮT CHỜ " + sec + "S"); };
(async function boot() {
  await loadSettings();
  FEEH = (await Store.kvGet("feeHist").catch(() => null)) || {};
  FEEOV = (await Store.kvGet("feeOv").catch(() => null)) || {};
  FEEOUT = (await Store.kvGet("feeOut").catch(() => null)) || {};
  PSTATE = (await Store.kvGet("pstate").catch(() => null)) || {};
  Object.assign(BALT, (await Store.kvGet("balt").catch(() => null)) || {});
  { const s = await chrome.storage.local.get(["fakeMark", "fakeIgn"]); FMARK = s.fakeMark || {}; FIGN = s.fakeIgn || {}; }
  rebuild(); segs(); go("home");
  checkUpdate(); setInterval(checkUpdate, 30 * 60e3);
  if (await verifyLoop()) { licensed = true; start(); } else { await showLock((await License.check(await License.saved())).reason); }
  setInterval(async () => { if (licensed) { const ok = await verifyLoop(); if (!ok) licensed = false; } }, 60e3);
})();
})();
