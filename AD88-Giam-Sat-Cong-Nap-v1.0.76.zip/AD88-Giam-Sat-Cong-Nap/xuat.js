// AD88 Giám Sát XUẤT KHOẢN — đọc Lệnh rút tiền, nhà thứ 3 bên rút, FK
(() => {
const $ = (id) => document.getElementById(id);
const pad = (n) => String(n).padStart(2, "0");
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmt = (n) => Math.round(n || 0).toLocaleString("vi-VN");
const nk = (s) => String(s || "").normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[đĐ]/g, "d").toLowerCase().replace(/[^a-z0-9]/g, "");
const dayKey = (d) => d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
const dayStartOf = (key) => { const [y, m, d] = key.split("-").map(Number); return Math.floor(new Date(y, m - 1, d).getTime() / 1000); };
const nowU = () => Math.floor(Date.now() / 1000);
const clock = (t) => [Math.floor(t / 3600), Math.floor((t % 3600) / 60), t % 60].map((v) => pad(Math.floor(v))).join(":");
const hms = (s) => clock(Math.max(0, Math.min(86399, s)));
const parseHms = (v) => { const p = String(v || "").split(":").map((x) => parseInt(x, 10) || 0); return Math.min(23, p[0] || 0) * 3600 + Math.min(59, p[1] || 0) * 60 + Math.min(59, p[2] || 0); };
const durTxt = (s) => (s == null || s < 0 ? "—" : s >= 3600 ? Math.floor(s / 3600) + "g " + pad(Math.floor((s % 3600) / 60)) + "p" : Math.floor(s / 60) + "'" + pad(Math.round(s % 60)) + '"');
const dtTxt = (u) => (u ? new Date(u * 1000).toLocaleString("vi-VN", { hour12: false }) : "—");
const tod = (u, D0) => (u ? clock(u - D0) : "—");
// thời gian BO trả có thể là giây, mili-giây hoặc chuỗi "2026-10-13 12:00:00"
const toU = (v) => { if (v == null || v === "" || v === 0 || v === "0") return 0; if (typeof v === "number" || /^\d+$/.test(String(v))) { const n = Number(v); return n > 1e11 ? Math.floor(n / 1000) : n; } const d = new Date(String(v).replace(" ", "T")); return isNaN(d) ? 0 : Math.floor(d.getTime() / 1000); };

// ===== Tình trạng đơn rút (ô Tình trạng đơn hàng trên BO) =====
const STN = { 1: "Đang chờ chuyển tiền", 101: "Đang chờ chuyển tiền (không bị khóa)", 102: "Đang chờ chuyển tiền (bị khóa)", 3: "Chờ thanh toán bên thứ ba", 5: "Thanh toán không thành công", 9: "Thanh toán không thành công", 7: "Đã hủy", 2: "Đã từ chối", 4: "Đã thanh toán", 8: "Đã bắt buộc chuyển tiền" };
const grp = (st) => ([1, 101, 102].includes(st) ? "wait" : st === 3 ? "third" : st === 4 || st === 8 ? "ok" : st === 5 || st === 9 ? "fail" : st === 7 || st === 2 ? "cancel" : "wait");
const GRP = [["all", "Tất cả lệnh", ""], ["wait", "Chờ XNK chuyển tiền", "warn"], ["third", "Chờ bên thứ 3", "warn"], ["ok", "Đã thanh toán", "ok"], ["fail", "Thanh toán không thành công", "bad"], ["cancel", "Đã hủy / từ chối", ""]];
const PILL = { wait: "warnp", third: "warnp", ok: "on", fail: "badp", cancel: "" };

// ===== Trạng thái =====
let DAY = dayKey(new Date()), D0 = dayStartOf(DAY);
let VIEW = null;                     // ngày cũ đang xem
const ORD = new Map();               // số lệnh -> đơn (hôm nay)
const VORD = new Map();              // đơn ngày cũ
let FKMAP = {};
let FKALL = {};
let RVH = {};                        // số lệnh -> lịch sử đẩy nhà [{k:"01", m, s, mark, t, op}]                      // số lệnh -> {u, t} đọc từ file BO xuất (cột Kiểm toán viên / Thời gian xem xét kiểm soát rủi ro)
let NOFK = new Set();                // lệnh rút không cần xem xét (không qua FK)
let NOFKV = new Set();                      // số lệnh -> {u, t} ghi nhận từ trang Đánh giá kiểm soát rủi ro
let MERCH = [], merchAt = 0, merchErr = "";
let QT = null;                       // queryType dùng được (5 có cột FK, 3 không)
let scanning = false, lastFull = 0, lastScanAt = 0, licensed = false;
const st = { tab: "home", lg: "all", lh: "", page: 0, from: 0, to: 86399, basis: "ct", tf: "day" };
const SRC = () => (VIEW ? VORD : ORD);
const V0 = () => (VIEW ? dayStartOf(VIEW) : D0);
const NOWS = () => (VIEW ? 86399 : nowU() - D0);

// Số tiền như cột "Số tiền rút" trên BO (đơn vị nghìn ₫ → ₫). Lệnh USDT: realAmount là số USDT, quy đổi theo tỷ giá.
function numX(v) { if (v == null || v === "") return NaN; return Number(String(v).replace(/[,\s₫]/g, "")); }
function wdIsCoin(r) { const x = numX(r.exchangeRate); return (r.currencyCode && r.currencyCode !== "VND") || (x > 1.5) || /usdt|trc|erc/i.test(String(r.withdraw_account_type || "")); }
function wdAmt(r) {
  const m = numX(r.money), ra = numX(r.realAmount), x = numX(r.exchangeRate) || numX(r.cryptoRate);
  if (m > 0) return Math.round(m * 1000);
  if (wdIsCoin(r) && ra > 0 && x > 1.5) return Math.round(ra * x);
  const ca = numX(r.channelAmount); if (wdIsCoin(r) && ca > 1000) return Math.round(ca);
  return ra > 0 ? ra : 0;
}
function norm(r, dk) {
  const t = r.time || {};
  const ct = toU(t.create_time ?? r.createTime), at = toU(t.apply_time ?? r.optTime), ft = toU(t.cach_time);
  const s = Number(r.status);
  const merch = typeof r.merch === "string" ? r.merch : "";
  const fkU = r.auditUser || "", fkT = toU(r.auditTime);
  return {
    no: String(r.order_no ?? r.orderNo), day: dk, acc: r.platform_id || r.account || "", uid: String(r.username || r.userIdx || ""),
    amt: wdAmt(r),
    usd: wdIsCoin(r) ? numX(r.realAmount) : 0, cur: r.currencyCode || "VND",
    st: s, ct, at, ft: ft || (grp(s) === "ok" ? at : 0), dur: Number(r.cashDuration) || 0,
    pt: (() => { const p = toU(r.waitThirdPayTime); return p && p >= ct ? p : 0; })(),   // lúc XNK đẩy sang nhà thứ 3
    op: r.operator || "", lock: r.lockUser || "", merch, remark: r.remark || "", fkU, fkT, rv: Number(r.review_count) || 0,
    bank: (r.accountInfo && r.accountInfo["ngân hàng"]) || r.card_bank || "", recv: r.card_user || (r.accountInfo && r.accountInfo["Họ Tên Thật"]) || "", lvl: r.level_name || "", vip: r.vip_name || "",
    nDep: Number(r.depositCount) || 0, nWd: Number(r.withdraw_count) || 0, first: !!r.is_first
  };
}
// gắn FK từ trang rủi ro nếu BO không trả auditUser/auditTime
const isNoFK = (o) => (VIEW ? NOFKV : NOFK).has(o.no);
const fkOf = (o) => { if (isNoFK(o)) return { u: "", t: 0, no: true }; if (o.fkU && o.fkT) return { u: o.fkU, t: o.fkT }; const f = FKALL[o.no] || FKMAP[o.no]; return f ? { u: o.fkU || f.u, t: o.fkT || f.t } : { u: o.fkU, t: o.fkT }; };
const pushNo = (o) => { const h = RVH[o.no]; if (h && h.length) return h[h.length - 1].k; return o.rv ? pad(o.rv) : ""; };
const pushOut = (o) => (pushNo(o) ? pushNo(o) + o.no : "");
const histTxt = (o) => { const h = RVH[o.no]; return h && h.length > 1 ? h.map((x) => `${x.k} ${x.m}${x.s ? " (" + x.s + ")" : ""}`).join(" → ") : ""; };
const tTotal = (o) => (o.ft && o.ct ? o.ft - o.ct : null);
const tFK = (o) => { const f = fkOf(o); return f.no ? null : f.t && o.ct ? Math.max(0, f.t - o.ct) : null; };
// XNK = từ lúc FK note xong (hoặc lúc khách tạo lệnh nếu không qua FK) đến lúc đẩy sang nhà thứ 3
const tXNK = (o) => { const f = fkOf(o), b = f.no ? o.ct : f.t; const e = o.pt || o.ft; return e && b ? Math.max(0, e - b) : null; };
// Nhà thứ 3 chi = từ lúc đẩy sang nhà đến lúc hoàn thành
const tNHA = (o) => (o.pt && o.ft ? Math.max(0, o.ft - o.pt) : null);
const houseOf = (o) => o.merch || (grp(o.st) === "ok" ? "Thanh toán thủ công" : "");

// ===== giao diện chung =====
function sysmsg(text, kind, actions) { const el = $("sysmsg"); if (!text) { el.hidden = true; return; } el.hidden = false; el.className = "sysmsg " + (kind || "info"); el.innerHTML = `<span>${text}</span>` + (actions || ""); }
function runState(kind, txt) { const r = $("bnRun"); r.className = "bn-run" + (kind === "ok" ? "" : kind === "err" ? " err" : " idle"); $("bnRunTxt").textContent = txt; }
const THU = ["Chủ nhật", "Thứ 2", "Thứ 3", "Thứ 4", "Thứ 5", "Thứ 6", "Thứ 7"];
setInterval(() => { const d = new Date(); $("bnClock").textContent = d.toLocaleTimeString("vi-VN", { hour12: false }); $("bnDate").textContent = THU[d.getDay()] + ", " + pad(d.getDate()) + "/" + pad(d.getMonth() + 1) + "/" + d.getFullYear(); }, 1000);
$("verTxt").textContent = "v" + chrome.runtime.getManifest().version;
// phông, cỡ chữ, giao diện dùng chung với trang nhập
try { const f = localStorage.getItem("font"); if (f) document.body.dataset.font = f; const z = localStorage.getItem("size"); if (z) document.body.dataset.size = z; } catch (e) {}
const BG = (() => { let k = 0; const list = () => [...document.querySelectorAll(".bn-bg")].filter((e) => e.dataset.mode === (document.body.dataset.skin === "b" ? "light" : "dark")); function show(i) { const l = list(); if (!l.length) return; k = ((i % l.length) + l.length) % l.length; document.querySelectorAll(".bn-bg").forEach((e) => e.classList.toggle("on", e === l[k])); } setInterval(() => show(k + 1), 8000); return { reset: () => show(0) }; })();
let SKIN = "auto";
const autoSkin = () => { const h = new Date().getHours(); return h >= 6 && h < 18 ? "b" : "a"; };
function applySkin() { const w = SKIN === "auto" ? autoSkin() : SKIN; if (document.body.dataset.skin !== w) { document.body.dataset.skin = w; BG.reset(); } }
document.querySelector('[aria-label="Giao diện"]').addEventListener("click", (e) => { const b = e.target.closest("button"); if (!b) return; SKIN = b.dataset.skin; b.parentNode.querySelectorAll("button").forEach((x) => x.setAttribute("aria-pressed", x === b)); applySkin(); try { localStorage.setItem("skin", SKIN); } catch (_) {} });
try { SKIN = localStorage.getItem("skin") || "auto"; } catch (_) {}
document.querySelector(`[aria-label="Giao diện"] [data-skin="${SKIN}"]`)?.setAttribute("aria-pressed", "true"); applySkin(); setInterval(applySkin, 60000);

// ===== khung thời gian dùng chung =====
const TF = [["1h", "1 giờ", 3600], ["3h", "3 giờ", 10800], ["6h", "6 giờ", 21600], ["day", "00:00 → nay", 0]];
function range() { const N = NOWS(); if (st.tf === "custom") return [Math.min(st.from, st.to), Math.max(st.from, st.to)]; const f = TF.find((x) => x[0] === st.tf) || TF[3]; return f[2] ? [Math.max(0, N - f[2]), N] : [0, N]; }
function rangeLabel() { const [a, b] = range(); return `${(VIEW || DAY).split("-").reverse().join("/")} · ${clock(a)} → ${clock(b)} · theo ${st.basis === "ct" ? "thời gian yêu cầu" : "thời gian hoàn thành"}`; }
function inRange() { const [a, b] = range(), z = V0(); return [...SRC().values()].filter((o) => { const v = st.basis === "ct" ? o.ct : o.ft; return v && v - z >= a && v - z <= b; }); }
function inRangeCT() { const [a, b] = range(), z = V0(); return [...SRC().values()].filter((o) => o.ct && o.ct - z >= a && o.ct - z <= b); }
function segs() {
  $("xSeg").innerHTML = TF.map((f) => `<button aria-pressed="${st.tf === f[0]}" data-v="${f[0]}">${f[1]}</button>`).join("") + `<button aria-pressed="${st.tf === "custom"}" data-v="custom">Tự chọn</button>`;
  const [a, b] = range(); $("xFrom").value = hms(a); $("xTo").value = hms(b); $("xDay").max = DAY; $("xDay").value = VIEW || DAY;
}
$("xSeg").onclick = (e) => { const b = e.target.closest("button"); if (!b) return; if (b.dataset.v === "custom") { st.from = parseHms($("xFrom").value); st.to = parseHms($("xTo").value); } st.tf = b.dataset.v; st.page = 0; segs(); render(); };
const fmtIn = (v) => String(v).replace(/\D/g, "").slice(0, 6).replace(/^(\d{2})(\d)/, "$1:$2").replace(/^(\d{2}:\d{2})(\d)/, "$1:$2");
["xFrom", "xTo"].forEach((id) => { const i = $(id); i.addEventListener("input", () => (i.value = fmtIn(i.value))); i.addEventListener("blur", () => (i.value = hms(parseHms(i.value)))); i.addEventListener("keydown", (e) => { if (e.key === "Enter") $("xGo").click(); }); });
$("xGo").onclick = async () => { const d = $("xDay").value || DAY; st.from = parseHms($("xFrom").value); st.to = parseHms($("xTo").value); st.tf = "custom"; st.page = 0; if (d !== (VIEW || DAY)) { if (st.from === 0 && d < DAY) st.to = Math.max(st.to, 86399); await setView(d); } segs(); render(); };
$("xDay").addEventListener("change", async () => { const d = $("xDay").value || DAY; st.tf = "day"; st.page = 0; await setView(d); segs(); render(); });   // đổi ngày là tải ngay cả ngày đó (00:00 → 23:59)   // đổi ngày là tải ngay ngày đó
$("xToday").onclick = async () => { st.tf = "day"; await setView(null); segs(); render(); };
$("xBasis").onchange = () => { st.basis = $("xBasis").value; st.page = 0; render(); };

// ===== thống kê =====
function stat(L) {
  const a = { n: L.length, amt: 0, ok: 0, okAmt: 0, wait: 0, third: 0, fail: 0, cancel: 0, tot: [], fk: [], xnk: [], nha: [] };
  for (const o of L) {
    const g = grp(o.st); a[g]++; a.amt += o.amt;
    if (g === "ok") { a.okAmt += o.amt; const t = tTotal(o); if (t != null) a.tot.push(t); const x = tXNK(o); if (x != null) a.xnk.push(x); const h = tNHA(o); if (h != null) a.nha.push(h); }
    const f = tFK(o); if (f != null) a.fk.push(f);
  }
  const avg = (v) => (v.length ? v.reduce((s, x) => s + x, 0) / v.length : null);
  const pct = (v, lo, hi) => (v.length ? v.filter((x) => x > lo && x <= hi).length / v.length * 100 : 0);
  a.avgTot = avg(a.tot); a.avgFK = avg(a.fk); a.avgXNK = avg(a.xnk); a.avgNHA = avg(a.nha); a.maxNHA = a.nha.length ? Math.max(...a.nha) : null; a.pNha3 = pct(a.nha, 180, 1e9);
  a.p1 = pct(a.tot, -1, 60); a.p3 = pct(a.tot, 60, 180); a.p10 = pct(a.tot, 180, 600); a.pOver = pct(a.tot, 600, 1e9);
  a.max = a.tot.length ? Math.max(...a.tot) : null;
  return a;
}
const kpi = (lab, val, sub, cls, go) => `<div class="kpi ${cls || ""}${go ? " go" : ""}"${go ? ` data-go="${go}"` : ""}><div class="lab">${lab}</div><div class="val">${val}</div><div class="sub">${sub || ""}</div></div>`;
const vnd = (n) => fmt(n) + " ₫";
function merchFind(name) { const k = nk(name).replace(/vnd$/, ""); return MERCH.find((m) => nk(m.merchName) === k || nk(m.channelName).startsWith(k)) || null; }

function alerts(L) {
  const N = nowU(), out = [];
  if (VIEW) return out;
  const byH = {};
  for (const o of (openSynced ? ORD.values() : [])) { const g = grp(o.st); if (g === "third" && N - o.ct > 600) (byH[o.merch || "?"] ??= []).push(o); }
  for (const h in byH) out.push({ lv: "bad", t: `${h}: ${byH[h].length} lệnh chờ bên thứ 3 quá 10 phút`, d: "Lâu nhất " + durTxt(N - Math.min(...byH[h].map((o) => o.ct))) + " · " + byH[h].slice(0, 4).map((o) => o.no).join(", "), act: "Kiểm tra nhà", go: "third", h: h === "?" ? "" : h, q: byH[h].length === 1 ? byH[h][0].no : "" });
  const w = openSynced ? [...ORD.values()].filter((o) => grp(o.st) === "wait" && N - o.ct > 900) : [];
  if (w.length) out.push({ lv: "warn", t: `${w.length} lệnh chờ XNK chuyển tiền quá 15 phút`, d: w.slice(0, 5).map((o) => `${o.no} (${durTxt(N - o.ct)}${o.lock ? " · " + o.lock : ""})`).join(", "), act: "Xử lý", go: "wait", q: w.length === 1 ? w[0].no : "" });
  for (const m of MERCH) {
    const bal = Number(m.balance);
    if (m.status === 1 && m.payCurrency === "VND" && m.balance != null && bal < 20e6) out.push({ lv: "warn", t: `${m.merchName}: số dư thấp ${vnd(bal)}`, d: "Nhà đang bật nhưng số dư dưới 20 triệu", act: "Nạp quỹ", tab: "house" });
  }
  const failH = {}; for (const o of L) if (grp(o.st) === "fail") (failH[o.merch || "?"] ??= 0), failH[o.merch || "?"]++;
  for (const h in failH) if (failH[h] >= 3) out.push({ lv: "bad", t: `${h}: ${failH[h]} lệnh thanh toán không thành công`, d: "Trong khung thời gian đang xem", act: "Xem lệnh", go: "fail", h: h === "?" ? "" : h });
  return out;
}

function renderHome() {
  const L = inRange(), a = stat(L);
  $("h-kpis").innerHTML = [
    kpi("Tổng lệnh rút", fmt(a.n), vnd(a.amt), "", "all"),
    kpi("Đã thanh toán", fmt(a.ok), vnd(a.okAmt), "ok", "ok"),
    kpi("Chờ XNK chuyển tiền", fmt(a.wait), "đang chờ / đang khóa", a.wait ? "warn" : "", "wait"),
    kpi("Chờ bên thứ 3", fmt(a.third), "đã đẩy sang nhà", a.third ? "warn" : "", "third"),
    kpi("Không thành công", fmt(a.fail), "thanh toán lỗi", a.fail ? "bad" : "", "fail"),
    kpi("Hủy / từ chối", fmt(a.cancel), "", "", "cancel"),
    kpi("Tốc độ xuất khoản TB", durTxt(a.avgTot), `≤1': ${a.p1.toFixed(0)}% · >10': ${a.pOver.toFixed(0)}%`, ""),
    kpi("TB FK", durTxt(a.avgFK), fmt(a.fk.length) + " lệnh có FK · " + fmt(L.filter(isNoFK).length) + " lệnh không qua FK", ""),
    kpi("TB XNK đẩy đơn", durTxt(a.avgXNK), "từ lúc FK note (hoặc khách tạo lệnh) đến lúc đẩy sang nhà", ""),
    kpi("TB nhà thứ 3 chi", durTxt(a.avgNHA), "từ lúc đẩy sang nhà đến hoàn thành", "")
  ].join("");
  const al = alerts(L); $("cnt-alert").textContent = al.length;
  $("h-alerts").innerHTML = al.length ? al.map((x) => `<button class="alert ${x.lv}"${x.go ? ` data-go="${x.go}" data-h="${esc(x.h || "")}" data-q="${esc(x.q || "")}"` : x.tab ? ` data-gotab="${x.tab}"` : ""} title="Bấm để xem"><span class="lvl">${x.lv === "bad" ? "ĐỎ" : "VÀNG"}</span><span class="t">${esc(x.t)}</span><span class="act">${x.act}</span><span class="d">${esc(x.d)}</span></button>`).join("") : `<div class="empty">Không có gì bất thường.</div>`;
  $("h-hint").textContent = rangeLabel();
  $("h-tbl").innerHTML = houseTable(L, true);
}
function houseRows(L) {
  const by = {}; for (const o of L) { const h = houseOf(o); if (h) (by[h] ??= []).push(o); }
  return Object.entries(by).map(([h, l]) => ({ h, a: stat(l), m: merchFind(h) })).sort((x, y) => y.a.ok - x.a.ok);
}
function houseTable(L, short) {
  const rows = houseRows(L), N = nowU();
  let t = `<thead><tr><th class="l">Nhà thứ 3</th><th class="l">BO</th><th>Số dư (₫)</th><th>Đã chi</th><th>Tiền đã chi (₫)</th><th>Chờ bên thứ 3</th><th>Không thành công</th><th>TB tổng</th><th>TB XNK đẩy</th><th>TB nhà chi</th><th>Nhà chi &gt; 3'</th><th>Nhà chi chậm nhất</th><th>≤ 1'</th><th>1–3'</th><th>3–10'</th><th>&gt; 10'</th><th>Chậm nhất</th></tr></thead><tbody>`;
  for (const { h, a, m } of rows) {
    const waitOld = [...SRC().values()].filter((o) => o.merch === h && grp(o.st) === "third").map((o) => N - o.ct);
    t += `<tr class="${a.fail >= 3 || (waitOld.length && Math.max(...waitOld) > 600 && !VIEW) ? "rbad" : a.pOver > 5 ? "rwarn" : ""}"><td class="name">${esc(h)}</td><td class="l">${m ? (m.status === 1 ? '<span class="pill on">Bật</span>' : '<span class="pill badp">Tắt</span>') : '<span class="mut">—</span>'}</td><td>${m && m.balance != null ? fmt(m.balance) : "—"}</td><td class="ok gocell" data-go="ok" data-h="${esc(h)}">${fmt(a.ok)}</td><td>${fmt(a.okAmt)}</td><td class="${a.third ? "warn" : "mut"} gocell" data-go="third" data-h="${esc(h)}">${fmt(a.third)}${waitOld.length && !VIEW ? ` <small>(lâu nhất ${durTxt(Math.max(...waitOld))})</small>` : ""}</td><td class="${a.fail ? "bad" : "mut"} gocell" data-go="fail" data-h="${esc(h)}">${fmt(a.fail)}</td><td>${durTxt(a.avgTot)}</td><td>${durTxt(a.avgXNK)}</td><td class="${a.avgNHA > 180 ? "bad" : ""}">${durTxt(a.avgNHA)}</td><td class="${a.pNha3 ? "warn" : "mut"}">${a.pNha3.toFixed(0)}%</td><td>${durTxt(a.maxNHA)}</td><td>${a.p1.toFixed(0)}%</td><td>${a.p3.toFixed(0)}%</td><td>${a.p10.toFixed(0)}%</td><td class="${a.pOver ? "bad" : ""}">${a.pOver.toFixed(1)}%</td><td>${durTxt(a.max)}</td></tr>`;
  }
  if (!rows.length) t += `<tr><td class="l mut" colspan="17">Chưa có lệnh rút trong khung thời gian này</td></tr>`;
  return t + "</tbody>";
}
function renderHouse() {
  const L = inRange();
  $("ho-hint").textContent = rangeLabel();
  $("ho-tbl").innerHTML = houseTable(L);
  $("bal-hint").textContent = merchErr ? "Lỗi đọc số dư: " + merchErr : merchAt ? "Cập nhật " + new Date(merchAt).toLocaleTimeString("vi-VN", { hour12: false }) + " · đọc lại mỗi 2 phút" : "Đang đọc…";
  let t = `<thead><tr><th class="l">Nhà thứ 3</th><th class="l">Kênh</th><th class="l">Trạng thái</th><th>Số dư</th><th class="l">Tiền tệ</th><th>Rút tối thiểu</th><th>Rút tối đa</th><th>Thứ tự</th></tr></thead><tbody>`;
  for (const m of [...MERCH].sort((a, b) => (b.weight || 0) - (a.weight || 0))) {
    const lim = m.withdrawAmountLimits ? Object.values(m.withdrawAmountLimits)[0] || {} : {};
    t += `<tr class="${m.status === 1 ? "" : "rbad"}"><td class="name">${esc(m.merchName)}</td><td class="l mut">${esc(m.channelName)}</td><td class="l">${m.status === 1 ? '<span class="stp on"><i></i>ĐANG BẬT</span>' : '<span class="stp off"><i></i>ĐANG TẮT</span>'}</td><td>${m.balance != null ? fmt(m.balance) : "—"}</td><td class="l">${esc(m.payCurrency)}</td><td>${fmt(lim.min)}</td><td>${fmt(lim.max)}</td><td>${m.weight ?? ""}</td></tr>`;
  }
  if (!MERCH.length) t += `<tr><td class="l mut" colspan="8">Chưa đọc được danh sách nhà bên rút</td></tr>`;
  $("bal-tbl").innerHTML = t + "</tbody>";
}
function staffTable(L, kind) {
  const by = {};
  for (const o of L) {
    if (kind === "fk") { const f = fkOf(o), d = tFK(o); if (!f.u || d == null) continue; (by[f.u] ??= []).push([d, o]); }
    else { if (grp(o.st) !== "ok" || !o.op) continue; const d = tXNK(o) ?? tTotal(o); if (d == null) continue; (by[o.op] ??= []).push([d, o]); }
  }
  const rows = Object.entries(by).map(([u, l]) => { const v = l.map((x) => x[0]); return { u, n: l.length, amt: l.reduce((s, x) => s + x[1].amt, 0), avg: v.reduce((s, x) => s + x, 0) / v.length, min: Math.min(...v), max: Math.max(...v), slow: v.filter((x) => x > (kind === "fk" ? 300 : 600)).length }; }).sort((a, b) => b.n - a.n);
  let t = `<thead><tr><th class="l">Nhân viên</th><th>Số lệnh</th><th>Tổng tiền (₫)</th><th>Trung bình</th><th>Nhanh nhất</th><th>Chậm nhất</th><th>${kind === "fk" ? "&gt; 5 phút" : "&gt; 10 phút"}</th></tr></thead><tbody>`;
  for (const r of rows) t += `<tr><td class="name">${esc(r.u)}</td><td>${fmt(r.n)}</td><td>${fmt(r.amt)}</td><td>${durTxt(r.avg)}</td><td>${durTxt(r.min)}</td><td class="${r.max > (kind === "fk" ? 300 : 600) ? "bad" : ""}">${durTxt(r.max)}</td><td class="${r.slow ? "bad" : "mut"}">${fmt(r.slow)}</td></tr>`;
  if (!rows.length) t += `<tr><td class="l mut" colspan="7">${kind === "fk" ? "Chưa có dữ liệu FK (BO chưa trả cột FK; tool đang ghi nhận từ trang Đánh giá kiểm soát rủi ro)" : "Chưa có lệnh đã thanh toán"}</td></tr>`;
  return t + "</tbody>";
}
// ===== Tốc độ nhà thứ 3: so sánh khung đang chọn với khung liền trước và với hôm qua cùng giờ =====
let YEST = { dk: null, L: [] };
async function loadYest() {
  const base = VIEW || DAY, y = dayKey(new Date((dayStartOf(base) - 43200) * 1000));
  if (YEST.dk === y) return;
  YEST = { dk: y, L: (await StoreX.dayOrders(y).catch(() => [])) || [] };
  if (st.tab === "spd") render();
}
function spdOf(L) {
  const ok = L.filter((o) => grp(o.st) === "ok"), v = (f) => ok.map(f).filter((x) => x != null);
  const avg = (a) => (a.length ? a.reduce((s, x) => s + x, 0) / a.length : null);
  const tot = v(tTotal), nha = v(tNHA), xnk = v(tXNK);
  return { n: ok.length, amt: ok.reduce((s, o) => s + o.amt, 0), tot: avg(tot), nha: avg(nha), xnk: avg(xnk), p1: tot.length ? tot.filter((x) => x <= 60).length / tot.length * 100 : null, p3: nha.length ? nha.filter((x) => x > 180).length / nha.length * 100 : null, fail: L.filter((o) => grp(o.st) === "fail").length, rep: L.filter((o) => o.rv >= 2).length };
}
const trend = (cur, prev) => {
  if (cur == null || prev == null || !prev) return '<span class="mut">—</span>';
  const d = (cur - prev) / prev * 100;
  if (Math.abs(d) < 3) return `<span class="mut">≈ ${durTxt(prev)}</span>`;
  // thời gian giảm = nhanh hơn (tốt)
  return d < 0 ? `<span class="ok">▼ nhanh hơn ${Math.abs(d).toFixed(0)}%</span><small>trước: ${durTxt(prev)}</small>` : `<span class="bad">▲ chậm hơn ${d.toFixed(0)}%</span><small>trước: ${durTxt(prev)}</small>`;
};
function renderSpd() {
  loadYest();
  const [a, b] = range(), z = V0(), len = Math.max(600, b - a);
  const pick = (src, z0, x, y) => src.filter((o) => o.ct && o.ct - z0 >= x && o.ct - z0 <= y);
  const all = [...SRC().values()];
  const cur = pick(all, z, a, b), prev = pick(all, z, Math.max(0, a - len), a - 1);
  const yz = YEST.dk ? dayStartOf(YEST.dk) : 0, yday = YEST.L.length ? pick(YEST.L, yz, a, b) : [];
  const hs = [...new Set(cur.concat(prev, yday).map(houseOf).filter(Boolean))];
  const byH = (L, h) => L.filter((o) => houseOf(o) === h);
  const rows = hs.map((h) => ({ h, c: spdOf(byH(cur, h)), p: spdOf(byH(prev, h)), y: spdOf(byH(yday, h)), m: merchFind(h) })).filter((r) => r.c.n || r.p.n).sort((x, y) => (x.c.nha ?? 1e9) - (y.c.nha ?? 1e9));
  const T = spdOf(cur), TP = spdOf(prev), TY = spdOf(yday);
  const fast = rows.filter((r) => r.c.n >= 5 && r.c.nha != null)[0], slow = rows.filter((r) => r.c.n >= 5 && r.c.nha != null).slice(-1)[0];
  $("spd-kpis").innerHTML = [
    kpi("TB xử lý đơn (tổng)", durTxt(T.tot), "từ lúc khách tạo lệnh đến hoàn thành", ""),
    kpi("TB nhà thứ 3 chi", durTxt(T.nha), "từ lúc đẩy sang nhà đến hoàn thành", ""),
    kpi("So với khung trước", T.nha != null && TP.nha ? ((T.nha - TP.nha) / TP.nha * 100 > 0 ? "▲ " : "▼ ") + Math.abs((T.nha - TP.nha) / TP.nha * 100).toFixed(0) + "%" : "—", `${clock(Math.max(0, a - len))} → ${clock(a)}: ${durTxt(TP.nha)}`, T.nha != null && TP.nha ? (T.nha > TP.nha * 1.03 ? "bad" : T.nha < TP.nha * 0.97 ? "ok" : "") : ""),
    kpi("So với hôm qua cùng giờ", T.nha != null && TY.nha ? ((T.nha - TY.nha) / TY.nha * 100 > 0 ? "▲ " : "▼ ") + Math.abs((T.nha - TY.nha) / TY.nha * 100).toFixed(0) + "%" : "—", TY.n ? `hôm qua: ${durTxt(TY.nha)} · ${fmt(TY.n)} đơn` : "máy chưa lưu dữ liệu hôm qua", T.nha != null && TY.nha ? (T.nha > TY.nha * 1.03 ? "bad" : T.nha < TY.nha * 0.97 ? "ok" : "") : ""),
    kpi("Nhà chi nhanh nhất", fast ? esc(fast.h) : "—", fast ? "TB " + durTxt(fast.c.nha) + " · " + fmt(fast.c.n) + " đơn" : "", "ok"),
    kpi("Nhà chi chậm nhất", slow ? esc(slow.h) : "—", slow ? "TB " + durTxt(slow.c.nha) + " · " + fmt(slow.c.n) + " đơn" : "", "bad")
  ].join("");
  $("spd-hint").textContent = rangeLabel() + " · xếp từ nhà chi nhanh nhất · ▼ = nhanh hơn, ▲ = chậm hơn";
  let t = `<thead><tr><th class="l">#</th><th class="l">Nhà thứ 3</th><th class="l">BO</th><th>Đơn đã chi</th><th>Tiền đã chi (₫)</th><th>TB xử lý đơn (tổng)</th><th>TB XNK đẩy</th><th>TB nhà chi</th><th>Đơn ≤ 1' (tổng)</th><th>Nhà chi &gt; 3'</th><th>Không thành công</th><th title="Lệnh phải đẩy từ 2 lần (02, 03…) mới xong ở nhà này">Đẩy lại (02+)</th><th class="l">So với khung trước</th><th class="l">So với hôm qua cùng giờ</th></tr></thead><tbody>`;
  rows.forEach((r, i) => {
    const c = r.c;
    t += `<tr class="${c.nha > 180 || c.fail >= 3 ? "rbad" : c.nha > 90 ? "rwarn" : ""}"><td class="l mut">${i + 1}</td><td class="name">${esc(r.h)}</td><td class="l">${r.m ? (r.m.status === 1 ? '<span class="pill on">Bật</span>' : '<span class="pill badp">Tắt</span>') : ""}</td><td>${fmt(c.n)}</td><td>${fmt(c.amt)}</td><td style="font-weight:700">${durTxt(c.tot)}</td><td>${durTxt(c.xnk)}</td><td style="font-weight:700" class="${c.nha > 180 ? "bad" : c.nha > 90 ? "warn" : "ok"}">${durTxt(c.nha)}</td><td>${c.p1 == null ? "—" : c.p1.toFixed(0) + "%"}</td><td class="${c.p3 ? "warn" : "mut"}">${c.p3 == null ? "—" : c.p3.toFixed(0) + "%"}</td><td class="${c.fail ? "bad" : "mut"}">${fmt(c.fail)}</td><td class="${c.rep ? "warn" : "mut"}">${fmt(c.rep)}</td><td class="l">${trend(c.nha, r.p.nha)}</td><td class="l">${trend(c.nha, r.y.nha)}</td></tr>`;
  });
  if (!rows.length) t += `<tr><td class="l mut" colspan="14">Chưa có đơn đã chi trong khung thời gian này</td></tr>`;
  $("spd-tbl").innerHTML = t + "</tbody>";
  // bảng theo giờ cả ngày
  const dayAll = all.filter((o) => grp(o.st) === "ok" && tNHA(o) != null);
  const nowH = VIEW ? 23 : Math.floor(NOWS() / 3600);
  let u = `<thead><tr><th class="l">Nhà thứ 3</th>${Array.from({ length: nowH + 1 }, (_, h) => `<th>${pad(h)}h</th>`).join("")}</tr></thead><tbody>`;
  for (const h of rows.map((r) => r.h)) {
    u += `<tr><td class="name">${esc(h)}</td>`;
    for (let hr = 0; hr <= nowH; hr++) { const L = dayAll.filter((o) => houseOf(o) === h && Math.floor((o.ct - z) / 3600) === hr).map(tNHA); const v = L.length ? L.reduce((s, x) => s + x, 0) / L.length : null; u += `<td class="${v > 180 ? "bad" : v > 90 ? "warn" : v != null ? "" : "mut"}" title="${L.length} đơn">${v == null ? "·" : durTxt(v)}</td>`; }
    u += "</tr>";
  }
  $("spd-hr").innerHTML = u + "</tbody>";
}
// ===== Tốc độ xuất khoản BT3: nhà nào giữ đơn lâu, nhà nào đi đơn nhanh =====
const TDC = ["#16a34a", "#0891b2", "#2563eb", "#7c3aed", "#0d9488", "#dc2626", "#ea580c", "#e11d48", "#9333ea", "#ca8a04", "#65a30d", "#db2777", "#0284c7", "#4f46e5", "#b45309"];
const tdCol = (h) => { let x = 0; for (const c of String(h).toLowerCase()) x = (x * 31 + c.charCodeAt(0)) >>> 0; return TDC[x % TDC.length]; };
const tdLv = (s) => (s == null ? "" : s < 90 ? "ok" : s <= 180 ? "warn" : "bad");
const TDLV = { ok: "Nhanh", warn: "Hơi chậm", bad: "Giữ đơn lâu" };
const tdHeld = () => { if (VIEW) return []; const N = nowU(); return [...ORD.values()].filter((o) => grp(o.st) === "third" && o.merch).map((o) => ({ o, d: Math.max(0, N - (o.pt || o.at || o.ct)) })).sort((a, b) => b.d - a.d); };
function tdStat(L) { const ok = L.filter((o) => grp(o.st) === "ok" && o.merch && tNHA(o) != null), v = ok.map(tNHA); return { n: ok.length, avg: v.length ? v.reduce((s, x) => s + x, 0) / v.length : null, p1: v.length ? v.filter((x) => x <= 60).length / v.length * 100 : null, p3: v.length ? v.filter((x) => x > 180).length / v.length * 100 : null, fail: L.filter((o) => grp(o.st) === "fail" && o.merch).length }; }
function renderBt3() {
  const L = inRange(), [a, b] = range(), z = V0(), len = Math.max(600, b - a);
  const prev = [...SRC().values()].filter((o) => { const v = st.basis === "ct" ? o.ct : o.ft; return v && v - z >= Math.max(0, a - len) && v - z < a; });
  const held = tdHeld(), byHeld = {}; for (const x of held) (byHeld[x.o.merch] ??= []).push(x);
  const hs = [...new Set(L.filter((o) => o.merch).map((o) => o.merch).concat(Object.keys(byHeld)))];
  const rows = hs.map((h) => ({ h, c: tdStat(L.filter((o) => o.merch === h)), p: tdStat(prev.filter((o) => o.merch === h)), hd: byHeld[h] || [] })).filter((r) => r.c.n || r.hd.length).sort((x, y) => (x.c.avg ?? 1e9) - (y.c.avg ?? 1e9));
  const hasP = a > 0; $("td-hint").textContent = rangeLabel() + (hasP ? " · so sánh với khung trước " + clock(Math.max(0, a - len)).slice(0, 5) + " → " + clock(a).slice(0, 5) : "");
  const rk = rows.filter((r) => r.c.n >= 3 && r.c.avg != null), fast = rk[0], slow = rk.length > 1 ? rk[rk.length - 1] : null;
  const big = (k, ic, t, name, sub, val, vs) => `<div class="td-b" style="--k:var(--nb-${k})"><div class="ic">${ic}</div><div><small>${t}</small><b>${name}</b><span>${sub}</span></div><div class="t"><b>${val}</b><span>${vs}</span></div></div>`;
  $("td-big").innerHTML = big("ok", "⚡", "Đi đơn nhanh nhất", fast ? esc(fast.h) : "—", fast ? `${fmt(fast.c.n)} đơn · ${fast.c.p1.toFixed(0)}% xong dưới 1 phút` : "chưa đủ đơn", fast ? durTxt(fast.c.avg) : "—", "trung bình")
    + big("bad", "🐢", "Giữ đơn lâu nhất", slow ? esc(slow.h) : "—", slow ? `${fmt(slow.c.n)} đơn · ${slow.c.p3.toFixed(0)}% đơn trên 3 phút` : "chưa đủ đơn", slow ? durTxt(slow.c.avg) : "—", "trung bình")
    + big(held.length ? (held[0].d > 300 ? "bad" : "warn") : "ok", "⏳", "Đang giữ đơn ngay lúc này", VIEW ? "—" : held.length ? `${held.length} đơn · ${Object.keys(byHeld).length} nhà` : "Không có", VIEW ? "chỉ xem được khi xem hôm nay" : held.length ? "lâu nhất: " + esc(held[0].o.merch) : "các nhà đều đã chi hết", held.length ? durTxt(held[0].d) : "—", held.length ? "đang chờ" : "");
  const MAX = Math.max(300, ...rows.map((r) => (r.c.avg || 0) * 1.12)), P = (s) => Math.min(100, s / MAX * 100);
  $("td-rk").innerHTML = rows.map((r, i) => { const c = r.c, l = tdLv(c.avg), d = c.avg != null && r.p.avg ? (c.avg - r.p.avg) / r.p.avg * 100 : null;
    return `<div class="td-r ${l} ${st.td === r.h ? "sel" : ""}" data-td="${esc(r.h)}" style="--hc:${tdCol(r.h)}"><span class="n">${c.avg == null ? "" : i + 1}</span><span class="h">${esc(r.h)}<small>${fmt(c.n)} đơn đã chi${c.fail ? ` · <span class="bad" title="${c.fail} lệnh không thành công">${c.fail} lỗi</span>` : ""}</small></span>
      <div class="trk">${c.avg != null ? `<em style="width:${P(c.avg)}%"></em>` : ""}<i class="m" style="left:${P(90)}%"></i><i class="m" style="left:${P(180)}%"></i><span class="v${c.avg != null && P(c.avg) > 78 ? " in" : ""}" style="${c.avg != null && P(c.avg) > 78 ? `right:${100 - P(c.avg)}%` : `left:${c.avg != null ? P(c.avg) : 0}%`}">${c.avg != null ? durTxt(c.avg) : "chưa có đơn chi xong"}</span></div>
      <span>${l ? `<span class="lv">${TDLV[l]}</span>` : ""}</span><span class="tr">${!hasP ? "" : d == null ? '<span class="mut">—</span>' : Math.abs(d) < 3 ? '<span class="mut">≈ như khung trước</span>' : d > 0 ? `<span class="bad">▲ chậm hơn ${d.toFixed(0)}%</span>` : `<span class="ok">▼ nhanh hơn ${(-d).toFixed(0)}%</span>`}${hasP ? `<small>${r.p.avg ? "khung trước: " + durTxt(r.p.avg) : "so với khung trước"}</small>` : ""}</span></div>`; }).join("")
    + (rows.length ? `<div class="td-ax"><span></span><span></span><div>${[0, 90, 180, 300].filter((s) => s <= MAX).map((s) => `<span style="left:${P(s)}%">${s ? durTxt(s) : "0'"}</span>`).join("")}</div><span></span><span></span></div>` : `<div class="mut" style="padding:16px">Chưa có đơn rút đã chi qua nhà thứ 3 trong khung thời gian này.</div>`);
  const al = (s) => (s > 300 ? "bad" : s > 180 ? "warn" : "ok"), hk = Object.entries(byHeld).sort((x, y) => y[1][0].d - x[1][0].d);
  const free = rows.filter((r) => !r.hd.length).map((r) => r.h);
  $("td-hold").innerHTML = VIEW ? `<div class="mut">Phần này chỉ hiện khi xem hôm nay (đơn đang chờ nhà chi).</div>` : hk.map(([h, l]) => `<div class="td-hd ${al(l[0].d)}" data-td="${esc(h)}" style="--hc:${tdCol(h)}"><div class="td-top"><b>${esc(h)}</b><span class="mut">· giữ ${l.length} đơn</span><div class="old"><b>${durTxt(l[0].d)}</b><small>đơn lâu nhất</small></div></div>
    <div class="chips">${l.slice(0, 12).map((x) => `<span class="td-chip ${al(x.d)}" title="${esc(x.o.no)} · ${esc(x.o.acc)}"><b>${durTxt(x.d)}</b> <span>· ${fmt(x.o.amt)} ₫</span></span>`).join("")}${l.length > 12 ? `<span class="mut">+${l.length - 12} đơn</span>` : ""}</div></div>`).join("")
    + `<div class="mut">${hk.length ? (free.length ? `Các nhà còn lại: <b class="ok">không giữ đơn nào</b> — ${free.map(esc).join(", ")}` : "") : '<b class="ok">Không nhà nào đang giữ đơn.</b>'}</div>`;
  $("cnt-hold").textContent = held.length; $("cnt-hold").hidden = !held.length;
  tdDetail(L);
}
let TDCUR = [];
function tdDetail(L) {
  const h = st.td, box = $("td-dt");
  if (!h) { box.hidden = true; return; }
  box.hidden = false; box.style.setProperty("--hc", tdCol(h));
  const N = nowU(), z = V0(), held = tdHeld().filter((x) => x.o.merch === h), hn = new Set(held.map((x) => x.o.no));
  const rows = held.map((x) => ({ o: x.o, d: x.d, s: "hold" })).concat(L.filter((o) => o.merch === h && !hn.has(o.no) && (grp(o.st) === "ok" || grp(o.st) === "fail")).map((o) => ({ o, d: grp(o.st) === "ok" ? tNHA(o) : o.pt && o.ft ? Math.max(0, o.ft - o.pt) : null, s: grp(o.st) === "ok" ? "done" : "fail" })));
  rows.sort((x, y) => (y.d ?? -1) - (x.d ?? -1));
  const dn = rows.filter((r) => r.s === "done" && r.d != null), v = dn.map((r) => r.d), avg = v.length ? v.reduce((s, x) => s + x, 0) / v.length : null;
  const F = { all: rows, hold: rows.filter((r) => r.s === "hold"), slow: rows.filter((r) => r.d > 180), fast: dn.filter((r) => r.d < 90), fail: rows.filter((r) => r.s === "fail") };
  const f = F[st.tdf] ? st.tdf : "all", q = ($("td-q").value || "").trim().toLowerCase();
  const V = F[f].filter((r) => !q || [r.o.no, r.o.acc].some((x) => String(x || "").toLowerCase().includes(q)));
  TDCUR = V;
  $("td-dh").textContent = h; $("td-dhint").textContent = rangeLabel() + " · xếp từ đơn nhà giữ lâu nhất · bấm mã lệnh để xem đầy đủ trong Danh sách lệnh rút";
  const k = (t, val, c) => `<div class="k ${c || ""}"><small>${t}</small><b>${val}</b></div>`;
  $("td-ks").innerHTML = k("Đơn đã chi", fmt(dn.length)) + k("Nhà chi trung bình", durTxt(avg), tdLv(avg)) + k("Nhanh nhất", v.length ? durTxt(Math.min(...v)) : "—", "ok") + k("Lâu nhất", v.length ? durTxt(Math.max(...v)) : "—", "bad") + k("Đang giữ", fmt(F.hold.length), F.hold.length ? "bad" : "") + k("Đơn trên 3 phút", fmt(F.slow.length), F.slow.length ? "warn" : "");
  $("td-f").innerHTML = [["all", "Tất cả"], ["hold", "Đang giữ"], ["slow", "Trên 3 phút"], ["fast", "Nhanh dưới 1'30\""], ["fail", "Không thành công"]].map(([x, n]) => `<button class="chip" aria-pressed="${f === x}" data-tdf="${x}">${n} (${fmt(F[x].length)})</button>`).join("");
  let t = `<thead><tr><th class="l">#</th><th class="l">Mã lệnh</th><th class="l">Tài khoản</th><th>Số tiền (₫)</th><th>Khách tạo lệnh</th><th>Đẩy sang nhà</th><th>Nhà chi xong</th><th>Nhà chi mất</th><th class="l">Lần đẩy</th><th class="l">XNK</th><th class="l">Trạng thái</th></tr></thead><tbody>`;
  V.slice(0, 500).forEach((r, i) => { const o = r.o, l = r.s === "hold" ? (r.d > 180 ? "bad" : tdLv(r.d)) : tdLv(r.d);
    t += `<tr class="${r.s === "hold" || r.d > 180 ? "rbad" : r.d >= 90 ? "rwarn" : ""}"><td class="l mut">${i + 1}</td><td class="l"><a href="#" class="td-no" data-go="all" data-q="${esc(o.no)}">${esc(o.no)}</a></td><td class="l">${esc(o.acc)}</td><td>${fmt(o.amt)}</td><td>${tod(o.ct, z)}</td><td>${o.pt ? tod(o.pt, z) : "—"}</td><td>${o.ft ? tod(o.ft, z) : "—"}</td><td data-sort="${r.d ?? ""}">${r.d != null ? `<span class="td-du ${l}">${durTxt(r.d)}${r.s === "hold" ? " ⏳" : ""}</span>` : "—"}</td><td class="l">${pushNo(o) ? `<span class="pill ${o.rv >= 2 ? "warnp" : ""}">${pushNo(o)}</span>` : "—"}</td><td class="l">${esc(o.op || "—")}</td><td class="l"><span class="pill ${r.s === "hold" ? "badp" : r.s === "done" ? "on" : ""}">${r.s === "hold" ? "Nhà đang giữ" : r.s === "done" ? "Đã chi" : esc(STN[o.st] || "Không thành công")}</span></td></tr>`; });
  if (!V.length) t += `<tr><td class="l mut" colspan="11">Không có đơn.</td></tr>`;
  if (V.length > 500) t += `<tr><td class="l mut" colspan="11">Đang hiện 500 / ${fmt(V.length)} đơn — tải Excel để xem đủ.</td></tr>`;
  $("td-tbl").innerHTML = t + "</tbody>";
}
$("p-bt3").addEventListener("click", (e) => {
  const c = e.target.closest("[data-td]"); if (c) { st.td = c.dataset.td; st.tdf = "all"; $("td-q").value = ""; render(); $("td-dt").scrollIntoView({ behavior: "smooth", block: "start" }); return; }
  const b = e.target.closest("[data-tdf]"); if (b) { st.tdf = b.dataset.tdf; render(); }
  if (e.target.closest(".td-no")) e.preventDefault();
});
$("td-close").onclick = () => { st.td = ""; render(); window.scrollTo({ top: 0, behavior: "smooth" }); };
$("td-q").addEventListener("input", () => render());
$("td-xls").onclick = async () => {
  if (!TDCUR.length) return;
  const wb = new XLSXW.Book(), ws = wb.sheet("Đơn hàng"), F = "Times New Roman";
  const tz = new Date().getTimezoneOffset() * 60, xdt = (u) => (u ? (u - tz) / 86400 + 25569 : null), xd = (s) => (s == null ? null : Math.round(s) / 86400);
  const H = ["Mã lệnh", "Tài khoản", "Số tiền (₫)", "Khách tạo lệnh", "Đẩy sang nhà", "Nhà chi xong", "Nhà chi mất", "Lần đẩy", "XNK", "Trạng thái"], fm = [null, null, "0", "dd/mm/yyyy hh:mm:ss", "dd/mm/yyyy hh:mm:ss", "dd/mm/yyyy hh:mm:ss", "[h]:mm:ss", null, null, null];
  H.forEach((h, i) => { ws.set(1, i + 1, h, { font: { name: F, size: 10, bold: true, color: "FFFFFF" }, fill: "0B2A55", border: true }); ws.width(i + 1, i === 0 ? 24 : 16); });
  TDCUR.forEach((r, j) => { const o = r.o; [o.no, o.acc, o.amt, xdt(o.ct), xdt(o.pt), xdt(o.ft), xd(r.d), pushNo(o), o.op, r.s === "hold" ? "Nhà đang giữ" : r.s === "done" ? "Đã chi" : STN[o.st] || "Không thành công"].forEach((v, c) => ws.set(j + 2, c + 1, v, { font: { name: F, size: 10 }, border: true, fmt: fm[c] || undefined })); });
  ws.freeze(2, 2);
  const blob = await wb.blob(), now = new Date(), el = document.createElement("a");
  el.href = URL.createObjectURL(blob); el.download = `Toc_do_BT3_${String(st.td).replace(/[^\w-]+/g, "")}_${pad(now.getDate())}-${pad(now.getMonth() + 1)}_${pad(now.getHours())}h${pad(now.getMinutes())}.xlsx`; document.body.appendChild(el); el.click(); el.remove();
};
function renderStaff() { const L = inRange(); $("fk-tbl").innerHTML = staffTable(L, "fk"); $("xnk-tbl").innerHTML = staffTable(L, "xnk"); }
let LCUR = [];
function renderList() {
  const L = inRange(), N = nowU();
  const cnt = { all: L.length }; for (const o of L) { const g = grp(o.st); cnt[g] = (cnt[g] || 0) + 1; }
  $("lst").innerHTML = GRP.map(([k, n, c]) => `<button class="stab ${c}" aria-pressed="${st.lg === k}" data-v="${k}"><small>${n}</small><b>${fmt(cnt[k] || 0)}</b><span>${vnd(L.filter((o) => k === "all" || grp(o.st) === k).reduce((s, o) => s + o.amt, 0))}</span></button>`).join("");
  const hs = [...new Set(L.map(houseOf).filter(Boolean))].sort();
  $("lh").innerHTML = `<button class="chip" aria-pressed="${!st.lh}" data-v="">Tất cả</button>` + hs.map((h) => `<button class="chip" aria-pressed="${st.lh === h}" data-v="${esc(h)}">${esc(h)}</button>`).join("");
  const q = ($("lq").value || "").trim().toLowerCase();
  let list = L.filter((o) => (st.lg === "all" || grp(o.st) === st.lg) && (!st.lh || houseOf(o) === st.lh) && (!q || [o.no, o.acc, o.op, o.lock, fkOf(o).u, o.merch].some((x) => String(x || "").toLowerCase().includes(q))));
  list.sort((a, b) => b.ct - a.ct);
  list = TSort.sort("l-tbl", list, [(o) => o.no, (o) => o.acc, (o) => o.lvl, (o) => o.recv, (o) => o.amt, (o) => o.ct, (o) => (fkOf(o).no ? "không qua fk" : fkOf(o).u), (o) => fkOf(o).t, (o) => o.op, (o) => o.merch, (o) => o.pt, (o) => o.ft, tFK, tXNK, tNHA, tTotal, (o) => STN[o.st] || "", (o) => o.remark]);
  LCUR = list;
  $("l-h").textContent = (GRP.find((x) => x[0] === st.lg) || GRP[0])[1];
  $("l-hint").textContent = rangeLabel(); $("l-sum").textContent = fmt(list.length) + " lệnh · " + vnd(list.reduce((s, o) => s + o.amt, 0));
  const PG = 100, pages = Math.max(1, Math.ceil(list.length / PG)); st.page = Math.min(st.page, pages - 1);
  const z = V0();
  let t = `<thead><tr><th class="l">Số lệnh</th><th class="l">Tài khoản</th><th class="l">Cấp độ</th><th class="l">Người nhận · Ngân hàng</th><th>Số tiền (₫)</th><th>Yêu cầu</th><th class="l">FK</th><th>FK note</th><th class="l">XNK</th><th class="l">Bên thứ 3 · lần đẩy</th><th>Đẩy sang nhà</th><th>Hoàn thành</th><th>FK mất</th><th>XNK đẩy</th><th>Nhà chi</th><th>Tổng</th><th class="l">Tình trạng</th><th class="l">Ghi chú</th></tr></thead><tbody>`;
  for (const o of list.slice(st.page * PG, st.page * PG + PG)) {
    const f = fkOf(o), g = grp(o.st), open = g === "wait" || g === "third";
    t += `<tr class="${g === "fail" ? "rbad" : open && !VIEW && N - o.ct > 600 ? "rwarn" : ""}"><td class="l">${esc(o.no)}</td><td class="name">${esc(o.acc)}<small>${esc(o.vip || "")}${o.nDep ? " · nạp " + o.nDep + " / rút " + o.nWd : ""}</small></td><td class="l mut">${esc(o.lvl || "")}</td><td class="l">${esc(o.recv || "")}<small>${esc(o.bank || "")}</small></td><td>${fmt(o.amt)}</td><td>${tod(o.ct, z)}</td><td class="l">${f.no ? '<span class="mut">Không qua FK</span>' : esc(f.u || "—")}</td><td>${f.t ? tod(f.t, z) : "—"}</td><td class="l">${esc(o.op || "—")}${open && o.lock && o.lock !== o.op ? `<small>khóa: ${esc(o.lock)}</small>` : open && o.lock ? "<small>đang khóa</small>" : ""}</td><td class="l">${esc(o.merch || "—")}${pushNo(o) ? ` <span class="pill ${o.rv >= 2 ? "warnp" : ""}" title="${esc(pushOut(o))}">${pushNo(o)}</span>` : ""}${histTxt(o) ? `<small>${esc(histTxt(o))}</small>` : ""}</td><td>${o.pt ? tod(o.pt, z) : "—"}</td><td>${o.ft ? tod(o.ft, z) : open && !VIEW ? `<span class="warn">chờ ${durTxt(N - o.ct)}</span>` : "—"}</td><td>${durTxt(tFK(o))}</td><td>${durTxt(tXNK(o))}</td><td>${durTxt(tNHA(o))}</td><td>${durTxt(tTotal(o))}</td><td class="l"><span class="pill ${PILL[g]}">${esc(STN[o.st] || "Mã " + o.st)}</span></td><td class="l mut">${esc(o.remark)}</td></tr>`;
  }
  if (!list.length) t += `<tr><td class="l mut" colspan="18">Không có lệnh</td></tr>`;
  $("l-tbl").innerHTML = t + "</tbody>";
  $("l-pg").innerHTML = pages > 1 ? `<button ${st.page ? "" : "disabled"} data-p="${st.page - 1}">‹ Trước</button><span>Trang ${st.page + 1} / ${pages} · 100 lệnh mỗi trang</span><button ${st.page < pages - 1 ? "" : "disabled"} data-p="${st.page + 1}">Sau ›</button>` : "";
  $("cnt-wait").textContent = [...ORD.values()].filter((o) => { const g = grp(o.st); return g === "wait" || g === "third"; }).length;
}
$("lst").onclick = (e) => { const b = e.target.closest(".stab"); if (b) { st.lg = b.dataset.v; st.page = 0; render(); } };
$("lh").onclick = (e) => { const b = e.target.closest(".chip"); if (b) { st.lh = b.dataset.v; st.page = 0; render(); } };
$("lq").addEventListener("input", () => { st.page = 0; render(); });
$("l-pg").onclick = (e) => { const b = e.target.closest("button[data-p]"); if (b) { st.page = +b.dataset.p; render(); } };
document.addEventListener("click", (e) => {
  const t = e.target.closest("[data-gotab]"); if (t) { go(t.dataset.gotab); return; }
  const g = e.target.closest("[data-go]"); if (!g) return;
  st.lg = g.dataset.go; st.lh = g.dataset.h || ""; st.page = 0; $("lq").value = g.dataset.q || "";
  // xem cả ngày để không bị khung giờ che mất lệnh
  if (st.tf !== "day" && g.dataset.q) { st.tf = "day"; segs(); }
  go("list"); window.scrollTo({ top: document.querySelector(".nav").offsetTop - 8, behavior: "smooth" });
});

// ===== Tải Excel để dán vào biểu =====
const XL = [
  ["don", "1 · Tốc độ xuất khoản trung bình → ĐƠN XUẤT KHOẢN", "Số thứ tự · Tốc độ xử lý · Thời gian đăng ký · Thời gian xử lý · Tên người dùng trả · Số tiền xuất khoản · Nhân viên xử lý · Ghi chú", "Chỉ lệnh Đã thanh toán, lọc theo Thời gian yêu cầu. Tốc độ xử lý = thời gian xử lý − thời gian đăng ký."],
  ["tb", "2 · 2026 Tốc độ xuất khoản TB → NƠI DÁN DỮ LIỆU", "Số thứ tự · Hội viên · Thời gian yêu cầu · Thời gian hoạt động", "Chỉ lệnh Đã thanh toán, lọc theo Thời gian yêu cầu."],
  ["fk", "3 · Tốc độ xuất khoản trung bình → DATA FK", "Số lệnh · Thời gian xem xét rủi ro · Nhân viên FK", "Cần lấy cột FK từ file BO xuất (khung bên dưới). Lọc theo thời gian xem xét rủi ro."],
];
function renderXls() {
  { const [a, b] = range(); $("x-hint").textContent = `${(VIEW || DAY).split("-").reverse().join("/")} · ${clock(a)} → ${clock(b)} · luôn lọc theo Thời gian yêu cầu`; }
  const ok = inRangeCT().filter((o) => grp(o.st) === "ok");
  const fkIn = (() => { const [a, b] = range(), z = V0(); return [...SRC().values()].filter((o) => { const f = fkOf(o); return f.t && f.t - z >= a && f.t - z <= b; }); })();
  const n = { don: ok.length, tb: ok.length, fk: fkIn.length, kl: ok.length };
  const nf = ok.filter((o) => fkOf(o).t).length;
  $("fkimp-hint").textContent = `Đã có cột FK cho ${fmt(nf)}/${fmt(ok.filter((o) => !isNoFK(o)).length)} lệnh đã thanh toán qua FK trong khung đang chọn`;
  $("xgrid").innerHTML = XL.map(([k, t, cols, note]) => `<div class="xcard"><h4>${t}</h4><p>Cột: <code>${cols}</code></p><p>${note}</p><button class="bbtn green" data-x="${k}"><span class="ic sm"><svg viewBox="0 0 24 24"><path d="M12 3v12M7 10l5 5 5-5M4 21h16"/></svg></span>Tải (${fmt(n[k])} dòng)</button></div>`).join("");
}
// ===== Lấy cột FK từ file BO xuất (zip có mật khẩu) =====
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function zipCryptoDecrypt(data, pwd) {
  let k0 = 0x12345678, k1 = 0x23456789, k2 = 0x34567890;
  const crc = (c, b) => (CRC[(c ^ b) & 0xff] ^ (c >>> 8)) >>> 0;
  const upd = (b) => { k0 = crc(k0, b); k1 = (k1 + (k0 & 0xff)) >>> 0; k1 = (Math.imul(k1, 134775813) + 1) >>> 0; k2 = crc(k2, k1 >>> 24); };
  for (const b of new TextEncoder().encode(pwd)) upd(b);
  const out = new Uint8Array(data.length);
  for (let i = 0; i < data.length; i++) { const t = (k2 | 2) & 0xffff; const c = data[i] ^ ((Math.imul(t, t ^ 1) >>> 8) & 0xff); out[i] = c; upd(c); }
  return out;
}
async function inflateRaw(u8) { const ds = new DecompressionStream("deflate-raw"); return new Uint8Array(await new Response(new Blob([u8]).stream().pipeThrough(ds)).arrayBuffer()); }
async function unzipFirst(buf, pwd) {
  const u = new Uint8Array(buf), dv = new DataView(buf);
  // tìm thư mục trung tâm để biết kích thước nén (file có thể dùng data descriptor)
  let eocd = -1; for (let i = u.length - 22; i >= Math.max(0, u.length - 70000); i--) if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  if (eocd < 0) throw new Error("File không phải .zip hợp lệ.");
  let p = dv.getUint32(eocd + 16, true); const n = dv.getUint16(eocd + 10, true), out = [];
  for (let j = 0; j < n; j++) {
    const flag = dv.getUint16(p + 8, true), meth = dv.getUint16(p + 10, true), time = dv.getUint16(p + 12, true), crc = dv.getUint32(p + 16, true), csize = dv.getUint32(p + 20, true);
    const fl = dv.getUint16(p + 28, true), xl = dv.getUint16(p + 30, true), cl = dv.getUint16(p + 32, true), off = dv.getUint32(p + 42, true);
    const name = new TextDecoder().decode(u.subarray(p + 46, p + 46 + fl));
    p += 46 + fl + xl + cl;
    const start = off + 30 + dv.getUint16(off + 26, true) + dv.getUint16(off + 28, true);
    let data = u.subarray(start, start + csize);
    if (flag & 1) {
      if (!pwd) throw new Error("File có mật khẩu: hãy dán mật khẩu ở bước 2.");
      const d = zipCryptoDecrypt(data, pwd), chk = flag & 8 ? (time >>> 8) & 0xff : crc >>> 24;
      if (d[11] !== chk) throw new Error("Sai mật khẩu giải nén. Trên BO bấm Kiểm tra → Sao chép đúng dòng file vừa tải.");
      data = d.subarray(12);
    }
    if (meth === 8) data = await inflateRaw(data); else if (meth !== 0) throw new Error("Kiểu nén chưa hỗ trợ (" + meth + ").");
    out.push([name, data]);
  }
  return out;
}
function parseCsv(txt) {
  const rows = []; let row = [], f = "", q = false;
  for (let i = 0; i < txt.length; i++) {
    const c = txt[i];
    if (q) { if (c === '"') { if (txt[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += c; }
    else if (c === '"') q = true; else if (c === ",") { row.push(f); f = ""; } else if (c === "\n") { row.push(f); rows.push(row); row = []; f = ""; } else if (c !== "\r") f += c;
  }
  if (f || row.length) { row.push(f); rows.push(row); }
  return rows;
}
const cleanCell = (v) => String(v ?? "").replace(/^\uFEFF/, "").replace(/^=?"?|"?$/g, "").replace(/^'/, "").trim();
function toUany(v) {
  v = cleanCell(v); if (!v) return 0;
  let m = /^(\d{4})[-/](\d{1,2})[-/](\d{1,2})[ T](\d{1,2}):(\d{2})(?::(\d{2}))?/.exec(v);
  if (m) return Math.floor(new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0)).getTime() / 1000);
  m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})[ T](\d{1,2}):(\d{2})(?::(\d{2}))?/.exec(v);
  if (m) return Math.floor(new Date(+m[3], +m[2] - 1, +m[1], +m[4], +m[5], +(m[6] || 0)).getTime() / 1000);
  return toU(v);
}
// đọc file BO xuất (zip có mật khẩu hoặc csv) -> nạp cột FK
async function importFkBuffer(buf, name, pwd) {
  const files = /\.zip$/i.test(name) || new Uint8Array(buf, 0, 2)[0] === 0x50 ? await unzipFirst(buf, pwd) : [[name, new Uint8Array(buf)]];
  let got = 0, rowsN = 0;
  for (const [fn, data] of files) {
    if (!/\.csv$/i.test(fn)) continue;
    const rows = parseCsv(new TextDecoder("utf-8").decode(data)); if (!rows.length) continue;
    const H = rows[0].map((h) => nk(cleanCell(h)));
    const ci = (...keys) => H.findIndex((h) => keys.some((k) => h === nk(k)));
    const iNo = ci("Số lệnh", "orderNo"), iU = ci("Kiểm toán viên kiểm soát rủi ro", "auditUser"), iT = ci("Thời gian xem xét kiểm soát rủi ro", "auditTime");
    if (iNo < 0 || iU < 0 || iT < 0) throw new Error("File không có cột Số lệnh / Kiểm toán viên kiểm soát rủi ro / Thời gian xem xét kiểm soát rủi ro.");
    for (const r of rows.slice(1)) { const no = cleanCell(r[iNo]), u = cleanCell(r[iU]), t = toUany(r[iT]); rowsN++; if (no && u && t) { FKALL[no] = { u, t }; got++; } }
  }
  await StoreX.kvSet("fkall", FKALL);
  return { got, rowsN };
}
async function importFkFile(file) {
  const msg = (t, k) => { $("fkDropTxt").textContent = t; sysmsg(k ? t : "", k || "info"); };
  try {
    msg("Đang đọc " + file.name + "…");
    const { got, rowsN } = await importFkBuffer(await file.arrayBuffer(), file.name, $("fkPwd").value.trim());
    msg(`Đã lấy cột FK cho ${fmt(got)} lệnh (file có ${fmt(rowsN)} dòng). Bấm tải DATA FK / Khối lượng công việc ở trên.`, "info");
    render();
  } catch (e) { msg("Không đọc được file: " + e.message, "err"); }
}
$("fkFile").onchange = (e) => { const f = e.target.files[0]; if (f) importFkFile(f); e.target.value = ""; };
$("fkDrop").addEventListener("dragover", (e) => { e.preventDefault(); $("fkDrop").classList.add("on"); });
$("fkDrop").addEventListener("dragleave", () => $("fkDrop").classList.remove("on"));
$("fkDrop").addEventListener("drop", (e) => { e.preventDefault(); $("fkDrop").classList.remove("on"); const f = e.dataTransfer.files[0]; if (f) importFkFile(f); });
// mật khẩu: bấm Sao chép trên BO rồi quay lại tool là tự dán
const looksPwd = (t) => /^\S{8,40}$/.test(t || "") && !/^https?:/i.test(t) && !/^\d{15,}$/.test(t);
async function pastePwd(force) { try { const t = (await navigator.clipboard.readText()).trim(); if (force || looksPwd(t)) { if (looksPwd(t)) $("fkPwd").value = t; } } catch (e) {} }
$("fkPaste").onclick = () => pastePwd(true);
window.addEventListener("focus", () => { if (st.tab === "xls") pastePwd(false); });
// ===== Tự lấy FK: xuất báo cáo -> chờ file -> giải mã mật khẩu (AES-ECB, khoá của trang BO) -> tải zip -> đọc =====
const OSS_KEY = "thanks,pig4cloud";
const b64u8 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
function decodePwd(enc) { if (!enc) return ""; try { const p = AESD.decrypt(b64u8(enc), new TextEncoder().encode(OSS_KEY), "ecb"); return p ? new TextDecoder().decode(p) : enc; } catch (e) { return enc; } }
function findRecords(d) { if (Array.isArray(d) && d.length && typeof d[0] === "object" && d[0] && "id" in d[0]) return d; if (d && typeof d === "object") for (const k of ["records", "list", "data", "rows"]) { const r = findRecords(d[k]); if (r) return r; } return null; }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let fkBusy = false;
async function autoFetchFk() {
  if (fkBusy) return; fkBusy = true;
  const btn = $("fkAuto"), say = (t, k) => { $("fkAutoMsg").textContent = t; $("fkAutoMsg").className = k === "err" ? "bad" : k === "ok" ? "ok" : "mut"; };
  btn.disabled = true;
  try {
    const [a, z] = range(), d0 = V0();
    // BO bắt nhập mã bảo mật khi Xuất báo cáo, nên bạn tự bấm Xuất trên BO; tool lấy file mới nhất trong mục Xuất tải xuống
    say("Đang tìm file vừa xuất trong mục Xuất tải xuống…");
    const L = (findRecords(await BO.exportPage()) || []).sort((x, y) => Number(y.id) - Number(x.id));
    const isWd = (r) => /rút|rut|withdraw/i.test(JSON.stringify(r));
    let rec = L.find(isWd) || L[0], urls = null;
    if (!rec) throw new Error("Chưa thấy file nào. Trên BO vào Lệnh rút tiền → Xuất báo cáo (nhập mã bảo mật), rồi bấm lại nút này.");
    for (let i = 0; i < 24 && !urls; i++) { const u = await BO.exportUrls(rec.id).catch(() => null); if (Array.isArray(u) && u.length) urls = u; else { say(`BO đang tạo file… (${i + 1})`); await sleep(5000); } }
    if (!urls) throw new Error("BO chưa tạo xong file, thử lại sau ít phút.");
    say("Đang lấy mật khẩu file…");
    const pwd = decodePwd(await BO.exportPwd(rec.id));
    say("Đang tải file…");
    let buf = null, lastErr = "";
    for (const u of urls) { try { const r = await fetch(u, { cache: "no-store" }); if (r.ok) { buf = await r.arrayBuffer(); break; } lastErr = "HTTP " + r.status; } catch (e) { lastErr = e.message; } }
    if (!buf) throw new Error("Không tải được file (" + lastErr + ").");
    say("Đang giải nén và đọc cột FK…");
    const { got, rowsN } = await importFkBuffer(buf, "export.zip", pwd);
    say(`Xong: đã lấy cột FK cho ${fmt(got)} lệnh (file ${fmt(rowsN)} dòng) lúc ${new Date().toLocaleTimeString("vi-VN", { hour12: false })}.`, "ok");
    render();
  } catch (e) { say("Không lấy được FK: " + e.message, "err"); }
  finally { fkBusy = false; btn.disabled = false; }
}
$("fkAuto").onclick = autoFetchFk;
$("fkExport").onclick = async () => {
  const b = $("fkExport"); b.disabled = true; $("fkExpMsg").textContent = "Đang gửi lệnh xuất…";
  try {
    const [a, z] = range(), d0 = V0();
    await BO.withdrawExport(d0 + a, d0 + z);
    $("fkExpMsg").textContent = `Đã gửi lệnh xuất ${clock(a)} → ${clock(z)}. Vào BO mục Xuất tải xuống để tải file và sao chép mật khẩu.`;
  } catch (e) { $("fkExpMsg").textContent = "Không gửi được lệnh xuất: " + e.message + " · Bạn có thể bấm Xuất báo cáo ngay trên BO."; }
  finally { b.disabled = false; }
};
$("xgrid").addEventListener("click", async (e) => {
  const b = e.target.closest("[data-x]"); if (!b) return;
  if (b.disabled) return; { const t0 = b.innerHTML; b.disabled = true; b.textContent = "Đang đối chiếu BO…"; try { await guardBO(); } finally { b.disabled = false; b.innerHTML = t0; } }
  if (false) {
    // chưa đủ cột FK -> tự lấy từ BO trước rồi mới tải
    const need = inRangeCT().filter((o) => grp(o.st) === "ok" && !isNoFK(o)), has = need.filter((o) => fkOf(o).t).length;
    if (need.length && has < need.length * 0.95) {
      b.disabled = true; const t0 = b.innerHTML; b.textContent = "Đang tự lấy FK từ BO…";
      try { await autoFetchFk(); } finally { b.disabled = false; b.innerHTML = t0; }
      const has2 = need.filter((o) => fkOf(o).t).length;
      if (has2 < need.length * 0.5) { sysmsg("Chưa lấy được cột FK từ BO, file sẽ thiếu FK. Xem dòng báo lỗi ở khung Lấy cột FK bên dưới.", "err"); }
    }
  }
  const k = b.dataset.x, L = inRangeCT().sort((a, b) => a.ct - b.ct), F = "Times New Roman";
  const S = (o) => Object.assign({ font: { name: F, size: 10 } }, o || {});
  const H = S({ font: { name: F, size: 10, bold: true } });
  const tz = new Date().getTimezoneOffset() * 60, xdt = (u) => (u ? (u - tz) / 86400 + 25569 : null), xt = (u) => (u ? ((u - tz) % 86400 + 86400) % 86400 / 86400 : null), xd = (s) => (s == null ? null : Math.round(s) / 86400);
  let head, rows, fm;
  const ok = L.filter((o) => grp(o.st) === "ok");
  if (k === "don") { head = ["Số thứ tự", "Tốc độ xử lý", "Thời gian đăng ký", "Thời gian xử lý", "Tên người dùng trả", "Số tiền xuất khoản", "Nhân viên xử lý", "Ghi chú"]; rows = ok.map((o) => [o.no, xd(tTotal(o)), xt(o.ct), xt(o.ft), o.merch, o.amt, o.op, o.remark]); fm = [null, "hh:mm:ss", "hh:mm:ss", "hh:mm:ss", null, "0", null, null]; }
  else if (k === "fk") { const [ra, rb] = range(), zz = V0(); head = ["Số lệnh", "Thời gian xem xét rủi ro", "Nhân viên FK"]; rows = [...SRC().values()].filter((o) => { const t = fkOf(o).t; return t && t - zz >= ra && t - zz <= rb; }).sort((a, b) => fkOf(a).t - fkOf(b).t).map((o) => [o.no, xdt(fkOf(o).t), fkOf(o).u]); fm = [null, "dd/mm/yyyy hh:mm", null]; }
  else if (k === "kl") { head = ["SỐ LỆNH", "TÀI KHOẢN", "NHÂN VIÊN FK", "THỜI GIAN XEM XÉT RỦI RO", "THỜI GIAN YÊU CẦU", "THỜI GIAN THÀNH CÔNG", "SỐ TIỀN RÚT", "NHÂN VIÊN XNK", "BÊN THỨ 3"]; rows = ok.map((o) => { const f = fkOf(o); return [o.no, o.acc, f.u, xdt(f.t), xdt(o.ct), xdt(o.ft), o.amt, o.op, o.merch]; }); fm = [null, null, null, "dd/mm/yyyy hh:mm", "dd/mm/yyyy hh:mm", "dd/mm/yyyy hh:mm", "0", null, null]; }
  else { head = ["Số thứ tự", "Hội viên", "Thời gian yêu cầu", "Thời gian hoạt động"]; rows = ok.map((o) => [o.no, o.acc, xdt(o.ct), xdt(o.ft)]); fm = [null, null, "yyyy/mm/dd hh:mm:ss", "yyyy/mm/dd hh:mm:ss"]; }
  if (!rows.length) { sysmsg("Không có dòng nào trong khung thời gian này.", "info"); setTimeout(() => sysmsg(""), 3000); return; }
  const wb = new XLSXW.Book(), ws = wb.sheet("Dữ liệu");
  head.forEach((h, i) => { ws.set(1, i + 1, h, H); ws.width(i + 1, i === 0 ? 24 : 18); });
  rows.forEach((r, i) => r.forEach((v, j) => ws.set(i + 2, j + 1, v, S(fm[j] ? { fmt: fm[j] } : {}))));
  ws.freeze(2, 1);
  const blob = await wb.blob(), dk = VIEW || DAY, [a, z] = range();
  const el = document.createElement("a"); el.href = URL.createObjectURL(blob);
  el.download = `XK_${{ don: "DON_XUAT_KHOAN", fk: "DATA_FK", kl: "KHOI_LUONG_CONG_VIEC", tb: "TOC_DO_XK_TB" }[k]}_${dk.slice(8)}-${dk.slice(5, 7)}_${clock(a).slice(0, 5).replace(":", "h")}-${clock(z).slice(0, 5).replace(":", "h")}.xlsx`;
  document.body.appendChild(el); el.click(); el.remove(); setTimeout(() => URL.revokeObjectURL(el.href), 4000);
});
$("lxls").onclick = async () => {
  const bt = $("lxls"); if (bt.disabled) return; { const t0 = bt.innerHTML; bt.disabled = true; bt.textContent = "Đang đối chiếu BO…"; try { await guardBO(); } finally { bt.disabled = false; bt.innerHTML = t0; } }
  if (!LCUR.length) return;
  const wb = new XLSXW.Book(), ws = wb.sheet("Lệnh rút"), F = "Times New Roman";
  const tz = new Date().getTimezoneOffset() * 60, xdt = (u) => (u ? (u - tz) / 86400 + 25569 : null), xd = (s) => (s == null ? null : Math.round(s) / 86400);
  const H = ["Số lệnh", "Tài khoản", "Số tiền (₫)", "Thời gian yêu cầu", "Nhân viên FK", "FK note lúc", "Nhân viên XNK", "Bên thứ 3", "Lần đẩy", "Mã đơn đẩy nhà", "Lịch sử đẩy nhà", "Đẩy sang nhà lúc", "Hoàn thành lúc", "FK mất", "XNK đẩy", "Nhà chi", "Tổng thời gian", "Tình trạng", "Ghi chú"];
  const fm = [null, null, "0", "dd/mm/yyyy hh:mm:ss", null, "dd/mm/yyyy hh:mm:ss", null, null, null, null, null, "dd/mm/yyyy hh:mm:ss", "dd/mm/yyyy hh:mm:ss", "[h]:mm:ss", "[h]:mm:ss", "[h]:mm:ss", "[h]:mm:ss", null, null];
  H.forEach((h, i) => { ws.set(1, i + 1, h, { font: { name: F, size: 10, bold: true, color: "FFFFFF" }, fill: "0B2A55", border: true }); ws.width(i + 1, i === 0 ? 24 : 15); });
  LCUR.forEach((o, r) => { const f = fkOf(o); [o.no, o.acc, o.amt, xdt(o.ct), f.no ? "Không qua FK" : f.u, xdt(f.t), o.op, o.merch, pushNo(o), pushOut(o), histTxt(o), xdt(o.pt), xdt(o.ft), xd(tFK(o)), xd(tXNK(o)), xd(tNHA(o)), xd(tTotal(o)), STN[o.st] || o.st, o.remark].forEach((v, j) => ws.set(r + 2, j + 1, v, { font: { name: F, size: 10 }, border: true, fmt: fm[j] || undefined })); });
  ws.freeze(2, 2);
  const blob = await wb.blob(), now = new Date();
  const el = document.createElement("a"); el.href = URL.createObjectURL(blob); el.download = `Lenh_rut_${st.lg}_${pad(now.getDate())}-${pad(now.getMonth() + 1)}_${pad(now.getHours())}h${pad(now.getMinutes())}.xlsx`; document.body.appendChild(el); el.click(); el.remove();
};

// ===== điều hướng =====
TSort.full("l-tbl", () => { st.page = 0; render(); });
function render() { ({ home: renderHome, house: renderHouse, spd: renderSpd, bt3: renderBt3, staff: renderStaff, list: renderList, xls: renderXls })[st.tab](); if (st.tab !== "list") renderCounts(); }
function renderCounts() { $("cnt-wait").textContent = [...ORD.values()].filter((o) => { const g = grp(o.st); return g === "wait" || g === "third"; }).length; if (st.tab !== "home") $("cnt-alert").textContent = alerts(inRange()).length; }
function go(tab) { st.tab = tab; document.querySelectorAll(".nav button").forEach((b) => b.setAttribute("aria-selected", b.dataset.tab === tab)); document.querySelectorAll(".page").forEach((p) => (p.hidden = p.id !== "p-" + tab)); render(); try { localStorage.setItem("xtab", tab); } catch (e) {} }
document.querySelector(".nav").onclick = (e) => { const b = e.target.closest("button[data-tab]"); if (b) go(b.dataset.tab); };

// ===== đọc BO =====
async function fetchRange(from, to, onProg) {
  const out = [];
  let page = 1, pages = 1, size = 200;
  while (page <= pages) {
    let d;
    if (QT == null) {
      // lần đầu: thử kiểu "Xuất báo cáo" (queryType 5) xem BO có trả cột FK không
      try { d = await BO.withdrawList(from, to, 1, size, 5); const L = (d && d.data) || []; QT = L.some((r) => r.auditUser || r.auditTime) ? 5 : 3; if (QT === 3) d = null; }
      catch (e) { if (e.kind === "login" || e.kind === "net") throw e; QT = 3; }
      chrome.storage.local.set({ wdQT: QT });
    }
    if (!d) d = await BO.withdrawList(from, to, page, size, QT);
    const L = (d && d.data) || [], total = Number(d && d.total) || 0;
    if (page === 1) { if (L.length && L.length < size && total > L.length) size = L.length; pages = Math.max(1, Math.ceil(total / Math.max(1, size))); }
    out.push(...L);
    if (onProg) onProg(page, pages, out.length, total);
    if (!L.length) break;
    page++; d = null;
  }
  return out;
}
async function ingest(raw, map, dk) { const list = raw.map((r) => norm(r, dk)); for (const o of list) { const p = map.get(o.no); if (p && !o.fkU && p.fkU) { o.fkU = p.fkU; o.fkT = p.fkT; } map.set(o.no, o); } await StoreX.putOrders(list).catch(() => {}); return list.length; }
async function fetchNoAudit(from, to, set) {
  try {
    let page = 1, pages = 1;
    while (page <= pages) {
      const d = await BO.withdrawNoAudit(from, to, page, 200), L = (d && d.data) || [], total = Number(d && d.total) || 0;
      if (page === 1) pages = Math.max(1, Math.ceil(total / Math.max(1, L.length || 200)));
      for (const r of L) set.add(String(r.order_no ?? r.orderNo));
      if (!L.length) break; page++;
    }
  } catch (e) { if (e.kind === "login" || e.kind === "net") throw e; }
}
async function loadMerch() { try { MERCH = await BO.withdrawMerchs(); merchAt = Date.now(); merchErr = ""; } catch (e) { if (e.kind === "login" || e.kind === "net") throw e; merchErr = e.message; } }
// hàng chờ XNK (trang Thanh toán tài chính): nạp thẳng vào danh sách để không sót đơn đang chờ chuyển tiền
let CHECKQ = new Set(), checkAt = 0;
// Đồng bộ nhanh tình trạng lệnh đang mở: hỏi BO đúng các lệnh "chờ" (1 trang), lệnh nào tool còn ghi chờ mà BO không còn chờ
// thì đọc lại riêng lệnh đó (theo đúng giây tạo lệnh) → tránh báo "chờ 32 phút" cho lệnh nhà đã chi xong.
let openSynced = false;   // chưa hỏi BO tình trạng lệnh chờ lần nào thì chưa cảnh báo (tránh báo theo dữ liệu cũ đã lưu)
async function pollOpen() {
  try {
    const put = (r) => { const o0 = norm(r, DAY); if (o0.ct < D0) { const o = norm(r, dayKey(new Date((D0 - 3600) * 1000))); o.tail = 1; return o; } return o0; };
    const keep = (o) => { const p = ORD.get(o.no); if (p && !o.fkU && p.fkU) { o.fkU = p.fkU; o.fkT = p.fkT; } ORD.set(o.no, o); return o; };
    const open = new Set(), fresh = [];
    for (let page = 1; page <= 5; page++) {
      const d = await BO.withdrawList(D0 - TAIL_SEC, D0 + 86399, page, 200, QT || 3, 0, "1,101,102,3"), L = (d && d.data) || [];
      for (const r of L) { const o = keep(put(r)); open.add(o.no); if (!o.tail) fresh.push(o); }
      if (L.length < 200) break;
    }
    const stale = [...ORD.values()].filter((o) => { const g = grp(o.st); return (g === "wait" || g === "third") && !open.has(o.no); }).slice(0, 30);
    for (const s of stale) {
      const d = await BO.withdrawList(s.ct - 1, s.ct + 1, 1, 50, QT || 3), L = (d && d.data) || [];
      const r = L.find((x) => String(x.order_no ?? x.orderNo) === s.no);
      if (r) { const o = keep(put(r)); if (!o.tail) fresh.push(o); }
    }
    if (fresh.length) await StoreX.putOrders(fresh).catch(() => {});
    openSynced = true;
    return stale.length;
  } catch (e) { if (e.kind === "login" || e.kind === "net") throw e; return 0; }
}
async function pollCheck() {
  try {
    const q = new Set(), list = [];
    for (let page = 1; page <= 5; page++) {
      const d = await BO.withdrawCheck(page, 200), L = (d && d.data) || [];
      for (const r of L) { const o = norm(r, DAY); if (o.ct >= D0 - 86400) { q.add(o.no); list.push(o); } }
      if (L.length < 200) break;
    }
    for (const o of list) { if (o.ct < D0) continue; const p = ORD.get(o.no); if (p && !o.fkU && p.fkU) { o.fkU = p.fkU; o.fkT = p.fkT; } ORD.set(o.no, o); }
    // đơn trước đây còn chờ nhưng không còn trong hàng chờ -> đọc lại ở lần quét sau (đánh dấu để lấy từ Lệnh rút tiền)
    CHECKQ = q; checkAt = Date.now();
  } catch (e) { if (e.kind === "login" || e.kind === "net") throw e; }
}
// đọc lịch sử đẩy nhà cho lệnh bị đẩy từ 2 lần trở lên (01 → 02 → …)
async function fetchHist() {
  const need = [...ORD.values()].filter((o) => o.rv >= 2 && !(RVH[o.no] && RVH[o.no].length >= o.rv && RVH[o.no].fin)).slice(0, 15);
  let ch = false;
  for (const o of need) {
    try {
      const d = await BO.reviewOrders(o.no), R = (d && d.records) || [];
      const h = R.map((r) => ({ k: String(r.orderNoOut || "").slice(0, Math.max(0, String(r.orderNoOut || "").length - o.no.length)) || "", m: r.merchName || "", s: r.statusName || "", mark: r.mark || "", t: toU(r.operationTime), op: r.operator || "" })).sort((a, b) => a.k.localeCompare(b.k) || a.t - b.t);
      if (h.length) { h.fin = ["ok", "cancel"].includes(grp(o.st)); RVH[o.no] = h; ch = true; }
    } catch (e) { if (e.kind === "login" || e.kind === "net") throw e; }
  }
  if (ch) StoreX.kvSet("rvh", Object.fromEntries(Object.entries(RVH).map(([k, v]) => [k, Object.assign([...v], { fin: v.fin })]))).catch(() => {});
}
async function pollRisk() {
  try {
    const d = await BO.withdrawRisk(1, 200), L = (d && d.data) || [];
    let ch = false;
    for (const r of L) {
      const op = r.operator || r.lockUser || ""; if (!op || op === "system") continue;
      const no = String(r.order_no ?? r.orderNo), t = toU((r.time || {}).apply_time) || nowU();
      const p = FKMAP[no]; if (!p || p.u !== op || t > p.t) { FKMAP[no] = { u: op, t }; ch = true; }
    }
    if (ch) StoreX.kvSet("fk:" + DAY, FKMAP).catch(() => {});
  } catch (e) { if (e.kind === "login" || e.kind === "net") throw e; }
}
let lastMerch = 0, lastWide = 0, fillTo = null, wideRun = false;
async function tick() {
  if (scanning || !licensed || viewLoading) return; scanning = true;
  try {
    const nd = dayKey(new Date()); if (nd !== DAY) { DAY = nd; D0 = dayStartOf(DAY); ORD.clear(); NOFK = new Set(); FKMAP = (await StoreX.kvGet("fk:" + DAY).catch(() => null)) || {}; lastFull = 0; fillTo = null; }
    if (!lastMerch || Date.now() - lastMerch > 120e3) { lastMerch = Date.now(); await loadMerch(); }
    if (QT !== 5) await pollRisk();
    await pollCheck();
    const N = nowU();
    // 1) mỗi lượt (30 giây): đọc lệnh mới 15 phút gần nhất + hỏi BO tình trạng mới nhất của mọi lệnh còn chờ
    const recentFrom = Math.max(D0, N - 900);
    await ingest(await fetchRange(recentFrom, D0 + 86399), ORD, DAY);
    { const n0 = NOFK.size; await fetchNoAudit(recentFrom, D0 + 86399, NOFK); if (NOFK.size !== n0) StoreX.kvSet("nofk:" + DAY, [...NOFK]).catch(() => {}); }
    await pollOpen();
    if (!VIEW) render();
    // 2) nạp dần cả ngày theo từng giờ (lùi từ hiện tại về 00:00), mỗi lượt tối đa ~25 giây → tình trạng lệnh không bị chờ cả lượt tải dài
    if (fillTo == null || fillTo > recentFrom) fillTo = recentFrom;
    if (lastFull && Date.now() - lastWide > 30 * 60e3) { lastWide = Date.now(); fillTo = recentFrom; wideRun = true; }
    const t0 = Date.now();
    while (fillTo > D0 && Date.now() - t0 < 25e3 && !viewLoading) {
      const a = Math.max(D0, fillTo - 3600);
      if (!lastFull && !viewLoading) sysmsg(`Đang tải lệnh rút hôm nay: ${clock(a - D0).slice(0, 5)} → ${clock(fillTo - D0).slice(0, 5)} · đã có ${fmt(ORD.size)} lệnh <span class="prog"><span style="width:${((N - a) / Math.max(1, N - D0) * 100).toFixed(0)}%"></span></span>`, "info");
      await ingest(await fetchRange(a, fillTo), ORD, DAY);
      const n0 = NOFK.size; await fetchNoAudit(a, fillTo, NOFK); if (NOFK.size !== n0) StoreX.kvSet("nofk:" + DAY, [...NOFK]).catch(() => {});
      fillTo = a; if (!VIEW) render();
    }
    if (fillTo <= D0 && (!lastFull || wideRun)) {
      await fetchTail(DAY, ORD, NOFK); StoreX.kvSet("nofk:" + DAY, [...NOFK]).catch(() => {});
      if (!lastFull && !viewLoading) sysmsg("");
      lastFull = Date.now(); if (!wideRun) lastWide = Date.now(); wideRun = false;
    }
    await fetchHist();
    lastScanAt = Date.now();
    $("lastScan").textContent = new Date().toLocaleTimeString("vi-VN", { hour12: false });
    if (!VIEW) { $("readCount").textContent = fmt(ORD.size); $("dayRange").textContent = DAY.slice(8) + "/" + DAY.slice(5, 7) + " 00:00 → " + new Date().toLocaleTimeString("vi-VN", { hour12: false }).slice(0, 5); }
    runState("ok", "ĐANG QUÉT" + (QT === 5 ? "" : " · FK ghi nhận trực tiếp"));
    StoreX.setDay(DAY, { day: DAY, complete: false, at: Date.now() }).catch(() => {});
    render();
  } catch (e) {
    if (e.kind === "perm") { runState("err", "THIẾU QUYỀN BO"); sysmsg(esc(e.message) + ". Tài khoản BO trên Chrome này chưa được cấp quyền xem trang đó. Nhờ quản trị BO cấp quyền, hoặc đăng nhập tài khoản có quyền rồi vào trang Lệnh rút tiền một lần.", "err"); }
    else if (e.kind === "login") { runState("err", "MẤT ĐĂNG NHẬP"); sysmsg("Mất đăng nhập BO. Mở BO trên <b>đúng Chrome đang cài tool</b>, đăng nhập rồi vào trang Lệnh rút tiền một lần — tool sẽ tự quét lại. <span class=\"mut\">Chi tiết: " + esc(e.message) + "</span>", "err"); }
    else { runState("err", "LỖI KẾT NỐI"); sysmsg(esc(e.message) + " · Tool tự thử lại sau 30 giây.", "err"); if (!["net", "rate", "http", "perm"].includes(e.kind)) console.warn(e); }
  } finally { scanning = false; }
}
// Lệnh tạo trước 00:00 nhưng hoàn thành trong ngày (BO lọc "thời gian hoàn thành" vẫn tính) — đọc thêm 4 giờ cuối ngày hôm trước.
// Không ghi vào kho ngày hôm trước để số "theo thời gian yêu cầu" của ngày đó không đổi; lưu riêng ở kv "tail:<ngày>".
const TAIL_SEC = 4 * 3600;
async function fetchTail(dk, map, nofk, from, onProg) {
  const d0 = dayStartOf(dk), pk = dayKey(new Date((d0 - 3600) * 1000));
  const raw = await fetchRange(from ?? d0 - TAIL_SEC, d0 - 1, onProg);
  const isToday = dk === DAY, keep = [];
  for (const r of raw) {
    const o = norm(r, pk), g = grp(o.st), open = g === "wait" || g === "third";
    if ((o.ft && o.ft >= d0 && o.ft <= d0 + 86399) || (isToday && open)) { const p = map.get(o.no); if (p && !o.fkU && p.fkU) { o.fkU = p.fkU; o.fkT = p.fkT; } o.tail = 1; map.set(o.no, o); keep.push(o); }
    else if (map.has(o.no) && map.get(o.no).tail) map.delete(o.no);
  }
  if (nofk) await fetchNoAudit(from ?? d0 - TAIL_SEC, d0 - 1, nofk);
  const all = [...map.values()].filter((o) => o.tail);
  StoreX.kvSet("tail:" + dk, all).catch(() => {});
  return keep.length;
}

// ===== Đối chiếu với BO =====
// BO trả kèm "total" (số lệnh) và "amount" (tổng Số tiền rút, đơn vị nghìn ₫) cho đúng khung thời gian hỏi → so với tool
let reconBusy = false;
async function boSum(a, b, status) { const d = await BO.withdrawList(a, b, 1, 1, 3, 0, status); return { n: Number(d && d.total) || 0, k: Number(String((d && d.amount) ?? 0).replace(/,/g, "")) || 0 }; }
function toolSum(map, a, b, okOnly) { let n = 0, k = 0; for (const o of map.values()) { if (o.tail || !o.ct || o.ct < a || o.ct > b) continue; if (okOnly && grp(o.st) !== "ok") continue; n++; k += o.amt / 1000; } return { n, k }; }
const same = (x, y) => x.n === y.n && Math.abs(x.k - y.k) < 1;
// Đối chiếu khung [a,b] (thời gian yêu cầu) với BO; lệch thì tìm giờ lệch, đọc lại và sửa. Trả kết quả để hiện / ghi chú khi tải file.
async function syncRange(a, b, say) {
  const dk = VIEW || DAY, map = SRC();
  const bAll = await boSum(a, b), tAll = toolSum(map, a, b), bOk = await boSum(a, b, "4,8"), tOk = toolSum(map, a, b, true);
  const res = { bAll, tAll, bOk, tOk, bad: [], diffs: [], ok: same(bAll, tAll) && same(bOk, tOk), fixed: false };
  if (res.ok) return res;
  for (let h0 = a; h0 <= b; h0 += 3600) {
    const h1 = Math.min(h0 + 3599, b);
    say && say(`Đang tìm giờ bị lệch: ${clock(h0 - dayStartOf(dk)).slice(0, 5)}…`);
    const bo = await boSum(h0, h1, "4,8"), bo2 = await boSum(h0, h1);
    if (!same(bo, toolSum(map, h0, h1, true)) || !same(bo2, toolSum(map, h0, h1))) res.bad.push([h0, h1]);
  }
  for (const [h0, h1] of res.bad) {
    say && say(`Đang đọc lại ${clock(h0 - dayStartOf(dk)).slice(0, 5)} từ BO để sửa…`);
    const raw = await fetchRange(h0, h1), fresh = new Map(raw.map((r) => { const o = norm(r, dk); return [o.no, o]; }));
    for (const o of fresh.values()) {
      const p = map.get(o.no);
      if (!p) res.diffs.push([o.no, "Tool thiếu lệnh này", "—", vnd(o.amt) + " · " + (STN[o.st] || o.st)]);
      else if (Math.abs(p.amt - o.amt) >= 1 || grp(p.st) !== grp(o.st)) res.diffs.push([o.no, "Khác số tiền / tình trạng", vnd(p.amt) + " · " + (STN[p.st] || p.st), vnd(o.amt) + " · " + (STN[o.st] || o.st)]);
      if (p && !o.fkU && p.fkU) { o.fkU = p.fkU; o.fkT = p.fkT; }
      map.set(o.no, o);
    }
    const extra = [...map.values()].filter((o) => !o.tail && o.ct >= h0 && o.ct <= h1 && !fresh.has(o.no));
    for (const o of extra) { res.diffs.push([o.no, "BO không còn lệnh này", vnd(o.amt), "—"]); map.delete(o.no); }
    await StoreX.putOrders([...fresh.values()]).catch(() => {}); await StoreX.delOrders(extra.map((o) => o.no)).catch(() => {});
  }
  res.tAll2 = toolSum(map, a, b); res.tOk2 = toolSum(map, a, b, true);
  res.fixed = same(bAll, res.tAll2) && same(bOk, res.tOk2);
  return res;
}
const kvd = (k) => fmt(k * 1000) + " ₫";
function reconHtml(r, label) {
  const row = (n, b, t) => `<tr><td>${n}</td><td>${fmt(b.n)}</td><td>${fmt(t.n)}</td><td>${kvd(b.k)}</td><td>${kvd(t.k)}</td><td class="${same(b, t) ? "okc" : "badc"}">${same(b, t) ? "Khớp" : "Lệch " + fmt(t.n - b.n) + " lệnh · " + kvd(t.k - b.k)}</td></tr>`;
  let h = `<div><b>${label}</b></div><table class="tbl"><tr><th></th><th>BO · lệnh</th><th>Tool · lệnh</th><th>BO · Số tiền rút</th><th>Tool · Số tiền rút</th><th></th></tr>${row("Tất cả lệnh", r.bAll, r.tAll)}${row("Đã thanh toán", r.bOk, r.tOk)}</table>`;
  if (r.ok) return `<div class="okc">Khớp BO từng đồng.</div>` + h;
  h += `<p>Giờ lệch: <b>${r.bad.length ? r.bad.map(([x]) => clock(x - dayStartOf(VIEW || DAY)).slice(0, 5)).join(", ") : "không thấy (BO vừa thay đổi trong lúc đối chiếu)"}</b>. ${r.diffs.length ? `Lệnh khác nhau (${r.diffs.length}):` : ""}</p>`;
  if (r.diffs.length) h += `<table class="tbl"><tr><th>Số lệnh</th><th>Lệch gì</th><th>Tool trước đây</th><th>BO</th></tr>${r.diffs.slice(0, 200).map((d) => `<tr><td class="mono">${esc(d[0])}</td><td>${esc(d[1])}</td><td>${esc(d[2])}</td><td>${esc(d[3])}</td></tr>`).join("")}</table>`;
  h += `<p class="${r.fixed ? "okc" : "badc"}">${r.fixed ? "Đã đồng bộ: tool khớp BO từng đồng (" + fmt(r.tAll2.n) + " lệnh · " + kvd(r.tAll2.k) + ")." : "Sau khi sửa vẫn lệch " + fmt(r.tAll2.n - r.bAll.n) + " lệnh · " + kvd(r.tAll2.k - r.bAll.k) + " — BO đang thay đổi (hôm nay), bấm đối chiếu lại sau ít phút."}</p>`;
  return h;
}
async function recon() {
  if (reconBusy || viewLoading) return; reconBusy = true;
  const btn = $("recon"), out = $("recon-out"), dk = VIEW || DAY, d0 = dayStartOf(dk);
  const end = Math.min(d0 + 86399, VIEW ? d0 + 86399 : nowU() - 120);
  btn.disabled = true;
  for (let i = 0; i < 60 && scanning; i++) await new Promise((r) => setTimeout(r, 500));
  try {
    out.innerHTML = "Đang hỏi BO tổng cả ngày…";
    const r = await syncRange(d0, end, (t) => { out.innerHTML = t; });
    out.innerHTML = reconHtml(r, `${dk.split("-").reverse().join("/")} · 00:00:00 → ${clock(end - d0)} · theo thời gian yêu cầu`); render();
  } catch (e) { out.innerHTML = `<span class="badc">Không đối chiếu được: ${esc(e.message)}</span>`; }
  finally { reconBusy = false; btn.disabled = false; }
}
// Trước khi tải file: đối chiếu đúng khung đang chọn với BO, lệch thì sửa xong mới tải
async function guardBO() {
  if (reconBusy) return null; reconBusy = true;
  const dk = VIEW || DAY, d0 = dayStartOf(dk), [ra, rb] = range();
  let a = d0 + ra, b = Math.min(d0 + rb, VIEW ? d0 + 86399 : nowU() - 120);
  if (st.basis !== "ct") { a = d0; b = Math.min(d0 + 86399, VIEW ? d0 + 86399 : nowU() - 120); }
  for (let i = 0; i < 60 && scanning; i++) await new Promise((r) => setTimeout(r, 500));
  try {
    if (b < a) return null;
    sysmsg("Đang đối chiếu với BO trước khi tải file…", "info");
    const r = await syncRange(a, b, (t) => sysmsg(t, "info"));
    const lbl = `${dk.split("-").reverse().join("/")} · ${clock(a - d0)} → ${clock(b - d0)}`;
    if (r.ok || r.fixed) sysmsg(`Đã đối chiếu BO (${lbl}): <b>khớp từng đồng</b> · ${fmt(r.bAll.n)} lệnh · ${kvd(r.bAll.k)} · đã thanh toán ${fmt(r.bOk.n)} lệnh · ${kvd(r.bOk.k)}${r.diffs.length ? ` · đã sửa ${r.diffs.length} lệnh lệch` : ""}.`, "info");
    else sysmsg(`Đối chiếu BO (${lbl}) còn lệch ${fmt(r.tAll2.n - r.bAll.n)} lệnh · ${kvd(r.tAll2.k - r.bAll.k)} do BO đang thay đổi. File vẫn tải, bấm tải lại sau ít phút để chắc chắn.`, "err");
    $("recon-out").innerHTML = reconHtml(r, lbl); render();
    return r;
  } catch (e) { sysmsg("Không đối chiếu được với BO: " + esc(e.message) + ". File tải theo dữ liệu tool đang có.", "err"); return null; }
  finally { reconBusy = false; }
}
$("recon").onclick = recon;
let viewLoading = null;
async function setView(dk) {
  if (viewLoading) { sysmsg(`Đang tải ngày ${viewLoading.split("-").reverse().join("/")}, chờ tải xong rồi chọn ngày khác.`, "info"); return; }
  if (!dk || dk >= DAY) { VIEW = null; VORD.clear(); $("dayLbl").textContent = "Hôm nay"; $("readCount").textContent = fmt(ORD.size); sysmsg(""); return; }
  const d0 = dayStartOf(dk); VORD.clear();
  const info = await StoreX.getDay(dk).catch(() => null); let list = await StoreX.dayOrders(dk).catch(() => []);
  let tailL = (await StoreX.kvGet("tail:" + dk).catch(() => null)) || [];
  // dữ liệu lưu từ bản cũ có lệnh USDT ghi số USDT thay vì số tiền ₫ → đọc lại 1 lần
  const badAmt = list.some((o) => o.amt > 0 && (o.amt < 1000 || o.amt % 1 !== 0));
  if (!info || !info.complete || !list.length || !info.tail || badAmt) {
    viewLoading = dk; const btn = $("xGo"); btn.disabled = true;
    // chờ lượt quét hôm nay đang chạy xong để BO không bắt chờ chồng lên nhau
    for (let i = 0; i < 60 && scanning; i++) await new Promise((r) => setTimeout(r, 500));
    try {
      const raw = await fetchRange(d0, d0 + 86399, (p, ps, got, total) => { const t = `Đang tải lệnh rút ngày ${dk.split("-").reverse().join("/")}: trang ${p}/${ps} · ${fmt(got)}/${fmt(total)} lệnh · BO bắt chờ vài giây mỗi trang, cả ngày mất khoảng ${Math.ceil(ps * 5 / 60)} phút`; sysmsg(t + ` <span class="prog"><span style="width:${(p / ps * 100).toFixed(0)}%"></span></span>`, "info"); btn.textContent = `Đang tải ${p}/${ps}`; });
      const m = new Map(); await ingest(raw, m, dk);
      await fetchTail(dk, m, null, undefined, (p, ps) => { sysmsg(`Đang đọc thêm lệnh tạo trước 00:00 nhưng hoàn thành trong ngày ${dk.split("-").reverse().join("/")}: trang ${p}/${ps}`, "info"); btn.textContent = `Đọc thêm ${p}/${ps}`; });
      list = [...m.values()]; await StoreX.setDay(dk, { day: dk, complete: true, tail: 1, at: Date.now() });
    } catch (e) { sysmsg("Không tải được ngày này: " + esc(e.message), "err"); return; }
    finally { viewLoading = null; btn.disabled = false; btn.innerHTML = '<span class="ic sm"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg></span>Tìm'; }
  }
  const fk = (await StoreX.kvGet("fk:" + dk).catch(() => null)) || {};
  NOFKV = new Set((await StoreX.kvGet("nofk:" + dk).catch(() => null)) || []);
  if (!NOFKV.size) { await fetchNoAudit(d0 - TAIL_SEC, d0 + 86399, NOFKV).catch(() => {}); StoreX.kvSet("nofk:" + dk, [...NOFKV]).catch(() => {}); }
  if (info && info.complete && info.tail) for (const o of tailL) if (!list.some((x) => x.no === o.no)) list.push(o);
  for (const o of list) { if (!o.fkU && fk[o.no]) { o.fkU = fk[o.no].u; o.fkT = fk[o.no].t; } VORD.set(o.no, o); }
  VIEW = dk; $("dayLbl").textContent = "Ngày"; $("dayRange").textContent = dk.slice(8) + "/" + dk.slice(5, 7) + " 00:00 → 23:59"; $("readCount").textContent = fmt(VORD.size);
  sysmsg(`Đang xem lệnh rút <b>ngày ${dk.split("-").reverse().join("/")}</b> (${fmt(VORD.size)} lệnh).`, "info", ` <button class="btn" id="xReload">Đọc lại ngày này từ BO</button>`);
  const r = $("xReload"); if (r) r.onclick = async () => { await StoreX.setDay(dk, { day: dk, complete: false }); VIEW = null; await setView(dk); render(); };
}
$("btn-ref").onclick = () => { lastMerch = 0; tick(); };
BO.onWait = (sec) => runState("idle", "BO BẮT CHỜ " + sec + "S");

(async function boot() {
  const r = await License.check(await License.saved());
  if (!r.ok) { $("lock").hidden = false; $("lockMsg").textContent = r.reason || "Chưa có key."; runState("idle", "CHƯA CÓ KEY"); return; }
  licensed = true;
  const p = r.info; $("keyChip").textContent = "Key: " + (p.n ? p.n + " · " : "") + (p.e ? "hết " + new Date(p.e * 1000).toLocaleDateString("vi-VN") : "vĩnh viễn");
  QT = (await chrome.storage.local.get("wdQT")).wdQT ?? null;
  FKMAP = (await StoreX.kvGet("fk:" + DAY).catch(() => null)) || {};
  FKALL = (await StoreX.kvGet("fkall").catch(() => null)) || {};
  RVH = (await StoreX.kvGet("rvh").catch(() => null)) || {};
  NOFK = new Set((await StoreX.kvGet("nofk:" + DAY).catch(() => null)) || []);
  const cached = await StoreX.dayOrders(DAY).catch(() => []); for (const o of cached) ORD.set(o.no, o);
  for (const o of (await StoreX.kvGet("tail:" + DAY).catch(() => null)) || []) if (!ORD.has(o.no)) ORD.set(o.no, o);
  StoreX.prune(CFG.KEEP_DAYS).catch(() => {});
  segs();
  let t0 = "home"; try { t0 = localStorage.getItem("xtab") || "home"; } catch (e) {}
  go(t0);
  tick(); setInterval(tick, 30e3);
  setInterval(async () => { const x = await License.check(await License.saved()); if (!x.ok) { licensed = false; $("lock").hidden = false; $("lockMsg").textContent = x.reason; } }, 60e3);
})();
})();
